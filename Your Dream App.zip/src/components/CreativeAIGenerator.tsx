import { useState } from "react";
import { Sparkles, Loader2, Copy, Check } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";

const CONTENT_TYPES = ["Anúncio Meta Ads", "Anúncio Google Ads", "Post orgânico", "E-mail marketing", "Roteiro de vídeo", "Headline LP"];
const TONES = ["Profissional e direto", "Inspirador", "Divertido/casual", "Urgente/promocional", "Educativo", "Empático"];

export function CreativeAIGenerator() {
  const [briefing, setBriefing] = useState("");
  const [contentType, setContentType] = useState(CONTENT_TYPES[0]);
  const [tone, setTone] = useState(TONES[0]);
  const [audience, setAudience] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState("");
  const [copied, setCopied] = useState(false);

  const generate = async () => {
    if (briefing.trim().length < 10) {
      toast({ title: "Briefing muito curto", description: "Descreva melhor o objetivo (mín. 10 caracteres).", variant: "destructive" });
      return;
    }
    setLoading(true); setResult("");
    const { data, error } = await supabase.functions.invoke("generate-creative-content", {
      body: { briefing, contentType, tone, audience },
    });
    setLoading(false);
    if (error) {
      toast({ title: "Erro ao gerar", description: error.message, variant: "destructive" });
      return;
    }
    if (data?.error) {
      toast({ title: "Erro", description: data.error, variant: "destructive" });
      return;
    }
    setResult(data?.content || "");
  };

  const copy = async () => {
    await navigator.clipboard.writeText(result);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
      <div className="space-y-3 bg-card border border-border rounded-xl p-5">
        <div className="flex items-center gap-2 mb-1">
          <Sparkles size={16} className="text-accent" />
          <h3 className="text-sm font-semibold text-foreground">Briefing</h3>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <div>
            <label className="text-[10px] uppercase tracking-wider text-muted-foreground">Tipo</label>
            <select value={contentType} onChange={(e) => setContentType(e.target.value)} className="w-full mt-1 bg-secondary border border-border rounded-lg px-2 py-1.5 text-xs text-foreground">
              {CONTENT_TYPES.map((t) => <option key={t}>{t}</option>)}
            </select>
          </div>
          <div>
            <label className="text-[10px] uppercase tracking-wider text-muted-foreground">Tom</label>
            <select value={tone} onChange={(e) => setTone(e.target.value)} className="w-full mt-1 bg-secondary border border-border rounded-lg px-2 py-1.5 text-xs text-foreground">
              {TONES.map((t) => <option key={t}>{t}</option>)}
            </select>
          </div>
        </div>

        <div>
          <label className="text-[10px] uppercase tracking-wider text-muted-foreground">Público-alvo</label>
          <input value={audience} onChange={(e) => setAudience(e.target.value)} placeholder="Ex: mulheres 25-40, interessadas em estética" className="w-full mt-1 bg-secondary border border-border rounded-lg px-3 py-1.5 text-xs text-foreground" />
        </div>

        <div>
          <label className="text-[10px] uppercase tracking-wider text-muted-foreground">Briefing detalhado</label>
          <textarea value={briefing} onChange={(e) => setBriefing(e.target.value)} rows={8} placeholder="Produto, oferta, objetivo, dor do cliente, diferenciais, gatilhos..." className="w-full mt-1 bg-secondary border border-border rounded-lg px-3 py-2 text-xs text-foreground resize-none" />
        </div>

        <button onClick={generate} disabled={loading} className="w-full bg-accent text-accent-foreground py-2 rounded-lg text-sm font-medium hover:bg-accent/90 transition-colors flex items-center justify-center gap-2 disabled:opacity-50">
          {loading ? <><Loader2 size={14} className="animate-spin" /> Gerando...</> : <><Sparkles size={14} /> Gerar conteúdo</>}
        </button>
      </div>

      <div className="bg-card border border-border rounded-xl p-5 min-h-[400px] flex flex-col">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold text-foreground">Resultado</h3>
          {result && (
            <button onClick={copy} className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1">
              {copied ? <><Check size={12} className="text-metric-green" /> Copiado</> : <><Copy size={12} /> Copiar</>}
            </button>
          )}
        </div>
        {!result && !loading && (
          <div className="flex-1 flex items-center justify-center text-center text-muted-foreground/60 text-xs">
            Preencha o briefing e clique em gerar para receber<br />headlines, copies, descrições e CTAs.
          </div>
        )}
        {loading && (
          <div className="flex-1 flex items-center justify-center"><Loader2 size={20} className="animate-spin text-accent" /></div>
        )}
        {result && (
          <pre className="flex-1 whitespace-pre-wrap text-xs text-foreground font-sans leading-relaxed overflow-y-auto">{result}</pre>
        )}
      </div>
    </div>
  );
}
