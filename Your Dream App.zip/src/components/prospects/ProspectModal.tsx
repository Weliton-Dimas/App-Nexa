import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Prospect, useDeleteProspect, useUpsertProspect } from "@/hooks/useProspects";
import { Trash2 } from "lucide-react";

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  prospect?: Prospect | null;
  defaultStatus?: string;
}

const STATUS_OPTIONS = [
  { value: "novo", label: "Novo" },
  { value: "em_contato", label: "Em Contato" },
  { value: "qualificado", label: "Qualificado" },
  { value: "negociacao", label: "Negociação" },
  { value: "ganho", label: "Ganho" },
  { value: "perdido", label: "Perdido" },
];

const TEMP_OPTIONS = [
  { value: "quente", label: "🔥 Quente" },
  { value: "frio", label: "🧊 Frio" },
  { value: "urgente", label: "⚡ Urgente" },
];

const SOURCE_OPTIONS = ["Indicação", "Google Ads", "Outbound", "LinkedIn", "Instagram", "Site", "Outro"];

const empty = {
  company_name: "",
  contact_name: "",
  contact_role: "",
  email: "",
  phone: "",
  website_url: "",
  instagram_url: "",
  linkedin_url: "",
  status: "novo",
  temperature: "",
  source: "",
  bant_budget: false,
  bant_authority: false,
  bant_need: false,
  bant_timeline: false,
  next_action: "",
  next_action_at: "",
  estimated_value: "",
  notes: "",
};

export default function ProspectModal({ open, onOpenChange, prospect, defaultStatus }: Props) {
  const [form, setForm] = useState<any>(empty);
  const upsert = useUpsertProspect();
  const del = useDeleteProspect();

  useEffect(() => {
    if (prospect) {
      setForm({
        ...empty,
        ...prospect,
        temperature: prospect.temperature ?? "",
        source: prospect.source ?? "",
        next_action: prospect.next_action ?? "",
        next_action_at: prospect.next_action_at ? prospect.next_action_at.slice(0, 16) : "",
        estimated_value: prospect.estimated_value?.toString() ?? "",
        notes: prospect.notes ?? "",
      });
    } else {
      setForm({ ...empty, status: defaultStatus ?? "novo" });
    }
  }, [prospect, defaultStatus, open]);

  const set = (k: string, v: any) => setForm((p: any) => ({ ...p, [k]: v }));

  const handleSave = async () => {
    if (!form.company_name?.trim()) return;
    await upsert.mutateAsync({
      ...(prospect?.id ? { id: prospect.id } : {}),
      company_name: form.company_name,
      contact_name: form.contact_name || null,
      contact_role: form.contact_role || null,
      email: form.email || null,
      phone: form.phone || null,
      website_url: form.website_url || null,
      instagram_url: form.instagram_url || null,
      linkedin_url: form.linkedin_url || null,
      status: form.status,
      temperature: form.temperature || null,
      source: form.source || null,
      bant_budget: !!form.bant_budget,
      bant_authority: !!form.bant_authority,
      bant_need: !!form.bant_need,
      bant_timeline: !!form.bant_timeline,
      next_action: form.next_action || null,
      next_action_at: form.next_action_at ? new Date(form.next_action_at).toISOString() : null,
      estimated_value: form.estimated_value ? Number(form.estimated_value) : null,
      notes: form.notes || null,
    });
    onOpenChange(false);
  };

  const handleDelete = async () => {
    if (!prospect?.id) return;
    if (!confirm("Excluir este prospect?")) return;
    await del.mutateAsync(prospect.id);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{prospect ? "Editar Prospect" : "Novo Prospect"}</DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-2 gap-3">
          <div className="col-span-2">
            <Label>Empresa *</Label>
            <Input value={form.company_name} onChange={(e) => set("company_name", e.target.value)} />
          </div>
          <div>
            <Label>Nome do contato</Label>
            <Input value={form.contact_name} onChange={(e) => set("contact_name", e.target.value)} />
          </div>
          <div>
            <Label>Cargo</Label>
            <Input value={form.contact_role} onChange={(e) => set("contact_role", e.target.value)} />
          </div>
          <div>
            <Label>E-mail</Label>
            <Input type="email" value={form.email} onChange={(e) => set("email", e.target.value)} />
          </div>
          <div>
            <Label>Telefone / WhatsApp</Label>
            <Input value={form.phone} onChange={(e) => set("phone", e.target.value)} />
          </div>
          <div>
            <Label>Site</Label>
            <Input placeholder="https://" value={form.website_url} onChange={(e) => set("website_url", e.target.value)} />
          </div>
          <div>
            <Label>Instagram</Label>
            <Input placeholder="https://instagram.com/..." value={form.instagram_url} onChange={(e) => set("instagram_url", e.target.value)} />
          </div>
          <div className="col-span-2">
            <Label>LinkedIn</Label>
            <Input placeholder="https://linkedin.com/in/..." value={form.linkedin_url} onChange={(e) => set("linkedin_url", e.target.value)} />
          </div>

          <div>
            <Label>Status</Label>
            <Select value={form.status} onValueChange={(v) => set("status", v)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {STATUS_OPTIONS.map((s) => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Temperatura</Label>
            <Select value={form.temperature || "none"} onValueChange={(v) => set("temperature", v === "none" ? "" : v)}>
              <SelectTrigger><SelectValue placeholder="—" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="none">—</SelectItem>
                {TEMP_OPTIONS.map((s) => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Origem</Label>
            <Select value={form.source || "none"} onValueChange={(v) => set("source", v === "none" ? "" : v)}>
              <SelectTrigger><SelectValue placeholder="—" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="none">—</SelectItem>
                {SOURCE_OPTIONS.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Valor estimado (R$)</Label>
            <Input type="number" step="0.01" value={form.estimated_value} onChange={(e) => set("estimated_value", e.target.value)} />
          </div>

          <div className="col-span-2">
            <Label className="mb-2 block">Qualificação BANT</Label>
            <div className="grid grid-cols-4 gap-2">
              {[
                { k: "bant_budget", l: "Budget" },
                { k: "bant_authority", l: "Authority" },
                { k: "bant_need", l: "Need" },
                { k: "bant_timeline", l: "Timeline" },
              ].map((o) => (
                <label key={o.k} className="flex items-center gap-2 text-sm border border-border rounded-md px-2 py-1.5 cursor-pointer">
                  <Checkbox checked={!!form[o.k]} onCheckedChange={(v) => set(o.k, !!v)} />
                  {o.l}
                </label>
              ))}
            </div>
          </div>

          <div className="col-span-2">
            <Label>Próxima ação</Label>
            <Input placeholder="Ex.: Ligar terça às 14h" value={form.next_action} onChange={(e) => set("next_action", e.target.value)} />
          </div>
          <div className="col-span-2">
            <Label>Data/hora da próxima ação</Label>
            <Input type="datetime-local" value={form.next_action_at} onChange={(e) => set("next_action_at", e.target.value)} />
          </div>

          <div className="col-span-2">
            <Label>Notas</Label>
            <Textarea rows={3} value={form.notes} onChange={(e) => set("notes", e.target.value)} />
          </div>
        </div>

        <DialogFooter className="gap-2">
          {prospect && (
            <Button variant="destructive" onClick={handleDelete} className="mr-auto">
              <Trash2 className="w-4 h-4 mr-1" /> Excluir
            </Button>
          )}
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
          <Button onClick={handleSave} disabled={upsert.isPending}>Salvar</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
