import { Prospect } from "@/hooks/useProspects";
import { Globe, Instagram, Linkedin, Phone, MessageCircle, Pencil, Flame, Snowflake, Zap, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useDraggable } from "@dnd-kit/core";

interface Props {
  prospect: Prospect;
  onEdit: () => void;
}

const STATUS_STYLES: Record<string, string> = {
  novo: "bg-[hsl(var(--metric-blue))]/15 text-[hsl(var(--metric-blue))] border-[hsl(var(--metric-blue))]/30",
  em_contato: "bg-accent/15 text-accent border-accent/30",
  qualificado: "bg-[hsl(var(--metric-amber))]/15 text-[hsl(var(--metric-amber))] border-[hsl(var(--metric-amber))]/30",
  negociacao: "bg-primary/15 text-primary border-primary/30",
  ganho: "bg-[hsl(var(--metric-green))]/15 text-[hsl(var(--metric-green))] border-[hsl(var(--metric-green))]/30",
  perdido: "bg-destructive/15 text-destructive border-destructive/30",
};

const STATUS_LABEL: Record<string, string> = {
  novo: "Novo",
  em_contato: "Em Contato",
  qualificado: "Qualificado",
  negociacao: "Negociação",
  ganho: "Ganho",
  perdido: "Perdido",
};

function tempIcon(t: string | null) {
  if (t === "quente") return { Icon: Flame, label: "Quente", cls: "text-destructive" };
  if (t === "frio") return { Icon: Snowflake, label: "Frio", cls: "text-[hsl(var(--metric-blue))]" };
  if (t === "urgente") return { Icon: Zap, label: "Urgente", cls: "text-[hsl(var(--metric-amber))]" };
  return null;
}

function digits(s: string | null) {
  return (s ?? "").replace(/\D/g, "");
}

const stop = (e: React.MouseEvent | React.PointerEvent) => e.stopPropagation();

export default function ProspectCard({ prospect: p, onEdit }: Props) {
  const temp = tempIcon(p.temperature);
  const wa = digits(p.phone);

  const { attributes, listeners, setNodeRef, transform, isDragging } = useDraggable({
    id: p.id,
    data: { status: p.status },
  });

  const style: React.CSSProperties = {
    transform: transform ? `translate3d(${transform.x}px, ${transform.y}px, 0)` : undefined,
    opacity: isDragging ? 0.5 : 1,
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      {...attributes}
      {...listeners}
      onClick={onEdit}
      className="bg-card border border-border rounded-lg p-3 space-y-2.5 hover:border-accent/50 transition-colors cursor-pointer touch-none"
    >
      {/* Header */}
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <h3 className="font-bold text-sm text-foreground truncate">{p.company_name}</h3>
          {(p.contact_name || p.contact_role) && (
            <p className="text-xs text-muted-foreground truncate">
              {[p.contact_name, p.contact_role].filter(Boolean).join(" · ")}
            </p>
          )}
        </div>
        <div className="flex items-center gap-1 shrink-0">
          <span className={`px-1.5 py-0.5 rounded text-[10px] font-semibold border ${STATUS_STYLES[p.status] ?? ""}`}>
            {STATUS_LABEL[p.status] ?? p.status}
          </span>
          <Button
            variant="ghost"
            size="icon"
            className="h-6 w-6"
            onClick={(e) => { e.stopPropagation(); onEdit(); }}
            onPointerDown={stop}
          >
            <Pencil className="w-3 h-3" />
          </Button>
        </div>
      </div>

      {/* Links */}
      <div className="flex flex-wrap gap-1.5 text-xs" onPointerDown={stop} onClick={stop}>
        {p.website_url && (
          <a href={p.website_url} target="_blank" rel="noreferrer" className="flex items-center gap-1 text-muted-foreground hover:text-accent">
            <Globe className="w-3 h-3" /> Site
          </a>
        )}
        {p.instagram_url && (
          <a href={p.instagram_url} target="_blank" rel="noreferrer" className="flex items-center gap-1 text-muted-foreground hover:text-accent">
            <Instagram className="w-3 h-3" /> Instagram
          </a>
        )}
        {p.linkedin_url && (
          <a href={p.linkedin_url} target="_blank" rel="noreferrer" className="flex items-center gap-1 text-muted-foreground hover:text-accent">
            <Linkedin className="w-3 h-3" /> LinkedIn
          </a>
        )}
        {p.phone && (
          <span className="flex items-center gap-1 text-muted-foreground">
            <Phone className="w-3 h-3" /> {p.phone}
          </span>
        )}
        {wa && (
          <a
            href={`https://wa.me/${wa}`}
            target="_blank"
            rel="noreferrer"
            className="flex items-center gap-1 text-[hsl(var(--metric-green))] hover:underline"
          >
            <MessageCircle className="w-3 h-3" /> WhatsApp
          </a>
        )}
      </div>

      {/* BANT */}
      <div className="flex items-center gap-1 text-[10px]">
        <span className="text-muted-foreground mr-1">BANT:</span>
        {[
          { v: p.bant_budget, l: "B" },
          { v: p.bant_authority, l: "A" },
          { v: p.bant_need, l: "N" },
          { v: p.bant_timeline, l: "T" },
        ].map((b, i) => (
          <span
            key={i}
            className={`w-5 h-5 rounded flex items-center justify-center font-bold border ${
              b.v
                ? "bg-[hsl(var(--metric-green))]/15 text-[hsl(var(--metric-green))] border-[hsl(var(--metric-green))]/30"
                : "bg-muted text-muted-foreground border-border"
            }`}
          >
            {b.l}
          </span>
        ))}
      </div>

      {/* Temp + Source */}
      <div className="flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
        {temp && (
          <span className={`flex items-center gap-1 ${temp.cls}`}>
            <temp.Icon className="w-3 h-3" /> {temp.label}
          </span>
        )}
        {p.source && <span>Origem: <span className="text-foreground">{p.source}</span></span>}
      </div>

      {/* Próxima ação */}
      {p.next_action && (
        <div className="flex items-start gap-1.5 text-xs text-foreground border-t border-border pt-2">
          <Clock className="w-3 h-3 mt-0.5 text-accent shrink-0" />
          <span className="truncate">{p.next_action}</span>
        </div>
      )}
    </div>
  );
}
