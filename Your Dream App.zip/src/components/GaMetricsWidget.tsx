import { BarChart3, Users, Target, DollarSign, Clock, TrendingUp, RefreshCw } from "lucide-react";
import { useGaMetrics } from "@/hooks/useGaMetrics";

interface Props {
  clientId: string;
  datePreset?: string;
}

const fmtInt = (v: number) => v.toLocaleString("pt-BR");
const fmtCurrency = (v: number) =>
  v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
const fmtPct = (v: number) => `${(v * 100).toFixed(2)}%`;
const fmtDuration = (s: number) => {
  const m = Math.floor(s / 60);
  const sec = Math.round(s % 60);
  return `${m}m ${sec.toString().padStart(2, "0")}s`;
};

export function GaMetricsWidget({ clientId, datePreset = "last_7d" }: Props) {
  const { data, isLoading, refetch, isFetching } = useGaMetrics(clientId, datePreset);

  const m = data?.data;
  const error = data?.error;

  return (
    <section>
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-[#F9AB00]/15 flex items-center justify-center">
            <BarChart3 size={14} className="text-[#F9AB00]" />
          </div>
          <p className="text-xs font-bold uppercase text-muted-foreground tracking-wider">
            Google Analytics 4
          </p>
        </div>
        <button
          onClick={() => refetch()}
          disabled={isFetching}
          className="w-8 h-8 rounded-lg border border-border/60 flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors disabled:opacity-50"
          title="Atualizar"
        >
          <RefreshCw size={12} className={isFetching ? "animate-spin" : ""} />
        </button>
      </div>

      {isLoading ? (
        <div className="rounded-2xl border border-border/60 bg-card p-8 text-center text-sm text-muted-foreground">
          Carregando GA4...
        </div>
      ) : error ? (
        <div className="rounded-2xl border border-border/60 bg-card p-6 text-sm text-muted-foreground">
          {error}
        </div>
      ) : m ? (
        <>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
            <GaCard icon={Users} label="Usuários ativos" value={fmtInt(m.activeUsers)} />
            <GaCard icon={BarChart3} label="Sessões" value={fmtInt(m.sessions)} />
            <GaCard icon={Target} label="Conversões" value={fmtInt(m.conversions)} />
            <GaCard icon={DollarSign} label="Receita" value={fmtCurrency(m.revenue)} />
            <GaCard icon={TrendingUp} label="Engajamento" value={fmtPct(m.engagementRate)} />
            <GaCard icon={Clock} label="Duração média" value={fmtDuration(m.avgSessionDuration)} />
          </div>

          {m.channels.length > 0 && (
            <div className="mt-4 rounded-2xl border border-border/60 bg-card overflow-hidden">
              <div className="px-4 py-3 border-b border-border/60">
                <p className="text-xs font-semibold text-foreground">Canais (sessões)</p>
              </div>
              <table className="w-full text-xs">
                <thead>
                  <tr className="text-muted-foreground bg-secondary/30">
                    <th className="text-left font-medium py-2 px-4">Canal</th>
                    <th className="text-right font-medium py-2 px-4">Sessões</th>
                    <th className="text-right font-medium py-2 px-4">Conversões</th>
                    <th className="text-right font-medium py-2 px-4">Receita</th>
                  </tr>
                </thead>
                <tbody>
                  {m.channels.map((c) => (
                    <tr key={c.channel} className="border-t border-border/40">
                      <td className="py-2 px-4 text-foreground font-medium">{c.channel}</td>
                      <td className="text-right tabular-nums py-2 px-4 text-foreground">{fmtInt(c.sessions)}</td>
                      <td className="text-right tabular-nums py-2 px-4 text-foreground">{fmtInt(c.conversions)}</td>
                      <td className="text-right tabular-nums py-2 px-4 text-foreground">{fmtCurrency(c.revenue)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </>
      ) : null}
    </section>
  );
}

function GaCard({ icon: Icon, label, value }: { icon: typeof BarChart3; label: string; value: string }) {
  return (
    <div className="rounded-2xl bg-card border border-border/60 p-4">
      <div className="flex items-center gap-1.5 text-muted-foreground mb-2">
        <Icon size={12} />
        <p className="text-[10px] uppercase font-semibold tracking-wider">{label}</p>
      </div>
      <p className="text-xl font-bold text-foreground tabular-nums">{value}</p>
    </div>
  );
}
