import { useState } from "react";
import { FileText, Upload, Link as LinkIcon, Trash2, Download, Loader2 } from "lucide-react";
import { toast } from "sonner";
import {
  useClientContracts,
  useAddContract,
  useDeleteContract,
  getContractSignedUrl,
  type ClientContract,
} from "@/hooks/useClientContracts";

interface Props {
  clientId: string | null;
}

export function ClientContractTab({ clientId }: Props) {
  const { data: contracts = [], isLoading } = useClientContracts(clientId);
  const addMut = useAddContract();
  const delMut = useDeleteContract();

  const [name, setName] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [externalUrl, setExternalUrl] = useState("");
  const [start, setStart] = useState("");
  const [end, setEnd] = useState("");
  const [notes, setNotes] = useState("");

  if (!clientId) {
    return (
      <div className="rounded-lg border border-border bg-secondary/30 p-6 text-center text-sm text-muted-foreground">
        💾 Salve o cliente primeiro para adicionar contratos.
      </div>
    );
  }

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file && !externalUrl) {
      toast.error("Anexe um arquivo ou informe um link externo");
      return;
    }
    try {
      await addMut.mutateAsync({
        client_id: clientId,
        name,
        file,
        external_url: externalUrl,
        contract_start: start || null,
        contract_end: end || null,
        notes,
      });
      toast.success("Contrato adicionado");
      setName("");
      setFile(null);
      setExternalUrl("");
      setStart("");
      setEnd("");
      setNotes("");
    } catch (err: any) {
      toast.error(err?.message ?? "Erro ao salvar");
    }
  };

  const openFile = async (c: ClientContract) => {
    if (c.file_path) {
      const url = await getContractSignedUrl(c.file_path);
      if (url) window.open(url, "_blank");
      else toast.error("Não foi possível gerar link");
    } else if (c.external_url) {
      window.open(c.external_url, "_blank");
    }
  };

  const remove = async (c: ClientContract) => {
    if (!confirm("Excluir este contrato?")) return;
    try {
      await delMut.mutateAsync(c);
      toast.success("Contrato removido");
    } catch (err: any) {
      toast.error(err?.message ?? "Erro");
    }
  };

  return (
    <div className="space-y-4">
      <div className="rounded-lg border border-accent/30 bg-accent/5 p-3 text-xs text-muted-foreground">
        📎 Anexe um arquivo do contrato (PDF, DOCX, imagem) ou cole o link de um documento externo (Google Drive, Notion, etc.).
      </div>

      {/* Lista */}
      <div className="space-y-2">
        {isLoading && <p className="text-xs text-muted-foreground">Carregando...</p>}
        {!isLoading && contracts.length === 0 && (
          <p className="text-xs text-muted-foreground">Nenhum contrato anexado ainda.</p>
        )}
        {contracts.map((c) => (
          <div
            key={c.id}
            className="flex items-center gap-3 rounded-lg border border-border bg-secondary/40 p-3"
          >
            <FileText size={16} className="text-accent shrink-0" />
            <div className="flex-1 min-w-0">
              <p className="text-sm text-foreground font-medium truncate">{c.name}</p>
              <p className="text-[11px] text-muted-foreground">
                {c.contract_start && new Date(c.contract_start + "T00:00:00").toLocaleDateString("pt-BR")}
                {c.contract_start && c.contract_end && " → "}
                {c.contract_end && new Date(c.contract_end + "T00:00:00").toLocaleDateString("pt-BR")}
                {!c.contract_start && !c.contract_end && c.external_url && (
                  <span className="inline-flex items-center gap-1">
                    <LinkIcon size={10} /> Link externo
                  </span>
                )}
              </p>
            </div>
            <button
              type="button"
              onClick={() => openFile(c)}
              className="p-1.5 rounded hover:bg-secondary text-muted-foreground hover:text-foreground"
              title="Abrir"
            >
              <Download size={14} />
            </button>
            <button
              type="button"
              onClick={() => remove(c)}
              className="p-1.5 rounded hover:bg-secondary text-muted-foreground hover:text-destructive"
              title="Excluir"
            >
              <Trash2 size={14} />
            </button>
          </div>
        ))}
      </div>

      {/* Form add */}
      <form onSubmit={submit} className="space-y-3 rounded-lg border border-border p-3">
        <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          Novo contrato
        </p>
        <div>
          <label className="text-xs font-medium text-muted-foreground mb-1 block">Nome</label>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Ex: Contrato 2026 — Mensal"
            className="w-full px-3 py-2 rounded-lg bg-secondary border border-border text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-accent"
          />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-xs font-medium text-muted-foreground mb-1 block">Início</label>
            <input
              type="date"
              value={start}
              onChange={(e) => setStart(e.target.value)}
              className="w-full px-3 py-2 rounded-lg bg-secondary border border-border text-foreground text-sm"
            />
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground mb-1 block">Fim</label>
            <input
              type="date"
              value={end}
              onChange={(e) => setEnd(e.target.value)}
              className="w-full px-3 py-2 rounded-lg bg-secondary border border-border text-foreground text-sm"
            />
          </div>
        </div>
        <div>
          <label className="text-xs font-medium text-muted-foreground mb-1 block">
            Arquivo (PDF, DOCX, imagem)
          </label>
          <label className="flex items-center gap-2 cursor-pointer rounded-lg border border-dashed border-border bg-secondary/40 px-3 py-3 text-xs text-muted-foreground hover:border-accent">
            <Upload size={14} />
            {file ? file.name : "Clique para selecionar um arquivo"}
            <input
              type="file"
              accept=".pdf,.doc,.docx,image/*"
              onChange={(e) => setFile(e.target.files?.[0] ?? null)}
              className="hidden"
            />
          </label>
        </div>
        <div>
          <label className="text-xs font-medium text-muted-foreground mb-1 block">
            Ou link externo
          </label>
          <input
            type="url"
            value={externalUrl}
            onChange={(e) => setExternalUrl(e.target.value)}
            placeholder="https://drive.google.com/..."
            className="w-full px-3 py-2 rounded-lg bg-secondary border border-border text-foreground text-sm"
          />
        </div>
        <div>
          <label className="text-xs font-medium text-muted-foreground mb-1 block">Observações</label>
          <textarea
            rows={2}
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            className="w-full px-3 py-2 rounded-lg bg-secondary border border-border text-foreground text-sm"
          />
        </div>
        <button
          type="submit"
          disabled={addMut.isPending}
          className="w-full py-2 rounded-lg bg-accent text-accent-foreground text-sm font-medium hover:opacity-90 transition disabled:opacity-50 flex items-center justify-center gap-2"
        >
          {addMut.isPending && <Loader2 size={14} className="animate-spin" />}
          Adicionar contrato
        </button>
      </form>
    </div>
  );
}
