import { useRef, useState, useEffect, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Upload, X, User as UserIcon, Crop as CropIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import Cropper, { Area } from "react-easy-crop";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Slider } from "@/components/ui/slider";

interface AvatarUploadProps {
  currentUrl?: string | null;
  onFileSelected: (file: File | null) => void;
  size?: number;
  shape?: "circle" | "square";
  label?: string;
  /** Max file size in MB. Default 5. */
  maxSizeMB?: number;
  /** Accepted MIME types. Default common image types. */
  acceptedTypes?: string[];
}

const DEFAULT_TYPES = ["image/png", "image/jpeg", "image/jpg", "image/webp", "image/gif", "image/svg+xml", "image/x-icon", "image/vnd.microsoft.icon"];

async function getCroppedBlob(imageSrc: string, area: Area, mimeType: string): Promise<Blob> {
  const img = await new Promise<HTMLImageElement>((resolve, reject) => {
    const i = new Image();
    i.crossOrigin = "anonymous";
    i.onload = () => resolve(i);
    i.onerror = reject;
    i.src = imageSrc;
  });
  const canvas = document.createElement("canvas");
  canvas.width = area.width;
  canvas.height = area.height;
  const ctx = canvas.getContext("2d")!;
  ctx.drawImage(img, area.x, area.y, area.width, area.height, 0, 0, area.width, area.height);
  return new Promise((resolve, reject) => {
    canvas.toBlob((b) => (b ? resolve(b) : reject(new Error("Falha ao gerar imagem"))), mimeType, 0.92);
  });
}

export function AvatarUpload({
  currentUrl,
  onFileSelected,
  size = 96,
  shape = "circle",
  label = "Trocar imagem",
  maxSizeMB = 5,
  acceptedTypes = DEFAULT_TYPES,
}: AvatarUploadProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(currentUrl ?? null);
  const [localBlobUrl, setLocalBlobUrl] = useState<string | null>(null);

  // Crop modal state
  const [cropOpen, setCropOpen] = useState(false);
  const [cropSrc, setCropSrc] = useState<string | null>(null);
  const [cropFileName, setCropFileName] = useState<string>("avatar.png");
  const [cropMime, setCropMime] = useState<string>("image/png");
  const [crop, setCrop] = useState({ x: 0, y: 0 });
  const [zoom, setZoom] = useState(1);
  const [croppedAreaPixels, setCroppedAreaPixels] = useState<Area | null>(null);

  useEffect(() => {
    if (!localBlobUrl) setPreviewUrl(currentUrl ?? null);
  }, [currentUrl, localBlobUrl]);

  useEffect(() => {
    return () => {
      if (localBlobUrl) URL.revokeObjectURL(localBlobUrl);
      if (cropSrc) URL.revokeObjectURL(cropSrc);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const validate = (file: File): string | null => {
    if (!acceptedTypes.includes(file.type)) {
      return `Formato não suportado. Use: ${acceptedTypes
        .map((t) => t.split("/")[1])
        .filter((v, i, a) => a.indexOf(v) === i)
        .join(", ")}.`;
    }
    const sizeMB = file.size / (1024 * 1024);
    if (sizeMB > maxSizeMB) {
      return `Arquivo muito grande (${sizeMB.toFixed(1)} MB). Máximo permitido: ${maxSizeMB} MB.`;
    }
    if (file.size === 0) return "Arquivo vazio.";
    return null;
  };

  const setSelectedFile = (file: File | null) => {
    if (localBlobUrl) URL.revokeObjectURL(localBlobUrl);
    if (file) {
      const url = URL.createObjectURL(file);
      setLocalBlobUrl(url);
      setPreviewUrl(url);
    } else {
      setLocalBlobUrl(null);
      setPreviewUrl(currentUrl ?? null);
    }
    onFileSelected(file);
  };

  const handleFileInput = (file: File | null) => {
    if (!file) {
      setSelectedFile(null);
      return;
    }
    const err = validate(file);
    if (err) {
      toast.error("Imagem inválida", { description: err });
      if (inputRef.current) inputRef.current.value = "";
      return;
    }
    setSelectedFile(file);
  };

  const openCropFromCurrent = () => {
    if (!previewUrl) {
      toast.error("Selecione uma imagem antes de recortar.");
      return;
    }
    // Use existing local blob url or remote url; remote needs CORS
    setCropSrc(previewUrl);
    setCropMime(localBlobUrl ? "image/png" : "image/png");
    setCropFileName("avatar-cropped.png");
    setCrop({ x: 0, y: 0 });
    setZoom(1);
    setCropOpen(true);
  };

  const onCropComplete = useCallback((_: Area, areaPixels: Area) => {
    setCroppedAreaPixels(areaPixels);
  }, []);

  const handleApplyCrop = async () => {
    if (!cropSrc || !croppedAreaPixels) return;
    try {
      const blob = await getCroppedBlob(cropSrc, croppedAreaPixels, cropMime);
      const file = new File([blob], cropFileName, { type: cropMime });
      const err = validate(file);
      if (err) {
        toast.error("Imagem inválida", { description: err });
        return;
      }
      setSelectedFile(file);
      setCropOpen(false);
      toast.success("Recorte aplicado");
    } catch (e: any) {
      toast.error("Falha ao recortar", { description: e?.message });
    }
  };

  return (
    <div className="flex items-center gap-4">
      <div
        className={cn(
          "bg-muted flex items-center justify-center overflow-hidden border border-border shrink-0",
          shape === "circle" ? "rounded-full" : "rounded-lg"
        )}
        style={{ width: size, height: size }}
      >
        {previewUrl ? (
          <img src={previewUrl} alt="Preview" className="w-full h-full object-cover" />
        ) : (
          <UserIcon className="text-muted-foreground" size={size * 0.4} />
        )}
      </div>
      <div className="flex flex-col gap-2">
        <input
          ref={inputRef}
          type="file"
          accept={acceptedTypes.join(",")}
          className="hidden"
          onChange={(e) => handleFileInput(e.target.files?.[0] ?? null)}
        />
        <div className="flex flex-wrap gap-2">
          <Button type="button" variant="outline" size="sm" onClick={() => inputRef.current?.click()} className="gap-2">
            <Upload className="h-4 w-4" /> {label}
          </Button>
          {previewUrl && (
            <Button type="button" variant="outline" size="sm" onClick={openCropFromCurrent} className="gap-2">
              <CropIcon className="h-4 w-4" /> Recortar
            </Button>
          )}
          {localBlobUrl && (
            <Button type="button" variant="ghost" size="sm" onClick={() => handleFileInput(null)} className="gap-2 text-muted-foreground">
              <X className="h-4 w-4" /> Cancelar
            </Button>
          )}
        </div>
        <p className="text-[11px] text-muted-foreground">
          Máx {maxSizeMB} MB · {acceptedTypes.map((t) => t.split("/")[1]).filter((v, i, a) => a.indexOf(v) === i).slice(0, 4).join(", ")}
        </p>
      </div>

      <Dialog open={cropOpen} onOpenChange={setCropOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Recortar imagem</DialogTitle>
          </DialogHeader>
          <div className="relative w-full h-72 bg-muted rounded-md overflow-hidden">
            {cropSrc && (
              <Cropper
                image={cropSrc}
                crop={crop}
                zoom={zoom}
                aspect={1}
                cropShape={shape === "circle" ? "round" : "rect"}
                onCropChange={setCrop}
                onZoomChange={setZoom}
                onCropComplete={onCropComplete}
              />
            )}
          </div>
          <div className="space-y-2">
            <p className="text-xs text-muted-foreground">Zoom</p>
            <Slider value={[zoom]} min={1} max={4} step={0.05} onValueChange={(v) => setZoom(v[0])} />
          </div>
          <DialogFooter>
            <Button type="button" variant="ghost" onClick={() => setCropOpen(false)}>Cancelar</Button>
            <Button type="button" onClick={handleApplyCrop}>Aplicar recorte</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
