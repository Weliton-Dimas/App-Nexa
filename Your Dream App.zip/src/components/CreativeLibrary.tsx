import { useEffect, useState } from "react";
import { Upload, Loader2, Trash2, ImageIcon, Video, FileText, Search } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "@/hooks/use-toast";

interface Asset {
  id: string;
  name: string;
  client_id: string | null;
  media_type: string;
  file_url: string;
  thumbnail_url: string | null;
  tags: string[];
  notes: string | null;
  uploaded_by: string;
  created_at: string;
}
interface Client { id: string; name: string }

export function CreativeLibrary() {
  const { user } = useAuth();
  const [assets, setAssets] = useState<Asset[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [search, setSearch] = useState("");
  const [filterClient, setFilterClient] = useState("");

  useEffect(() => { fetchData(); }, []);

  const fetchData = async () => {
    setLoading(true);
    const [a, c] = await Promise.all([
      supabase.from("creative_library").select("*").order("created_at", { ascending: false }),
      supabase.from("clients").select("id, name").order("name"),
    ]);
    setAssets(a.data || []);
    setClients(c.data || []);
    setLoading(false);
  };

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0 || !user) return;
    setUploading(true);
    for (const file of Array.from(files)) {
      const ext = file.name.split(".").pop();
      const path = `${user.id}/${crypto.randomUUID()}.${ext}`;
      const { error: upErr } = await supabase.storage.from("creatives").upload(path, file);
      if (upErr) { toast({ title: "Erro no upload", description: upErr.message, variant: "destructive" }); continue; }
      const { data: pub } = supabase.storage.from("creatives").getPublicUrl(path);
      const mediaType = file.type.startsWith("image/") ? "image" : file.type.startsWith("video/") ? "video" : "file";
      await supabase.from("creative_library").insert({
        name: file.name, file_url: pub.publicUrl, media_type: mediaType, uploaded_by: user.id, client_id: filterClient || null,
      });
    }
    setUploading(false); e.target.value = ""; fetchData();
    toast({ title: "Upload concluído" });
  };

  const remove = async (asset: Asset) => {
    if (!confirm(`Excluir "${asset.name}"?`)) return;
    await supabase.from("creative_library").delete().eq("id", asset.id);
    fetchData();
  };

  const filtered = assets.filter((a) => {
    if (search && !a.name.toLowerCase().includes(search.toLowerCase())) return false;
    if (filterClient && a.client_id !== filterClient) return false;
    return true;
  });

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <div className="relative flex-1 min-w-[200px]">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Buscar por nome..." className="w-full bg-secondary border border-border rounded-lg pl-9 pr-3 py-2 text-sm text-foreground" />
        </div>
        <select value={filterClient} onChange={(e) => setFilterClient(e.target.value)} className="bg-secondary border border-border rounded-lg px-3 py-2 text-sm text-foreground">
          <option value="">Todos os clientes</option>
          {clients.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
        <label className="flex items-center gap-2 bg-accent text-accent-foreground px-4 py-2 rounded-lg text-sm font-medium cursor-pointer hover:bg-accent/90">
          {uploading ? <Loader2 size={14} className="animate-spin" /> : <Upload size={14} />}
          {uploading ? "Enviando..." : "Upload"}
          <input type="file" multiple accept="image/*,video/*" onChange={handleUpload} disabled={uploading} className="hidden" />
        </label>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20"><Loader2 size={20} className="animate-spin text-accent" /></div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16 border border-dashed border-border rounded-xl text-muted-foreground/60 text-sm">
          Nenhum criativo na biblioteca. Faça upload de imagens ou vídeos.
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
          {filtered.map((a) => {
            const client = clients.find((c) => c.id === a.client_id);
            return (
              <div key={a.id} className="group bg-card border border-border rounded-lg overflow-hidden hover:border-accent/40 transition-colors">
                <div className="aspect-square bg-secondary relative">
                  {a.media_type === "image" ? (
                    <img src={a.file_url} alt={a.name} loading="lazy" className="w-full h-full object-cover" />
                  ) : a.media_type === "video" ? (
                    <video src={a.file_url} className="w-full h-full object-cover" />
                  ) : (
                    <div className="flex items-center justify-center h-full"><FileText size={32} className="text-muted-foreground" /></div>
                  )}
                  <div className="absolute top-1.5 left-1.5 bg-background/80 backdrop-blur px-1.5 py-0.5 rounded text-[10px] text-foreground flex items-center gap-1">
                    {a.media_type === "image" ? <ImageIcon size={10} /> : a.media_type === "video" ? <Video size={10} /> : <FileText size={10} />}
                  </div>
                  <button onClick={() => remove(a)} className="absolute top-1.5 right-1.5 bg-background/80 backdrop-blur p-1 rounded text-muted-foreground hover:text-metric-red opacity-0 group-hover:opacity-100 transition-opacity">
                    <Trash2 size={11} />
                  </button>
                </div>
                <div className="p-2">
                  <p className="text-xs text-foreground truncate" title={a.name}>{a.name}</p>
                  {client && <p className="text-[10px] text-muted-foreground truncate">{client.name}</p>}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
