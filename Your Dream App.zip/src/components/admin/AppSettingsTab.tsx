import { useEffect, useState } from "react";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { AvatarUpload } from "@/components/AvatarUpload";
import { useAppSettings, useInvalidateAppSettings } from "@/hooks/useAppSettings";
import { useAuth } from "@/hooks/useAuth";

const schema = z.object({
  app_name: z.string().trim().min(1, "Nome obrigatório").max(60, "Máx. 60 caracteres"),
});

export function AppSettingsTab() {
  const { user } = useAuth();
  const { toast } = useToast();
  const { data: settings, isLoading } = useAppSettings();
  const invalidate = useInvalidateAppSettings();

  const [appName, setAppName] = useState("");
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [faviconFile, setFaviconFile] = useState<File | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (settings) setAppName(settings.app_name);
  }, [settings]);

  const uploadToBranding = async (file: File, prefix: string) => {
    const ext = file.name.split(".").pop() || "png";
    const path = `${prefix}-${Date.now()}.${ext}`;
    const { error } = await supabase.storage
      .from("branding")
      .upload(path, file, { upsert: true, contentType: file.type });
    if (error) throw error;
    return supabase.storage.from("branding").getPublicUrl(path).data.publicUrl;
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !settings) return;

    const parsed = schema.safeParse({ app_name: appName });
    if (!parsed.success) {
      toast({ title: "Dados inválidos", description: parsed.error.errors[0].message, variant: "destructive" });
      return;
    }

    setSaving(true);
    try {
      let logoUrl = settings.logo_url;
      let faviconUrl = settings.favicon_url;

      if (logoFile) logoUrl = await uploadToBranding(logoFile, "logo");
      if (faviconFile) faviconUrl = await uploadToBranding(faviconFile, "favicon");

      const payload = {
        app_name: parsed.data.app_name,
        logo_url: logoUrl,
        favicon_url: faviconUrl,
        updated_by: user.id,
      };

      const { error } = settings.id
        ? await supabase.from("app_settings").update(payload).eq("id", settings.id)
        : await supabase.from("app_settings").insert(payload);
      if (error) throw error;

      setLogoFile(null);
      setFaviconFile(null);
      invalidate();
      toast({ title: "Configurações salvas!" });
    } catch (err: any) {
      toast({ title: "Erro ao salvar", description: err.message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }

  return (
    <Card>
      <CardContent className="pt-6">
        <form onSubmit={handleSave} className="space-y-6 max-w-xl">
          <div className="space-y-2">
            <Label htmlFor="app_name">Nome do App</Label>
            <Input
              id="app_name"
              value={appName}
              onChange={(e) => setAppName(e.target.value)}
              placeholder="Centralize"
              maxLength={60}
              required
            />
            <p className="text-xs text-muted-foreground">Aparece no título da aba e no header.</p>
          </div>

          <div className="space-y-2">
            <Label>Logo do App</Label>
            <AvatarUpload
              currentUrl={settings?.logo_url}
              onFileSelected={setLogoFile}
              size={80}
              shape="square"
              label="Trocar logo"
            />
          </div>

          <div className="space-y-2">
            <Label>Favicon</Label>
            <AvatarUpload
              currentUrl={settings?.favicon_url}
              onFileSelected={setFaviconFile}
              size={48}
              shape="square"
              label="Trocar favicon"
            />
            <p className="text-xs text-muted-foreground">Recomendado: PNG quadrado 64×64 ou maior.</p>
          </div>

          <Button type="submit" disabled={saving} className="w-full sm:w-auto">
            {saving ? "Salvando..." : "Salvar Configurações Globais"}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
