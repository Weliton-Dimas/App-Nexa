import { useState } from "react";
import { X } from "lucide-react";
import { cn } from "@/lib/utils";
import { PAGE_OPTIONS, type ClientFormState } from "@/lib/clientConstants";
import { ClientIntegrationTab } from "./ClientIntegrationTab";
import { ClientContractTab } from "./ClientContractTab";

interface Props {
  form: ClientFormState;
  setForm: (next: ClientFormState) => void;
  editingId: string | null;
  isPending: boolean;
  canFinancial?: boolean;
  onClose: () => void;
  onSubmit: (e: React.FormEvent) => void;
}

export function ClientFormModal({ form, setForm, editingId, isPending, canFinancial, onClose, onSubmit }: Props) {
  const [tab, setTab] = useState<"geral" | "integracao" | "financeiro" | "contrato">("geral");

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm p-4">
      <form
        onSubmit={onSubmit}
        className="bg-card border border-border rounded-2xl w-full max-w-lg shadow-xl max-h-[90vh] flex flex-col"
      >
        <div className="flex items-center justify-between px-6 py-4 border-b border-border">
          <h2 className="text-lg font-semibold text-foreground">
            {editingId ? "Editar Cliente" : "Novo Cliente"}
          </h2>
          <button type="button" onClick={onClose} className="text-muted-foreground hover:text-foreground">
            <X size={18} />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 px-6 pt-3 border-b border-border">
          {[
            { id: "geral", label: "Geral", show: true },
            { id: "integracao", label: "Integração", show: true },
            { id: "contrato", label: "Contrato", show: true },
            { id: "financeiro", label: "Financeiro", show: !!canFinancial },
          ]
            .filter((t) => t.show)
            .map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => setTab(t.id as typeof tab)}
                className={cn(
                  "px-4 py-2 text-sm font-medium rounded-t-lg transition border-b-2",
                  tab === t.id
                    ? "text-foreground border-accent"
                    : "text-muted-foreground border-transparent hover:text-foreground",
                )}
              >
                {t.label}
              </button>
            ))}
        </div>

        <div className="flex-1 overflow-y-auto px-6 py-4 space-y-3">
          {tab === "geral" && (
            <>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Nome</label>
                <input
                  required
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg bg-secondary border border-border text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-accent"
                />
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Website</label>
                <input
                  value={form.website_url}
                  onChange={(e) => setForm({ ...form, website_url: e.target.value })}
                  placeholder="https://..."
                  className="w-full px-3 py-2 rounded-lg bg-secondary border border-border text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-accent"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-medium text-muted-foreground mb-1 block">Status</label>
                  <select
                    value={form.status}
                    onChange={(e) => setForm({ ...form, status: e.target.value as "ativo" | "inativo" })}
                    className="w-full px-3 py-2 rounded-lg bg-secondary border border-border text-foreground text-sm"
                  >
                    <option value="ativo">Ativo</option>
                    <option value="inativo">Inativo</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-medium text-muted-foreground mb-1 block">Classificação</label>
                  <select
                    value={form.rating}
                    onChange={(e) => setForm({ ...form, rating: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-secondary border border-border text-foreground text-sm"
                  >
                    <option value="ruim">Ruim</option>
                    <option value="regular">Regular</option>
                    <option value="bom">Bom</option>
                    <option value="ótimo">Ótimo</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-medium text-muted-foreground mb-1 block">Tipo Pagamento</label>
                  <select
                    value={form.payment_type}
                    onChange={(e) => setForm({ ...form, payment_type: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-secondary border border-border text-foreground text-sm"
                  >
                    <option value="mensal">Mensal</option>
                    <option value="trimestral">Trimestral</option>
                    <option value="semestral">Semestral</option>
                    <option value="anual">Anual</option>
                    <option value="avulso">Avulso</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-medium text-muted-foreground mb-1 block">Pagamento</label>
                  <select
                    value={form.payment_status}
                    onChange={(e) => setForm({ ...form, payment_status: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-secondary border border-border text-foreground text-sm"
                  >
                    <option value="em_dia">Em dia</option>
                    <option value="atrasado">Atrasado</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Fundos</label>
                <select
                  value={form.has_funds ? "sim" : "nao"}
                  onChange={(e) => setForm({ ...form, has_funds: e.target.value === "sim" })}
                  className="w-full px-3 py-2 rounded-lg bg-secondary border border-border text-foreground text-sm"
                >
                  <option value="sim">Disponível</option>
                  <option value="nao">Sem fundos</option>
                </select>
              </div>

              <div className="bg-muted/30 border border-border rounded-lg p-3 text-[11px] text-muted-foreground">
                💡 <strong>Demandas</strong> são calculadas automaticamente a partir das otimizações vencidas (mais de 7 dias) e dos criativos pendentes.
              </div>

              {/* Channels */}
              <div className="pt-2 border-t border-border">
                <p className="text-xs font-semibold text-muted-foreground mb-2 uppercase tracking-wider">Canais de mídia</p>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setForm({ ...form, has_meta: !form.has_meta })}
                    className={cn(
                      "flex-1 flex items-center gap-2 px-3 py-2 rounded-lg border text-sm transition",
                      form.has_meta
                        ? "border-[#1877F2]/50 bg-[#1877F2]/10 text-foreground"
                        : "border-border bg-secondary text-muted-foreground",
                    )}
                  >
                    <span className="w-5 h-5 rounded bg-[#1877F2] text-white text-xs font-bold flex items-center justify-center">f</span>
                    Meta Ads
                  </button>
                  <button
                    type="button"
                    onClick={() => setForm({ ...form, has_google: !form.has_google })}
                    className={cn(
                      "flex-1 flex items-center gap-2 px-3 py-2 rounded-lg border text-sm transition",
                      form.has_google
                        ? "border-[#EA4335]/50 bg-[#EA4335]/10 text-foreground"
                        : "border-border bg-secondary text-muted-foreground",
                    )}
                  >
                    <span className="w-5 h-5 rounded bg-[#EA4335] text-white text-xs font-bold flex items-center justify-center">G</span>
                    Google Ads
                  </button>
                </div>
              </div>

              {/* Visible Pages */}
              <div className="pt-2 border-t border-border">
                <p className="text-xs font-semibold text-muted-foreground mb-2 uppercase tracking-wider">Aparecer em</p>
                <div className="grid grid-cols-2 gap-2">
                  {PAGE_OPTIONS.map((p) => {
                    const checked = form.visible_pages.includes(p.value);
                    return (
                      <button
                        key={p.value}
                        type="button"
                        onClick={() =>
                          setForm({
                            ...form,
                            visible_pages: checked
                              ? form.visible_pages.filter((v) => v !== p.value)
                              : [...form.visible_pages, p.value],
                          })
                        }
                        className={cn(
                          "flex items-center gap-2 px-3 py-2 rounded-lg border text-sm transition text-left",
                          checked
                            ? "border-accent/50 bg-accent/10 text-foreground"
                            : "border-border bg-secondary text-muted-foreground",
                        )}
                      >
                        <span
                          className={cn(
                            "w-4 h-4 rounded border flex items-center justify-center shrink-0",
                            checked ? "bg-accent border-accent" : "border-border",
                          )}
                        >
                          {checked && <span className="text-accent-foreground text-[10px] font-bold">✓</span>}
                        </span>
                        {p.label}
                      </button>
                    );
                  })}
                </div>
              </div>
            </>
          )}
          {tab === "integracao" && <ClientIntegrationTab clientId={editingId} />}
          {tab === "contrato" && <ClientContractTab clientId={editingId} />}
          {tab === "financeiro" && (
            <div className="space-y-4">
              <div className="rounded-lg border border-accent/30 bg-accent/5 p-3 text-xs text-muted-foreground">
                💰 Configure a mensalidade fixa do cliente. Os valores aparecem automaticamente no módulo <strong className="text-foreground">Financeiro</strong>.
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-medium text-muted-foreground mb-1 block">Mensalidade (R$)</label>
                  <input
                    type="text"
                    inputMode="decimal"
                    value={form.monthly_fee === 0 ? "" : String(form.monthly_fee).replace(".", ",")}
                    onChange={(e) => {
                      const raw = e.target.value.replace(/[^\d,.]/g, "").replace(",", ".");
                      // allow empty / partial input like "1500."
                      if (raw === "" || raw === ".") {
                        setForm({ ...form, monthly_fee: 0 });
                        return;
                      }
                      const parsed = parseFloat(raw);
                      setForm({ ...form, monthly_fee: isNaN(parsed) ? 0 : parsed });
                    }}
                    placeholder="Ex: 1500,00"
                    className="w-full px-3 py-2 rounded-lg bg-secondary border border-border text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-accent"
                  />
                </div>
                <div>
                  <label className="text-xs font-medium text-muted-foreground mb-1 block">Dia do vencimento</label>
                  <input
                    type="number"
                    min="1"
                    max="31"
                    value={form.billing_day ?? ""}
                    onChange={(e) =>
                      setForm({
                        ...form,
                        billing_day: e.target.value ? Math.min(31, Math.max(1, Number(e.target.value))) : null,
                      })
                    }
                    placeholder="Ex: 10"
                    className="w-full px-3 py-2 rounded-lg bg-secondary border border-border text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-accent"
                  />
                </div>
              </div>
              <div className="rounded-lg border border-border bg-secondary/30 p-4 text-center">
                <p className="text-xs text-muted-foreground mb-1">Mensalidade</p>
                <p className="text-2xl font-bold text-foreground tabular-nums">
                  {Number(form.monthly_fee).toLocaleString("pt-BR", {
                    style: "currency",
                    currency: "BRL",
                  })}
                </p>
              </div>
            </div>
          )}
        </div>

        <div className="px-6 py-4 border-t border-border">
          <button
            type="submit"
            disabled={isPending}
            className="w-full py-2.5 rounded-lg bg-accent text-accent-foreground text-sm font-medium hover:opacity-90 transition disabled:opacity-50"
          >
            {isPending ? "Salvando..." : editingId ? "Salvar Alterações" : "Adicionar Cliente"}
          </button>
        </div>
      </form>
    </div>
  );
}
