import { Navigate, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { AVAILABLE_PAGES } from "@/pages/AdminUsersPage";
import { useUserPermissions } from "@/hooks/useUserPermissions";
import { Button } from "@/components/ui/button";
import { LogOut } from "lucide-react";

const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  const { user, loading, signOut } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const { data: perms, isLoading: permsLoading } = useUserPermissions();

  if (loading || (user && permsLoading)) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/auth" replace />;
  }

  if (perms?.isAdmin) {
    return <>{children}</>;
  }

  const pathname = location.pathname.replace(/\/$/, "") || "/";
  const dynamicRouteSlug = pathname.startsWith("/clients/") ? "analysis-dashboard" : null;
  const currentPage = dynamicRouteSlug
    ? AVAILABLE_PAGES.find((p) => p.slug === dynamicRouteSlug)
    : AVAILABLE_PAGES.find((p) => {
        if (p.path === "/") return pathname === "/";
        return pathname === p.path || pathname.startsWith(`${p.path}/`);
      });

  const hasAccess = !!currentPage && !!perms?.allowedSlugs.has(currentPage.slug);

  if (!hasAccess) {
    console.warn("[ProtectedRoute] Access denied", {
      pathname: location.pathname,
      normalizedPathname: pathname,
      matchedSlug: currentPage?.slug ?? null,
      allowedSlugs: perms ? Array.from(perms.allowedSlugs) : [],
      isAdmin: perms?.isAdmin,
    });
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-6">
        <div className="text-center space-y-4 max-w-md">
          <h1 className="text-2xl font-bold text-foreground">Acesso Negado</h1>
          <p className="text-muted-foreground">Você não tem permissão para acessar esta página.</p>
          <p className="text-sm text-muted-foreground">
            Se você acabou de trocar de conta ou perdeu acesso, saia e entre novamente.
          </p>
          <div className="flex flex-col sm:flex-row gap-2 justify-center pt-2">
            <Button
              variant="default"
              onClick={async () => {
                await signOut();
                navigate("/auth", { replace: true });
              }}
            >
              <LogOut className="h-4 w-4 mr-2" />
              Sair e entrar novamente
            </Button>
            <Button variant="outline" onClick={() => navigate("/", { replace: true })}>
              Voltar para o início
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return <>{children}</>;
};

export default ProtectedRoute;
