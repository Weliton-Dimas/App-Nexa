import { useEffect, useState, useCallback } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Loader2, CheckCircle2, XCircle, Save, Building2, Unlink } from "lucide-react";
import { cn } from "@/lib/utils";

type Provider = "meta" | "google" | "google_analytics" | "magazord";

interface AvailableAccount { account_id: string; name: string }
interface IntegrationRow {
  provider: Provider;
  status: "connected" | "disconnected" | "expired" | "error" | "pending_account_selection";
  account_id: string | null;
  account_name: string | null;
}

interface Props { clientId: string | null }

const PROVIDERS: Array<{ id: Provider; label: string; color: string; initial: string; selectLabel: string }> = [
  { id: "meta",             label: "Meta Ads",         color: "#1877F2", initial: "f", selectLabel: "ad account" },
  { id: "google",           label: "Google Ads",       color: "#EA4335", initial: "G", selectLabel: "Customer ID" },
  { id: "google_analytics", label: "Google Analytics", color: "#F9AB00", initial: "A", selectLabel: "propriedade GA4" },
  { id: "magazord",         label: "Magazord",         color: "#7C3AED", initial: "M", selectLabel: "loja" },
];

const FN_BASE = "https://xfmudoopaspsbdrceqdl.supabase.co/functions/v1";

export function ClientIntegrationTab({ clientId }: Props) {
  const [rows, setRows] = useState<IntegrationRow[]>([]);
  const [available, setAvailable] = useState<Record<Provider, AvailableAccount[]>>({ meta: [], google: [], google_analytics: [], magazord: [] });
  const [picked, setPicked] = useState<Record<Provider, string>>({ meta: "", google: "", google_analytics: "", magazord: "" });
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<Provider | null>(null);

  const fetchAll = useCallback(async () => {
    if (!clientId) { setRows([]); setLoading(false); return; }
    setLoading(true);
    const { data: sess } = await supabase.auth.getSession();
    const token = sess.session?.access_token;
    if (!token) { setLoading(false); return; }

    const [rowsRes, ...wsResults] = await Promise.all([
      supabase.from("client_integrations").select("provider, status, account_id, account_name").eq("client_id", clientId),
      ...(["meta", "google", "google_analytics"] as const).map(async (p) => {
        const r = await fetch(`${FN_BASE}/workspace-list-accounts?provider=${p}`, { headers: { Authorization: `Bearer ${token}` } });
        const j = await r.json();
        return [p, (j.integration?.available_accounts ?? []) as AvailableAccount[]] as const;
      }),
      (async () => {
        const r = await fetch(`${FN_BASE}/workspace-magazord-stores`, { headers: { Authorization: `Bearer ${token}` } });
        const j = await r.json();
        const stores = (j.stores ?? []) as Array<{ id: string; label: string }>;
        return ["magazord", stores.map((s) => ({ account_id: s.id, name: s.label }))] as const;
      })(),
    ]);

    const next: Record<Provider, AvailableAccount[]> = { meta: [], google: [], google_analytics: [], magazord: [] };
    for (const [k, v] of wsResults) next[k as Provider] = v as AvailableAccount[];
    setAvailable(next);

    const r = (rowsRes.data ?? []) as IntegrationRow[];
    setRows(r);
    const p: Record<Provider, string> = { meta: "", google: "", google_analytics: "", magazord: "" };
    for (const row of r) if (row.account_id) p[row.provider] = row.account_id;
    setPicked(p);
    setLoading(false);
  }, [clientId]);

  useEffect(() => { fetchAll(); }, [fetchAll]);

  const link = async (provider: Provider) => {
    if (!clientId || !picked[provider]) return;
    setBusy(provider);
    const { data, error } = await supabase.functions.invoke("client-link-account", {
      body: { client_id: clientId, provider, account_id: picked[provider] },
    });
    setBusy(null);
    if (error || (data as { error?: string })?.error) {
      toast.error((data as { error?: string })?.error || error?.message || "Falha"); return;
    }
    toast.success("Vinculado");
    fetchAll();
  };

  const disconnect = async (provider: Provider) => {
    if (!clientId) return;
    if (!confirm(`Desvincular ${PROVIDERS.find(p => p.id === provider)?.label}?`)) return;
    setBusy(provider);
    await supabase.functions.invoke("disconnect-integration", { body: { client_id: clientId, provider } });
    setBusy(null);
    toast.success("Desvinculado");
    fetchAll();
  };

  if (!clientId) {
    return <div className="rounded-xl border border-dashed border-border p-6 text-center text-sm text-muted-foreground">Salve o cliente primeiro para configurar integrações.</div>;
  }
  if (loading) {
    return <div className="flex justify-center py-8"><Loader2 size={20} className="animate-spin text-muted-foreground" /></div>;
  }

  return (
    <div className="space-y-3">
      <p className="text-xs text-muted-foreground">
        Selecione qual conta deste workspace usar neste cliente.{" "}
        <Link to="/integracoes" className="text-accent hover:underline inline-flex items-center gap-1"><Building2 size={11}/> Gerenciar integrações</Link>
      </p>

      {PROVIDERS.map((p) => {
        const row = rows.find((r) => r.provider === p.id);
        const isConnected = row?.status === "connected";
        const accounts = available[p.id];
        const isBusy = busy === p.id;
        const dirty = picked[p.id] && picked[p.id] !== (row?.account_id ?? "");

        return (
          <div key={p.id} className="rounded-xl border border-border bg-secondary/30 p-4 space-y-3">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                <span className="w-9 h-9 rounded-lg text-white text-sm font-bold flex items-center justify-center shrink-0" style={{ backgroundColor: p.color }}>{p.initial}</span>
                <div>
                  <div className="text-sm font-semibold text-foreground">{p.label}</div>
                  <div className="text-[11px] text-muted-foreground">Selecione a {p.selectLabel} deste cliente.</div>
                </div>
              </div>
              <span className={cn(
                "text-[10px] px-2 py-1 rounded-full border flex items-center gap-1 whitespace-nowrap shrink-0",
                isConnected ? "bg-primary/15 text-primary border-primary/30" : "bg-destructive/10 text-destructive border-destructive/30",
              )}>
                {isConnected ? <CheckCircle2 size={10} /> : <XCircle size={10} />}
                {isConnected ? "Vinculado" : "Não vinculado"}
              </span>
            </div>

            {accounts.length === 0 ? (
              <div className="rounded-lg bg-background/40 border border-border/60 px-3 py-3 text-xs space-y-1">
                <div className="text-muted-foreground">{p.label} ainda não foi conectado no workspace.</div>
                <Link to="/integracoes" className="text-accent hover:underline inline-flex items-center gap-1.5"><Building2 size={11}/> Ir para Integrações</Link>
              </div>
            ) : (
              <div className="flex gap-2">
                <select
                  value={picked[p.id]}
                  onChange={(e) => setPicked((s) => ({ ...s, [p.id]: e.target.value }))}
                  className="flex-1 px-3 py-2 rounded-lg bg-background/60 border border-border text-xs text-foreground focus:outline-none focus:ring-1 focus:ring-primary"
                >
                  <option value="">— Selecione —</option>
                  {accounts.map((a) => (
                    <option key={a.account_id} value={a.account_id}>{a.name}{p.id !== "magazord" ? ` (${a.account_id})` : ""}</option>
                  ))}
                </select>
                <button type="button" onClick={() => link(p.id)} disabled={!picked[p.id] || isBusy || !dirty}
                  className="px-3 py-2 rounded-lg bg-accent/15 text-accent text-xs font-medium hover:bg-accent/25 transition flex items-center gap-1.5 disabled:opacity-40">
                  {isBusy ? <Loader2 size={12} className="animate-spin"/> : <Save size={12}/>} Salvar
                </button>
              </div>
            )}

            {isConnected && (
              <button type="button" onClick={() => disconnect(p.id)} disabled={isBusy}
                className="w-full py-1.5 rounded-lg bg-destructive/10 text-destructive text-[11px] hover:bg-destructive/20 transition flex items-center justify-center gap-1.5 disabled:opacity-50">
                <Unlink size={11}/> Desvincular
              </button>
            )}
          </div>
        );
      })}
    </div>
  );
}
