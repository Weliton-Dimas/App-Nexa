import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Building2, Check, ChevronDown, Loader2, Link as LinkIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Link } from "react-router-dom";

interface AvailableAccount { account_id: string; name: string }
interface WorkspaceMeta {
  status: string;
  business_name: string | null;
  available_accounts: AvailableAccount[];
}

interface Props { clientId: string }

export function MetaAccountPicker({ clientId }: Props) {
  const [ws, setWs] = useState<WorkspaceMeta | null>(null);
  const [loading, setLoading] = useState(true);
  const [linked, setLinked] = useState<{ account_id: string | null; account_name: string | null } | null>(null);
  const [saving, setSaving] = useState<string | null>(null);
  const [open, setOpen] = useState(false);
  const [filter, setFilter] = useState("");

  const load = useCallback(async () => {
    setLoading(true);
    const { data: sess } = await supabase.auth.getSession();
    const token = sess.session?.access_token;
    if (!token) { setLoading(false); return; }
    try {
      const [wsRes, ciRes] = await Promise.all([
        fetch(`https://xfmudoopaspsbdrceqdl.supabase.co/functions/v1/workspace-list-accounts?provider=meta`, {
          headers: { Authorization: `Bearer ${token}` },
        }).then((r) => r.json()),
        supabase.from("client_integrations").select("account_id, account_name").eq("client_id", clientId).eq("provider", "meta").maybeSingle(),
      ]);
      setWs(wsRes.integration ?? null);
      setLinked(ciRes.data ?? null);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [clientId]);

  useEffect(() => { load(); }, [load]);

  const pick = async (acc: AvailableAccount) => {
    setSaving(acc.account_id);
    const { data, error } = await supabase.functions.invoke("client-link-account", {
      body: { client_id: clientId, provider: "meta", account_id: acc.account_id },
    });
    setSaving(null);
    if (error || (data as { error?: string })?.error) {
      toast.error((data as { error?: string })?.error || error?.message || "Falha ao salvar");
      return;
    }
    toast.success(`Conta vinculada: ${acc.name}`);
    setLinked({ account_id: acc.account_id, account_name: acc.name });
    setOpen(false);
  };

  if (loading) {
    return (
      <button className="flex items-center gap-2 px-3 py-2 rounded-xl border border-border/60 text-sm text-muted-foreground" disabled>
        <Loader2 size={14} className="animate-spin" />
        <span className="text-xs">Meta</span>
      </button>
    );
  }

  if (!ws || ws.status !== "connected") {
    return (
      <Link
        to="/integracoes"
        className="flex items-center gap-2 px-3 py-2 rounded-xl border border-[hsl(var(--metric-amber))]/40 bg-[hsl(var(--metric-amber))]/10 text-[hsl(var(--metric-amber))] text-xs hover:bg-[hsl(var(--metric-amber))]/20 transition-colors"
        title="Conecte a Business Manager em Integrações"
      >
        <LinkIcon size={12} />
        <span>Conectar Meta</span>
      </Link>
    );
  }

  const accounts = ws.available_accounts ?? [];
  const filtered = filter
    ? accounts.filter((a) => a.name.toLowerCase().includes(filter.toLowerCase()) || a.account_id.includes(filter))
    : accounts;

  const label = linked?.account_name ?? linked?.account_id ?? "Selecionar conta Meta";

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <button
          className={cn(
            "flex items-center gap-2 px-3 py-2 rounded-xl border text-sm transition-colors max-w-[260px]",
            linked?.account_id
              ? "border-primary/40 bg-primary/10 text-primary hover:bg-primary/20"
              : "border-border/60 text-foreground hover:bg-secondary",
          )}
          title={ws.business_name ? `BM: ${ws.business_name}` : undefined}
        >
          <Building2 size={14} className="shrink-0" />
          <span className="truncate text-xs">{label}</span>
          <ChevronDown size={12} className="opacity-60 shrink-0" />
        </button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-[340px] p-0">
        <div className="px-3 py-2 border-b border-border/60">
          <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Business Manager</div>
          <div className="text-xs text-foreground font-medium truncate">{ws.business_name ?? "—"}</div>
        </div>
        <div className="p-2 border-b border-border/60">
          <input
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            placeholder="Buscar conta..."
            className="w-full px-2 py-1.5 rounded-md bg-background border border-border text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary"
          />
        </div>
        <div className="max-h-[320px] overflow-y-auto py-1">
          {filtered.length === 0 ? (
            <div className="px-3 py-6 text-center text-xs text-muted-foreground">Nenhuma conta encontrada</div>
          ) : filtered.map((a) => {
            const isLinked = linked?.account_id === a.account_id;
            const isSaving = saving === a.account_id;
            return (
              <button
                key={a.account_id}
                onClick={() => !isLinked && pick(a)}
                disabled={isSaving}
                className={cn(
                  "w-full flex items-center gap-2 px-3 py-2 text-left text-xs hover:bg-secondary transition-colors",
                  isLinked && "bg-primary/10",
                )}
              >
                <span className="flex-1 min-w-0">
                  <span className="block truncate text-foreground">{a.name}</span>
                  <span className="block truncate text-[10px] text-muted-foreground font-mono">{a.account_id}</span>
                </span>
                {isSaving ? <Loader2 size={12} className="animate-spin text-muted-foreground" />
                  : isLinked ? <Check size={14} className="text-primary" /> : null}
              </button>
            );
          })}
        </div>
      </PopoverContent>
    </Popover>
  );
}
