import { useState, useEffect, useRef } from "react";
import { X, Plus, Trash2, Link as LinkIcon, CheckSquare, ImagePlus, Paperclip, Upload, FileText, Download } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "@/hooks/use-toast";
import { z } from "zod";

const DEMAND_TYPES = [
  "Anúncio estático",
  "Anúncio em vídeo",
  "Carrossel",
  "Stories/Reels",
  "Banner/Display",
  "Landing Page",
  "E-mail marketing",
  "Post orgânico",
  "Roteiro UGC",
  "Outro",
];

const PRIORITIES = [
  { value: "baixa", label: "Baixa" },
  { value: "media", label: "Média" },
  { value: "alta", label: "Alta" },
  { value: "urgente", label: "Urgente" },
];

const STATUS_OPTIONS = [
  { value: "backlog", label: "Backlog" },
  { value: "em_producao", label: "Em Produção" },
  { value: "em_revisao", label: "Em Revisão" },
  { value: "concluido", label: "Concluído" },
];

interface ChecklistItem { id: string; text: string; done: boolean }
interface FinalAsset { url: string; name: string; type: string; size: number; uploaded_at: string }
interface Client { id: string; name: string }
interface Profile { user_id: string; display_name: string | null }

interface Props {
  open: boolean;
  onClose: () => void;
  onSaved: () => void;
  initialDemand?: any;
}

const schema = z.object({
  type: z.string().min(1, "Selecione um tipo"),
  element: z.string().trim().min(2, "Descreva o elemento").max(200),
  client_id: z.string().uuid("Selecione um cliente"),
  briefing: z.string().max(2000).optional(),
});

const MAX_BRIEFING_IMAGES = 10;
const MAX_IMG_BYTES = 5 * 1024 * 1024;
const MAX_FINAL_BYTES = 50 * 1024 * 1024;

function formatBytes(b: number) {
  if (b < 1024) return `${b} B`;
  if (b < 1024 * 1024) return `${(b / 1024).toFixed(1)} KB`;
  return `${(b / 1024 / 1024).toFixed(1)} MB`;
}

export function CreativeDemandModal({ open, onClose, onSaved, initialDemand }: Props) {
  const { user } = useAuth();
  const [clients, setClients] = useState<Client[]>([]);
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [saving, setSaving] = useState(false);
  const [uploadingBriefing, setUploadingBriefing] = useState(false);
  const [uploadingFinal, setUploadingFinal] = useState(false);

  const [type, setType] = useState("");
  const [element, setElement] = useState("");
  const [clientId, setClientId] = useState("");
  const [assigneeId, setAssigneeId] = useState("");
  const [managerId, setManagerId] = useState("");
  const [priority, setPriority] = useState("media");
  const [status, setStatus] = useState("backlog");
  const [deadline, setDeadline] = useState("");
  const [briefing, setBriefing] = useState("");
  const [briefingImages, setBriefingImages] = useState<string[]>([]);
  const [refLinks, setRefLinks] = useState<string[]>([]);
  const [newLink, setNewLink] = useState("");
  const [checklist, setChecklist] = useState<ChecklistItem[]>([]);
  const [newChecklistItem, setNewChecklistItem] = useState("");
  const [finalAssets, setFinalAssets] = useState<FinalAsset[]>([]);
  const [finalNotes, setFinalNotes] = useState("");

  const briefingFileRef = useRef<HTMLInputElement>(null);
  const finalFileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!open) return;
    fetchClients();
    fetchProfiles();
    if (initialDemand) {
      setType(initialDemand.type || "");
      setElement(initialDemand.element || "");
      setClientId(initialDemand.client_id || "");
      setAssigneeId(initialDemand.assignee_id || "");
      setManagerId(initialDemand.manager_id || "");
      setPriority(initialDemand.priority || "media");
      setStatus(initialDemand.status || "backlog");
      setDeadline(initialDemand.deadline || "");
      setBriefing(initialDemand.briefing || "");
      setBriefingImages(initialDemand.briefing_images || []);
      setRefLinks(initialDemand.reference_links || []);
      setChecklist(initialDemand.checklist || []);
      setFinalAssets(initialDemand.final_assets || []);
      setFinalNotes(initialDemand.final_notes || "");
    } else {
      resetForm();
    }
  }, [open, initialDemand]);

  const resetForm = () => {
    setType(""); setElement(""); setClientId(""); setAssigneeId(""); setManagerId("");
    setPriority("media"); setStatus("backlog"); setDeadline(""); setBriefing("");
    setBriefingImages([]); setRefLinks([]); setNewLink(""); setChecklist([]); setNewChecklistItem("");
    setFinalAssets([]); setFinalNotes("");
  };

  const fetchClients = async () => {
    const { data } = await supabase.from("clients").select("id, name").eq("status", "ativo").order("name");
    setClients(data || []);
  };

  const fetchProfiles = async () => {
    const { data } = await supabase.from("profiles").select("user_id, display_name").order("display_name");
    setProfiles(data || []);
  };

  const uploadFile = async (file: File, prefix: string): Promise<string | null> => {
    const ext = file.name.split(".").pop() || "bin";
    const id = (initialDemand?.id || "new") as string;
    const path = `${prefix}/${id}/${crypto.randomUUID()}.${ext}`;
    const { error } = await supabase.storage.from("creatives").upload(path, file, { upsert: false, contentType: file.type });
    if (error) {
      toast({ title: "Erro no upload", description: error.message, variant: "destructive" });
      return null;
    }
    const { data } = supabase.storage.from("creatives").getPublicUrl(path);
    return data.publicUrl;
  };

  const handleBriefingFiles = async (files: FileList | File[]) => {
    const arr = Array.from(files);
    if (briefingImages.length + arr.length > MAX_BRIEFING_IMAGES) {
      toast({ title: `Máximo de ${MAX_BRIEFING_IMAGES} imagens`, variant: "destructive" });
      return;
    }
    setUploadingBriefing(true);
    const uploaded: string[] = [];
    for (const f of arr) {
      if (!f.type.startsWith("image/")) { toast({ title: `${f.name}: não é imagem`, variant: "destructive" }); continue; }
      if (f.size > MAX_IMG_BYTES) { toast({ title: `${f.name}: maior que 5MB`, variant: "destructive" }); continue; }
      const url = await uploadFile(f, "briefings");
      if (url) uploaded.push(url);
    }
    if (uploaded.length) setBriefingImages([...briefingImages, ...uploaded]);
    setUploadingBriefing(false);
  };

  const handlePaste = (e: React.ClipboardEvent) => {
    const items = e.clipboardData?.items;
    if (!items) return;
    const files: File[] = [];
    for (const it of Array.from(items)) {
      if (it.kind === "file") {
        const f = it.getAsFile();
        if (f && f.type.startsWith("image/")) files.push(f);
      }
    }
    if (files.length) { e.preventDefault(); handleBriefingFiles(files); }
  };

  const handleFinalFiles = async (files: FileList | File[]) => {
    const arr = Array.from(files);
    setUploadingFinal(true);
    const added: FinalAsset[] = [];
    for (const f of arr) {
      if (f.size > MAX_FINAL_BYTES) { toast({ title: `${f.name}: maior que 50MB`, variant: "destructive" }); continue; }
      const url = await uploadFile(f, "final");
      if (url) added.push({ url, name: f.name, type: f.type || "application/octet-stream", size: f.size, uploaded_at: new Date().toISOString() });
    }
    if (added.length) setFinalAssets([...finalAssets, ...added]);
    setUploadingFinal(false);
  };

  const addLink = () => {
    const url = newLink.trim();
    if (!url) return;
    try { new URL(url); } catch { toast({ title: "URL inválida", variant: "destructive" }); return; }
    setRefLinks([...refLinks, url]); setNewLink("");
  };

  const addChecklistItem = () => {
    const t = newChecklistItem.trim();
    if (!t) return;
    setChecklist([...checklist, { id: crypto.randomUUID(), text: t, done: false }]);
    setNewChecklistItem("");
  };

  const handleSubmit = async () => {
    const result = schema.safeParse({ type, element, client_id: clientId, briefing });
    if (!result.success) {
      toast({ title: "Verifique os campos", description: result.error.errors[0].message, variant: "destructive" });
      return;
    }
    if (!user) return;
    setSaving(true);
    const becomingCompleted = status === "concluido";
    const payload: any = {
      type, element, client_id: clientId,
      assignee_id: assigneeId || null,
      manager_id: managerId || null,
      priority, status,
      deadline: deadline || null,
      briefing: briefing || null,
      briefing_images: briefingImages,
      reference_links: refLinks,
      checklist: checklist as any,
      final_assets: finalAssets as any,
      final_notes: finalNotes || null,
      completed_at: becomingCompleted ? (initialDemand?.completed_at || new Date().toISOString()) : null,
    };
    let error;
    if (initialDemand?.id) {
      ({ error } = await supabase.from("creative_demands").update(payload).eq("id", initialDemand.id));
    } else {
      payload.created_by = user.id;
      ({ error } = await supabase.from("creative_demands").insert(payload));
    }
    setSaving(false);
    if (error) {
      toast({ title: "Erro ao salvar", description: error.message, variant: "destructive" });
    } else {
      toast({ title: initialDemand ? "Demanda atualizada" : "Demanda criada" });
      onSaved(); onClose();
    }
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm p-4" onClick={onClose}>
      <div className="bg-card border border-border rounded-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between px-5 py-4 border-b border-border sticky top-0 bg-card z-10">
          <h2 className="text-lg font-semibold text-foreground">{initialDemand ? "Editar Demanda" : "Nova Demanda Criativa"}</h2>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground"><X size={18} /></button>
        </div>

        <div className="p-5 space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Tipo de Demanda *</label>
              <select value={type} onChange={(e) => setType(e.target.value)} className="w-full bg-secondary border border-border rounded-lg px-3 py-2 text-sm text-foreground">
                <option value="">Selecione o tipo</option>
                {DEMAND_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Elemento *</label>
              <input value={element} onChange={(e) => setElement(e.target.value)} placeholder="Ex: Banner Instagram, LP Black Friday..." maxLength={200} className="w-full bg-secondary border border-border rounded-lg px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground/50" />
            </div>
          </div>

          <div>
            <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Cliente *</label>
            <select value={clientId} onChange={(e) => setClientId(e.target.value)} className="w-full bg-secondary border border-border rounded-lg px-3 py-2 text-sm text-foreground">
              <option value="">Selecione o cliente</option>
              {clients.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Responsável</label>
              <select value={assigneeId} onChange={(e) => setAssigneeId(e.target.value)} className="w-full bg-secondary border border-border rounded-lg px-3 py-2 text-sm text-foreground">
                <option value="">Selecione</option>
                {profiles.map((p) => <option key={p.user_id} value={p.user_id}>{p.display_name || p.user_id.slice(0, 8)}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Gestor Responsável</label>
              <select value={managerId} onChange={(e) => setManagerId(e.target.value)} className="w-full bg-secondary border border-border rounded-lg px-3 py-2 text-sm text-foreground">
                <option value="">Selecione</option>
                {profiles.map((p) => <option key={p.user_id} value={p.user_id}>{p.display_name || p.user_id.slice(0, 8)}</option>)}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Prioridade</label>
              <select value={priority} onChange={(e) => setPriority(e.target.value)} className="w-full bg-secondary border border-border rounded-lg px-3 py-2 text-sm text-foreground">
                {PRIORITIES.map((p) => <option key={p.value} value={p.value}>{p.label}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Status</label>
              <select value={status} onChange={(e) => setStatus(e.target.value)} className="w-full bg-secondary border border-border rounded-lg px-3 py-2 text-sm text-foreground">
                {STATUS_OPTIONS.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Prazo</label>
              <input type="date" value={deadline} onChange={(e) => setDeadline(e.target.value)} className="w-full bg-secondary border border-border rounded-lg px-3 py-2 text-sm text-foreground" />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-medium text-muted-foreground">Briefing / Descrição</label>
              <button
                type="button"
                onClick={() => briefingFileRef.current?.click()}
                disabled={uploadingBriefing || briefingImages.length >= MAX_BRIEFING_IMAGES}
                className="text-xs flex items-center gap-1 text-accent hover:text-accent/80 disabled:opacity-50"
              >
                <ImagePlus size={12} /> {uploadingBriefing ? "Enviando..." : "Adicionar imagem"}
              </button>
              <input
                ref={briefingFileRef}
                type="file"
                accept="image/*"
                multiple
                hidden
                onChange={(e) => e.target.files && handleBriefingFiles(e.target.files)}
              />
            </div>
            <textarea
              value={briefing}
              onChange={(e) => setBriefing(e.target.value)}
              onPaste={handlePaste}
              placeholder="Descreva o objetivo, a mensagem, o público, o conceito... Você pode colar imagens (Ctrl+V) aqui."
              maxLength={2000}
              rows={4}
              className="w-full bg-secondary border border-border rounded-lg px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground/50 resize-none"
            />
            <p className="text-[10px] text-muted-foreground mt-1">{briefing.length}/2000 — {briefingImages.length}/{MAX_BRIEFING_IMAGES} imagens</p>
            {briefingImages.length > 0 && (
              <div className="mt-2 grid grid-cols-4 gap-2">
                {briefingImages.map((url, i) => (
                  <div key={i} className="relative group aspect-square rounded-lg overflow-hidden border border-border bg-secondary">
                    <a href={url} target="_blank" rel="noreferrer">
                      <img src={url} alt={`ref-${i}`} className="w-full h-full object-cover" />
                    </a>
                    <button
                      type="button"
                      onClick={() => setBriefingImages(briefingImages.filter((_, idx) => idx !== i))}
                      className="absolute top-1 right-1 bg-background/80 text-metric-red rounded p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <Trash2 size={11} />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div>
            <label className="text-xs font-medium text-muted-foreground mb-1.5 flex items-center gap-1.5"><LinkIcon size={11} />Links de referência</label>
            <div className="flex gap-2 mb-2">
              <input value={newLink} onChange={(e) => setNewLink(e.target.value)} onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), addLink())} placeholder="https://..." className="flex-1 bg-secondary border border-border rounded-lg px-3 py-1.5 text-sm text-foreground" />
              <button onClick={addLink} className="bg-accent/20 text-accent px-3 rounded-lg hover:bg-accent/30 transition-colors"><Plus size={14} /></button>
            </div>
            {refLinks.length > 0 && (
              <ul className="space-y-1">
                {refLinks.map((link, i) => (
                  <li key={i} className="flex items-center justify-between bg-secondary/50 border border-border rounded px-2 py-1 text-xs">
                    <a href={link} target="_blank" rel="noreferrer" className="text-metric-blue hover:underline truncate flex-1">{link}</a>
                    <button onClick={() => setRefLinks(refLinks.filter((_, idx) => idx !== i))} className="text-muted-foreground hover:text-metric-red ml-2"><Trash2 size={12} /></button>
                  </li>
                ))}
              </ul>
            )}
          </div>

          <div>
            <label className="text-xs font-medium text-muted-foreground mb-1.5 flex items-center gap-1.5"><CheckSquare size={11} />Checklist de subtarefas</label>
            <div className="flex gap-2 mb-2">
              <input value={newChecklistItem} onChange={(e) => setNewChecklistItem(e.target.value)} onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), addChecklistItem())} placeholder="Ex: Roteiro, Captação, Edição..." className="flex-1 bg-secondary border border-border rounded-lg px-3 py-1.5 text-sm text-foreground" />
              <button onClick={addChecklistItem} className="bg-accent/20 text-accent px-3 rounded-lg hover:bg-accent/30"><Plus size={14} /></button>
            </div>
            {checklist.length > 0 && (
              <ul className="space-y-1">
                {checklist.map((item) => (
                  <li key={item.id} className="flex items-center gap-2 bg-secondary/50 border border-border rounded px-2 py-1.5 text-xs">
                    <input type="checkbox" checked={item.done} onChange={(e) => setChecklist(checklist.map((i) => i.id === item.id ? { ...i, done: e.target.checked } : i))} className="accent-accent" />
                    <span className={item.done ? "line-through text-muted-foreground flex-1" : "text-foreground flex-1"}>{item.text}</span>
                    <button onClick={() => setChecklist(checklist.filter((i) => i.id !== item.id))} className="text-muted-foreground hover:text-metric-red"><Trash2 size={12} /></button>
                  </li>
                ))}
              </ul>
            )}
          </div>

          {/* Entrega Final */}
          <div className="border-t border-border pt-4">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-semibold text-foreground flex items-center gap-1.5">
                <Paperclip size={13} className="text-metric-green" /> Entrega Final
              </h3>
              {status !== "concluido" && (
                <button
                  type="button"
                  onClick={() => setStatus("concluido")}
                  className="text-xs text-metric-green hover:underline"
                >
                  Marcar como concluído
                </button>
              )}
            </div>
            <p className="text-[11px] text-muted-foreground mb-3">
              Anexe os criativos entregues e adicione observações/dados da entrega. Disponível também antes de finalizar.
            </p>

            <div className="mb-3">
              <button
                type="button"
                onClick={() => finalFileRef.current?.click()}
                disabled={uploadingFinal}
                className="w-full flex items-center justify-center gap-2 bg-secondary hover:bg-secondary/70 border border-dashed border-border rounded-lg px-3 py-3 text-sm text-foreground transition-colors disabled:opacity-50"
              >
                <Upload size={14} />
                {uploadingFinal ? "Enviando..." : "Adicionar arquivos (imagens, vídeos, PDF, ZIP)"}
              </button>
              <input
                ref={finalFileRef}
                type="file"
                multiple
                hidden
                onChange={(e) => e.target.files && handleFinalFiles(e.target.files)}
              />
            </div>

            {finalAssets.length > 0 && (
              <ul className="space-y-1 mb-3">
                {finalAssets.map((a, i) => (
                  <li key={i} className="flex items-center gap-2 bg-secondary/50 border border-border rounded px-2 py-1.5 text-xs">
                    {a.type.startsWith("image/") ? (
                      <img src={a.url} alt={a.name} className="w-8 h-8 object-cover rounded" />
                    ) : (
                      <div className="w-8 h-8 flex items-center justify-center bg-secondary rounded text-muted-foreground"><FileText size={14} /></div>
                    )}
                    <div className="flex-1 min-w-0">
                      <p className="text-foreground truncate">{a.name}</p>
                      <p className="text-[10px] text-muted-foreground">{formatBytes(a.size)}</p>
                    </div>
                    <a href={a.url} target="_blank" rel="noreferrer" download className="text-muted-foreground hover:text-foreground p-1"><Download size={12} /></a>
                    <button onClick={() => setFinalAssets(finalAssets.filter((_, idx) => idx !== i))} className="text-muted-foreground hover:text-metric-red p-1"><Trash2 size={12} /></button>
                  </li>
                ))}
              </ul>
            )}

            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Resultados / Dados da entrega</label>
              <textarea
                value={finalNotes}
                onChange={(e) => setFinalNotes(e.target.value)}
                placeholder="Observações sobre a entrega, métricas, links de publicação, aprovações..."
                rows={3}
                className="w-full bg-secondary border border-border rounded-lg px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground/50 resize-none"
              />
            </div>
          </div>
        </div>

        <div className="flex justify-end gap-2 px-5 py-4 border-t border-border sticky bottom-0 bg-card">
          <button onClick={onClose} className="px-4 py-2 text-sm text-muted-foreground hover:text-foreground">Cancelar</button>
          <button onClick={handleSubmit} disabled={saving} className="px-5 py-2 bg-accent text-accent-foreground rounded-lg text-sm font-medium hover:bg-accent/90 disabled:opacity-50">
            {saving ? "Salvando..." : initialDemand ? "Atualizar" : "Criar Demanda"}
          </button>
        </div>
      </div>
    </div>
  );
}
