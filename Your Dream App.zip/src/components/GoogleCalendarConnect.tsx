import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Loader2, CheckCircle2, RefreshCw, Unlink, Calendar as CalIcon } from "lucide-react";
import { toast } from "sonner";

const FN_BASE = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1`;

interface TokenRow {
  google_email: string | null;
  last_synced_at: string | null;
}

interface Props { onSynced?: () => void }

export function GoogleCalendarConnect({ onSynced }: Props) {
  const [tok, setTok] = useState<TokenRow | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from("user_google_calendar_tokens")
      .select("google_email, last_synced_at")
      .maybeSingle();
    setTok(data as TokenRow | null);
    setLoading(false);
  }, []);

  useEffect(() => { refresh(); }, [refresh]);

  useEffect(() => {
    const handler = (ev: MessageEvent) => {
      const d = ev.data;
      if (!d || d.source !== "lovable-oauth" || d.scope !== "google-calendar") return;
      setBusy(null);
      if (d.ok) {
        toast.success(`Conectado: ${d.email ?? ""}`);
        refresh();
        sync();
      } else {
        toast.error(d.message || "Falha ao conectar");
      }
    };
    window.addEventListener("message", handler);
    return () => window.removeEventListener("message", handler);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [refresh]);

  const connect = async () => {
    const { data: sess } = await supabase.auth.getSession();
    const token = sess.session?.access_token;
    if (!token) return toast.error("Sessão expirada");
    setBusy("connect");
    const w = window.open(
      `${FN_BASE}/google-calendar-oauth-start?token=${encodeURIComponent(token)}&origin=${encodeURIComponent(window.location.origin)}`,
      "google-cal-oauth", "width=600,height=750,popup=yes",
    );
    if (!w) { setBusy(null); return toast.error("Permita pop-ups."); }
    const t = setInterval(() => { if (w.closed) { clearInterval(t); setBusy((b) => b === "connect" ? null : b); } }, 1000);
  };

  const sync = async () => {
    setBusy("sync");
    const { data, error } = await supabase.functions.invoke("google-calendar-sync", { body: { action: "sync" } });
    setBusy(null);
    if (error || (data as { error?: string })?.error) {
      toast.error((data as { error?: string })?.error || error?.message || "Falha");
      return;
    }
    const d = data as { imported: number; updated: number; pushed: number };
    toast.success(`Sincronizado: ${d.imported} importados, ${d.updated} atualizados, ${d.pushed} enviados`);
    refresh();
    onSynced?.();
  };

  const disconnect = async () => {
    if (!confirm("Desconectar Google Calendar?")) return;
    setBusy("dc");
    await supabase.from("user_google_calendar_tokens").delete().neq("id", "00000000-0000-0000-0000-000000000000");
    setBusy(null);
    setTok(null);
    toast.success("Desconectado");
  };

  if (loading) return <Loader2 className="animate-spin text-muted-foreground" size={14} />;

  if (!tok) {
    return (
      <button onClick={connect} disabled={busy === "connect"}
        className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg bg-secondary text-foreground hover:bg-secondary/80 border border-border transition disabled:opacity-50">
        {busy === "connect" ? <Loader2 size={12} className="animate-spin" /> : <CalIcon size={12} />}
        Conectar Google Calendar
      </button>
    );
  }

  return (
    <div className="flex items-center gap-1.5">
      <span className="flex items-center gap-1 text-[11px] px-2 py-1 rounded-full bg-primary/15 text-primary border border-primary/30">
        <CheckCircle2 size={11} /> {tok.google_email ?? "Conectado"}
      </span>
      <button onClick={sync} disabled={busy === "sync"} title="Sincronizar agora"
        className="p-1.5 rounded-lg hover:bg-secondary text-muted-foreground hover:text-foreground transition disabled:opacity-50">
        {busy === "sync" ? <Loader2 size={12} className="animate-spin" /> : <RefreshCw size={12} />}
      </button>
      <button onClick={disconnect} disabled={busy === "dc"} title="Desconectar"
        className="p-1.5 rounded-lg hover:bg-destructive/15 text-muted-foreground hover:text-destructive transition disabled:opacity-50">
        <Unlink size={12} />
      </button>
    </div>
  );
}
