import { ReactNode } from "react";
import { useApplyBranding } from "@/hooks/useAppSettings";

export function AppBrandingProvider({ children }: { children: ReactNode }) {
  useApplyBranding();
  return <>{children}</>;
}
