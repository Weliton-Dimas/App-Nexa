import { useState } from "react";
import { X, FileText, Calendar, Check } from "lucide-react";
import { cn } from "@/lib/utils";

export type FinishPayload = {
  optimized_meta: boolean;
  optimized_google: boolean;
  action_budget: boolean;
  action_creative: boolean;
  action_audience: boolean;
  action_monitoring: boolean;
  observation: string;
};

interface Props {
  open: boolean;
  clientName: string;
  hasMeta: boolean;
  hasGoogle: boolean;
  onClose: () => void;
  onSave: (payload: FinishPayload) => Promise<void> | void;
}

const todayLabel = () => {
  const d = new Date();
  const months = [
    "janeiro", "fevereiro", "março", "abril", "maio", "junho",
    "julho", "agosto", "setembro", "outubro", "novembro", "dezembro",
  ];
  return `${d.getDate()} de ${months[d.getMonth()]} de ${d.getFullYear()}`;
};

export function OptimizationFinishModal({ open, clientName, hasMeta, hasGoogle, onClose, onSave }: Props) {
  const [meta, setMeta] = useState(false);
  const [google, setGoogle] = useState(false);
  const [budget, setBudget] = useState(false);
  const [creative, setCreative] = useState(false);
  const [audience, setAudience] = useState(false);
  const [monitoring, setMonitoring] = useState(false);
  const [observation, setObservation] = useState("");
  const [saving, setSaving] = useState(false);

  if (!open) return null;

  const reset = () => {
    setMeta(false); setGoogle(false); setBudget(false); setCreative(false);
    setAudience(false); setMonitoring(false); setObservation("");
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await onSave({
        optimized_meta: meta,
        optimized_google: google,
        action_budget: budget,
        action_creative: creative,
        action_audience: audience,
        action_monitoring: monitoring,
        observation: observation.trim(),
      });
      reset();
    } finally {
      setSaving(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="bg-card border border-border rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-start justify-between p-5 border-b border-border">
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-lg bg-secondary border border-border flex items-center justify-center shrink-0">
              <FileText size={16} className="text-foreground" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-foreground">Registrar otimização</h2>
              <p className="text-xs text-muted-foreground mt-0.5">
                Registre as ações realizadas para <span className="text-foreground font-semibold">{clientName}</span>
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-md hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors"
          >
            <X size={16} />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 space-y-5">
          {/* Date */}
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Calendar size={14} />
            <span>{todayLabel()}</span>
          </div>

          {/* Channels */}
          <div>
            <p className="text-sm font-semibold text-foreground mb-2.5">Canais otimizados</p>
            <div className="flex gap-3">
              <ChannelCheckbox
                checked={meta}
                onChange={setMeta}
                disabled={!hasMeta}
                label="Meta Ads"
                color="#1877F2"
                letter="f"
              />
              <ChannelCheckbox
                checked={google}
                onChange={setGoogle}
                disabled={!hasGoogle}
                label="Google Ads"
                color="#EA4335"
                letter="G"
              />
            </div>
          </div>

          {/* Actions */}
          <div>
            <p className="text-sm font-semibold text-foreground mb-2.5">Ações realizadas</p>
            <div className="space-y-1.5">
              <ActionCheckbox checked={budget} onChange={setBudget} label="Ajuste de orçamento" />
              <ActionCheckbox checked={creative} onChange={setCreative} label="Criativo pausado/novo" />
              <ActionCheckbox checked={audience} onChange={setAudience} label="Público ajustado" />
              <ActionCheckbox checked={monitoring} onChange={setMonitoring} label="Monitoramento (nenhuma ação)" />
            </div>
          </div>

          {/* Observation */}
          <div>
            <p className="text-sm font-semibold text-foreground mb-2">
              Observação <span className="text-muted-foreground font-normal">(opcional)</span>
            </p>
            <textarea
              value={observation}
              onChange={(e) => setObservation(e.target.value.slice(0, 300))}
              placeholder="Adicione uma observação curta..."
              rows={3}
              className="w-full bg-background border border-border rounded-lg px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent/40 focus:border-accent/40 resize-none"
            />
            <p className="text-[10px] text-muted-foreground text-right mt-1">{observation.length}/300</p>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end gap-2 p-5 border-t border-border">
          <button
            onClick={onClose}
            disabled={saving}
            className="px-4 py-2 rounded-lg bg-secondary border border-border text-foreground text-sm font-semibold hover:bg-secondary/70 transition-colors disabled:opacity-50"
          >
            Cancelar
          </button>
          <button
            onClick={handleSave}
            disabled={saving}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[hsl(var(--metric-amber))] text-background text-sm font-semibold hover:opacity-90 transition-opacity disabled:opacity-50"
          >
            <Check size={14} />
            {saving ? "Salvando..." : "Salvar e marcar como otimizada"}
          </button>
        </div>
      </div>
    </div>
  );
}

function ChannelCheckbox({
  checked, onChange, disabled, label, color, letter,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  disabled?: boolean;
  label: string;
  color: string;
  letter: string;
}) {
  return (
    <button
      type="button"
      onClick={() => !disabled && onChange(!checked)}
      disabled={disabled}
      className={cn(
        "flex-1 flex items-center gap-2.5 px-3 py-2.5 rounded-lg border transition-colors",
        checked ? "border-accent/50 bg-accent/5" : "border-border bg-background hover:border-border",
        disabled && "opacity-40 cursor-not-allowed",
      )}
    >
      <div className={cn(
        "w-4 h-4 rounded border flex items-center justify-center shrink-0",
        checked ? "bg-accent border-accent" : "border-border bg-background",
      )}>
        {checked && <Check size={11} className="text-accent-foreground" strokeWidth={3} />}
      </div>
      <div
        className="w-6 h-6 rounded-md flex items-center justify-center text-xs font-bold text-white shrink-0"
        style={{ backgroundColor: color }}
      >
        {letter}
      </div>
      <span className="text-sm font-medium text-foreground">{label}</span>
    </button>
  );
}

function ActionCheckbox({
  checked, onChange, label,
}: { checked: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button
      type="button"
      onClick={() => onChange(!checked)}
      className="w-full flex items-center gap-2.5 px-2 py-2 rounded-lg hover:bg-secondary/50 transition-colors text-left"
    >
      <div className={cn(
        "w-4 h-4 rounded border flex items-center justify-center shrink-0",
        checked ? "bg-accent border-accent" : "border-border bg-background",
      )}>
        {checked && <Check size={11} className="text-accent-foreground" strokeWidth={3} />}
      </div>
      <span className="text-sm text-foreground">{label}</span>
    </button>
  );
}
