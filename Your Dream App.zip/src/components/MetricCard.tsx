import { cn } from "@/lib/utils";

interface MetricCardProps {
  value: string | number;
  label: string;
  icon: React.ReactNode;
  variant?: "green" | "blue" | "red" | "amber" | "default";
  className?: string;
}

const variantStyles = {
  green: "bg-metric-green/10 border-metric-green/30",
  blue: "bg-metric-blue/10 border-metric-blue/30",
  red: "bg-metric-red/10 border-metric-red/30",
  amber: "bg-metric-amber/10 border-metric-amber/30",
  default: "bg-card border-border",
};

const iconVariantStyles = {
  green: "text-metric-green",
  blue: "text-metric-blue",
  red: "text-metric-red",
  amber: "text-metric-amber",
  default: "text-muted-foreground",
};

const valueVariantStyles = {
  green: "text-metric-green",
  blue: "text-metric-blue",
  red: "text-metric-red",
  amber: "text-metric-amber",
  default: "text-foreground",
};

export function MetricCard({ value, label, icon, variant = "default", className }: MetricCardProps) {
  return (
    <div className={cn(
      "flex flex-col items-center justify-center gap-2 rounded-xl border p-5 flex-1 min-w-0",
      variantStyles[variant],
      className
    )}>
      <div className={cn("opacity-80", iconVariantStyles[variant])}>
        {icon}
      </div>
      <p className={cn("text-3xl font-bold tabular-nums leading-none", valueVariantStyles[variant])}>
        {value}
      </p>
      <p className="text-xs text-muted-foreground font-medium text-center">{label}</p>
    </div>
  );
}
