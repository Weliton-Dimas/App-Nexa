import { useState, useMemo } from "react";
import { cn } from "@/lib/utils";
import {
  Search,
  ChevronDown,
  SlidersHorizontal,
  FolderOpen,
  BarChart3,
  Calendar as CalendarIcon,
  ArrowLeftRight,
  FileText,
  Layers,
  Megaphone,
  LayoutGrid,
  FileText as AdIcon,
  ChevronLeft,
  ChevronRight,
  Pencil,
} from "lucide-react";

type SubTab = "plataformas" | "campanhas" | "conjuntos" | "anuncios";

interface PlatformRow {
  id: string;
  platform: "meta" | "google";
  name: string;
  campaigns: number;
  investimento: number;
  cpc: number;
  ctr: number;
  compras: number;
  custoCompra: number;
  valorConversao: number;
  roas: number;
}

interface CampaignRow {
  id: string;
  platform: "meta" | "google";
  name: string;
  active: boolean;
  orcamentoDiario: number;
  conjuntos: number;
  investimento: number;
  cpc: number;
  ctr: number;
  compras: number;
  custoCompra: number;
  valorConversao: number;
}

const formatCurrency = (v: number) =>
  v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
const formatNumber = (v: number, d = 2) =>
  v.toLocaleString("pt-BR", { minimumFractionDigits: d, maximumFractionDigits: d });
const formatInt = (v: number) => v.toLocaleString("pt-BR");
const formatPct = (v: number) => `${formatNumber(v)}%`;

const PLATFORM_DATA: PlatformRow[] = [];

const CAMPAIGN_DATA: CampaignRow[] = [];

function PlatformIcon({ platform }: { platform: "meta" | "google" }) {
  if (platform === "meta") {
    return (
      <div className="w-7 h-7 rounded-full bg-[#1877F2]/15 flex items-center justify-center text-sm font-bold text-[#1877F2]">
        ƒ
      </div>
    );
  }
  return (
    <div className="w-7 h-7 rounded-full bg-[#FBBC05]/15 flex items-center justify-center text-xs font-bold text-[#FBBC05]">
      G
    </div>
  );
}

function ActiveToggle({ active }: { active: boolean }) {
  return (
    <div
      className={cn(
        "w-9 h-5 rounded-full p-0.5 flex items-center transition-colors",
        active ? "bg-metric-green" : "bg-secondary"
      )}
    >
      <div
        className={cn(
          "w-4 h-4 rounded-full bg-background transition-transform",
          active && "translate-x-4"
        )}
      />
    </div>
  );
}

function IconBtn({ children }: { children: React.ReactNode }) {
  return (
    <button className="w-10 h-10 rounded-xl border border-border/60 flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
      {children}
    </button>
  );
}

interface Props {
  clientName: string;
}

export function ClientCampaignsTab({ clientName }: Props) {
  const [tab, setTab] = useState<SubTab>("plataformas");
  const [statusFilter, setStatusFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const today = new Date();
  const start = new Date(today.getFullYear(), today.getMonth(), 1);
  const fmt = (d: Date) => d.toLocaleDateString("pt-BR");
  const dateRange = `${fmt(start)} - ${fmt(today)}`;

  const tabs: { key: SubTab; label: string; icon: typeof Layers; count?: number }[] = [
    { key: "plataformas", label: "Plataformas", icon: Layers, count: tab !== "plataformas" ? 1 : undefined },
    { key: "campanhas", label: "Campanhas", icon: Megaphone },
    { key: "conjuntos", label: "Conjuntos", icon: LayoutGrid },
    { key: "anuncios", label: "Anúncios", icon: AdIcon },
  ];

  const filteredCampaigns = useMemo(() => {
    let list = [...CAMPAIGN_DATA];
    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter((c) => c.name.toLowerCase().includes(q));
    }
    return list;
  }, [search]);

  const totalRecords = tab === "plataformas" ? PLATFORM_DATA.length : filteredCampaigns.length;
  const totalPages = Math.max(1, Math.ceil(totalRecords / pageSize));
  const pageStart = (page - 1) * pageSize;
  const pagedRows = tab === "plataformas"
    ? PLATFORM_DATA.slice(pageStart, pageStart + pageSize)
    : filteredCampaigns.slice(pageStart, pageStart + pageSize);

  return (
    <section className="space-y-4">
      {/* Filters bar */}
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-2 flex-wrap">
          <div className="relative">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="appearance-none pl-9 pr-9 py-2.5 rounded-xl border border-border/60 bg-card text-sm text-foreground hover:bg-secondary transition-colors cursor-pointer"
            >
              <option value="all">Status</option>
              <option value="active">Ativas</option>
              <option value="paused">Pausadas</option>
            </select>
            <SlidersHorizontal size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
            <ChevronDown size={13} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
          </div>

          <div className="relative w-[260px]">
            <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Buscar nome..."
              className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-border/60 bg-card text-sm text-foreground placeholder:text-muted-foreground"
            />
          </div>

          <IconBtn><SlidersHorizontal size={14} /></IconBtn>
          <IconBtn><FolderOpen size={14} /></IconBtn>
          <IconBtn><BarChart3 size={14} /></IconBtn>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-border/60 text-sm text-foreground">
            <CalendarIcon size={14} className="text-muted-foreground" />
            <span className="tabular-nums">{dateRange}</span>
          </div>
          <IconBtn><ArrowLeftRight size={14} /></IconBtn>
          <IconBtn><FileText size={14} /></IconBtn>
          <IconBtn><SlidersHorizontal size={14} /></IconBtn>
        </div>
      </div>

      {/* Sub-tabs */}
      <div className="grid grid-cols-4 border-b border-border/60">
        {tabs.map((t) => {
          const Icon = t.icon;
          const active = tab === t.key;
          return (
            <button
              key={t.key}
              onClick={() => { setTab(t.key); setPage(1); }}
              className={cn(
                "flex items-center justify-center gap-2 px-4 py-3 text-sm font-medium transition-colors relative",
                active ? "text-foreground" : "text-muted-foreground hover:text-foreground"
              )}
            >
              <Icon size={15} />
              {t.label}
              {t.count !== undefined && (
                <span className="ml-1 px-1.5 py-0.5 rounded text-[10px] bg-secondary text-muted-foreground tabular-nums">
                  {t.count}
                </span>
              )}
              {active && <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-foreground" />}
            </button>
          );
        })}
      </div>

      {/* Table */}
      <div className="rounded-xl border border-border/60 overflow-hidden">
        {tab === "plataformas" && (
          <table className="w-full text-sm">
            <thead>
              <tr className="text-muted-foreground text-xs">
                <th className="text-left px-4 py-3 font-medium w-10"></th>
                <th className="text-left px-4 py-3 font-medium">Plataforma</th>
                <th className="text-right px-4 py-3 font-medium">Campanhas</th>
                <th className="text-right px-4 py-3 font-medium">
                  <span className="inline-flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-metric-blue"></span>
                    Investimento
                  </span>
                </th>
                <th className="text-right px-4 py-3 font-medium">CPC</th>
                <th className="text-right px-4 py-3 font-medium">CTR</th>
                <th className="text-right px-4 py-3 font-medium">Compras</th>
                <th className="text-right px-4 py-3 font-medium">Custo por compra</th>
                <th className="text-right px-4 py-3 font-medium">Valor de conversão</th>
                <th className="text-right px-4 py-3 font-medium">ROAS</th>
              </tr>
            </thead>
            <tbody>
              {(pagedRows as PlatformRow[]).map((r) => (
                <tr key={r.id} className="border-t border-border/40 hover:bg-secondary/30 transition-colors">
                  <td className="px-4 py-4">
                    <input type="checkbox" className="rounded border-border" />
                  </td>
                  <td className="px-4 py-4">
                    <div className="flex items-center gap-3">
                      <PlatformIcon platform={r.platform} />
                      <span className="font-semibold text-foreground">{r.name}</span>
                    </div>
                  </td>
                  <td className="px-4 py-4 text-right tabular-nums text-foreground">{r.campaigns}</td>
                  <td className="px-4 py-4 text-right tabular-nums text-foreground">{formatCurrency(r.investimento)}</td>
                  <td className="px-4 py-4 text-right tabular-nums text-foreground">{formatCurrency(r.cpc)}</td>
                  <td className="px-4 py-4 text-right tabular-nums text-foreground">{formatPct(r.ctr)}</td>
                  <td className="px-4 py-4 text-right tabular-nums text-foreground">{formatInt(r.compras)}</td>
                  <td className="px-4 py-4 text-right tabular-nums text-foreground">{formatCurrency(r.custoCompra)}</td>
                  <td className="px-4 py-4 text-right tabular-nums text-foreground">{formatCurrency(r.valorConversao)}</td>
                  <td className="px-4 py-4 text-right tabular-nums text-foreground">{formatNumber(r.roas)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
        {tab === "plataformas" && pagedRows.length === 0 && (
          <div className="py-16 text-center text-sm text-muted-foreground border-t border-border/40">
            Os dados de Plataformas aparecerão aqui após a integração com a API ({clientName}).
          </div>
        )}

        {tab === "campanhas" && (
          <>
            <div className="px-4 py-2 text-xs text-muted-foreground bg-card border-b border-border/40">
              Meta Ads
            </div>
            <table className="w-full text-sm">
              <thead>
                <tr className="text-muted-foreground text-xs">
                  <th className="text-left px-4 py-3 font-medium w-10"></th>
                  <th className="text-left px-4 py-3 font-medium w-10"></th>
                  <th className="text-left px-4 py-3 font-medium w-10"></th>
                  <th className="text-left px-4 py-3 font-medium">Campanha</th>
                  <th className="text-right px-4 py-3 font-medium">Orçamento diário</th>
                  <th className="text-right px-4 py-3 font-medium">Conjuntos</th>
                  <th className="text-right px-4 py-3 font-medium">
                    <span className="inline-flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-metric-blue"></span>
                      Investimento
                    </span>
                  </th>
                  <th className="text-right px-4 py-3 font-medium">CPC</th>
                  <th className="text-right px-4 py-3 font-medium">CTR</th>
                  <th className="text-right px-4 py-3 font-medium">Compras</th>
                  <th className="text-right px-4 py-3 font-medium">Custo por compra</th>
                  <th className="text-right px-4 py-3 font-medium">Valor de conversão</th>
                </tr>
              </thead>
              <tbody>
                {(pagedRows as CampaignRow[]).map((r) => (
                  <tr key={r.id} className="border-t border-border/40 hover:bg-secondary/30 transition-colors">
                    <td className="px-4 py-4">
                      <input type="checkbox" className="rounded border-border" />
                    </td>
                    <td className="px-4 py-4">
                      <PlatformIcon platform={r.platform} />
                    </td>
                    <td className="px-4 py-4">
                      <ActiveToggle active={r.active} />
                    </td>
                    <td className="px-4 py-4 font-semibold text-foreground max-w-[280px] truncate">{r.name}</td>
                    <td className="px-4 py-4 text-right tabular-nums text-foreground">
                      <span className="inline-flex items-center gap-2">
                        {formatCurrency(r.orcamentoDiario)}
                        <Pencil size={11} className="text-muted-foreground/70" />
                      </span>
                    </td>
                    <td className="px-4 py-4 text-right tabular-nums text-foreground">{r.conjuntos}</td>
                    <td className="px-4 py-4 text-right tabular-nums text-foreground">{formatCurrency(r.investimento)}</td>
                    <td className="px-4 py-4 text-right tabular-nums text-foreground">{formatCurrency(r.cpc)}</td>
                    <td className="px-4 py-4 text-right tabular-nums text-foreground">{formatPct(r.ctr)}</td>
                    <td className="px-4 py-4 text-right tabular-nums text-foreground">{formatInt(r.compras)}</td>
                    <td className="px-4 py-4 text-right tabular-nums text-foreground">{formatCurrency(r.custoCompra)}</td>
                    <td className="px-4 py-4 text-right tabular-nums text-foreground">{formatCurrency(r.valorConversao)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            {pagedRows.length === 0 && (
              <div className="py-16 text-center text-sm text-muted-foreground border-t border-border/40">
                As campanhas aparecerão aqui após a integração com a API ({clientName}).
              </div>
            )}
          </>
        )}

        {(tab === "conjuntos" || tab === "anuncios") && (
          <div className="py-16 text-center text-sm text-muted-foreground">
            Os dados de {tab === "conjuntos" ? "Conjuntos" : "Anúncios"} aparecerão aqui após a integração com a API ({clientName}).
          </div>
        )}

        {/* Pagination */}
        <div className="flex items-center justify-between px-4 py-3 border-t border-border/40 bg-card text-xs text-muted-foreground">
          <div className="flex items-center gap-3">
            <span>{pageStart + 1}–{Math.min(pageStart + pageSize, totalRecords)} de {totalRecords} registros</span>
            <span className="flex items-center gap-2">
              Linhas por página
              <div className="relative">
                <select
                  value={pageSize}
                  onChange={(e) => { setPageSize(Number(e.target.value)); setPage(1); }}
                  className="appearance-none pl-3 pr-8 py-1 rounded-md border border-border/60 bg-background text-foreground cursor-pointer"
                >
                  {[10, 25, 50, 100].map((n) => <option key={n} value={n}>{n}</option>)}
                </select>
                <ChevronDown size={12} className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
              </div>
            </span>
          </div>
          <div className="flex items-center gap-3">
            <span>Página {page} de {totalPages}</span>
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page === 1}
              className="w-7 h-7 rounded-md border border-border/60 flex items-center justify-center hover:bg-secondary disabled:opacity-40"
            >
              <ChevronLeft size={13} />
            </button>
            <button
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={page === totalPages}
              className="w-7 h-7 rounded-md border border-border/60 flex items-center justify-center hover:bg-secondary disabled:opacity-40"
            >
              <ChevronRight size={13} />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
