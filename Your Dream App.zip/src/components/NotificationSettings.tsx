import { useEffect, useState } from "react";
import { Bell, BellOff, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { usePushNotifications } from "@/hooks/usePushNotifications";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";

type Prefs = {
  kanban_enabled: boolean;
  kanban_minutes_before: number;
  calendar_enabled: boolean;
  calendar_hour: number;
  prospects_enabled: boolean;
  prospects_minutes_before: number;
};

const DEFAULTS: Prefs = {
  kanban_enabled: true,
  kanban_minutes_before: 60,
  calendar_enabled: true,
  calendar_hour: 8,
  prospects_enabled: true,
  prospects_minutes_before: 15,
};

export function NotificationSettings() {
  const { user } = useAuth();
  const { toast } = useToast();
  const { supported, permission, subscribed, busy, subscribe, unsubscribe } = usePushNotifications();
  const [prefs, setPrefs] = useState<Prefs>(DEFAULTS);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!user) return;
    supabase
      .from("notification_preferences")
      .select("*")
      .eq("user_id", user.id)
      .maybeSingle()
      .then(({ data }) => {
        if (data) setPrefs({
          kanban_enabled: data.kanban_enabled,
          kanban_minutes_before: data.kanban_minutes_before,
          calendar_enabled: data.calendar_enabled,
          calendar_hour: data.calendar_hour,
          prospects_enabled: data.prospects_enabled,
          prospects_minutes_before: data.prospects_minutes_before,
        });
      });
  }, [user]);

  const savePrefs = async (next: Prefs) => {
    if (!user) return;
    setPrefs(next);
    setSaving(true);
    const { error } = await supabase
      .from("notification_preferences")
      .upsert({ user_id: user.id, ...next, updated_at: new Date().toISOString() });
    setSaving(false);
    if (error) toast({ title: "Erro ao salvar", description: error.message, variant: "destructive" });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Bell size={18} /> Notificações no computador
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {!supported && (
          <p className="text-sm text-muted-foreground">
            Seu navegador não suporta notificações push. Use Chrome, Edge, Firefox ou Brave no desktop.
          </p>
        )}

        {supported && (
          <div className="flex items-center justify-between rounded-lg border border-border p-4">
            <div className="space-y-1">
              <p className="text-sm font-medium text-foreground">
                {subscribed ? "Notificações ativadas neste navegador" : "Ativar notificações neste navegador"}
              </p>
              <p className="text-xs text-muted-foreground">
                {permission === "denied"
                  ? "Permissão bloqueada. Libere nas configurações do navegador."
                  : subscribed
                  ? "Você receberá alertas mesmo com o app fechado."
                  : "Habilite para receber alertas do Kanban, Calendário e Prospecção."}
              </p>
            </div>
            {subscribed ? (
              <Button variant="outline" size="sm" onClick={unsubscribe} disabled={busy}>
                {busy ? <Loader2 className="animate-spin" size={14} /> : <><BellOff size={14} className="mr-1" /> Desativar</>}
              </Button>
            ) : (
              <Button size="sm" onClick={subscribe} disabled={busy || permission === "denied"}>
                {busy ? <Loader2 className="animate-spin" size={14} /> : <><Bell size={14} className="mr-1" /> Ativar</>}
              </Button>
            )}
          </div>
        )}

        <div className="space-y-4">
          <PrefRow
            title="Tarefas do Kanban"
            description="Notifica antes do prazo de cards"
            enabled={prefs.kanban_enabled}
            onToggle={(v) => savePrefs({ ...prefs, kanban_enabled: v })}
          >
            <NumberField
              label="Minutos antes"
              value={prefs.kanban_minutes_before}
              onChange={(v) => savePrefs({ ...prefs, kanban_minutes_before: v })}
            />
          </PrefRow>

          <PrefRow
            title="Eventos do Calendário"
            description="Resumo diário das tarefas"
            enabled={prefs.calendar_enabled}
            onToggle={(v) => savePrefs({ ...prefs, calendar_enabled: v })}
          >
            <NumberField
              label="Horário (0-23)"
              value={prefs.calendar_hour}
              max={23}
              onChange={(v) => savePrefs({ ...prefs, calendar_hour: Math.max(0, Math.min(23, v)) })}
            />
          </PrefRow>

          <PrefRow
            title="Follow-up de Prospecções"
            description="Lembrete do próximo contato"
            enabled={prefs.prospects_enabled}
            onToggle={(v) => savePrefs({ ...prefs, prospects_enabled: v })}
          >
            <NumberField
              label="Minutos antes"
              value={prefs.prospects_minutes_before}
              onChange={(v) => savePrefs({ ...prefs, prospects_minutes_before: v })}
            />
          </PrefRow>
        </div>

        {saving && <p className="text-xs text-muted-foreground">Salvando...</p>}
      </CardContent>
    </Card>
  );
}

function PrefRow({ title, description, enabled, onToggle, children }: any) {
  return (
    <div className="rounded-lg border border-border p-4 space-y-3">
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-sm font-medium text-foreground">{title}</p>
          <p className="text-xs text-muted-foreground">{description}</p>
        </div>
        <Switch checked={enabled} onCheckedChange={onToggle} />
      </div>
      {enabled && <div className="pt-2">{children}</div>}
    </div>
  );
}

function NumberField({ label, value, onChange, max = 1440 }: { label: string; value: number; onChange: (v: number) => void; max?: number }) {
  return (
    <div className="flex items-center gap-3">
      <Label className="text-xs text-muted-foreground min-w-[120px]">{label}</Label>
      <Input
        type="number"
        min={0}
        max={max}
        value={value}
        onChange={(e) => onChange(parseInt(e.target.value || "0", 10))}
        className="w-28"
      />
    </div>
  );
}
