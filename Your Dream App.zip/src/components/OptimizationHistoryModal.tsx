import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { X, History, Calendar, Clock, User as UserIcon, FileText } from "lucide-react";
import { cn } from "@/lib/utils";

type Session = {
  id: string;
  user_id: string;
  started_at: string;
  ended_at: string | null;
  duration_seconds: number;
  optimized_meta: boolean;
  optimized_google: boolean;
  action_budget: boolean;
  action_creative: boolean;
  action_audience: boolean;
  action_monitoring: boolean;
  observation: string | null;
};

type Profile = { user_id: string; display_name: string | null; avatar_url: string | null };

interface Props {
  open: boolean;
  clientId: string | null;
  clientName: string;
  profileById: Record<string, Profile>;
  onClose: () => void;
}

const formatDuration = (s: number) => {
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
};

const formatDateTime = (iso: string) => {
  const d = new Date(iso);
  return `${String(d.getDate()).padStart(2, "0")}/${String(d.getMonth() + 1).padStart(2, "0")}/${d.getFullYear()} ${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
};

export function OptimizationHistoryModal({ open, clientId, clientName, profileById, onClose }: Props) {
  const { data: sessions = [], isLoading } = useQuery({
    queryKey: ["opt-history", clientId],
    queryFn: async () => {
      if (!clientId) return [];
      const { data, error } = await supabase
        .from("optimization_sessions")
        .select("*")
        .eq("client_id", clientId)
        .not("ended_at", "is", null)
        .order("ended_at", { ascending: false });
      if (error) throw error;
      return (data || []) as Session[];
    },
    enabled: open && !!clientId,
  });

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="bg-card border border-border rounded-2xl shadow-2xl w-full max-w-2xl max-h-[85vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-start justify-between p-5 border-b border-border">
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-lg bg-secondary border border-border flex items-center justify-center shrink-0">
              <History size={16} className="text-foreground" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-foreground">Histórico de otimizações</h2>
              <p className="text-xs text-muted-foreground mt-0.5">
                <span className="text-foreground font-semibold">{clientName}</span> — {sessions.length} registro{sessions.length === 1 ? "" : "s"}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-md hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors"
          >
            <X size={16} />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-3">
          {isLoading && (
            <div className="text-center py-12 text-sm text-muted-foreground">Carregando...</div>
          )}
          {!isLoading && sessions.length === 0 && (
            <div className="text-center py-12">
              <History size={32} className="mx-auto text-muted-foreground/40 mb-2" />
              <p className="text-sm text-muted-foreground">Nenhuma otimização registrada ainda.</p>
            </div>
          )}
          {sessions.map((s) => {
            const manager = profileById[s.user_id];
            const channels: string[] = [];
            if (s.optimized_meta) channels.push("Meta Ads");
            if (s.optimized_google) channels.push("Google Ads");
            const actions: string[] = [];
            if (s.action_budget) actions.push("Ajuste de orçamento");
            if (s.action_creative) actions.push("Criativo pausado/novo");
            if (s.action_audience) actions.push("Público ajustado");
            if (s.action_monitoring) actions.push("Monitoramento (nenhuma ação)");

            return (
              <div key={s.id} className="bg-background border border-border rounded-xl p-4">
                {/* Top row */}
                <div className="flex items-center justify-between mb-3 pb-3 border-b border-border/50">
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Calendar size={12} />
                    <span className="text-foreground font-medium">{formatDateTime(s.ended_at!)}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-1.5 text-xs">
                      <Clock size={12} className="text-muted-foreground" />
                      <span className="font-mono tabular-nums text-foreground">{formatDuration(s.duration_seconds)}</span>
                    </div>
                    {manager && (
                      <div className="flex items-center gap-1.5 text-xs">
                        <UserIcon size={12} className="text-muted-foreground" />
                        <span className="text-foreground">{manager.display_name || "Gestor"}</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Channels */}
                <div className="mb-3">
                  <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground mb-1.5">Canais</p>
                  {channels.length === 0 ? (
                    <p className="text-xs text-muted-foreground italic">Nenhum canal selecionado</p>
                  ) : (
                    <div className="flex gap-2 flex-wrap">
                      {s.optimized_meta && (
                        <span className="inline-flex items-center gap-1.5 px-2 py-1 rounded-md bg-[#1877F2]/10 text-[#1877F2] text-xs font-medium">
                          <span className="w-4 h-4 rounded bg-[#1877F2] text-white text-[10px] font-bold flex items-center justify-center">f</span>
                          Meta Ads
                        </span>
                      )}
                      {s.optimized_google && (
                        <span className="inline-flex items-center gap-1.5 px-2 py-1 rounded-md bg-[#EA4335]/10 text-[#EA4335] text-xs font-medium">
                          <span className="w-4 h-4 rounded bg-[#EA4335] text-white text-[10px] font-bold flex items-center justify-center">G</span>
                          Google Ads
                        </span>
                      )}
                    </div>
                  )}
                </div>

                {/* Actions */}
                <div className={cn(s.observation && "mb-3")}>
                  <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground mb-1.5">Ações realizadas</p>
                  {actions.length === 0 ? (
                    <p className="text-xs text-muted-foreground italic">Nenhuma ação marcada</p>
                  ) : (
                    <div className="flex gap-1.5 flex-wrap">
                      {actions.map((a) => (
                        <span key={a} className="px-2 py-0.5 rounded-md bg-secondary border border-border text-xs text-foreground">
                          {a}
                        </span>
                      ))}
                    </div>
                  )}
                </div>

                {/* Observation */}
                {s.observation && (
                  <div>
                    <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground mb-1.5 flex items-center gap-1">
                      <FileText size={10} /> Observação
                    </p>
                    <p className="text-xs text-foreground bg-secondary/40 border border-border rounded-md p-2">{s.observation}</p>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
