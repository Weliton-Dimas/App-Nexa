import {
  LayoutDashboard,
  Zap,
  Palette,
  Users,
  Share2,
  Mail,
  TrendingUp,
  DollarSign,
  User,
  ChevronDown,
  ChevronRight,
  Boxes,
  KanbanSquare,
  CalendarDays,
  BarChart2,
  Settings,
  LogOut,
  Shield,
  Link2,
  Target,
  Calculator,
  Lightbulb,
  PanelLeftClose,
  PanelLeftOpen,
  GripVertical,
  Pencil,
  Check,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useState, useEffect, useMemo } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { useAppSettings } from "@/hooks/useAppSettings";
import { useSidebarCollapsed } from "@/hooks/useSidebarCollapsed";
import { useUserPermissions } from "@/hooks/useUserPermissions";
import { useNavOrder, useSaveNavOrder, applyNavOrder, NavOrder } from "@/hooks/useNavOrder";
import { toast } from "sonner";
import {
  DndContext,
  DragEndEvent,
  PointerSensor,
  closestCenter,
  useSensor,
  useSensors,
} from "@dnd-kit/core";
import {
  SortableContext,
  arrayMove,
  useSortable,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";

const SECTION_PREFIX = "SECTION::";
const ITEM_PREFIX = "ITEM::";
const itemId = (section: string, label: string) => `${ITEM_PREFIX}${section}::${label}`;
const sectionId = (title: string) => `${SECTION_PREFIX}${title}`;

interface NavItem {
  icon: React.ReactNode;
  label: string;
  path?: string;
  slug?: string;
  adminOnly?: boolean;
  children?: { label: string; path?: string }[];
}

interface NavSection {
  title: string;
  items: NavItem[];
}

const sections: NavSection[] = [
  {
    title: "PESSOAL",
    items: [{ icon: <Lightbulb size={15} />, label: "Banco de Ideias", path: "/meu-espaco", slug: "meu-espaco" }],
  },
  {
    title: "OPERACIONAL",
    items: [
      { icon: <LayoutDashboard size={15} />, label: "Painel do Dia", path: "/", slug: "dashboard" },
      { icon: <KanbanSquare size={15} />, label: "Kanban", path: "/kanban", slug: "kanban" },
      { icon: <CalendarDays size={15} />, label: "Calendário", path: "/calendar", slug: "calendar" },
      { icon: <Zap size={15} />, label: "Otimização", path: "/optimization", slug: "optimization" },
      { icon: <Palette size={15} />, label: "Criativos", path: "/criativos", slug: "criativos" },
      { icon: <Link2 size={15} />, label: "Links", path: "/links", slug: "links" },
    ],
  },
  {
    title: "GESTÃO DE CONTAS",
    items: [
      { icon: <Users size={15} />, label: "Clientes", path: "/clients", slug: "clients" },
      {
        icon: <Share2 size={15} />,
        label: "Social Media",
        adminOnly: true,
        children: [{ label: "Instagram" }, { label: "Facebook" }, { label: "LinkedIn" }],
      },
      {
        icon: <Mail size={15} />,
        label: "E-mail",
        adminOnly: true,
        children: [{ label: "Campanhas" }, { label: "Automações" }],
      },
    ],
  },
  {
    title: "COMERCIAL",
    items: [
      { icon: <Target size={15} />, label: "Prospecção", path: "/prospeccao", slug: "prospeccao" },
    ],
  },
  {
    title: "ANÁLISE & FINANCEIRO",
    items: [
      { icon: <BarChart2 size={15} />, label: "Dashboard", path: "/dashboard", slug: "analysis-dashboard" },
      { icon: <TrendingUp size={15} />, label: "CRO & UX", adminOnly: true },
      { icon: <DollarSign size={15} />, label: "Financeiro", path: "/financeiro", slug: "financial" },
      { icon: <Calculator size={15} />, label: "Precificação", path: "/precificacao", slug: "pricing" },
    ],
  },
  {
    title: "CONFIGURAÇÕES",
    items: [
      { icon: <Link2 size={15} />, label: "Integrações", path: "/integracoes", adminOnly: true },
    ],
  },
];

// ---------- Sortable wrappers ----------

function SortableItemRow({ id, children }: { id: string; children: React.ReactNode }) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id });
  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };
  return (
    <li ref={setNodeRef} style={style} className="flex items-center gap-1">
      <button
        {...attributes}
        {...listeners}
        className="p-1 text-sidebar-foreground/40 hover:text-sidebar-accent-foreground cursor-grab active:cursor-grabbing touch-none"
        aria-label="Arrastar"
      >
        <GripVertical size={12} />
      </button>
      <div className="flex-1 min-w-0">{children}</div>
    </li>
  );
}

function SortableSectionBlock({ id, children }: { id: string; children: React.ReactNode }) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id });
  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };
  return (
    <div ref={setNodeRef} style={style} className="rounded-md ring-1 ring-sidebar-border/40 p-1">
      <div className="flex items-center gap-1 px-1 mb-1">
        <button
          {...attributes}
          {...listeners}
          className="p-1 text-sidebar-foreground/40 hover:text-sidebar-accent-foreground cursor-grab active:cursor-grabbing touch-none"
          aria-label="Arrastar seção"
        >
          <GripVertical size={12} />
        </button>
        <div className="flex-1 min-w-0">{children}</div>
      </div>
    </div>
  );
}

// ---------- Main component ----------

export function DashboardSidebar() {
  const [expanded, setExpanded] = useState<string[]>([]);
  const [isAdmin, setIsAdmin] = useState(false);
  const [profileName, setProfileName] = useState<string | null>(null);
  const [profileAvatar, setProfileAvatar] = useState<string | null>(null);
  const navigate = useNavigate();
  const location = useLocation();
  const { user, signOut } = useAuth();
  const { data: branding } = useAppSettings();
  const { data: perms, isLoading: permsLoading } = useUserPermissions();
  const { collapsed, setCollapsed, isMobile } = useSidebarCollapsed();
  const { data: navOrderData } = useNavOrder();
  const saveNavOrder = useSaveNavOrder();

  const [editMode, setEditMode] = useState(false);
  const [draftOrder, setDraftOrder] = useState<NavOrder | null>(null);

  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 4 } }));

  // The sections shown to the current user (filtered + ordered by stored or draft order)
  const visibleSections = useMemo(() => {
    const filtered = sections
      .map((section) => ({
        ...section,
        items: section.items.filter((item) => {
          if (perms?.isAdmin) return true;
          if (item.adminOnly) return false;
          if (item.slug) return perms?.allowedSlugs.has(item.slug) ?? false;
          return false;
        }),
      }))
      // Keep empty sections in edit mode so user can drop items back into them
      .filter((s) => editMode || s.items.length > 0);

    const activeOrder = editMode ? draftOrder : navOrderData?.order;
    return applyNavOrder(filtered, activeOrder ?? undefined);
  }, [perms, navOrderData, editMode, draftOrder]);

  useEffect(() => {
    if (user) {
      checkUserRole();
      fetchProfile();
    }
    const handler = () => fetchProfile();
    window.addEventListener("profile-updated", handler);
    return () => window.removeEventListener("profile-updated", handler);
  }, [user]);

  const checkUserRole = async () => {
    if (!user) return;
    const { data } = await supabase.rpc("has_role", { _user_id: user.id, _role: "admin" });
    setIsAdmin(!!data);
  };

  const fetchProfile = async () => {
    if (!user) return;
    const { data } = await supabase
      .from("profiles")
      .select("display_name, avatar_url")
      .eq("user_id", user.id)
      .single();
    if (data) {
      setProfileName(data.display_name);
      setProfileAvatar(data.avatar_url);
    }
  };

  const toggle = (label: string) => {
    setExpanded((prev) => (prev.includes(label) ? prev.filter((l) => l !== label) : [...prev, label]));
  };

  const isActive = (item: NavItem) => item.path && location.pathname === item.path;

  const handleSignOut = async () => {
    await signOut();
    navigate("/auth");
  };

  const startEdit = () => {
    // Seed draft from current visible order so unsaved order matches what user sees
    const seed: NavOrder = {
      sections: visibleSections.map((s) => s.title),
      items: Object.fromEntries(visibleSections.map((s) => [s.title, s.items.map((i) => i.label)])),
    };
    setDraftOrder(seed);
    setEditMode(true);
  };

  const cancelEdit = () => {
    setEditMode(false);
    setDraftOrder(null);
  };

  const saveEdit = async () => {
    if (!draftOrder) return;
    try {
      await saveNavOrder.mutateAsync({ id: navOrderData?.id ?? "", order: draftOrder });
      toast.success("Ordem do menu salva");
      setEditMode(false);
      setDraftOrder(null);
    } catch (e: any) {
      toast.error(e?.message ?? "Erro ao salvar ordem");
    }
  };

  const handleDragEnd = (e: DragEndEvent) => {
    if (!draftOrder) return;
    const { active, over } = e;
    if (!over) return;
    const a = String(active.id);
    const o = String(over.id);
    if (a === o) return;

    // Section reorder
    if (a.startsWith(SECTION_PREFIX) && o.startsWith(SECTION_PREFIX)) {
      const list = draftOrder.sections ?? visibleSections.map((s) => s.title);
      const from = list.indexOf(a.slice(SECTION_PREFIX.length));
      const to = list.indexOf(o.slice(SECTION_PREFIX.length));
      if (from < 0 || to < 0) return;
      setDraftOrder({ ...draftOrder, sections: arrayMove(list, from, to) });
      return;
    }

    // Item move (within or across sections)
    if (!a.startsWith(ITEM_PREFIX)) return;
    const [, srcSection, ...labelParts] = a.slice(ITEM_PREFIX.length).split("::").length
      ? [ITEM_PREFIX, ...a.slice(ITEM_PREFIX.length).split("::")]
      : [];
    // Simpler: re-parse
    const aBody = a.slice(ITEM_PREFIX.length);
    const sepA = aBody.indexOf("::");
    const aSection = aBody.slice(0, sepA);
    const aLabel = aBody.slice(sepA + 2);

    let dstSection: string;
    let dstIndex: number;
    const currentItemsFor = (title: string) =>
      draftOrder.items?.[title] ??
      visibleSections.find((s) => s.title === title)?.items.map((i) => i.label) ??
      [];

    if (o.startsWith(ITEM_PREFIX)) {
      const oBody = o.slice(ITEM_PREFIX.length);
      const sepO = oBody.indexOf("::");
      dstSection = oBody.slice(0, sepO);
      const oLabel = oBody.slice(sepO + 2);
      const dstItems = currentItemsFor(dstSection);
      dstIndex = dstItems.indexOf(oLabel);
      if (dstIndex < 0) dstIndex = dstItems.length;
    } else if (o.startsWith(SECTION_PREFIX)) {
      dstSection = o.slice(SECTION_PREFIX.length);
      dstIndex = currentItemsFor(dstSection).length;
    } else {
      return;
    }

    const items: Record<string, string[]> = { ...(draftOrder.items ?? {}) };
    // Ensure both source and destination lists are materialised
    items[aSection] = [...currentItemsFor(aSection)];
    if (aSection !== dstSection) items[dstSection] = [...currentItemsFor(dstSection)];

    if (aSection === dstSection) {
      const list = items[aSection];
      const from = list.indexOf(aLabel);
      if (from < 0) return;
      items[aSection] = arrayMove(list, from, dstIndex);
    } else {
      items[aSection] = items[aSection].filter((l) => l !== aLabel);
      const dst = [...items[dstSection]];
      dst.splice(dstIndex, 0, aLabel);
      items[dstSection] = dst;
    }

    setDraftOrder({ ...draftOrder, items });
    // suppress unused-warning helper
    void srcSection; void labelParts;
  };

  if (collapsed) {
    return (
      <button
        onClick={() => setCollapsed(false)}
        title="Abrir menu"
        className="fixed top-3 left-3 z-50 w-9 h-9 rounded-lg bg-sidebar border border-sidebar-border flex items-center justify-center text-sidebar-foreground hover:text-sidebar-accent-foreground hover:bg-sidebar-accent transition-colors shadow-md"
      >
        <PanelLeftOpen size={16} />
      </button>
    );
  }

  const renderItem = (item: NavItem) => {
    const isExpanded = expanded.includes(item.label);
    const active = isActive(item);
    return (
      <>
        <button
          onClick={() => {
            if (editMode) return;
            if (item.path) navigate(item.path);
            if (item.children) toggle(item.label);
          }}
          className={cn(
            "w-full flex items-center gap-2.5 px-2 py-2 rounded-lg text-sm transition-all duration-150",
            active
              ? "bg-accent/15 text-accent font-medium"
              : "text-sidebar-foreground hover:text-sidebar-accent-foreground hover:bg-sidebar-accent",
            editMode && "cursor-default"
          )}
        >
          <span className={cn(active ? "text-accent" : "text-sidebar-foreground/70")}>{item.icon}</span>
          <span className="flex-1 text-left">{item.label}</span>
          {item.children &&
            !editMode &&
            (isExpanded ? (
              <ChevronDown size={12} className="text-sidebar-foreground/50" />
            ) : (
              <ChevronRight size={12} className="text-sidebar-foreground/50" />
            ))}
        </button>
        {item.children && isExpanded && !editMode && (
          <ul className="ml-6 mt-0.5 space-y-0.5 border-l border-sidebar-border pl-3">
            {item.children.map((child) => (
              <li key={child.label}>
                <button className="w-full text-left text-[13px] text-sidebar-foreground hover:text-sidebar-accent-foreground py-1.5 px-2 rounded-md hover:bg-sidebar-accent transition-colors">
                  {child.label}
                </button>
              </li>
            ))}
          </ul>
        )}
      </>
    );
  };

  const renderSectionInner = (section: NavSection) => (
    <>
      <p className="px-2 mb-1.5 text-[10px] font-semibold tracking-widest text-sidebar-foreground/60 uppercase">
        {section.title}
      </p>
      {editMode ? (
        <SortableContext
          items={section.items.map((i) => itemId(section.title, i.label))}
          strategy={verticalListSortingStrategy}
        >
          <ul className="space-y-0.5 min-h-[8px]">
            {section.items.map((item) => (
              <SortableItemRow key={item.label} id={itemId(section.title, item.label)}>
                {renderItem(item)}
              </SortableItemRow>
            ))}
            {section.items.length === 0 && (
              <li className="text-[10px] italic text-sidebar-foreground/40 px-2 py-2">
                Solte um item aqui
              </li>
            )}
          </ul>
        </SortableContext>
      ) : (
        <ul className="space-y-0.5">
          {section.items.map((item) => (
            <li key={item.label}>{renderItem(item)}</li>
          ))}
        </ul>
      )}
    </>
  );

  return (
    <>
      {/* Mobile backdrop */}
      {isMobile && (
        <div
          onClick={() => setCollapsed(true)}
          className="fixed inset-0 bg-black/60 z-40 md:hidden"
        />
      )}
      <aside
        className={cn(
          "flex flex-col w-56 shrink-0 h-screen bg-sidebar border-r border-sidebar-border overflow-y-auto relative",
          isMobile && "fixed inset-y-0 left-0 z-50 shadow-2xl"
        )}
      >
        {/* Floating collapse tab on right edge */}
        <button
          onClick={() => setCollapsed(true)}
          title="Recolher menu"
          className="absolute top-4 -right-3 z-10 w-6 h-6 rounded-full bg-sidebar border border-sidebar-border flex items-center justify-center text-sidebar-foreground/70 hover:text-sidebar-accent-foreground hover:bg-sidebar-accent transition-colors shadow-md"
        >
          <PanelLeftClose size={12} />
        </button>

        {/* Logo */}
        <div className="px-4 py-4 border-b border-sidebar-border flex items-center gap-2.5 min-w-0">
          <div className="w-8 h-8 rounded-lg bg-accent flex items-center justify-center shrink-0 overflow-hidden">
            {branding?.logo_url ? (
              <img src={branding.logo_url} alt="Logo" className="w-full h-full object-cover" />
            ) : (
              <Boxes size={16} className="text-accent-foreground" />
            )}
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-sidebar-accent-foreground text-sm font-semibold leading-none truncate">
              {branding?.app_name || "Centralize"}
            </p>
            <p className="text-sidebar-foreground text-[10px] mt-0.5 uppercase tracking-widest truncate">Gestão Operacional</p>
          </div>
        </div>



      {/* Edit mode toolbar */}
      {editMode && (
        <div className="px-3 py-2 border-b border-sidebar-border bg-accent/5 flex items-center gap-2">
          <span className="text-[11px] text-sidebar-foreground/70 flex-1">Arraste para reordenar</span>
          <button
            onClick={cancelEdit}
            className="p-1.5 rounded-md text-sidebar-foreground/70 hover:text-destructive hover:bg-sidebar-accent transition-colors"
            title="Cancelar"
          >
            <X size={14} />
          </button>
          <button
            onClick={saveEdit}
            disabled={saveNavOrder.isPending}
            className="p-1.5 rounded-md text-accent hover:bg-sidebar-accent transition-colors disabled:opacity-50"
            title="Salvar"
          >
            <Check size={14} />
          </button>
        </div>
      )}

      {/* Nav sections */}
      <nav className="flex-1 py-4 px-2 space-y-5">
        {permsLoading ? null : editMode ? (
          <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
            <SortableContext
              items={visibleSections.map((s) => sectionId(s.title))}
              strategy={verticalListSortingStrategy}
            >
              <div className="space-y-3">
                {visibleSections.map((section) => (
                  <SortableSectionBlock key={section.title} id={sectionId(section.title)}>
                    {renderSectionInner(section)}
                  </SortableSectionBlock>
                ))}
              </div>
            </SortableContext>
          </DndContext>
        ) : (
          visibleSections.map((section) => <div key={section.title}>{renderSectionInner(section)}</div>)
        )}
      </nav>

      {/* Bottom user area */}
      <div className="border-t border-sidebar-border">
        {/* Edit menu (admin only) */}
        {isAdmin && !editMode && (
          <button
            onClick={startEdit}
            className="w-full px-4 py-2.5 flex items-center gap-2 text-[11px] text-sidebar-foreground/70 hover:text-sidebar-accent-foreground hover:bg-sidebar-accent transition-colors border-b border-sidebar-border"
          >
            <Pencil size={12} />
            <span>Editar menu</span>
          </button>
        )}

        {/* Only show admin shortcut if admin */}
        <div
          className={cn(
            "px-4 py-3 flex items-center gap-3 text-[11px] text-sidebar-foreground/60 transition-colors",
            isAdmin && "hover:bg-sidebar-accent cursor-pointer"
          )}
          onClick={() => isAdmin && navigate("/admin/users")}
        >
          {isAdmin ? (
            <div className="w-full flex items-center justify-between group">
              <span className="flex items-center gap-1.5">
                <Shield size={12} className="text-accent" />
                <span>Painel Admin</span>
              </span>
              <Settings size={12} className="opacity-0 group-hover:opacity-100 transition-opacity" />
            </div>
          ) : (
            <div className="flex items-center gap-3 w-full">
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-metric-green inline-block" />0
              </span>
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-metric-amber inline-block" />0
              </span>
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-metric-red inline-block" />0
              </span>
            </div>
          )}
        </div>

        <div className="px-3 py-3 flex items-center gap-2.5 border-t border-sidebar-border">
          <button
            onClick={() => navigate("/perfil")}
            className="w-8 h-8 rounded-full bg-accent/20 flex items-center justify-center shrink-0 overflow-hidden hover:ring-2 hover:ring-accent transition-all"
            title="Meu Perfil"
          >
            {profileAvatar ? (
              <img src={profileAvatar} alt="Avatar" className="w-full h-full object-cover" />
            ) : (
              <User size={14} className="text-accent" />
            )}
          </button>
          <button
            onClick={() => navigate("/perfil")}
            className="flex-1 min-w-0 text-left hover:opacity-80 transition-opacity"
          >
            <p className="text-sidebar-accent-foreground text-sm font-medium leading-none truncate">
              {profileName || user?.email?.split("@")[0] || "Usuário"}
            </p>
            <p className="text-sidebar-foreground text-xs mt-0.5">
              {isAdmin ? "Administrador" : "Colaborador"}
            </p>
          </button>
          <button
            onClick={handleSignOut}
            className="p-1.5 hover:bg-sidebar-accent rounded-md transition-colors text-sidebar-foreground/50 hover:text-destructive"
            title="Sair"
          >
            <LogOut size={14} />
          </button>
        </div>
      </div>
      </aside>
    </>
  );
}
