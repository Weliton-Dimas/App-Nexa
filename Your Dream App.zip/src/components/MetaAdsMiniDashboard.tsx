import { useMemo, useState } from "react";
import { Layers, Megaphone, MapPin } from "lucide-react";
import { cn } from "@/lib/utils";
import type { MetaAdsMetrics } from "@/hooks/useMetaAdsMetrics";

type SubTab = "plataformas" | "campanhas" | "regioes";

const formatCurrency = (v: number) =>
  v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
const formatInt = (v: number) => v.toLocaleString("pt-BR");
const formatPct = (v: number) => `${v.toFixed(2)}%`;

const platformLabel: Record<string, string> = {
  facebook: "Facebook",
  instagram: "Instagram",
  audience_network: "Audience Network",
  messenger: "Messenger",
  unknown: "Outros",
};

const platformColor: Record<string, string> = {
  facebook: "#1877F2",
  instagram: "#E1306C",
  audience_network: "#9333EA",
  messenger: "#00B2FF",
};

interface Props {
  metrics?: MetaAdsMetrics;
  loading: boolean;
}

export function MetaAdsMiniDashboard({ metrics, loading }: Props) {
  const [tab, setTab] = useState<SubTab>("plataformas");

  // Aggregate campaigns from adBreakdown (group by campaignName)
  const campaigns = useMemo(() => {
    if (!metrics?.adBreakdown) return [];
    const map = new Map<string, { name: string; spend: number; clicks: number; conversations: number; impressions: number; ads: number }>();
    for (const ad of metrics.adBreakdown) {
      const key = ad.campaignName || "Sem campanha";
      const cur = map.get(key) ?? { name: key, spend: 0, clicks: 0, conversations: 0, impressions: 0, ads: 0 };
      cur.spend += ad.spend;
      cur.clicks += ad.clicks;
      cur.conversations += ad.conversations;
      cur.impressions += ad.impressions;
      cur.ads += 1;
      map.set(key, cur);
    }
    return Array.from(map.values())
      .sort((a, b) => b.spend - a.spend)
      .slice(0, 5);
  }, [metrics]);

  const platforms = (metrics?.platformBreakdown ?? []).slice(0, 5);
  const regions = (metrics?.regionBreakdown ?? []).slice(0, 5);

  const tabs: { key: SubTab; label: string; icon: typeof Layers }[] = [
    { key: "plataformas", label: "Plataformas", icon: Layers },
    { key: "campanhas", label: "Top campanhas", icon: Megaphone },
    { key: "regioes", label: "Regiões", icon: MapPin },
  ];

  return (
    <div className="mt-4 rounded-lg border border-border/60 bg-secondary/20 overflow-hidden">
      {/* Sub-tabs */}
      <div className="flex border-b border-border/60">
        {tabs.map((t) => {
          const Icon = t.icon;
          const active = tab === t.key;
          return (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={cn(
                "flex-1 flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-medium transition-colors relative",
                active
                  ? "text-foreground bg-card"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              <Icon size={12} />
              {t.label}
              {active && <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-accent" />}
            </button>
          );
        })}
      </div>

      <div className="p-3">
        {loading ? (
          <div className="py-8 text-center text-xs text-muted-foreground">Carregando...</div>
        ) : tab === "plataformas" ? (
          platforms.length === 0 ? (
            <EmptyState text="Nenhum dado de plataforma disponível." />
          ) : (
            <table className="w-full text-xs">
              <thead>
                <tr className="text-muted-foreground">
                  <th className="text-left font-medium py-1.5">Plataforma</th>
                  <th className="text-right font-medium py-1.5">Investido</th>
                  <th className="text-right font-medium py-1.5">Cliques</th>
                  <th className="text-right font-medium py-1.5">Conversas</th>
                  <th className="text-right font-medium py-1.5">Alcance</th>
                </tr>
              </thead>
              <tbody>
                {platforms.map((p) => (
                  <tr key={p.platform} className="border-t border-border/40">
                    <td className="py-2">
                      <span className="inline-flex items-center gap-2">
                        <span
                          className="w-2 h-2 rounded-full"
                          style={{ backgroundColor: platformColor[p.platform] ?? "hsl(var(--muted-foreground))" }}
                        />
                        <span className="text-foreground font-medium capitalize">
                          {platformLabel[p.platform] ?? p.platform}
                        </span>
                      </span>
                    </td>
                    <td className="text-right tabular-nums text-foreground">{formatCurrency(p.spend)}</td>
                    <td className="text-right tabular-nums text-foreground">{formatInt(p.clicks)}</td>
                    <td className="text-right tabular-nums text-foreground">{formatInt(p.conversations)}</td>
                    <td className="text-right tabular-nums text-foreground">{formatInt(p.reach)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )
        ) : tab === "campanhas" ? (
          campaigns.length === 0 ? (
            <EmptyState text="Nenhuma campanha encontrada no período." />
          ) : (
            <table className="w-full text-xs">
              <thead>
                <tr className="text-muted-foreground">
                  <th className="text-left font-medium py-1.5">Campanha</th>
                  <th className="text-right font-medium py-1.5">Anúncios</th>
                  <th className="text-right font-medium py-1.5">Investido</th>
                  <th className="text-right font-medium py-1.5">Cliques</th>
                  <th className="text-right font-medium py-1.5">Conversas</th>
                </tr>
              </thead>
              <tbody>
                {campaigns.map((c) => (
                  <tr key={c.name} className="border-t border-border/40">
                    <td className="py-2 text-foreground font-medium max-w-[280px] truncate">{c.name}</td>
                    <td className="text-right tabular-nums text-foreground">{c.ads}</td>
                    <td className="text-right tabular-nums text-foreground">{formatCurrency(c.spend)}</td>
                    <td className="text-right tabular-nums text-foreground">{formatInt(c.clicks)}</td>
                    <td className="text-right tabular-nums text-foreground">{formatInt(c.conversations)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )
        ) : regions.length === 0 ? (
          <EmptyState text="Nenhum dado de região disponível." />
        ) : (
          <table className="w-full text-xs">
            <thead>
              <tr className="text-muted-foreground">
                <th className="text-left font-medium py-1.5">Região</th>
                <th className="text-right font-medium py-1.5">Investido</th>
                <th className="text-right font-medium py-1.5">Cliques</th>
                <th className="text-right font-medium py-1.5">Conversas</th>
                <th className="text-right font-medium py-1.5">Alcance</th>
              </tr>
            </thead>
            <tbody>
              {regions.map((r) => (
                <tr key={r.region} className="border-t border-border/40">
                  <td className="py-2 text-foreground font-medium">{r.region}</td>
                  <td className="text-right tabular-nums text-foreground">{formatCurrency(r.spend)}</td>
                  <td className="text-right tabular-nums text-foreground">{formatInt(r.clicks)}</td>
                  <td className="text-right tabular-nums text-foreground">{formatInt(r.conversations)}</td>
                  <td className="text-right tabular-nums text-foreground">{formatInt(r.reach)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

function EmptyState({ text }: { text: string }) {
  return (
    <div className="py-8 text-center text-xs text-muted-foreground">{text}</div>
  );
}
