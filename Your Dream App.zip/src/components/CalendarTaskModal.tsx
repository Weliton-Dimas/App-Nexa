import { useEffect, useState } from "react";
import { X, Trash2, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";
import { z } from "zod";
import { cn } from "@/lib/utils";

export interface CalendarTask {
  id: string;
  title: string;
  description: string | null;
  date: string; // YYYY-MM-DD
  status: string;
  priority: string;
  client_id: string | null;
  assignee_id: string | null;
  created_by: string;
  color: string;
}

interface ClientOpt { id: string; name: string }
interface UserOpt { user_id: string; display_name: string | null }

interface Props {
  open: boolean;
  onClose: () => void;
  date: Date;
  task: CalendarTask | null;
  clients: ClientOpt[];
  users: UserOpt[];
  onSaved: () => void;
}

const STATUSES = [
  { value: "nova", label: "Nova", color: "bg-metric-blue/20 text-metric-blue border-metric-blue/30" },
  { value: "em_andamento", label: "Em andamento", color: "bg-metric-amber/20 text-metric-amber border-metric-amber/30" },
  { value: "concluida", label: "Concluída", color: "bg-metric-green/20 text-metric-green border-metric-green/30" },
  { value: "cancelada", label: "Cancelada", color: "bg-metric-red/20 text-metric-red border-metric-red/30" },
];

const PRIORITIES = [
  { value: "baixa", label: "Baixa" },
  { value: "media", label: "Média" },
  { value: "alta", label: "Alta" },
  { value: "urgente", label: "Urgente" },
];

const COLORS = ["blue", "green", "amber", "red"] as const;
const colorBg: Record<string, string> = {
  blue: "bg-metric-blue",
  green: "bg-metric-green",
  amber: "bg-metric-amber",
  red: "bg-metric-red",
};

const taskSchema = z.object({
  title: z.string().trim().min(1, "Título obrigatório").max(200, "Máx. 200 caracteres"),
  description: z.string().trim().max(2000, "Máx. 2000 caracteres").optional(),
});

function toIsoDate(d: Date) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${dd}`;
}

export function CalendarTaskModal({ open, onClose, date, task, clients, users, onSaved }: Props) {
  const { user } = useAuth();
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [status, setStatus] = useState("nova");
  const [priority, setPriority] = useState("media");
  const [clientId, setClientId] = useState<string>("");
  const [assigneeId, setAssigneeId] = useState<string>("");
  const [color, setColor] = useState<string>("blue");
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    if (!open) return;
    if (task) {
      setTitle(task.title);
      setDescription(task.description ?? "");
      setStatus(task.status);
      setPriority(task.priority);
      setClientId(task.client_id ?? "");
      setAssigneeId(task.assignee_id ?? "");
      setColor(task.color);
    } else {
      setTitle("");
      setDescription("");
      setStatus("nova");
      setPriority("media");
      setClientId("");
      setAssigneeId(user?.id ?? "");
      setColor("blue");
    }
  }, [open, task, user]);

  if (!open) return null;

  const handleSave = async () => {
    const parsed = taskSchema.safeParse({ title, description });
    if (!parsed.success) {
      toast.error(parsed.error.issues[0].message);
      return;
    }
    if (!user) return;
    setSaving(true);

    const payload = {
      title: parsed.data.title,
      description: parsed.data.description || null,
      date: toIsoDate(date),
      status,
      priority,
      client_id: clientId || null,
      assignee_id: assigneeId || null,
      color,
    };

    if (task) {
      const { error } = await supabase
        .from("calendar_tasks")
        .update(payload)
        .eq("id", task.id);
      if (error) toast.error("Erro ao salvar: " + error.message);
      else { toast.success("Tarefa atualizada"); onSaved(); onClose(); }
    } else {
      const { error } = await supabase
        .from("calendar_tasks")
        .insert({ ...payload, created_by: user.id });
      if (error) toast.error("Erro ao criar: " + error.message);
      else { toast.success("Tarefa criada"); onSaved(); onClose(); }
    }
    setSaving(false);
  };

  const handleDelete = async () => {
    if (!task) return;
    if (!confirm("Excluir esta tarefa?")) return;
    setDeleting(true);
    const { error } = await supabase.from("calendar_tasks").delete().eq("id", task.id);
    if (error) toast.error("Erro ao excluir: " + error.message);
    else { toast.success("Tarefa excluída"); onSaved(); onClose(); }
    setDeleting(false);
  };

  const dateLabel = date.toLocaleDateString("pt-BR", {
    weekday: "long", day: "2-digit", month: "long", year: "numeric",
  });

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div
        className="bg-card border border-border rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-border sticky top-0 bg-card z-10">
          <p className="text-xs text-muted-foreground capitalize">{dateLabel}</p>
          <div className="flex items-center gap-1">
            {task && (
              <button
                onClick={handleDelete}
                disabled={deleting}
                className="p-1.5 rounded-lg text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors"
                title="Excluir"
              >
                {deleting ? <Loader2 size={14} className="animate-spin" /> : <Trash2 size={14} />}
              </button>
            )}
            <button onClick={onClose} className="p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
              <X size={14} />
            </button>
          </div>
        </div>

        <div className="px-6 py-5 space-y-5">
          {/* Title */}
          <input
            autoFocus={!task}
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Nova tarefa"
            className="w-full bg-transparent text-2xl font-bold text-foreground placeholder:text-muted-foreground/40 outline-none"
            maxLength={200}
          />

          {/* Properties grid */}
          <div className="space-y-2.5">
            <Row label="Cliente">
              <select
                value={clientId}
                onChange={(e) => setClientId(e.target.value)}
                className="w-full bg-transparent text-sm text-foreground outline-none hover:bg-secondary/50 rounded px-2 py-1 -mx-2 cursor-pointer"
              >
                <option value="">Vazio</option>
                {clients.map((c) => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
            </Row>

            <Row label="Status">
              <div className="flex flex-wrap gap-1.5">
                {STATUSES.map((s) => (
                  <button
                    key={s.value}
                    onClick={() => setStatus(s.value)}
                    className={cn(
                      "text-xs px-2.5 py-1 rounded-md border transition-all",
                      status === s.value ? s.color : "border-border text-muted-foreground hover:text-foreground"
                    )}
                  >
                    {s.label}
                  </button>
                ))}
              </div>
            </Row>

            <Row label="Prioridade">
              <div className="flex flex-wrap gap-1.5">
                {PRIORITIES.map((p) => (
                  <button
                    key={p.value}
                    onClick={() => setPriority(p.value)}
                    className={cn(
                      "text-xs px-2.5 py-1 rounded-md border transition-all",
                      priority === p.value
                        ? "bg-accent/15 text-accent border-accent/30"
                        : "border-border text-muted-foreground hover:text-foreground"
                    )}
                  >
                    {p.label}
                  </button>
                ))}
              </div>
            </Row>

            <Row label="Responsável">
              <select
                value={assigneeId}
                onChange={(e) => setAssigneeId(e.target.value)}
                className="w-full bg-transparent text-sm text-foreground outline-none hover:bg-secondary/50 rounded px-2 py-1 -mx-2 cursor-pointer"
              >
                <option value="">Sem responsável</option>
                {users.map((u) => (
                  <option key={u.user_id} value={u.user_id}>
                    {u.display_name || "Usuário"}
                  </option>
                ))}
              </select>
            </Row>

            <Row label="Cor">
              <div className="flex gap-1.5">
                {COLORS.map((c) => (
                  <button
                    key={c}
                    onClick={() => setColor(c)}
                    className={cn(
                      "w-6 h-6 rounded-full transition-all",
                      colorBg[c],
                      color === c ? "ring-2 ring-offset-2 ring-offset-card ring-foreground scale-110" : "opacity-70"
                    )}
                  />
                ))}
              </div>
            </Row>
          </div>

          {/* Description */}
          <div className="pt-3 border-t border-border">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Descrição</p>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Adicione detalhes sobre a tarefa..."
              rows={6}
              className="w-full bg-secondary/40 border border-border rounded-lg px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground/50 outline-none focus:border-accent resize-none"
              maxLength={2000}
            />
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-border flex justify-end gap-2 sticky bottom-0 bg-card">
          <button
            onClick={onClose}
            className="text-sm text-muted-foreground hover:text-foreground px-4 py-2 rounded-lg hover:bg-secondary transition-colors"
          >
            Cancelar
          </button>
          <button
            onClick={handleSave}
            disabled={saving}
            className="text-sm bg-accent text-accent-foreground px-4 py-2 rounded-lg font-medium hover:bg-accent/90 transition-colors disabled:opacity-50 flex items-center gap-2"
          >
            {saving && <Loader2 size={13} className="animate-spin" />}
            {task ? "Salvar" : "Criar tarefa"}
          </button>
        </div>
      </div>
    </div>
  );
}

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="grid grid-cols-[140px_1fr] items-center gap-3">
      <span className="text-xs font-medium text-muted-foreground">{label}</span>
      <div>{children}</div>
    </div>
  );
}
