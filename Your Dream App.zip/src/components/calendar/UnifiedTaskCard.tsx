import { cn } from "@/lib/utils";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ArrowRight, Layout } from "lucide-react";
import type { UnifiedTask } from "@/hooks/useUnifiedTasks";

const COLOR_BAR: Record<string, string> = {
  green: "bg-metric-green",
  blue: "bg-metric-blue",
  amber: "bg-metric-amber",
  red: "bg-metric-red",
  purple: "bg-purple-500",
  pink: "bg-pink-500",
};

const PRIORITY_BADGE: Record<string, { label: string; cls: string }> = {
  urgente: { label: "Urgente", cls: "bg-metric-red/20 text-metric-red border-metric-red/30" },
  alta: { label: "Imp. Urg.", cls: "bg-metric-red/20 text-metric-red border-metric-red/30" },
  media: { label: "Não Urg. e Imp.", cls: "bg-metric-amber/20 text-metric-amber border-metric-amber/30" },
  baixa: { label: "Baixa", cls: "bg-metric-blue/20 text-metric-blue border-metric-blue/30" },
};

interface Props {
  task: UnifiedTask;
  onClick?: () => void;
  showDate?: boolean;
  showProgress?: boolean;
}

export function UnifiedTaskCard({ task, onClick, showDate, showProgress }: Props) {
  const bar = COLOR_BAR[task.color] ?? COLOR_BAR.blue;
  const prio = task.priority ? PRIORITY_BADGE[task.priority] : null;

  return (
    <button
      type="button"
      onClick={onClick}
      className="w-full text-left bg-secondary/50 hover:bg-secondary border border-border rounded-lg p-3 transition-colors group"
    >
      <div className="flex items-start gap-2">
        <div className={cn("w-1 self-stretch rounded-full shrink-0", bar)} />
        <div className="flex-1 min-w-0 space-y-2">
          <div className="flex items-start justify-between gap-2">
            <p className="text-sm font-medium text-foreground line-clamp-2">{task.title}</p>
            {task.source === "kanban" && (
              <span title="Vindo do Kanban"><Layout size={11} className="text-muted-foreground/60 shrink-0 mt-1" /></span>
            )}
          </div>

          {task.clientName && (
            <p className="text-xs text-muted-foreground flex items-center gap-1.5">
              <ArrowRight size={10} className="text-metric-green" />
              {task.clientName}
            </p>
          )}

          {showDate && task.date && (
            <p className="text-[10px] text-muted-foreground">
              {new Date(task.date + "T00:00:00").toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit", year: "numeric" })}
            </p>
          )}

          <div className="flex items-center flex-wrap gap-1.5">
            {task.assignees.slice(0, 3).map((a) => (
              <div key={a.id} className="flex items-center gap-1 text-[10px] text-muted-foreground">
                <Avatar className="h-4 w-4">
                  {a.avatar && <AvatarImage src={a.avatar} />}
                  <AvatarFallback className="text-[8px]">{a.name?.[0]?.toUpperCase() ?? "U"}</AvatarFallback>
                </Avatar>
                <span className="truncate max-w-[80px]">{a.name}</span>
              </div>
            ))}
          </div>

          <div className="flex items-center flex-wrap gap-1">
            {prio && (
              <span className={cn("text-[10px] px-1.5 py-0.5 rounded border", prio.cls)}>
                {prio.label}
              </span>
            )}
            {task.labels.slice(0, 2).map((l) => (
              <span key={l.name} className="text-[10px] px-1.5 py-0.5 rounded border border-border bg-card text-muted-foreground">
                {l.name}
              </span>
            ))}
            {showProgress && (
              <span className="text-[10px] px-1.5 py-0.5 rounded border border-border bg-card text-muted-foreground">
                {task.progressLabel}
              </span>
            )}
          </div>
        </div>
      </div>
    </button>
  );
}
