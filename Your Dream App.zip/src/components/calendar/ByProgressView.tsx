import { useMemo } from "react";
import type { UnifiedTask } from "@/hooks/useUnifiedTasks";
import { UnifiedTaskCard } from "./UnifiedTaskCard";

interface ProgressGroup { key: string; label: string }

interface Props {
  tasks: UnifiedTask[];
  groups: ProgressGroup[];
  onTaskClick: (t: UnifiedTask) => void;
}

export function ByProgressView({ tasks, groups, onTaskClick }: Props) {
  const grouped = useMemo(() => {
    const map = new Map<string, UnifiedTask[]>();
    for (const g of groups) map.set(g.key, []);
    for (const t of tasks) {
      const list = map.get(t.progressKey);
      if (list) list.push(t);
    }
    return map;
  }, [tasks, groups]);

  const visibleGroups = groups.filter((g) => (grouped.get(g.key)?.length ?? 0) > 0);

  return (
    <div className="h-full overflow-x-auto overflow-y-hidden">
      <div className="flex gap-4 h-full pb-4 min-w-min">
        {visibleGroups.map((g) => {
          const list = grouped.get(g.key) ?? [];
          return (
            <div key={g.key} className="w-72 shrink-0 flex flex-col">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-semibold uppercase tracking-wider text-foreground px-2 py-1 rounded bg-secondary">
                  {g.label}
                </span>
                <span className="text-[10px] text-muted-foreground">{list.length}</span>
              </div>
              <div className="flex-1 overflow-y-auto space-y-2 pr-1">
                {list.map((t) => (
                  <UnifiedTaskCard key={t.id} task={t} onClick={() => onTaskClick(t)} showDate />
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
