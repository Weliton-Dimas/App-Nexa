import { useMemo } from "react";
import { cn } from "@/lib/utils";
import type { UnifiedTask } from "@/hooks/useUnifiedTasks";

const COLOR_BAR: Record<string, string> = {
  green: "bg-metric-green",
  blue: "bg-metric-blue",
  amber: "bg-metric-amber",
  red: "bg-metric-red",
  purple: "bg-purple-500",
  pink: "bg-pink-500",
};

interface Props {
  tasks: UnifiedTask[];
  year: number;
  month: number; // 0-11
  onTaskClick: (t: UnifiedTask) => void;
}

function isoToDate(s: string) {
  const [y, m, d] = s.split("-").map(Number);
  return new Date(y, m - 1, d);
}

export function TimelineView({ tasks, year, month, onTaskClick }: Props) {
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const monthStart = new Date(year, month, 1);
  const monthEnd = new Date(year, month, daysInMonth);

  const rows = useMemo(() => {
    return tasks
      .filter((t) => t.date)
      .map((t) => {
        const end = isoToDate(t.date!);
        const start = t.startDate ? isoToDate(t.startDate) : end;
        return { task: t, start, end };
      })
      .filter((r) => r.end >= monthStart && r.start <= monthEnd)
      .sort((a, b) => a.start.getTime() - b.start.getTime());
  }, [tasks, year, month, monthStart, monthEnd]);

  const today = new Date();
  const todayIdx = today.getFullYear() === year && today.getMonth() === month ? today.getDate() : -1;

  return (
    <div className="h-full flex flex-col rounded-xl border border-border bg-card overflow-hidden">
      <div className="overflow-auto">
        <div className="min-w-max">
          {/* Header de dias */}
          <div
            className="grid sticky top-0 z-10 bg-card border-b border-border"
            style={{ gridTemplateColumns: `200px repeat(${daysInMonth}, 36px)` }}
          >
            <div className="px-3 py-2 text-xs font-semibold text-muted-foreground border-r border-border">
              Tarefa
            </div>
            {Array.from({ length: daysInMonth }, (_, i) => i + 1).map((d) => (
              <div
                key={d}
                className={cn(
                  "text-center py-2 text-[10px] border-r border-border",
                  d === todayIdx ? "text-accent font-semibold" : "text-muted-foreground",
                )}
              >
                {d}
              </div>
            ))}
          </div>

          {rows.length === 0 ? (
            <p className="px-6 py-10 text-sm text-muted-foreground text-center">
              Nenhuma tarefa neste mês.
            </p>
          ) : (
            rows.map(({ task, start, end }) => {
              const startDay = Math.max(1, start.getMonth() === month ? start.getDate() : 1);
              const endDay = Math.min(
                daysInMonth,
                end.getMonth() === month ? end.getDate() : daysInMonth,
              );
              const span = Math.max(1, endDay - startDay + 1);
              const bar = COLOR_BAR[task.color] ?? COLOR_BAR.blue;
              return (
                <div
                  key={task.id}
                  className="grid border-b border-border hover:bg-secondary/30 transition-colors"
                  style={{ gridTemplateColumns: `200px repeat(${daysInMonth}, 36px)` }}
                >
                  <button
                    type="button"
                    onClick={() => onTaskClick(task)}
                    className="px-3 py-2 text-xs text-left text-foreground truncate border-r border-border hover:text-accent"
                    title={task.title}
                  >
                    {task.title}
                  </button>
                  <div className="relative col-span-full" style={{ gridColumn: `2 / span ${daysInMonth}` }}>
                    <div className="relative h-9">
                      <button
                        type="button"
                        onClick={() => onTaskClick(task)}
                        className={cn(
                          "absolute top-1.5 h-6 rounded-md opacity-80 hover:opacity-100 transition-opacity text-[10px] text-white px-2 truncate text-left",
                          bar,
                        )}
                        style={{
                          left: `${(startDay - 1) * 36}px`,
                          width: `${span * 36 - 4}px`,
                        }}
                      >
                        {task.clientName || task.title}
                      </button>
                      {todayIdx > 0 && (
                        <div
                          className="absolute top-0 bottom-0 w-px bg-accent/40"
                          style={{ left: `${(todayIdx - 1) * 36 + 18}px` }}
                        />
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}
