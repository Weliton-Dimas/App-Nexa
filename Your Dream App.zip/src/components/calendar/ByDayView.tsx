import { useMemo } from "react";
import { Plus } from "lucide-react";
import type { UnifiedTask } from "@/hooks/useUnifiedTasks";
import { UnifiedTaskCard } from "./UnifiedTaskCard";

interface Props {
  tasks: UnifiedTask[];
  daysAhead?: number;
  onTaskClick: (t: UnifiedTask) => void;
  onAddForDate: (date: Date) => void;
}

function fmt(d: Date) {
  return d.toLocaleDateString("pt-BR", { day: "2-digit", month: "short", year: "numeric" }).replace(".", "");
}
function iso(d: Date) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${dd}`;
}

export function ByDayView({ tasks, daysAhead = 14, onTaskClick, onAddForDate }: Props) {
  const days = useMemo(() => {
    const arr: Date[] = [];
    const start = new Date();
    start.setHours(0, 0, 0, 0);
    for (let i = 0; i < daysAhead; i++) {
      const d = new Date(start);
      d.setDate(start.getDate() + i);
      arr.push(d);
    }
    return arr;
  }, [daysAhead]);

  const byDay = useMemo(() => {
    const map = new Map<string, UnifiedTask[]>();
    for (const t of tasks) {
      if (!t.date) continue;
      const list = map.get(t.date) ?? [];
      list.push(t);
      map.set(t.date, list);
    }
    return map;
  }, [tasks]);

  return (
    <div className="h-full overflow-x-auto overflow-y-hidden">
      <div className="flex gap-4 h-full pb-4 min-w-min">
        {days.map((d) => {
          const key = iso(d);
          const list = byDay.get(key) ?? [];
          return (
            <div key={key} className="w-72 shrink-0 flex flex-col">
              <p className="text-sm font-semibold text-foreground mb-3 capitalize">{fmt(d)}</p>
              <div className="flex-1 overflow-y-auto space-y-2 pr-1">
                {list.map((t) => (
                  <UnifiedTaskCard key={t.id} task={t} onClick={() => onTaskClick(t)} />
                ))}
                <button
                  onClick={() => onAddForDate(d)}
                  className="w-full flex items-center gap-2 text-xs text-muted-foreground hover:text-foreground border border-dashed border-border rounded-lg py-2 px-3 hover:bg-secondary/40 transition-colors"
                >
                  <Plus size={12} /> Nova tarefa
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
