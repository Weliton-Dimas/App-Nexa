import { useState } from "react";
import { Calendar as CalendarIcon, Flag, Plus, X, ChevronDown } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Calendar } from "@/components/ui/calendar";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";
import type { DateRange } from "react-day-picker";

export type PriorityKey = "urgente" | "alta" | "media" | "baixa" | "none";
export const PRIORITY_OPTIONS: { key: PriorityKey; label: string; dot: string }[] = [
  { key: "urgente", label: "Urgente", dot: "bg-red-500" },
  { key: "alta",    label: "Alta",    dot: "bg-orange-500" },
  { key: "media",   label: "Média",   dot: "bg-yellow-500" },
  { key: "baixa",   label: "Baixa",   dot: "bg-sky-500" },
  { key: "none",    label: "Sem prioridade", dot: "bg-muted-foreground/40" },
];

export type DatePreset =
  | { kind: "preset"; value: "hoje"|"amanha"|"semana"|"prox7"|"atrasados"|"semdata" }
  | { kind: "range"; from: Date; to?: Date };

export interface KanbanFiltersState {
  priorities: PriorityKey[];
  date: DatePreset | null;
}

export const EMPTY_FILTERS: KanbanFiltersState = { priorities: [], date: null };

export function dateLabel(d: DatePreset): string {
  if (d.kind === "preset") {
    return { hoje:"Hoje", amanha:"Amanhã", semana:"Esta semana", prox7:"Próximos 7 dias", atrasados:"Atrasados", semdata:"Sem data" }[d.value];
  }
  const f = format(d.from, "d MMM", { locale: ptBR });
  const t = d.to ? format(d.to, "d MMM", { locale: ptBR }) : null;
  return t && t !== f ? `${f} – ${t}` : f;
}

interface Props {
  state: KanbanFiltersState;
  onChange: (s: KanbanFiltersState) => void;
}

export function KanbanFilters({ state, onChange }: Props) {
  const hasPriority = state.priorities.length > 0;
  const hasDate = state.date !== null;
  const activeCount = (hasPriority?1:0) + (hasDate?1:0);

  const togglePriority = (k: PriorityKey) => {
    const s = new Set(state.priorities);
    s.has(k) ? s.delete(k) : s.add(k);
    onChange({ ...state, priorities: Array.from(s) });
  };

  return (
    <div className="flex items-center gap-2 flex-wrap">
      {hasPriority && (
        <FilterChip
          icon={<Flag size={12}/>}
          label="Prioridade"
          value={state.priorities.map(p => PRIORITY_OPTIONS.find(o=>o.key===p)?.label).filter(Boolean).join(", ")}
          onClear={()=>onChange({ ...state, priorities: [] })}
          popover={
            <PriorityPopoverBody selected={state.priorities} onToggle={togglePriority} onClear={()=>onChange({ ...state, priorities: [] })}/>
          }
        />
      )}
      {hasDate && state.date && (
        <FilterChip
          icon={<CalendarIcon size={12}/>}
          label="Vencimento"
          value={dateLabel(state.date)}
          onClear={()=>onChange({ ...state, date: null })}
          popover={<DatePopoverBody value={state.date} onChange={(d)=>onChange({ ...state, date: d })}/>}
        />
      )}

      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <button className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground border border-dashed border-border rounded-md px-2.5 py-1 hover:bg-secondary/60">
            <Plus size={12}/> Filtro
          </button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="start" className="w-44">
          {!hasPriority && (
            <PopoverDropdownItem
              icon={<Flag size={12}/>} label="Prioridade"
              body={<PriorityPopoverBody selected={state.priorities} onToggle={togglePriority} onClear={()=>onChange({ ...state, priorities: [] })}/>}
            />
          )}
          {!hasDate && (
            <PopoverDropdownItem
              icon={<CalendarIcon size={12}/>} label="Vencimento"
              body={<DatePopoverBody value={state.date} onChange={(d)=>onChange({ ...state, date: d })}/>}
            />
          )}
          {hasPriority && hasDate && (
            <DropdownMenuItem disabled className="text-xs text-muted-foreground">Nenhum filtro disponível</DropdownMenuItem>
          )}
        </DropdownMenuContent>
      </DropdownMenu>

      {activeCount >= 2 && (
        <button onClick={()=>onChange(EMPTY_FILTERS)} className="text-xs text-muted-foreground hover:text-foreground px-1.5">
          Limpar tudo
        </button>
      )}
    </div>
  );
}

function FilterChip({ icon, label, value, onClear, popover }: { icon: React.ReactNode; label: string; value: string; onClear: ()=>void; popover: React.ReactNode }) {
  return (
    <div className="inline-flex items-center bg-secondary border border-border rounded-md text-xs h-7 overflow-hidden">
      <Popover>
        <PopoverTrigger asChild>
          <button className="inline-flex items-center gap-1.5 px-2.5 h-full hover:bg-secondary/60">
            <span className="text-muted-foreground">{icon}</span>
            <span className="text-muted-foreground">{label}:</span>
            <span className="text-foreground font-medium truncate max-w-[160px]">{value}</span>
            <ChevronDown size={11} className="text-muted-foreground"/>
          </button>
        </PopoverTrigger>
        <PopoverContent align="start" className="w-64 p-3">{popover}</PopoverContent>
      </Popover>
      <button onClick={onClear} className="px-1.5 h-full text-muted-foreground hover:text-foreground border-l border-border" aria-label="Remover filtro">
        <X size={11}/>
      </button>
    </div>
  );
}

function PopoverDropdownItem({ icon, label, body }: { icon: React.ReactNode; label: string; body: React.ReactNode }) {
  // We render a popover inside the dropdown row; clicking opens it
  return (
    <Popover>
      <PopoverTrigger asChild>
        <button className="w-full text-left flex items-center gap-2 px-2 py-1.5 text-sm hover:bg-secondary rounded-sm">
          <span className="text-muted-foreground">{icon}</span>{label}
        </button>
      </PopoverTrigger>
      <PopoverContent align="start" className="w-64 p-3">{body}</PopoverContent>
    </Popover>
  );
}

function PriorityPopoverBody({ selected, onToggle, onClear }: { selected: PriorityKey[]; onToggle: (k: PriorityKey)=>void; onClear: ()=>void }) {
  return (
    <div className="space-y-1">
      <div className="text-xs font-semibold text-muted-foreground px-1 pb-1">Prioridade</div>
      {PRIORITY_OPTIONS.map(o => (
        <label key={o.key} className="flex items-center gap-2 px-1.5 py-1 rounded hover:bg-secondary cursor-pointer">
          <Checkbox checked={selected.includes(o.key)} onCheckedChange={()=>onToggle(o.key)}/>
          <span className={cn("h-2 w-2 rounded-full", o.dot)}/>
          <span className="text-sm flex-1">{o.label}</span>
        </label>
      ))}
      {selected.length > 0 && (
        <button onClick={onClear} className="w-full text-xs text-muted-foreground hover:text-foreground pt-2 mt-1 border-t border-border">Limpar</button>
      )}
    </div>
  );
}

function DatePopoverBody({ value, onChange }: { value: DatePreset | null; onChange: (d: DatePreset | null)=>void }) {
  const [showRange, setShowRange] = useState(value?.kind === "range");
  const [range, setRange] = useState<DateRange | undefined>(
    value?.kind === "range" ? { from: value.from, to: value.to } : undefined
  );
  const presets: { v: any; label: string }[] = [
    { v: "hoje", label: "Hoje" },
    { v: "amanha", label: "Amanhã" },
    { v: "semana", label: "Esta semana" },
    { v: "prox7", label: "Próximos 7 dias" },
    { v: "atrasados", label: "Atrasados" },
    { v: "semdata", label: "Sem data" },
  ];
  return (
    <div className="space-y-1">
      <div className="text-xs font-semibold text-muted-foreground px-1 pb-1">Vencimento</div>
      {!showRange && presets.map(p => {
        const active = value?.kind === "preset" && value.value === p.v;
        return (
          <button
            key={p.v}
            onClick={()=>onChange({ kind: "preset", value: p.v })}
            className={cn("w-full text-left text-sm px-2 py-1.5 rounded hover:bg-secondary", active && "bg-secondary text-foreground font-medium")}
          >
            {p.label}
          </button>
        );
      })}
      {!showRange ? (
        <button onClick={()=>setShowRange(true)} className="w-full text-left text-sm px-2 py-1.5 rounded hover:bg-secondary text-muted-foreground border-t border-border mt-1">
          Intervalo personalizado…
        </button>
      ) : (
        <div className="space-y-2">
          <Calendar
            mode="range"
            selected={range}
            onSelect={(r)=>{
              setRange(r);
              if (r?.from) onChange({ kind: "range", from: r.from, to: r.to });
            }}
            numberOfMonths={1}
            className="p-2 pointer-events-auto"
          />
          <Button variant="ghost" size="sm" className="w-full" onClick={()=>{ setShowRange(false); setRange(undefined); }}>Voltar aos presets</Button>
        </div>
      )}
    </div>
  );
}

// ---- Filter logic helpers ----

function startOfDay(d: Date) { const x = new Date(d); x.setHours(0,0,0,0); return x; }
function endOfDay(d: Date) { const x = new Date(d); x.setHours(23,59,59,999); return x; }
function addDays(d: Date, n: number) { const x = new Date(d); x.setDate(x.getDate()+n); return x; }

export function cardMatchesFilters(card: { due_date: string|null; priority: string|null }, f: KanbanFiltersState): boolean {
  if (f.priorities.length > 0) {
    const p = card.priority || "none";
    if (!f.priorities.includes(p as PriorityKey)) return false;
  }
  if (f.date) {
    const d = card.due_date ? new Date(card.due_date) : null;
    if (f.date.kind === "preset") {
      const now = new Date();
      const today = startOfDay(now);
      switch (f.date.value) {
        case "semdata": return !d;
        case "hoje":      return !!d && d >= today && d <= endOfDay(now);
        case "amanha":    { const t = addDays(today,1); return !!d && d >= t && d <= endOfDay(t); }
        case "semana":    {
          const day = today.getDay(); // 0=Sun
          const monday = addDays(today, day === 0 ? -6 : 1 - day);
          const sunday = endOfDay(addDays(monday, 6));
          return !!d && d >= monday && d <= sunday;
        }
        case "prox7":     return !!d && d >= today && d <= endOfDay(addDays(today, 7));
        case "atrasados": return !!d && d < today;
      }
    } else {
      if (!d) return false;
      const from = startOfDay(f.date.from);
      const to = endOfDay(f.date.to ?? f.date.from);
      return d >= from && d <= to;
    }
  }
  return true;
}
