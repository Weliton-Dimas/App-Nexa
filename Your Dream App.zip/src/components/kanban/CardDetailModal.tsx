import { useEffect, useMemo, useState } from "react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import {
  X, Tag as TagIcon, Calendar as CalendarIcon, CheckSquare, Paperclip, Users,
  Plus, Edit2, Trash2, Link as LinkIcon, FileText, MoreHorizontal, AlignLeft, Building2, Flag,
} from "lucide-react";
import { PRIORITY_OPTIONS } from "@/components/kanban/KanbanFilters";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useKanbanBoard, LABEL_COLORS, KanbanCard, KanbanColumn } from "@/hooks/useKanbanBoard";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Calendar } from "@/components/ui/calendar";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Checkbox } from "@/components/ui/checkbox";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface Props {
  card: KanbanCard;
  column: KanbanColumn;
  open: boolean;
  onClose: () => void;
}

export default function CardDetailModal({ card, column, open, onClose }: Props) {
  const k = useKanbanBoard();
  const { user } = useAuth();

  const [title, setTitle] = useState(card.title);
  const [description, setDescription] = useState(card.description || "");
  const [editingDesc, setEditingDesc] = useState(false);
  const [comment, setComment] = useState("");

  useEffect(() => { setTitle(card.title); setDescription(card.description || ""); }, [card.id]);

  const cardLabelIds = new Set(k.cardLabels.filter(cl => cl.card_id === card.id).map(cl => cl.label_id));
  const cardLabels = k.labels.filter(l => cardLabelIds.has(l.id));
  const checklist = k.checklist.filter(i => i.card_id === card.id).sort((a,b)=>a.position-b.position);
  const memberIds = new Set(k.members.filter(m => m.card_id === card.id).map(m => m.user_id));
  const memberProfiles = k.profiles.filter(p => memberIds.has(p.user_id));
  const attachments = k.attachments.filter(a => a.card_id === card.id);
  const comments = k.comments.filter(c => c.card_id === card.id);

  const checkedCount = checklist.filter(i => i.done).length;
  const checklistPct = checklist.length ? Math.round((checkedCount / checklist.length) * 100) : 0;

  const saveTitle = () => {
    const t = title.trim();
    if (t && t !== card.title) k.updateCard.mutate({ id: card.id, patch: { title: t } });
  };
  const saveDescription = () => {
    k.updateCard.mutate({ id: card.id, patch: { description: description || null } });
    setEditingDesc(false);
  };

  const sendComment = () => {
    const b = comment.trim();
    if (!b) return;
    k.addComment.mutate({ cardId: card.id, body: b });
    setComment("");
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-4xl max-h-[90vh] p-0 overflow-hidden bg-card border-border">
        <div className="flex items-center justify-between px-5 py-3 border-b border-border">
          <Select value={column.id} onValueChange={(v) => k.updateCard.mutate({ id: card.id, patch: { column_id: v } })}>
            <SelectTrigger className="w-[180px] h-8 text-xs bg-secondary"><SelectValue /></SelectTrigger>
            <SelectContent>
              {useKanbanBoard().columns.map(c => (
                <SelectItem key={c.id} value={c.id}>{c.title}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <div />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-[1fr_320px] max-h-[calc(90vh-50px)]">
          <ScrollArea className="border-r border-border">
            <div className="p-5 space-y-5">
              <Input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                onBlur={saveTitle}
                onKeyDown={(e) => e.key === "Enter" && (e.target as HTMLInputElement).blur()}
                className="text-xl font-semibold bg-transparent border-none focus-visible:ring-1 focus-visible:ring-ring px-2"
              />

              <div className="flex flex-wrap gap-2">
                <LabelsPopover cardId={card.id} cardLabelIds={cardLabelIds} />
                <DatesPopover card={card} />
                <ChecklistTrigger cardId={card.id} />
                <AttachmentPopover cardId={card.id} />
                <MembersPopover cardId={card.id} memberIds={memberIds} />
              </div>

              {memberProfiles.length > 0 && (
                <Section icon={<Users size={14}/>} title="Membros">
                  <div className="flex flex-wrap gap-2">
                    {memberProfiles.map(p => (
                      <Avatar key={p.user_id} className="h-8 w-8 ring-2 ring-card">
                        {p.avatar_url && <AvatarImage src={p.avatar_url}/>}
                        <AvatarFallback className="text-xs bg-primary/20 text-primary">{(p.display_name||"?").slice(0,2).toUpperCase()}</AvatarFallback>
                      </Avatar>
                    ))}
                  </div>
                </Section>
              )}

              <Section icon={<Building2 size={14}/>} title="Cliente">
                <Select
                  value={card.client_id ?? "none"}
                  onValueChange={(v) => k.updateCard.mutate({ id: card.id, patch: { client_id: v === "none" ? null : v } as any })}
                >
                  <SelectTrigger className="h-9 bg-secondary border-border w-full md:w-72">
                    <SelectValue placeholder="Selecionar cliente" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">Sem cliente</SelectItem>
                    {k.clients.map(c => (
                      <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </Section>

              <Section icon={<Flag size={14}/>} title="Prioridade">
                <Select
                  value={card.priority ?? "none"}
                  onValueChange={(v) => k.updateCard.mutate({ id: card.id, patch: { priority: v === "none" ? null : v } as any })}
                >
                  <SelectTrigger className="h-9 bg-secondary border-border w-full md:w-72">
                    <SelectValue placeholder="Definir prioridade" />
                  </SelectTrigger>
                  <SelectContent>
                    {PRIORITY_OPTIONS.map(o => (
                      <SelectItem key={o.key} value={o.key}>
                        <span className="inline-flex items-center gap-2">
                          <span className={cn("h-2 w-2 rounded-full", o.dot)}/>
                          {o.label}
                        </span>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </Section>


              {cardLabels.length > 0 && (
                <Section icon={<TagIcon size={14}/>} title="Etiquetas">
                  <div className="flex flex-wrap gap-1.5">
                    {cardLabels.map(l => (
                      <span key={l.id} className={cn("text-xs font-medium text-white px-2.5 py-1 rounded", colorClass(l.color))}>
                        {l.name || "\u00A0"}
                      </span>
                    ))}
                  </div>
                </Section>
              )}

              {card.due_date && (
                <Section icon={<CalendarIcon size={14}/>} title="Data de entrega">
                  <div className="inline-flex items-center gap-2 bg-secondary px-3 py-1.5 rounded text-sm">
                    {format(new Date(card.due_date), "d 'de' MMM 'às' HH:mm", { locale: ptBR })}
                    {card.reminder && <span className="text-xs text-muted-foreground">· lembrete: {card.reminder}</span>}
                  </div>
                </Section>
              )}

              <Section icon={<AlignLeft size={14}/>} title="Descrição">
                {editingDesc ? (
                  <div className="space-y-2">
                    <Textarea value={description} onChange={(e)=>setDescription(e.target.value)} rows={4} placeholder="Adicione uma descrição mais detalhada..." />
                    <div className="flex gap-2">
                      <Button size="sm" onClick={saveDescription}>Salvar</Button>
                      <Button size="sm" variant="ghost" onClick={()=>{setEditingDesc(false); setDescription(card.description||"");}}>Cancelar</Button>
                    </div>
                  </div>
                ) : (
                  <button
                    onClick={()=>setEditingDesc(true)}
                    className="w-full text-left bg-secondary hover:bg-secondary/70 rounded p-3 text-sm text-foreground/90 min-h-[60px]"
                  >
                    {card.description || <span className="text-muted-foreground">Adicionar uma descrição mais detalhada...</span>}
                  </button>
                )}
              </Section>

              {checklist.length > 0 && (
                <Section icon={<CheckSquare size={14}/>} title="Checklist">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <span>{checklistPct}%</span>
                      <Progress value={checklistPct} className="h-1.5 flex-1"/>
                    </div>
                    {checklist.map(item => (
                      <div key={item.id} className="group flex items-start gap-2 hover:bg-secondary/50 rounded p-1">
                        <Checkbox
                          checked={item.done}
                          onCheckedChange={(v)=>k.updateChecklistItem.mutate({ id: item.id, patch: { done: !!v }})}
                          className="mt-0.5"
                        />
                        <span className={cn("text-sm flex-1", item.done && "line-through text-muted-foreground")}>{item.text}</span>
                        <button onClick={()=>k.deleteChecklistItem.mutate(item.id)} className="opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-destructive">
                          <Trash2 size={12}/>
                        </button>
                      </div>
                    ))}
                    <ChecklistAddInline cardId={card.id} />
                  </div>
                </Section>
              )}

              {attachments.length > 0 && (
                <Section icon={<Paperclip size={14}/>} title="Anexos">
                  <div className="space-y-1.5">
                    {attachments.map(a => (
                      <div key={a.id} className="group flex items-center gap-3 bg-secondary hover:bg-secondary/70 rounded p-2">
                        <div className="h-10 w-12 bg-muted rounded flex items-center justify-center text-muted-foreground">
                          {a.kind === "link" ? <LinkIcon size={16}/> : <FileText size={16}/>}
                        </div>
                        <a href={a.url} target="_blank" rel="noreferrer" className="text-sm flex-1 truncate hover:underline">
                          {a.display_text || a.url}
                        </a>
                        <button onClick={()=>k.deleteAttachment.mutate(a.id)} className="opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-destructive">
                          <Trash2 size={14}/>
                        </button>
                      </div>
                    ))}
                  </div>
                </Section>
              )}

              <div className="pt-2 border-t border-border">
                <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive" onClick={()=>{ k.deleteCard.mutate(card.id); onClose(); }}>
                  <Trash2 size={14}/> Excluir cartão
                </Button>
              </div>
            </div>
          </ScrollArea>

          <div className="flex flex-col bg-card">
            <div className="px-4 py-3 border-b border-border">
              <h3 className="text-sm font-semibold flex items-center gap-2"><span>💬</span> Comentários e atividade</h3>
            </div>
            <div className="p-3 border-b border-border space-y-2">
              <Textarea
                value={comment}
                onChange={(e)=>setComment(e.target.value)}
                placeholder="Escrever um comentário..."
                rows={2}
                onKeyDown={(e)=>{ if (e.key==="Enter" && (e.metaKey||e.ctrlKey)) sendComment(); }}
              />
              <Button size="sm" onClick={sendComment} disabled={!comment.trim()}>Enviar</Button>
            </div>
            <ScrollArea className="flex-1">
              <div className="p-3 space-y-3">
                {comments.map(c => {
                  const author = k.profiles.find(p => p.user_id === c.author_id);
                  return (
                    <div key={c.id} className="flex gap-2">
                      <Avatar className="h-7 w-7">
                        {author?.avatar_url && <AvatarImage src={author.avatar_url}/>}
                        <AvatarFallback className="text-[10px] bg-primary/20 text-primary">{(author?.display_name||"?").slice(0,2).toUpperCase()}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <div className="text-xs text-muted-foreground">
                          <span className="text-foreground font-medium">{author?.display_name || "Usuário"}</span>
                          {" · "}{format(new Date(c.created_at), "d 'de' MMM, HH:mm", { locale: ptBR })}
                        </div>
                        <div className="bg-secondary rounded p-2 text-sm mt-1">{c.body}</div>
                        {c.author_id === user?.id && (
                          <button onClick={()=>k.deleteComment.mutate(c.id)} className="text-xs text-muted-foreground hover:text-destructive mt-1">excluir</button>
                        )}
                      </div>
                    </div>
                  );
                })}
                {comments.length === 0 && <p className="text-xs text-muted-foreground text-center py-4">Nenhum comentário ainda</p>}
              </div>
            </ScrollArea>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function Section({ icon, title, children }: { icon: React.ReactNode; title: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="flex items-center gap-2 text-xs font-semibold text-muted-foreground mb-2 uppercase tracking-wide">{icon} {title}</div>
      {children}
    </div>
  );
}

function colorClass(color: string) {
  return LABEL_COLORS.find(c => c.key === color)?.className || "bg-slate-500";
}

function LabelsPopover({ cardId, cardLabelIds }: { cardId: string; cardLabelIds: Set<string> }) {
  const k = useKanbanBoard();
  const [search, setSearch] = useState("");
  const [editing, setEditing] = useState<string|null>(null);
  const [newName, setNewName] = useState("");
  const [newColor, setNewColor] = useState<string>(LABEL_COLORS[0].key);
  const [creating, setCreating] = useState(false);

  const filtered = k.labels.filter(l => (l.name||"").toLowerCase().includes(search.toLowerCase()));

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="secondary" size="sm" className="h-8"><TagIcon size={14}/> Etiquetas</Button>
      </PopoverTrigger>
      <PopoverContent className="w-72 p-3 max-h-[85vh] overflow-y-auto" align="start" collisionPadding={16}>
        <div className="text-sm font-semibold mb-2">Etiquetas</div>
        <Input placeholder="Buscar etiquetas..." value={search} onChange={(e)=>setSearch(e.target.value)} className="mb-3 h-8"/>
        <div className="space-y-1.5 max-h-60 overflow-y-auto">
          {filtered.map(l => (
            <div key={l.id} className="flex items-center gap-2">
              <Checkbox checked={cardLabelIds.has(l.id)} onCheckedChange={(v)=>k.toggleCardLabel.mutate({ cardId, labelId: l.id, on: !!v })}/>
              <div className={cn("flex-1 h-7 rounded text-white text-xs flex items-center px-2 font-medium", colorClass(l.color))}>{l.name}</div>
              <button onClick={()=>{ setEditing(l.id); setNewName(l.name); setNewColor(l.color); }} className="text-muted-foreground hover:text-foreground"><Edit2 size={12}/></button>
            </div>
          ))}
        </div>
        {editing && (
          <div className="mt-3 pt-3 border-t border-border space-y-2">
            <Input value={newName} onChange={(e)=>setNewName(e.target.value)} placeholder="Nome" className="h-8"/>
            <div className="flex gap-1">
              {LABEL_COLORS.map(c => (
                <button key={c.key} onClick={()=>setNewColor(c.key)} className={cn("h-6 flex-1 rounded", c.className, newColor===c.key && "ring-2 ring-ring")}/>
              ))}
            </div>
            <div className="flex gap-2">
              <Button size="sm" onClick={()=>{ k.updateLabel.mutate({ id: editing, name: newName, color: newColor }); setEditing(null); }}>Salvar</Button>
              <Button size="sm" variant="destructive" onClick={()=>{ k.deleteLabel.mutate(editing); setEditing(null); }}>Excluir</Button>
              <Button size="sm" variant="ghost" onClick={()=>setEditing(null)}>Cancelar</Button>
            </div>
          </div>
        )}
        {creating ? (
          <div className="mt-3 pt-3 border-t border-border space-y-2">
            <Input value={newName} onChange={(e)=>setNewName(e.target.value)} placeholder="Nome" className="h-8"/>
            <div className="flex gap-1">
              {LABEL_COLORS.map(c => (
                <button key={c.key} onClick={()=>setNewColor(c.key)} className={cn("h-6 flex-1 rounded", c.className, newColor===c.key && "ring-2 ring-ring")}/>
              ))}
            </div>
            <Button size="sm" onClick={()=>{ k.createLabel.mutate({ name: newName, color: newColor }); setNewName(""); setCreating(false); }}>Criar</Button>
          </div>
        ) : (
          <Button variant="ghost" size="sm" className="w-full mt-2" onClick={()=>setCreating(true)}><Plus size={14}/> Criar nova etiqueta</Button>
        )}
      </PopoverContent>
    </Popover>
  );
}

function DatesPopover({ card }: { card: KanbanCard }) {
  const k = useKanbanBoard();
  const [open, setOpen] = useState(false);
  const [date, setDate] = useState<Date|undefined>(card.due_date ? new Date(card.due_date) : undefined);
  const [time, setTime] = useState(card.due_date ? format(new Date(card.due_date), "HH:mm") : "12:00");
  const [reminder, setReminder] = useState(card.reminder || "1 dia antes");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setDate(card.due_date ? new Date(card.due_date) : undefined);
    setTime(card.due_date ? format(new Date(card.due_date), "HH:mm") : "12:00");
    setReminder(card.reminder || "1 dia antes");
  }, [card.id, card.due_date, card.reminder]);

  const save = async () => {
    setSaving(true);
    try {
      if (!date) {
        await k.updateCard.mutateAsync({ id: card.id, patch: { due_date: null, reminder: null } });
      } else {
        const [hh, mm] = time.split(":").map(Number);
        const d = new Date(date); d.setHours(hh||0, mm||0, 0, 0);
        await k.updateCard.mutateAsync({ id: card.id, patch: { due_date: d.toISOString(), reminder } });
      }
      toast.success("Data salva");
      setOpen(false);
    } catch (e: any) {
      toast.error("Erro ao salvar data", { description: e?.message });
    } finally {
      setSaving(false);
    }
  };
  const remove = async () => {
    setSaving(true);
    try {
      await k.updateCard.mutateAsync({ id: card.id, patch: { due_date: null, reminder: null } });
      toast.success("Data removida");
      setOpen(false);
    } catch (e: any) {
      toast.error("Erro ao remover data", { description: e?.message });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="secondary" size="sm" className="h-8"><CalendarIcon size={14}/> Datas</Button>
      </PopoverTrigger>
      <PopoverContent className="w-auto p-0 max-h-[85vh] overflow-y-auto flex flex-col" align="start" collisionPadding={16}>
        <div className="p-3">
          <div className="text-sm font-semibold mb-2 text-center">Datas</div>
          <Calendar mode="single" selected={date} onSelect={setDate} className={cn("p-0 pointer-events-auto")} locale={ptBR}/>
          <div className="mt-3 space-y-2">
            <div>
              <label className="text-xs text-muted-foreground">Hora</label>
              <Input type="time" value={time} onChange={(e)=>setTime(e.target.value)} className="h-8"/>
            </div>
            <div>
              <label className="text-xs text-muted-foreground">Lembrete</label>
              <Select value={reminder} onValueChange={setReminder}>
                <SelectTrigger className="h-8"><SelectValue/></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Nenhum">Nenhum</SelectItem>
                  <SelectItem value="Na hora">Na hora</SelectItem>
                  <SelectItem value="5 min antes">5 min antes</SelectItem>
                  <SelectItem value="1 dia antes">1 dia antes</SelectItem>
                  <SelectItem value="1 semana antes">1 semana antes</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
        <div className="sticky bottom-0 bg-popover border-t border-border p-3 space-y-2">
          <Button size="sm" className="w-full" onClick={save} disabled={saving}>{saving ? "Salvando..." : "Salvar"}</Button>
          <Button size="sm" variant="ghost" className="w-full" onClick={remove} disabled={saving}>Remover</Button>
        </div>
      </PopoverContent>
    </Popover>
  );
}

function ChecklistTrigger({ cardId }: { cardId: string }) {
  const k = useKanbanBoard();
  const [text, setText] = useState("");
  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="secondary" size="sm" className="h-8"><CheckSquare size={14}/> Checklist</Button>
      </PopoverTrigger>
      <PopoverContent className="w-64 p-3 max-h-[85vh] overflow-y-auto" align="start" collisionPadding={16}>
        <div className="text-sm font-semibold mb-2">Adicionar item</div>
        <Input value={text} onChange={(e)=>setText(e.target.value)} placeholder="Ex.: Revisar criativos" className="h-8 mb-2"/>
        <Button size="sm" className="w-full" disabled={!text.trim()} onClick={()=>{ k.addChecklistItem.mutate({ cardId, text: text.trim() }); setText(""); }}>Adicionar</Button>
      </PopoverContent>
    </Popover>
  );
}

function ChecklistAddInline({ cardId }: { cardId: string }) {
  const k = useKanbanBoard();
  const [text, setText] = useState("");
  const submit = () => { if (text.trim()) { k.addChecklistItem.mutate({ cardId, text: text.trim() }); setText(""); } };
  return (
    <div className="flex gap-2 mt-2">
      <Input value={text} onChange={(e)=>setText(e.target.value)} onKeyDown={(e)=>e.key==="Enter" && submit()} placeholder="Adicionar item..." className="h-8"/>
      <Button size="sm" onClick={submit} disabled={!text.trim()}>+</Button>
    </div>
  );
}

function AttachmentPopover({ cardId }: { cardId: string }) {
  const k = useKanbanBoard();
  const [tab, setTab] = useState<"file"|"link">("link");
  const [url, setUrl] = useState("");
  const [text, setText] = useState("");
  const [uploading, setUploading] = useState(false);

  const onFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]; if (!file) return;
    setUploading(true);
    try {
      const path = `${cardId}/${Date.now()}-${file.name}`;
      const { error } = await supabase.storage.from("kanban-attachments").upload(path, file);
      if (error) throw error;
      const { data } = supabase.storage.from("kanban-attachments").getPublicUrl(path);
      const { data: signed } = await supabase.storage.from("kanban-attachments").createSignedUrl(path, 60*60*24*365);
      const finalUrl = signed?.signedUrl || data.publicUrl;
      k.addAttachment.mutate({ card_id: cardId, kind: "file", url: finalUrl, display_text: file.name, file_path: path });
    } finally { setUploading(false); }
  };

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="secondary" size="sm" className="h-8"><Paperclip size={14}/> Anexo</Button>
      </PopoverTrigger>
      <PopoverContent className="w-72 p-3 max-h-[85vh] overflow-y-auto" align="start" collisionPadding={16}>
        <div className="flex gap-1 mb-2">
          <Button size="sm" variant={tab==="link"?"default":"ghost"} className="flex-1" onClick={()=>setTab("link")}>Link</Button>
          <Button size="sm" variant={tab==="file"?"default":"ghost"} className="flex-1" onClick={()=>setTab("file")}>Arquivo</Button>
        </div>
        {tab === "link" ? (
          <div className="space-y-2">
            <Input placeholder="Cole um link..." value={url} onChange={(e)=>setUrl(e.target.value)} className="h-8"/>
            <Input placeholder="Texto exibido (opcional)" value={text} onChange={(e)=>setText(e.target.value)} className="h-8"/>
            <Button size="sm" className="w-full" disabled={!url.trim()} onClick={()=>{ k.addAttachment.mutate({ card_id: cardId, kind: "link", url: url.trim(), display_text: text || null }); setUrl(""); setText(""); }}>Inserir</Button>
          </div>
        ) : (
          <div className="space-y-2">
            <input type="file" onChange={onFile} disabled={uploading} className="text-xs w-full"/>
            {uploading && <p className="text-xs text-muted-foreground">Enviando...</p>}
          </div>
        )}
      </PopoverContent>
    </Popover>
  );
}

function MembersPopover({ cardId, memberIds }: { cardId: string; memberIds: Set<string> }) {
  const k = useKanbanBoard();
  const [search, setSearch] = useState("");
  const filtered = k.profiles.filter(p => (p.display_name||"").toLowerCase().includes(search.toLowerCase()));
  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="secondary" size="sm" className="h-8"><Users size={14}/> Membros</Button>
      </PopoverTrigger>
      <PopoverContent className="w-72 p-3 flex flex-col max-h-[70vh]" align="start" collisionPadding={16}>
        <div className="text-sm font-semibold mb-2 shrink-0">Membros</div>
        <Input placeholder="Buscar..." value={search} onChange={(e)=>setSearch(e.target.value)} className="mb-2 h-8 shrink-0"/>
        <div
          className="space-y-1 overflow-y-auto flex-1 min-h-0 pr-1 overscroll-contain"
          onWheel={(e)=>e.stopPropagation()}
          onTouchMove={(e)=>e.stopPropagation()}
        >
          {filtered.map(p => {
            const on = memberIds.has(p.user_id);
            return (
              <button key={p.user_id} onClick={()=>k.toggleCardMember.mutate({ cardId, userId: p.user_id, on: !on })}
                className={cn("w-full flex items-center gap-2 p-1.5 rounded hover:bg-secondary text-left", on && "bg-secondary")}>
                <Avatar className="h-7 w-7">
                  {p.avatar_url && <AvatarImage src={p.avatar_url}/>}
                  <AvatarFallback className="text-xs bg-primary/20 text-primary">{(p.display_name||"?").slice(0,2).toUpperCase()}</AvatarFallback>
                </Avatar>
                <span className="text-sm flex-1">{p.display_name || "Sem nome"}</span>
                {on && <span className="text-xs text-primary">✓</span>}
              </button>
            );
          })}
        </div>
      </PopoverContent>
    </Popover>
  );
}
