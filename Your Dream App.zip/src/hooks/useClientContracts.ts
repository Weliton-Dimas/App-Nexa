import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";

export interface ClientContract {
  id: string;
  client_id: string;
  name: string;
  file_url: string | null;
  file_path: string | null;
  external_url: string | null;
  contract_start: string | null;
  contract_end: string | null;
  notes: string | null;
  uploaded_by: string;
  created_at: string;
  updated_at: string;
}

export function useClientContracts(clientId: string | null) {
  return useQuery({
    queryKey: ["client-contracts", clientId],
    enabled: !!clientId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("client_contracts" as any)
        .select("*")
        .eq("client_id", clientId!)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as ClientContract[];
    },
  });
}

export function useAddContract() {
  const qc = useQueryClient();
  const { user } = useAuth();
  return useMutation({
    mutationFn: async (input: {
      client_id: string;
      name: string;
      file?: File | null;
      external_url?: string;
      contract_start?: string | null;
      contract_end?: string | null;
      notes?: string;
    }) => {
      if (!user) throw new Error("Não autenticado");
      let file_url: string | null = null;
      let file_path: string | null = null;

      if (input.file) {
        const ext = input.file.name.split(".").pop() ?? "bin";
        const path = `${input.client_id}/${Date.now()}-${crypto.randomUUID()}.${ext}`;
        const { error: upErr } = await supabase.storage
          .from("client-contracts")
          .upload(path, input.file, { cacheControl: "3600", upsert: false });
        if (upErr) throw upErr;
        file_path = path;
        const { data: signed } = await supabase.storage
          .from("client-contracts")
          .createSignedUrl(path, 60 * 60 * 24 * 365);
        file_url = signed?.signedUrl ?? null;
      }

      const { data, error } = await supabase
        .from("client_contracts" as any)
        .insert({
          client_id: input.client_id,
          uploaded_by: user.id,
          name: input.name || "Contrato",
          file_url,
          file_path,
          external_url: input.external_url || null,
          contract_start: input.contract_start || null,
          contract_end: input.contract_end || null,
          notes: input.notes || null,
        })
        .select()
        .single();
      if (error) throw error;
      return data;
    },
    onSuccess: (_d, v) =>
      qc.invalidateQueries({ queryKey: ["client-contracts", v.client_id] }),
  });
}

export function useDeleteContract() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (c: ClientContract) => {
      if (c.file_path) {
        await supabase.storage.from("client-contracts").remove([c.file_path]);
      }
      const { error } = await supabase
        .from("client_contracts" as any)
        .delete()
        .eq("id", c.id);
      if (error) throw error;
      return c;
    },
    onSuccess: (c) =>
      qc.invalidateQueries({ queryKey: ["client-contracts", c.client_id] }),
  });
}

export async function getContractSignedUrl(path: string) {
  const { data } = await supabase.storage
    .from("client-contracts")
    .createSignedUrl(path, 60 * 5);
  return data?.signedUrl ?? null;
}
