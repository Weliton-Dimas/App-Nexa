import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useKanbanBoard, type KanbanCard, type KanbanColumn } from "@/hooks/useKanbanBoard";

export type UnifiedSource = "calendar" | "kanban";

export interface UnifiedAssignee { id: string; name: string; avatar?: string | null }
export interface UnifiedLabel { name: string; color: string }

export interface UnifiedTask {
  id: string;
  source: UnifiedSource;
  title: string;
  /** YYYY-MM-DD (null para kanban sem due_date) */
  date: string | null;
  /** YYYY-MM-DD opcional (apenas kanban com start_date) */
  startDate?: string | null;
  clientId: string | null;
  clientName: string | null;
  assignees: UnifiedAssignee[];
  priority: string | null;
  /** chave de progresso para agrupamento */
  progressKey: string;
  progressLabel: string;
  progressColor?: string | null;
  /** label de cor para a barra da tarefa */
  color: string;
  labels: UnifiedLabel[];
  raw: any;
  kanbanColumn?: KanbanColumn;
  kanbanCard?: KanbanCard;
}

const CAL_STATUS_LABEL: Record<string, string> = {
  nova: "Nova",
  em_andamento: "Em andamento",
  fazendo: "Fazendo",
  aguardando: "Aguardando",
  concluida: "Concluída",
  cancelada: "Cancelada",
};

function toIso(d: string | Date | null): string | null {
  if (!d) return null;
  if (typeof d === "string") return d.slice(0, 10);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${dd}`;
}

export function useUnifiedTasks() {
  const k = useKanbanBoard();

  const calQ = useQuery({
    queryKey: ["calendar_tasks_all"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("calendar_tasks")
        .select("*")
        .order("date", { ascending: true });
      if (error) throw error;
      return data ?? [];
    },
  });

  const profiles = k.profiles;
  const clients = k.clients;

  const tasks = useMemo<UnifiedTask[]>(() => {
    const out: UnifiedTask[] = [];

    // calendar tasks
    for (const t of calQ.data ?? []) {
      const cli = clients.find((c) => c.id === t.client_id);
      const prof = profiles.find((p) => p.user_id === t.assignee_id);
      out.push({
        id: `cal-${t.id}`,
        source: "calendar",
        title: t.title,
        date: t.date,
        clientId: t.client_id,
        clientName: cli?.name ?? null,
        assignees: prof
          ? [{ id: prof.user_id, name: prof.display_name ?? "Usuário", avatar: prof.avatar_url }]
          : [],
        priority: t.priority,
        progressKey: `cal:${t.status}`,
        progressLabel: CAL_STATUS_LABEL[t.status] ?? t.status,
        color: t.color || "blue",
        labels: [],
        raw: t,
      });
    }

    // kanban cards
    for (const col of k.columns) {
      for (const c of col.cards) {
        const cli = clients.find((cl) => cl.id === c.client_id);
        const memberIds = k.members.filter((m) => m.card_id === c.id).map((m) => m.user_id);
        const assignees: UnifiedAssignee[] = memberIds
          .map((uid) => profiles.find((p) => p.user_id === uid))
          .filter(Boolean)
          .map((p: any) => ({ id: p.user_id, name: p.display_name ?? "Usuário", avatar: p.avatar_url }));
        const labelIds = new Set(
          k.cardLabels.filter((cl) => cl.card_id === c.id).map((cl) => cl.label_id),
        );
        const labels = k.labels
          .filter((l) => labelIds.has(l.id))
          .map((l) => ({ name: l.name, color: l.color }));
        out.push({
          id: `kan-${c.id}`,
          source: "kanban",
          title: c.title,
          date: toIso(c.due_date),
          startDate: c.start_date ?? null,
          clientId: c.client_id,
          clientName: cli?.name ?? null,
          assignees,
          priority: c.priority,
          progressKey: `kan:${col.id}`,
          progressLabel: col.title,
          progressColor: c.cover_color,
          color: c.cover_color || "blue",
          labels,
          raw: c,
          kanbanColumn: col,
          kanbanCard: c,
        });
      }
    }
    return out;
  }, [calQ.data, k.columns, k.members, k.cardLabels, k.labels, profiles, clients]);

  // progress groups (ordered): kanban columns first (by position), then calendar statuses
  const progressGroups = useMemo(() => {
    const groups: { key: string; label: string; source: UnifiedSource }[] = [];
    for (const col of [...k.columns].sort((a, b) => a.position - b.position)) {
      groups.push({ key: `kan:${col.id}`, label: col.title, source: "kanban" });
    }
    const calStatuses = ["nova", "em_andamento", "fazendo", "aguardando", "concluida"];
    for (const s of calStatuses) {
      groups.push({ key: `cal:${s}`, label: CAL_STATUS_LABEL[s], source: "calendar" });
    }
    return groups;
  }, [k.columns]);

  return {
    tasks,
    progressGroups,
    profiles,
    clients,
    isLoading: calQ.isLoading || k.isLoading,
    refetchCalendar: calQ.refetch,
    kanban: k,
  };
}

export function toIsoDate(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${dd}`;
}
