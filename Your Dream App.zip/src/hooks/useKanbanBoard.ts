import { useEffect, useMemo } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";

export const LABEL_COLORS = [
  { key: "green", className: "bg-emerald-600" },
  { key: "yellow", className: "bg-yellow-500" },
  { key: "orange", className: "bg-orange-500" },
  { key: "red", className: "bg-red-600" },
  { key: "purple", className: "bg-violet-600" },
  { key: "blue", className: "bg-blue-600" },
] as const;

export type LabelColor = typeof LABEL_COLORS[number]["key"];

export interface KanbanLabel { id: string; name: string; color: string; board_id: string }
export interface KanbanChecklistItem { id: string; card_id: string; text: string; done: boolean; position: number }
export interface KanbanAttachment { id: string; card_id: string; kind: "link"|"file"; url: string; display_text: string|null; file_path: string|null; uploaded_by: string; created_at: string }
export interface KanbanComment { id: string; card_id: string; body: string; author_id: string; created_at: string }
export interface KanbanCard {
  id: string; column_id: string; title: string; description: string|null;
  position: number; due_date: string|null; start_date: string|null;
  reminder: string|null; cover_color: string|null; created_by: string; created_at: string;
  client_id: string|null;
  priority: string|null;
}
export interface KanbanColumn { id: string; board_id: string; title: string; position: number; cards: KanbanCard[] }
export interface KanbanBoard { id: string; name: string }

export interface ProfileLite { user_id: string; display_name: string|null; avatar_url: string|null }

const BOARD_NAME = "Tarefas";

export function useKanbanBoard() {
  const qc = useQueryClient();
  const { user } = useAuth();

  // --- Board (auto-create if missing) ---
  const boardQ = useQuery({
    queryKey: ["kanban", "board"],
    enabled: !!user,
    queryFn: async (): Promise<KanbanBoard> => {
      const { data, error } = await supabase.from("kanban_boards").select("id,name").order("created_at").limit(1).maybeSingle();
      if (error) throw error;
      if (data) return data as KanbanBoard;
      // create board + default columns + labels
      const { data: nb, error: bErr } = await supabase.from("kanban_boards").insert({ name: BOARD_NAME, created_by: user!.id }).select("id,name").single();
      if (bErr) throw bErr;
      const cols = ["Para Fazer","Em Progresso","Concluído"].map((title,i)=>({ board_id: nb.id, title, position: (i+1)*1000 }));
      await supabase.from("kanban_columns").insert(cols);
      const labels = LABEL_COLORS.map(c=>({ board_id: nb.id, name: "", color: c.key }));
      await supabase.from("kanban_labels").insert(labels);
      return nb as KanbanBoard;
    },
  });

  const boardId = boardQ.data?.id;

  // --- Columns + cards ---
  const dataQ = useQuery({
    queryKey: ["kanban", "data", boardId],
    enabled: !!boardId,
    queryFn: async () => {
      const [colsRes, cardsRes, labelsRes, cardLabelsRes, checklistRes, membersRes, attachmentsRes, commentsRes] = await Promise.all([
        supabase.from("kanban_columns").select("*").eq("board_id", boardId!).order("position"),
        supabase.from("kanban_cards").select("*").order("position"),
        supabase.from("kanban_labels").select("*").eq("board_id", boardId!),
        supabase.from("kanban_card_labels").select("*"),
        supabase.from("kanban_checklist_items").select("*").order("position"),
        supabase.from("kanban_members").select("*"),
        supabase.from("kanban_attachments").select("*"),
        supabase.from("kanban_comments").select("*").order("created_at"),
      ]);
      const err = colsRes.error || cardsRes.error || labelsRes.error || cardLabelsRes.error || checklistRes.error || membersRes.error || attachmentsRes.error || commentsRes.error;
      if (err) throw err;

      const columns = (colsRes.data || []) as Omit<KanbanColumn, "cards">[];
      const cards = (cardsRes.data || []) as KanbanCard[];
      const colMap = new Map<string, KanbanColumn>();
      columns.forEach(c => colMap.set(c.id, { ...c, cards: [] }));
      cards.forEach(card => colMap.get(card.column_id)?.cards.push(card));

      return {
        columns: Array.from(colMap.values()).sort((a,b)=>a.position-b.position),
        labels: (labelsRes.data || []) as KanbanLabel[],
        cardLabels: (cardLabelsRes.data || []) as { card_id: string; label_id: string }[],
        checklist: (checklistRes.data || []) as KanbanChecklistItem[],
        members: (membersRes.data || []) as { card_id: string; user_id: string }[],
        attachments: (attachmentsRes.data || []) as KanbanAttachment[],
        comments: (commentsRes.data || []) as KanbanComment[],
      };
    },
  });

  // --- Profiles (for member assignment) ---
  const profilesQ = useQuery({
    queryKey: ["kanban", "profiles"],
    queryFn: async (): Promise<ProfileLite[]> => {
      const { data, error } = await supabase.from("profiles").select("user_id,display_name,avatar_url");
      if (error) throw error;
      return (data || []) as ProfileLite[];
    },
  });

  const clientsQ = useQuery({
    queryKey: ["kanban", "clients"],
    queryFn: async () => {
      const { data, error } = await supabase.from("clients").select("id,name").order("name");
      if (error) throw error;
      return (data || []) as { id: string; name: string }[];
    },
  });

  const invalidate = () => qc.invalidateQueries({ queryKey: ["kanban", "data", boardId] });

  // ------- Mutations -------
  const createCard = useMutation({
    mutationFn: async ({ columnId, title }: { columnId: string; title: string }) => {
      const cards = dataQ.data?.columns.find(c=>c.id===columnId)?.cards || [];
      const position = (cards[cards.length-1]?.position ?? 0) + 1000;
      const { error } = await supabase.from("kanban_cards").insert({ column_id: columnId, title, position, created_by: user!.id });
      if (error) throw error;
    },
    onSuccess: invalidate,
  });

  const updateCard = useMutation({
    mutationFn: async ({ id, patch }: { id: string; patch: Partial<KanbanCard> }) => {
      const { error } = await supabase.from("kanban_cards").update(patch).eq("id", id);
      if (error) throw error;
    },
    onSuccess: invalidate,
  });

  const deleteCard = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("kanban_cards").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: invalidate,
  });

  const moveCard = useMutation({
    mutationFn: async ({ cardId, toColumnId, newIndex }: { cardId: string; toColumnId: string; newIndex: number }) => {
      const cols = dataQ.data?.columns || [];
      const target = cols.find(c=>c.id===toColumnId);
      if (!target) return;
      const others = target.cards.filter(c=>c.id!==cardId);
      const before = others[newIndex-1]?.position;
      const after = others[newIndex]?.position;
      let position: number;
      if (before == null && after == null) position = 1000;
      else if (before == null) position = after! - 500;
      else if (after == null) position = before + 500;
      else position = (before + after) / 2;
      const { error } = await supabase.from("kanban_cards").update({ column_id: toColumnId, position }).eq("id", cardId);
      if (error) throw error;
    },
    onSuccess: invalidate,
  });

  const createColumn = useMutation({
    mutationFn: async (title: string) => {
      const cols = dataQ.data?.columns || [];
      const position = (cols[cols.length-1]?.position ?? 0) + 1000;
      const { error } = await supabase.from("kanban_columns").insert({ board_id: boardId!, title, position });
      if (error) throw error;
    },
    onSuccess: invalidate,
  });

  const updateColumn = useMutation({
    mutationFn: async ({ id, title }: { id: string; title: string }) => {
      const { error } = await supabase.from("kanban_columns").update({ title }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: invalidate,
  });

  const moveColumn = useMutation({
    mutationFn: async ({ columnId, newIndex }: { columnId: string; newIndex: number }) => {
      const cols = (dataQ.data?.columns || []).filter(c => c.id !== columnId);
      const before = cols[newIndex-1]?.position;
      const after = cols[newIndex]?.position;
      let position: number;
      if (before == null && after == null) position = 1000;
      else if (before == null) position = (after as number) - 500;
      else if (after == null) position = before + 500;
      else position = (before + after) / 2;
      const { error } = await supabase.from("kanban_columns").update({ position }).eq("id", columnId);
      if (error) throw error;
    },
    onSuccess: invalidate,
  });


  const deleteColumn = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("kanban_columns").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: invalidate,
  });

  // labels
  const createLabel = useMutation({
    mutationFn: async ({ name, color }: { name: string; color: string }) => {
      const { error } = await supabase.from("kanban_labels").insert({ board_id: boardId!, name, color });
      if (error) throw error;
    },
    onSuccess: invalidate,
  });
  const updateLabel = useMutation({
    mutationFn: async ({ id, name, color }: { id: string; name: string; color: string }) => {
      const { error } = await supabase.from("kanban_labels").update({ name, color }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: invalidate,
  });
  const deleteLabel = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("kanban_labels").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: invalidate,
  });
  const toggleCardLabel = useMutation({
    mutationFn: async ({ cardId, labelId, on }: { cardId: string; labelId: string; on: boolean }) => {
      if (on) {
        const { error } = await supabase.from("kanban_card_labels").insert({ card_id: cardId, label_id: labelId });
        if (error && !`${error.message}`.includes("duplicate")) throw error;
      } else {
        const { error } = await supabase.from("kanban_card_labels").delete().eq("card_id", cardId).eq("label_id", labelId);
        if (error) throw error;
      }
    },
    onSuccess: invalidate,
  });

  // checklist
  const addChecklistItem = useMutation({
    mutationFn: async ({ cardId, text }: { cardId: string; text: string }) => {
      const items = dataQ.data?.checklist.filter(i=>i.card_id===cardId) || [];
      const position = (items[items.length-1]?.position ?? 0) + 1000;
      const { error } = await supabase.from("kanban_checklist_items").insert({ card_id: cardId, text, position });
      if (error) throw error;
    },
    onSuccess: invalidate,
  });
  const updateChecklistItem = useMutation({
    mutationFn: async ({ id, patch }: { id: string; patch: Partial<KanbanChecklistItem> }) => {
      const { error } = await supabase.from("kanban_checklist_items").update(patch).eq("id", id);
      if (error) throw error;
    },
    onSuccess: invalidate,
  });
  const deleteChecklistItem = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("kanban_checklist_items").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: invalidate,
  });

  // members
  const toggleCardMember = useMutation({
    mutationFn: async ({ cardId, userId, on }: { cardId: string; userId: string; on: boolean }) => {
      if (on) {
        const { error } = await supabase.from("kanban_members").insert({ card_id: cardId, user_id: userId });
        if (error && !`${error.message}`.includes("duplicate")) throw error;
      } else {
        const { error } = await supabase.from("kanban_members").delete().eq("card_id", cardId).eq("user_id", userId);
        if (error) throw error;
      }
    },
    onSuccess: invalidate,
  });

  // attachments
  const addAttachment = useMutation({
    mutationFn: async (att: { card_id: string; kind: "link"|"file"; url: string; display_text?: string|null; file_path?: string|null }) => {
      const { error } = await supabase.from("kanban_attachments").insert({ ...att, uploaded_by: user!.id });
      if (error) throw error;
    },
    onSuccess: invalidate,
  });
  const deleteAttachment = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("kanban_attachments").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: invalidate,
  });

  // comments
  const addComment = useMutation({
    mutationFn: async ({ cardId, body }: { cardId: string; body: string }) => {
      const { error } = await supabase.from("kanban_comments").insert({ card_id: cardId, body, author_id: user!.id });
      if (error) throw error;
    },
    onSuccess: invalidate,
  });
  const updateComment = useMutation({
    mutationFn: async ({ id, body }: { id: string; body: string }) => {
      const { error } = await supabase.from("kanban_comments").update({ body }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: invalidate,
  });
  const deleteComment = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("kanban_comments").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: invalidate,
  });

  return {
    board: boardQ.data,
    isLoading: boardQ.isLoading || dataQ.isLoading,
    columns: dataQ.data?.columns || [],
    labels: dataQ.data?.labels || [],
    cardLabels: dataQ.data?.cardLabels || [],
    checklist: dataQ.data?.checklist || [],
    members: dataQ.data?.members || [],
    attachments: dataQ.data?.attachments || [],
    comments: dataQ.data?.comments || [],
    profiles: profilesQ.data || [],
    clients: clientsQ.data || [],
    refetch: invalidate,
    createCard, updateCard, deleteCard, moveCard,
    createColumn, updateColumn, deleteColumn, moveColumn,
    createLabel, updateLabel, deleteLabel, toggleCardLabel,
    addChecklistItem, updateChecklistItem, deleteChecklistItem,
    toggleCardMember,
    addAttachment, deleteAttachment,
    addComment, updateComment, deleteComment,
  };
}
