import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface PlatformBreakdown {
  platform: string;
  reach: number;
  impressions: number;
  spend: number;
  clicks: number;
  conversations: number;
  messages: number;
  purchases: number;
  leads: number;
}

export interface RegionBreakdown {
  region: string;
  reach: number;
  impressions: number;
  spend: number;
  clicks: number;
  conversations: number;
  messages: number;
  purchases: number;
  leads: number;
}

export interface CityBreakdown {
  city: string;
  reach: number;
  impressions: number;
  spend: number;
  clicks: number;
  conversations: number;
  messages: number;
  purchases: number;
  leads: number;
}

export interface AdBreakdown {
  adName: string;
  campaignName: string;
  reach: number;
  frequency: number;
  impressions: number;
  spend: number;
  cpm: number;
  clicks: number;
  ctr: number;
  cpc: number;
  conversations: number;
  messages: number;
  purchases: number;
  leads: number;
  purchaseValue: number;
  roas: number;
  costPerConversation: number;
}

export type ResultType = "purchase" | "lead" | "conversation" | "none";

export interface MetaAdsMetrics {
  reach: number;
  frequency: number;
  impressions: number;
  spend: number;
  cpm: number;
  clicks: number;
  ctr: number;
  cpc: number;
  conversations: number;
  messages: number;
  linkClicks: number;
  pageEngagement: number;
  postEngagement: number;
  purchases: number;
  purchaseValue: number;
  roas: number;
  leads: number;
  addToCart: number;
  initiateCheckout: number;
  videoViews: number;
  profileVisits: number;
  results: number;
  resultType: ResultType;
  costPerResult: number;
  costPerConversation: number;
  costPerMessage: number;
  datePreset: string;
  since: string | null;
  until: string | null;
  platformBreakdown: PlatformBreakdown[];
  regionBreakdown: RegionBreakdown[];
  cityBreakdown: CityBreakdown[];
  adBreakdown: AdBreakdown[];
}

export interface UseMetaAdsArgs {
  datePreset?: string;
  since?: string | null;
  until?: string | null;
  clientId?: string | null;
}

export function useMetaAdsMetrics(
  arg1: string | UseMetaAdsArgs = "last_7d",
  clientIdArg?: string | null,
) {
  const opts: UseMetaAdsArgs =
    typeof arg1 === "string" ? { datePreset: arg1, clientId: clientIdArg } : arg1;
  const { datePreset = "last_7d", since, until, clientId } = opts;
  const useCustom = !!(since && until);

  return useQuery<MetaAdsMetrics>({
    queryKey: ["meta-ads-metrics", useCustom ? `${since}_${until}` : datePreset, clientId],
    enabled: !!clientId,
    queryFn: async () => {
      const { data: sessionData } = await supabase.auth.getSession();
      const token = sessionData.session?.access_token;
      const projectId = import.meta.env.VITE_SUPABASE_PROJECT_ID;
      const anonKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;

      const params = new URLSearchParams({ client_id: String(clientId) });
      if (useCustom) {
        params.set("since", since!);
        params.set("until", until!);
      } else {
        params.set("date_preset", datePreset);
      }

      const res = await fetch(
        `https://${projectId}.supabase.co/functions/v1/meta-ads-metrics?${params.toString()}`,
        {
          headers: {
            Authorization: `Bearer ${token ?? anonKey}`,
            apikey: anonKey,
          },
        }
      );

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || "Falha ao buscar métricas");
      }

      return res.json();
    },
    refetchInterval: 5 * 60 * 1000,
    staleTime: 2 * 60 * 1000,
  });
}
