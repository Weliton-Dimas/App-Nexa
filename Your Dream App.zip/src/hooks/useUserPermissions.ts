import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";

export interface UserPermissions {
  isAdmin: boolean;
  allowedSlugs: Set<string>;
}

export function useUserPermissions() {
  const { user } = useAuth();
  return useQuery<UserPermissions>({
    queryKey: ["user-permissions", user?.id],
    enabled: !!user,
    staleTime: 30_000,
    queryFn: async () => {
      const { data: isAdmin } = await supabase.rpc("has_role", {
        _user_id: user!.id,
        _role: "admin",
      });
      if (isAdmin) {
        return { isAdmin: true, allowedSlugs: new Set<string>() };
      }
      const { data } = await supabase
        .from("user_page_permissions")
        .select("page_slug")
        .eq("user_id", user!.id);
      return {
        isAdmin: false,
        allowedSlugs: new Set((data ?? []).map((r) => r.page_slug)),
      };
    },
  });
}
