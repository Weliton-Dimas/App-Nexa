import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "@/hooks/use-toast";

export interface Prospect {
  id: string;
  user_id: string;
  company_name: string;
  contact_name: string | null;
  contact_role: string | null;
  email: string | null;
  phone: string | null;
  website_url: string | null;
  instagram_url: string | null;
  linkedin_url: string | null;
  status: string;
  temperature: string | null;
  source: string | null;
  bant_budget: boolean;
  bant_authority: boolean;
  bant_need: boolean;
  bant_timeline: boolean;
  next_action: string | null;
  next_action_at: string | null;
  estimated_value: number | null;
  notes: string | null;
  position: number;
  created_at: string;
  updated_at: string;
}

export type ProspectInput = Omit<Prospect, "id" | "user_id" | "created_at" | "updated_at" | "position">;

export function useProspects() {
  return useQuery<Prospect[]>({
    queryKey: ["prospects"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("prospects")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as Prospect[];
    },
  });
}

export function useUpsertProspect() {
  const qc = useQueryClient();
  const { user } = useAuth();
  return useMutation({
    mutationFn: async (input: Partial<Prospect> & { id?: string }) => {
      if (!user) throw new Error("Not authenticated");
      if (input.id) {
        const { id, ...rest } = input;
        const { data, error } = await supabase
          .from("prospects")
          .update(rest)
          .eq("id", id)
          .select()
          .single();
        if (error) throw error;
        return data;
      } else {
        const { data, error } = await supabase
          .from("prospects")
          .insert({ ...input, user_id: user.id, company_name: input.company_name ?? "" })
          .select()
          .single();
        if (error) throw error;
        return data;
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["prospects"] });
      toast({ title: "Prospect salvo" });
    },
    onError: (e: any) => toast({ title: "Erro ao salvar", description: e.message, variant: "destructive" }),
  });
}

export function useDeleteProspect() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("prospects").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["prospects"] });
      toast({ title: "Prospect removido" });
    },
  });
}
