import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useEffect } from "react";

export interface AppSettings {
  id: string;
  app_name: string;
  logo_url: string | null;
  favicon_url: string | null;
}

const CACHE_KEY = "app-branding-cache";

const DEFAULTS: AppSettings = {
  id: "",
  app_name: "Centralize",
  logo_url: null,
  favicon_url: null,
};

function readCache(): AppSettings | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(CACHE_KEY);
    if (!raw) return null;
    return JSON.parse(raw) as AppSettings;
  } catch {
    return null;
  }
}

function writeCache(data: AppSettings) {
  try {
    window.localStorage.setItem(CACHE_KEY, JSON.stringify(data));
  } catch {
    /* ignore */
  }
}

export function useAppSettings() {
  return useQuery<AppSettings>({
    queryKey: ["app-settings"],
    initialData: () => readCache() ?? undefined,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("app_settings")
        .select("id, app_name, logo_url, favicon_url")
        .limit(1)
        .maybeSingle();
      if (error) throw error;
      const result = data ?? DEFAULTS;
      writeCache(result);
      return result;
    },
    staleTime: 60_000,
  });
}

export function useInvalidateAppSettings() {
  const qc = useQueryClient();
  return () => qc.invalidateQueries({ queryKey: ["app-settings"] });
}

/** Applies app_name to <title> and favicon_url to <link rel="icon"> */
export function useApplyBranding() {
  const { data } = useAppSettings();
  useEffect(() => {
    const source = data ?? readCache();
    if (!source) return;
    document.title = source.app_name || "Centralize";
    if (source.favicon_url) {
      let link = document.querySelector<HTMLLinkElement>("link[rel~='icon']");
      if (!link) {
        link = document.createElement("link");
        link.rel = "icon";
        document.head.appendChild(link);
      }
      link.href = source.favicon_url;
    }
  }, [data]);
}
