import { useQuery, useQueryClient, useMutation } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface NavOrder {
  sections?: string[];
  /** Map of section title -> ordered labels assigned to that section */
  items?: Record<string, string[]>;
}

interface AppSettingsRow {
  id: string;
  nav_order: NavOrder | null;
}

export function useNavOrder() {
  return useQuery<{ id: string; order: NavOrder }>({
    queryKey: ["app-settings-nav-order"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("app_settings")
        .select("id, nav_order")
        .limit(1)
        .maybeSingle();
      if (error) throw error;
      const row = data as AppSettingsRow | null;
      return { id: row?.id ?? "", order: (row?.nav_order as NavOrder) ?? {} };
    },
    staleTime: 60_000,
  });
}

export function useSaveNavOrder() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, order }: { id: string; order: NavOrder }) => {
      if (id) {
        const { error } = await supabase
          .from("app_settings")
          .update({ nav_order: order as any })
          .eq("id", id);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from("app_settings")
          .insert({ nav_order: order as any });
        if (error) throw error;
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["app-settings-nav-order"] });
    },
  });
}

/**
 * Reorder sections + items based on stored order, supporting items moved to a
 * different section than where they're defined in code. Anything missing from
 * the stored order falls back to its original code position.
 */
export function applyNavOrder<
  I extends { label: string },
  S extends { title: string; items: I[] },
>(sections: S[], order: NavOrder | undefined): S[] {
  if (!order || (!order.sections && !order.items)) return sections;

  // Map of label -> { item, originalSection, originalIndexGlobal }
  const allItems = new Map<string, { item: I; originalSection: string; originalIndex: number }>();
  let globalIdx = 0;
  for (const s of sections) {
    for (const i of s.items) {
      allItems.set(i.label, { item: i, originalSection: s.title, originalIndex: globalIdx++ });
    }
  }

  // Determine target section for each known label
  const targetSection = new Map<string, string>();
  if (order.items) {
    for (const [sectionTitle, labels] of Object.entries(order.items)) {
      for (const l of labels) {
        if (allItems.has(l)) targetSection.set(l, sectionTitle);
      }
    }
  }
  // Labels not in stored order keep their original section
  for (const [label, meta] of allItems) {
    if (!targetSection.has(label)) targetSection.set(label, meta.originalSection);
  }

  // Ordered list of section titles to render: stored order first, then any
  // code section not present in stored order, appended in code order.
  const codeTitles = sections.map((s) => s.title);
  const codeTitleSet = new Set(codeTitles);
  const orderedTitles: string[] = [];
  for (const t of order.sections ?? []) {
    if (codeTitleSet.has(t) && !orderedTitles.includes(t)) orderedTitles.push(t);
  }
  for (const t of codeTitles) if (!orderedTitles.includes(t)) orderedTitles.push(t);

  const result: S[] = [];
  for (const title of orderedTitles) {
    const codeSection = sections.find((s) => s.title === title);
    if (!codeSection) continue;
    const desired = order.items?.[title] ?? [];
    // Collect every label whose target section is this one
    const labels = Array.from(allItems.entries())
      .filter(([l]) => targetSection.get(l) === title)
      .map(([l]) => l);
    labels.sort((a, b) => {
      const ia = desired.indexOf(a);
      const ib = desired.indexOf(b);
      if (ia === -1 && ib === -1) {
        return allItems.get(a)!.originalIndex - allItems.get(b)!.originalIndex;
      }
      if (ia === -1) return 1;
      if (ib === -1) return -1;
      return ia - ib;
    });
    const items = labels.map((l) => allItems.get(l)!.item);
    result.push({ ...codeSection, items } as S);
  }
  return result;
}
