import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { DEFAULT_SETTINGS, type InstallmentRate, type PricingSettings } from "@/lib/pricingMath";

export interface PricingSettingsRow extends PricingSettings {
  id: string;
  client_id: string;
  user_id: string;
}

export function usePricingSettings(clientId: string | null) {
  return useQuery({
    queryKey: ["pricing-settings", clientId],
    enabled: !!clientId,
    queryFn: async (): Promise<PricingSettingsRow | null> => {
      const { data, error } = await supabase
        .from("pricing_settings" as any)
        .select("*")
        .eq("client_id", clientId!)
        .maybeSingle();
      if (error) throw error;
      if (!data) return null;
      const d: any = data;
      return {
        ...d,
        installment_rates: Array.isArray(d.installment_rates) && d.installment_rates.length
          ? (d.installment_rates as InstallmentRate[])
          : DEFAULT_SETTINGS.installment_rates,
        column_kinds: (d.column_kinds && typeof d.column_kinds === "object") ? d.column_kinds : {},
        old_price_discount_pct: typeof d.old_price_discount_pct === "number" ? d.old_price_discount_pct : 15,
        pix_discount_pct: typeof d.pix_discount_pct === "number" ? d.pix_discount_pct : 5,
        column_widths: (d.column_widths && typeof d.column_widths === "object" && !Array.isArray(d.column_widths)) ? d.column_widths : {},
        hidden_columns: Array.isArray(d.hidden_columns) ? d.hidden_columns : [],
      } as PricingSettingsRow;
    },
  });
}

export function useUpsertSettings() {
  const qc = useQueryClient();
  const { user } = useAuth();
  return useMutation({
    mutationFn: async (s: Partial<PricingSettingsRow> & { client_id: string }) => {
      const payload: any = { ...s };
      if (s.id) {
        const { id, ...rest } = payload;
        const { data, error } = await supabase
          .from("pricing_settings" as any)
          .update(rest)
          .eq("id", id)
          .select()
          .single();
        if (error) throw error;
        return data as any;
      }
      payload.user_id = user!.id;
      const { data, error } = await supabase
        .from("pricing_settings" as any)
        .insert(payload)
        .select()
        .single();
      if (error) throw error;
      return data as any;
    },
    onSuccess: (d: any) => qc.invalidateQueries({ queryKey: ["pricing-settings", d.client_id] }),
  });
}
