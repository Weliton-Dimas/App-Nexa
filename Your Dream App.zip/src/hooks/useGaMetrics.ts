import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface GaChannelRow {
  channel: string;
  sessions: number;
  conversions: number;
  revenue: number;
}

export interface GaMetrics {
  sessions: number;
  activeUsers: number;
  conversions: number;
  revenue: number;
  engagementRate: number;
  avgSessionDuration: number;
  channels: GaChannelRow[];
}

export function useGaMetrics(clientId: string | undefined, datePreset: string = "last_7d", enabled = true) {
  return useQuery<{ data?: GaMetrics; error?: string }>({
    queryKey: ["ga-metrics", clientId, datePreset],
    enabled: !!clientId && enabled,
    staleTime: 60_000,
    queryFn: async () => {
      const { data: session } = await supabase.auth.getSession();
      const token = session?.session?.access_token;
      const url = new URL(
        `https://${import.meta.env.VITE_SUPABASE_PROJECT_ID}.supabase.co/functions/v1/ga-metrics`,
      );
      url.searchParams.set("client_id", clientId!);
      url.searchParams.set("date_preset", datePreset);
      const res = await fetch(url.toString(), {
        headers: { Authorization: `Bearer ${token ?? ""}` },
      });
      const json = await res.json();
      if (!res.ok) return { error: json?.error || "Falha ao buscar GA4" };
      return { data: json as GaMetrics };
    },
  });
}
