import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface DailyDevotional {
  id: string;
  date: string;
  verse: string;
  reference: string;
  reflection: string;
  prayer: string;
  application: string;
}

const CACHE_KEY = "daily-devotional-cache";

function todayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function readCache(date: string): DailyDevotional | null {
  try {
    const raw = localStorage.getItem(CACHE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as { date: string; data: DailyDevotional };
    return parsed?.date === date ? parsed.data : null;
  } catch {
    return null;
  }
}

function writeCache(date: string, data: DailyDevotional) {
  try {
    localStorage.setItem(CACHE_KEY, JSON.stringify({ date, data }));
  } catch {
    /* ignore */
  }
}

export function useDailyDevotional() {
  const date = todayKey();
  return useQuery({
    queryKey: ["daily-devotional", date],
    initialData: () => readCache(date) ?? undefined,
    queryFn: async (): Promise<DailyDevotional> => {
      const { data, error } = await supabase.functions.invoke<DailyDevotional>(
        "daily-devotional",
      );
      if (error) throw error;
      if (!data) throw new Error("Sem dados");
      writeCache(date, data);
      return data;
    },
    staleTime: 1000 * 60 * 60 * 12, // 12h
    retry: 1,
  });
}
