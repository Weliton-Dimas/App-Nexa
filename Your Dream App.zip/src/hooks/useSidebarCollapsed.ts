import { useEffect, useState } from "react";

const KEY = "sidebar-collapsed";
const EVT = "sidebar-collapsed-changed";
const MOBILE_BP = 768;

function isMobileNow(): boolean {
  if (typeof window === "undefined") return false;
  return window.innerWidth < MOBILE_BP;
}

function read(): boolean {
  if (typeof window === "undefined") return false;
  const stored = window.localStorage.getItem(KEY);
  if (stored === null) return isMobileNow();
  return stored === "1";
}

export function useSidebarCollapsed() {
  const [collapsed, setCollapsedState] = useState<boolean>(read);
  const [mobile, setMobile] = useState<boolean>(isMobileNow);

  useEffect(() => {
    const handler = () => {
      setCollapsedState(read());
      setMobile(isMobileNow());
    };
    window.addEventListener(EVT, handler);
    window.addEventListener("storage", handler);
    window.addEventListener("resize", handler);
    return () => {
      window.removeEventListener(EVT, handler);
      window.removeEventListener("storage", handler);
      window.removeEventListener("resize", handler);
    };
  }, []);

  const setCollapsed = (value: boolean) => {
    window.localStorage.setItem(KEY, value ? "1" : "0");
    window.dispatchEvent(new Event(EVT));
  };

  return { collapsed, setCollapsed, toggle: () => setCollapsed(!collapsed), isMobile: mobile };
}
