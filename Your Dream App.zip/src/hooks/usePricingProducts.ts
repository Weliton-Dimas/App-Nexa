import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import type { ExtraCost } from "@/lib/pricingMath";

export interface PricingProduct {
  id: string;
  client_id: string;
  user_id: string;
  position: number;
  name: string;
  sku: string | null;
  product_cost: number;
  taxes_pct: number;
  card_pct: number;
  gateway_pct: number;
  pix_pct: number;
  boleto_value: number;
  mix_card_pct: number;
  mix_pix_pct: number;
  mix_boleto_pct: number;
  platform_pct: number;
  marketing_pct: number;
  commission_pct: number;
  other_deductions_pct: number;
  selling_cost: number;
  shipping_cost: number;
  packaging_cost: number;
  other_inputs_cost: number;
  desired_margin_pct: number;
  margin_mode: "margin" | "markup";
  current_price: number;
  extra_costs: ExtraCost[];
  created_at: string;
  updated_at: string;
}

export function usePricingProducts(clientId: string | null) {
  return useQuery({
    queryKey: ["pricing-products", clientId],
    enabled: !!clientId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("pricing_products")
        .select("*")
        .eq("client_id", clientId!)
        .order("position", { ascending: true });
      if (error) throw error;
      return (data ?? []).map((d: any) => ({
        ...d,
        extra_costs: Array.isArray(d.extra_costs) ? d.extra_costs : [],
      })) as PricingProduct[];
    },
  });
}

export function useUpsertProduct() {
  const qc = useQueryClient();
  const { user } = useAuth();
  return useMutation({
    mutationFn: async (p: Partial<PricingProduct> & { client_id: string }) => {
      const payload: any = { ...p };
      if (p.id) {
        // UPDATE: avoids INSERT WITH CHECK requiring user_id
        const { id, ...rest } = payload;
        const { data, error } = await supabase
          .from("pricing_products")
          .update(rest)
          .eq("id", id)
          .select()
          .single();
        if (error) throw error;
        return data as unknown as PricingProduct;
      }
      payload.user_id = user!.id;
      const { data, error } = await supabase
        .from("pricing_products")
        .insert(payload)
        .select()
        .single();
      if (error) throw error;
      return data as unknown as PricingProduct;
    },
    onSuccess: (d) => qc.invalidateQueries({ queryKey: ["pricing-products", d.client_id] }),
  });
}

export function useDeleteProduct() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (p: { id: string; client_id: string }) => {
      const { error } = await supabase.from("pricing_products").delete().eq("id", p.id);
      if (error) throw error;
      return p;
    },
    onSuccess: (p) => qc.invalidateQueries({ queryKey: ["pricing-products", p.client_id] }),
  });
}
