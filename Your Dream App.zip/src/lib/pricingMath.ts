// Pure pricing math — no React, fully testable.

export interface ExtraCost {
  id: string;
  label: string;
  kind: "pct" | "value";
  value: number;
}

export interface InstallmentRate {
  n: number;
  rate: number; // total accumulated % charged for that # of installments
}

export type ColumnKind = "pct" | "value";
export type ColumnKinds = Partial<Record<TogglableField, ColumnKind>>;

/** Fields whose `kind` (% vs R$) can be toggled by the user. */
export type TogglableField =
  | "card_pct"
  | "gateway_pct"
  | "pix_pct"
  | "boleto_value"
  | "taxes_pct"
  | "platform_pct"
  | "commission_pct"
  | "other_deductions_pct"
  | "marketing_pct";

/** Native default kind for each toggle-able field. */
export const NATIVE_KIND: Record<TogglableField, ColumnKind> = {
  card_pct: "pct",
  gateway_pct: "pct",
  pix_pct: "pct",
  boleto_value: "value",
  taxes_pct: "pct",
  platform_pct: "pct",
  commission_pct: "pct",
  other_deductions_pct: "pct",
  marketing_pct: "pct",
};

export const effectiveKind = (k: ColumnKinds | undefined, f: TogglableField): ColumnKind =>
  (k && k[f]) || NATIVE_KIND[f];

export interface PricingSettings {
  installment_rates: InstallmentRate[];
  mix_card_pct: number;
  mix_pix_pct: number;
  mix_boleto_pct: number;
  pix_fee_pct: number;
  boleto_fee_value: number;
  gateway_pct: number;
  max_installments: number;
  old_price_discount_pct: number;
  pix_discount_pct: number;
  column_kinds?: ColumnKinds;
  column_widths?: Record<string, number>;
  hidden_columns?: string[];
}

export const DEFAULT_INSTALLMENT_RATES: InstallmentRate[] = [
  { n: 1, rate: 3.5 },
  { n: 2, rate: 4.8 },
  { n: 3, rate: 5.5 },
  { n: 4, rate: 6.5 },
  { n: 5, rate: 7.5 },
  { n: 6, rate: 8.5 },
  { n: 7, rate: 10.0 },
  { n: 8, rate: 11.0 },
  { n: 9, rate: 12.0 },
  { n: 10, rate: 13.5 },
  { n: 11, rate: 15.0 },
  { n: 12, rate: 17.0 },
];

export const DEFAULT_SETTINGS: PricingSettings = {
  installment_rates: DEFAULT_INSTALLMENT_RATES,
  mix_card_pct: 70,
  mix_pix_pct: 25,
  mix_boleto_pct: 5,
  pix_fee_pct: 0,
  boleto_fee_value: 0,
  gateway_pct: 0,
  max_installments: 12,
  old_price_discount_pct: 15,
  pix_discount_pct: 5,
  column_widths: {},
  hidden_columns: [],
};


export interface PricingProductRow {
  product_cost: number;
  taxes_pct: number;
  card_pct: number;
  gateway_pct?: number;
  pix_pct?: number;
  boleto_value?: number;
  mix_card_pct?: number;
  mix_pix_pct?: number;
  mix_boleto_pct?: number;
  platform_pct: number;
  marketing_pct: number;
  commission_pct: number;
  other_deductions_pct: number;
  selling_cost: number;
  shipping_cost: number;
  packaging_cost: number;
  other_inputs_cost: number;
  desired_margin_pct: number;
  /** "margin" = % sobre preço de venda (≤ 100). "markup" = % sobre custo (sem limite). */
  margin_mode?: "margin" | "markup";
  extra_costs?: ExtraCost[];
}

export interface ProductPricingResult {
  totalDeductionsPct: number;
  totalFixedCosts: number;
  sellingPrice: number;
  deductionsAmount: number;
  netProfit: number;
  netMarginPct: number;
  costPctOfPrice: number;
  adsBudgetPerUnit: number;
  paymentMixPct: number;     // ponderado: cartão+gateway+pix
  paymentMixValue: number;   // boleto fixo ponderado por mix
}

/**
 * Returns the row's contribution split into "pct" or "value" based on the
 * effective kind for that field.
 */
function splitField(
  raw: number | undefined,
  field: TogglableField,
  kinds: ColumnKinds | undefined,
): { pct: number; value: number } {
  const v = Number(raw) || 0;
  return effectiveKind(kinds, field) === "value" ? { pct: 0, value: v } : { pct: v, value: 0 };
}

/**
 * Suggested price formula:
 *   price = (totalFixedCosts) / (1 - (deductionsPct + margin%))
 *
 * Payment costs are weighted by the sales mix:
 *   paymentMixPct   = mixCard% × (card% + gateway%) + mixPix% × pix%
 *   paymentMixValue = mixBoleto% × boletoFixoR$
 *
 * When the user toggles a payment column to "value" it becomes a fixed R$ per
 * sale of that method (still weighted by mix). When the user toggles a
 * platform/marketing column to "value" it becomes a fixed R$ per unit.
 */
export function computeProductPricing(
  p: PricingProductRow,
  kinds: ColumnKinds = {},
): ProductPricingResult {
  const extras = p.extra_costs ?? [];
  const extraPct = extras.filter((e) => e.kind === "pct").reduce((a, e) => a + (Number(e.value) || 0), 0);
  const extraValue = extras.filter((e) => e.kind === "value").reduce((a, e) => a + (Number(e.value) || 0), 0);

  const mixCard = (p.mix_card_pct ?? 100) / 100;
  const mixPix = (p.mix_pix_pct ?? 0) / 100;
  const mixBoleto = (p.mix_boleto_pct ?? 0) / 100;

  // Payment columns: each can be % (of price) or R$ (per sale of that method).
  const card = splitField(p.card_pct, "card_pct", kinds);
  const gw = splitField(p.gateway_pct, "gateway_pct", kinds);
  const pix = splitField(p.pix_pct, "pix_pct", kinds);
  const boleto = splitField(p.boleto_value, "boleto_value", kinds);

  const paymentMixPct =
    mixCard * (card.pct + gw.pct) +
    mixPix * pix.pct +
    mixBoleto * boleto.pct;
  const paymentMixValue =
    mixCard * (card.value + gw.value) +
    mixPix * pix.value +
    mixBoleto * boleto.value;

  // Deduction columns (taxes, platform, commission, other, marketing).
  const taxes = splitField(p.taxes_pct, "taxes_pct", kinds);
  const platform = splitField(p.platform_pct, "platform_pct", kinds);
  const commission = splitField(p.commission_pct, "commission_pct", kinds);
  const other = splitField(p.other_deductions_pct, "other_deductions_pct", kinds);
  const marketing = splitField(p.marketing_pct, "marketing_pct", kinds);

  const totalDeductionsPct =
    taxes.pct +
    paymentMixPct +
    platform.pct +
    marketing.pct +
    commission.pct +
    other.pct +
    extraPct;

  const totalFixedCosts =
    (p.product_cost || 0) +
    (p.selling_cost || 0) +
    (p.shipping_cost || 0) +
    (p.packaging_cost || 0) +
    (p.other_inputs_cost || 0) +
    paymentMixValue +
    taxes.value +
    platform.value +
    commission.value +
    other.value +
    marketing.value +
    extraValue;

  const margin = Number(p.desired_margin_pct) || 0;
  const dedFrac = totalDeductionsPct / 100;
  let sellingPrice = 0;
  if (totalFixedCosts > 0 && dedFrac < 1) {
    if (p.margin_mode === "markup") {
      // Markup como multiplicador (×): aplica também sobre as taxas em %
      // (cartão, gateway, Pix%, impostos, plataforma, comissão, marketing%).
      // price = (custos_fixos × N) / (1 − N × deduções%)
      const mult = margin > 0 ? margin : 1;
      const denom = 1 - mult * dedFrac;
      sellingPrice = denom > 0 ? (totalFixedCosts * mult) / denom : 0;
    } else {
      const denom = 1 - dedFrac - margin / 100;
      sellingPrice = denom > 0 ? totalFixedCosts / denom : 0;
    }
  }
  const deductionsAmount = sellingPrice * (totalDeductionsPct / 100);
  const netProfit = sellingPrice - totalFixedCosts - deductionsAmount;
  const netMarginPct = sellingPrice > 0 ? (netProfit / sellingPrice) * 100 : 0;
  const costPctOfPrice = sellingPrice > 0 ? (totalFixedCosts / sellingPrice) * 100 : 0;
  const adsBudgetPerUnit =
    effectiveKind(kinds, "marketing_pct") === "value"
      ? marketing.value
      : sellingPrice * (marketing.pct / 100);
  return {
    totalDeductionsPct,
    totalFixedCosts,
    sellingPrice,
    deductionsAmount,
    netProfit,
    netMarginPct,
    costPctOfPrice,
    adsBudgetPerUnit,
    paymentMixPct,
    paymentMixValue,
  };
}

/**
 * Computes the suggested price assuming 100% of sales happen via the chosen
 * payment method. Used to expose parallel suggested prices (Pix / Cartão 1x /
 * Boleto) without altering the row's stored data.
 *
 * - "pix":     mix = 100% Pix → uses pix_pct.
 * - "card1x":  mix = 100% Cartão → uses installment_rates[n=1] as the card fee
 *              (falls back to row.card_pct when the table has no 1x rate),
 *              keeps gateway_pct.
 * - "boleto":  mix = 100% Boleto → uses boleto_value.
 */
export function computeSuggestedByMethod(
  row: PricingProductRow,
  settings: PricingSettings,
  method: "pix" | "card1x" | "boleto",
): ProductPricingResult {
  const r: PricingProductRow = {
    ...row,
    mix_card_pct: 0,
    mix_pix_pct: 0,
    mix_boleto_pct: 0,
  };
  if (method === "pix") {
    r.mix_pix_pct = 100;
  } else if (method === "boleto") {
    r.mix_boleto_pct = 100;
  } else {
    r.mix_card_pct = 100;
    const rate1x = settings.installment_rates?.find((x) => x.n === 1)?.rate;
    if (typeof rate1x === "number") r.card_pct = rate1x;
  }
  return computeProductPricing(r, settings.column_kinds);
}

/**
 * Computes the Pix selling price as a promotional discount over a "full price"
 * (typically the Sug. Cartão 1x). Used when the user wants to display Cartão as
 * the website's full price and Pix as a discount — common e-commerce pattern.
 *
 * pixPrice = fullPrice × (1 − pix_discount_pct/100)
 *
 * Profit/margin are recomputed for the discounted price using the row's Pix
 * payment cost (% or R$ depending on column kind) and the same non-payment
 * deductions/fixed costs.
 */
export function computePixWithDiscount(
  fullPrice: number,
  row: PricingProductRow,
  settings: PricingSettings,
): { sellingPrice: number; netProfit: number; netMarginPct: number; discountPct: number } {
  const discountPct = Math.max(0, Math.min(99.999, Number(settings.pix_discount_pct ?? 0)));
  if (!(fullPrice > 0)) return { sellingPrice: 0, netProfit: 0, netMarginPct: 0, discountPct };
  const pixPrice = fullPrice * (1 - discountPct / 100);
  // Recompute deductions/fixed costs for a 100%-Pix scenario, then apply on
  // the discounted price.
  const r: PricingProductRow = { ...row, mix_card_pct: 0, mix_pix_pct: 100, mix_boleto_pct: 0 };
  const base = computeProductPricing(r, settings.column_kinds);
  const deductions = pixPrice * (base.totalDeductionsPct / 100);
  const netProfit = pixPrice - base.totalFixedCosts - deductions;
  const netMarginPct = pixPrice > 0 ? (netProfit / pixPrice) * 100 : 0;
  return { sellingPrice: pixPrice, netProfit, netMarginPct, discountPct };
}

export interface BreakEven {
  minRoas: number;
  maxCpa: number;
}

export interface CurrentProfitResult {
  hasPrice: boolean;
  deductionsAmount: number;
  netProfit: number;
  netMarginPct: number;
  diffVsSuggested: number;
  diffPct: number;
}

export function computeCurrentProfit(
  base: ProductPricingResult,
  currentPrice: number,
): CurrentProfitResult {
  const price = Number(currentPrice) || 0;
  if (price <= 0) {
    return { hasPrice: false, deductionsAmount: 0, netProfit: 0, netMarginPct: 0, diffVsSuggested: 0, diffPct: 0 };
  }
  const deductionsAmount = price * (base.totalDeductionsPct / 100);
  const netProfit = price - base.totalFixedCosts - deductionsAmount;
  const netMarginPct = (netProfit / price) * 100;
  const diffVsSuggested = price - base.sellingPrice;
  const diffPct = base.sellingPrice > 0 ? (diffVsSuggested / base.sellingPrice) * 100 : 0;
  return { hasPrice: true, deductionsAmount, netProfit, netMarginPct, diffVsSuggested, diffPct };
}

export function computeBreakEven(r: { netMarginPct: number; netProfit: number; adsBudgetPerUnit: number }): BreakEven {
  const minRoas = r.netMarginPct > 0 ? 100 / r.netMarginPct : Infinity;
  const maxCpa = r.adsBudgetPerUnit + Math.max(0, r.netProfit);
  return { minRoas, maxCpa };
}

export interface SensitivityRow {
  delta: number;
  newPrice: number;
  newProfit: number;
  volumeForSameProfit: number;
}

export function computeSensitivity(base: ProductPricingResult, p: PricingProductRow): SensitivityRow[] {
  const deltas = [-10, -5, 0, 5, 10];
  return deltas.map((d) => {
    const newPrice = base.sellingPrice * (1 + d / 100);
    const deductions = newPrice * (base.totalDeductionsPct / 100);
    const newProfit = newPrice - base.totalFixedCosts - deductions;
    const volumeForSameProfit = newProfit > 0 ? base.netProfit / newProfit : Infinity;
    return { delta: d, newPrice, newProfit, volumeForSameProfit };
  });
}

/**
 * Cost base excludes the card/gateway% (per single sale at full card price)
 * because installment view recomputes its own card fee per # of installments.
 * It DOES include all other deductions (taxes, platform, marketing, commission,
 * extras) and all fixed costs.
 */
function nonCardCostBase(
  row: PricingProductRow,
  base: ProductPricingResult,
  price: number,
  kinds: ColumnKinds = {},
) {
  // Recompute non-payment deductions on price, respecting column kinds.
  const taxes = splitField(row.taxes_pct, "taxes_pct", kinds);
  const platform = splitField(row.platform_pct, "platform_pct", kinds);
  const marketing = splitField(row.marketing_pct, "marketing_pct", kinds);
  const commission = splitField(row.commission_pct, "commission_pct", kinds);
  const other = splitField(row.other_deductions_pct, "other_deductions_pct", kinds);
  const nonPaymentPct =
    taxes.pct + platform.pct + marketing.pct + commission.pct + other.pct +
    (row.extra_costs ?? []).filter((e) => e.kind === "pct").reduce((a, e) => a + (Number(e.value) || 0), 0);
  const nonPaymentValue =
    (row.product_cost || 0) +
    (row.selling_cost || 0) +
    (row.shipping_cost || 0) +
    (row.packaging_cost || 0) +
    (row.other_inputs_cost || 0) +
    taxes.value + platform.value + marketing.value + commission.value + other.value +
    (row.extra_costs ?? []).filter((e) => e.kind === "value").reduce((a, e) => a + (Number(e.value) || 0), 0);
  return {
    nonPaymentPct,
    nonPaymentValue,
    nonPaymentDeductions: price * (nonPaymentPct / 100),
  };
}

export interface InstallmentRow {
  n: number;
  rate: number;
  installmentValue: number;
  netReceived: number;
  netProfit: number;
  netMarginPct: number;
}

/**
 * Returns gateway fee per sale (R$) regardless of whether the gateway column
 * is in % or R$ mode.
 */
function gatewayFeeOnPrice(row: PricingProductRow, price: number, kinds: ColumnKinds): number {
  return effectiveKind(kinds, "gateway_pct") === "value"
    ? Number(row.gateway_pct) || 0
    : price * ((Number(row.gateway_pct) || 0) / 100);
}

export function computeInstallments(
  row: PricingProductRow,
  base: ProductPricingResult,
  settings: PricingSettings,
  price: number,
): InstallmentRow[] {
  const kinds = settings.column_kinds ?? {};
  const rates = settings.installment_rates?.length ? settings.installment_rates : DEFAULT_INSTALLMENT_RATES;
  const max = settings.max_installments || 12;
  const list = rates.filter((r) => r.n >= 1 && r.n <= max).sort((a, b) => a.n - b.n);
  const ctx = nonCardCostBase(row, base, price, kinds);
  const gwFee = gatewayFeeOnPrice(row, price, kinds);
  return list.map((r) => {
    const cardFeeOnly = price * (r.rate / 100); // installment rate stays %
    const totalFee = cardFeeOnly + gwFee;
    const netReceived = price - totalFee;
    const netProfit = netReceived - ctx.nonPaymentValue - ctx.nonPaymentDeductions;
    const netMarginPct = price > 0 ? (netProfit / price) * 100 : 0;
    return {
      n: r.n,
      rate: r.rate + (price > 0 ? (gwFee / price) * 100 : 0),
      installmentValue: price / r.n,
      netReceived,
      netProfit,
      netMarginPct,
    };
  });
}

export interface PaymentMethodRow {
  method: "pix" | "boleto" | "card1x" | "card6x" | "card12x";
  label: string;
  netReceived: number;
  netProfit: number;
  netMarginPct: number;
}

export function computePaymentBreakdown(
  row: PricingProductRow,
  base: ProductPricingResult,
  settings: PricingSettings,
  price: number,
): PaymentMethodRow[] {
  const kinds = settings.column_kinds ?? {};
  const ctx = nonCardCostBase(row, base, price, kinds);
  const rates = settings.installment_rates?.length ? settings.installment_rates : DEFAULT_INSTALLMENT_RATES;
  const rateOf = (n: number) => rates.find((r) => r.n === n)?.rate ?? 0;
  const gwFee = gatewayFeeOnPrice(row, price, kinds);

  const buildCard = (n: number, label: string): PaymentMethodRow => {
    const fee = price * (rateOf(n) / 100) + gwFee;
    const netReceived = price - fee;
    const netProfit = netReceived - ctx.nonPaymentValue - ctx.nonPaymentDeductions;
    return {
      method: `card${n}x` as PaymentMethodRow["method"],
      label,
      netReceived,
      netProfit,
      netMarginPct: price > 0 ? (netProfit / price) * 100 : 0,
    };
  };

  const pixFee = effectiveKind(kinds, "pix_pct") === "value"
    ? Number(row.pix_pct) || 0
    : price * ((Number(row.pix_pct) || 0) / 100);
  const pixNet = price - pixFee;
  const boletoFee = effectiveKind(kinds, "boleto_value") === "pct"
    ? price * ((Number(row.boleto_value) || 0) / 100)
    : Number(row.boleto_value) || 0;
  const boletoNet = price - boletoFee;

  return [
    {
      method: "pix",
      label: "Pix",
      netReceived: pixNet,
      netProfit: pixNet - ctx.nonPaymentValue - ctx.nonPaymentDeductions,
      netMarginPct: price > 0 ? ((pixNet - ctx.nonPaymentValue - ctx.nonPaymentDeductions) / price) * 100 : 0,
    },
    {
      method: "boleto",
      label: "Boleto",
      netReceived: boletoNet,
      netProfit: boletoNet - ctx.nonPaymentValue - ctx.nonPaymentDeductions,
      netMarginPct: price > 0 ? ((boletoNet - ctx.nonPaymentValue - ctx.nonPaymentDeductions) / price) * 100 : 0,
    },
    buildCard(1, "Cartão 1x"),
    buildCard(6, "Cartão 6x"),
    buildCard(12, "Cartão 12x"),
  ];
}

export const fmtBRL = (v: number) =>
  Number.isFinite(v)
    ? v.toLocaleString("pt-BR", { style: "currency", currency: "BRL", maximumFractionDigits: 2 })
    : "—";

export const fmtPct = (v: number, digits = 1) =>
  Number.isFinite(v) ? `${v.toFixed(digits)}%` : "—";

export const fmtNum = (v: number, digits = 0) =>
  Number.isFinite(v) ? v.toLocaleString("pt-BR", { maximumFractionDigits: digits }) : "—";
