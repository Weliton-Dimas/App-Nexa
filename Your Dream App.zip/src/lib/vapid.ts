// Public VAPID key — safe to expose in client. Must match server VAPID_PUBLIC_KEY secret.
export const VAPID_PUBLIC_KEY =
  "BP7so-51yWRxCzXrxg9Zql5_nHX4cC9-nEQwQm3Pcsrmic6JlcdVW6d9KdvKpwiGWU9ukm79PBJXaNle2RcMWFw";

export function urlBase64ToUint8Array(base64String: string): Uint8Array {
  const padding = "=".repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
  const raw = atob(base64);
  const arr = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++) arr[i] = raw.charCodeAt(i);
  return arr;
}
