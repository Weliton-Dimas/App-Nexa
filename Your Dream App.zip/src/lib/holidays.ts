// Feriados nacionais BR + sazonalidades comerciais.
// Cada item retorna a data calculada para um ano específico.

export type HolidayKind = "feriado" | "sazonalidade";

export interface HolidayEntry {
  date: Date;
  name: string;
  kind: HolidayKind;
}

// Cálculo da Páscoa (Anonymous Gregorian algorithm)
function easter(year: number): Date {
  const a = year % 19;
  const b = Math.floor(year / 100);
  const c = year % 100;
  const d = Math.floor(b / 4);
  const e = b % 4;
  const f = Math.floor((b + 8) / 25);
  const g = Math.floor((b - f + 1) / 3);
  const h = (19 * a + b - d - g + 15) % 30;
  const i = Math.floor(c / 4);
  const k = c % 4;
  const l = (32 + 2 * e + 2 * i - h - k) % 7;
  const m = Math.floor((a + 11 * h + 22 * l) / 451);
  const month = Math.floor((h + l - 7 * m + 114) / 31);
  const day = ((h + l - 7 * m + 114) % 31) + 1;
  return new Date(year, month - 1, day);
}

function addDays(d: Date, n: number): Date {
  const r = new Date(d);
  r.setDate(r.getDate() + n);
  return r;
}

// 4ª quinta-feira de novembro (Thanksgiving) → Black Friday é a sexta seguinte
function blackFriday(year: number): Date {
  const nov = new Date(year, 10, 1);
  const firstThu = (4 - nov.getDay() + 7) % 7;
  const fourthThu = 1 + firstThu + 21;
  return new Date(year, 10, fourthThu + 1);
}

// 2º domingo de maio
function mothersDay(year: number): Date {
  const may = new Date(year, 4, 1);
  const firstSun = (7 - may.getDay()) % 7;
  return new Date(year, 4, 1 + firstSun + 7);
}

// 2º domingo de agosto
function fathersDay(year: number): Date {
  const aug = new Date(year, 7, 1);
  const firstSun = (7 - aug.getDay()) % 7;
  return new Date(year, 7, 1 + firstSun + 7);
}

export function getHolidays(year: number): HolidayEntry[] {
  const easterDay = easter(year);
  return [
    // Feriados nacionais
    { date: new Date(year, 0, 1), name: "Confraternização Universal", kind: "feriado" },
    { date: addDays(easterDay, -48), name: "Carnaval", kind: "feriado" },
    { date: addDays(easterDay, -47), name: "Carnaval", kind: "feriado" },
    { date: addDays(easterDay, -2), name: "Sexta-feira Santa", kind: "feriado" },
    { date: easterDay, name: "Páscoa", kind: "feriado" },
    { date: new Date(year, 3, 21), name: "Tiradentes", kind: "feriado" },
    { date: new Date(year, 4, 1), name: "Dia do Trabalho", kind: "feriado" },
    { date: addDays(easterDay, 60), name: "Corpus Christi", kind: "feriado" },
    { date: new Date(year, 8, 7), name: "Independência do Brasil", kind: "feriado" },
    { date: new Date(year, 9, 12), name: "Nossa Senhora Aparecida", kind: "feriado" },
    { date: new Date(year, 10, 2), name: "Finados", kind: "feriado" },
    { date: new Date(year, 10, 15), name: "Proclamação da República", kind: "feriado" },
    { date: new Date(year, 10, 20), name: "Consciência Negra", kind: "feriado" },
    { date: new Date(year, 11, 25), name: "Natal", kind: "feriado" },

    // Sazonalidades / datas comerciais
    { date: new Date(year, 1, 14), name: "Dia dos Namorados (EUA)", kind: "sazonalidade" },
    { date: mothersDay(year), name: "Dia das Mães", kind: "sazonalidade" },
    { date: new Date(year, 5, 12), name: "Dia dos Namorados", kind: "sazonalidade" },
    { date: fathersDay(year), name: "Dia dos Pais", kind: "sazonalidade" },
    { date: new Date(year, 7, 15), name: "Dia dos Solteiros (preparação)", kind: "sazonalidade" },
    { date: new Date(year, 9, 12), name: "Dia das Crianças", kind: "sazonalidade" },
    { date: new Date(year, 9, 31), name: "Halloween", kind: "sazonalidade" },
    { date: new Date(year, 10, 11), name: "Dia dos Solteiros (11.11)", kind: "sazonalidade" },
    { date: blackFriday(year), name: "Black Friday", kind: "sazonalidade" },
    { date: addDays(blackFriday(year), 3), name: "Cyber Monday", kind: "sazonalidade" },
    { date: new Date(year, 11, 24), name: "Véspera de Natal", kind: "sazonalidade" },
    { date: new Date(year, 11, 31), name: "Réveillon", kind: "sazonalidade" },
  ];
}

export function getHolidaysForMonth(year: number, month: number): HolidayEntry[] {
  return getHolidays(year).filter((h) => h.date.getMonth() === month);
}

export function getHolidaysForDay(year: number, month: number, day: number): HolidayEntry[] {
  return getHolidays(year).filter(
    (h) => h.date.getMonth() === month && h.date.getDate() === day,
  );
}
