export const devotionals = [
  { verse: "O Senhor é o meu pastor; nada me faltará.", ref: "Salmos 23:1", reflection: "Confie que Deus supre cada necessidade do seu dia." },
  { verse: "Tudo posso naquele que me fortalece.", ref: "Filipenses 4:13", reflection: "A força para os desafios de hoje vem de cima, não de você mesmo." },
  { verse: "Busquem primeiro o reino de Deus e a sua justiça, e todas estas coisas lhes serão acrescentadas.", ref: "Mateus 6:33", reflection: "Priorize o essencial e o resto se alinhará." },
  { verse: "Acima de tudo, porém, revistam-se do amor, que é o elo perfeito.", ref: "Colossenses 3:14", reflection: "Hoje, escolha ser o ponto de união e compreensão em seus encontros." },
  { verse: "Não se amoldem ao padrão deste mundo, mas transformem-se pela renovação da sua mente.", ref: "Romanos 12:2", reflection: "Renove sua mente com a verdade e aja diferente." },
  { verse: "Sede fortes e corajosos. Não tenhais medo nem terror, porque o Senhor, vosso Deus, vai convosco.", ref: "Deuteronômio 31:6", reflection: "O medo não é o chefe — Deus sim. Avance com coragem." },
  { verse: "O coração do homem planeja o seu caminho, mas o Senhor lhe dirige os passos.", ref: "Provérbios 16:9", reflection: "Planeje com dedicação, mas entregue os resultados a Deus." },
  { verse: "Entrega o teu caminho ao Senhor; confia nele, e ele tudo fará.", ref: "Salmos 37:5", reflection: "Entrega significa ação com fé, não passividade." },
  { verse: "Por isso, não tema, pois estou com você; não se apavore, pois sou o seu Deus.", ref: "Isaías 41:10", reflection: "O Deus do universo está ao seu lado. Que medo pode resistir a isso?" },
  { verse: "A alegria do Senhor é a nossa força.", ref: "Neemias 8:10", reflection: "Cultive alegria como disciplina espiritual, não como emoção passageira." },
  { verse: "Portanto, confessem os seus pecados uns aos outros e orem uns pelos outros para que sejam curados.", ref: "Tiago 5:16", reflection: "A cura começa com honestidade e começa em comunidade." },
  { verse: "O amor é paciente, o amor é bondoso. Não inveja, não se vangloria, não se orgulha.", ref: "1 Coríntios 13:4", reflection: "Avalie seu amor de hoje por esse padrão." },
  { verse: "Deem graças em todas as circunstâncias, pois esta é a vontade de Deus para vocês.", ref: "1 Tessalonicenses 5:18", reflection: "A gratidão transforma a perspectiva antes mesmo de mudar as circunstâncias." },
  { verse: "Mas eu vos digo: amai os vossos inimigos e orai pelos que vos perseguem.", ref: "Mateus 5:44", reflection: "O amor radical é o testemunho mais poderoso que existe." },
  { verse: "Lancem sobre ele toda a sua ansiedade, porque ele tem cuidado de vocês.", ref: "1 Pedro 5:7", reflection: "Cada preocupação pode ser transformada em oração." },
  { verse: "Confie no Senhor de todo o seu coração e não se apoie em seu próprio entendimento.", ref: "Provérbios 3:5", reflection: "Sabedoria começa onde nossa autossuficiência termina." },
  { verse: "Vocês não me escolheram, mas eu os escolhi e os designei para que vão e dêem fruto.", ref: "João 15:16", reflection: "Você não está aqui por acidente — há um propósito para sua presença." },
  { verse: "Não se afaste deste livro da lei; medite nele de dia e de noite.", ref: "Josué 1:8", reflection: "Meditação na Palavra não é tarefa, é combustível." },
  { verse: "Que a paz de Deus, que excede todo o entendimento, guarde os seus corações e as suas mentes.", ref: "Filipenses 4:7", reflection: "A paz de Deus não se explica — ela se experiencia." },
  { verse: "Pois sou eu que conheço os planos que tenho para vocês, planos de paz e não de calamidade.", ref: "Jeremias 29:11", reflection: "O futuro está nas mãos de quem também cuida do presente." },
  { verse: "Em tudo dai graças, porque esta é a vontade de Deus em Cristo Jesus para convosco.", ref: "1 Tessalonicenses 5:18", reflection: "Gratidão não é ingenuidade — é fé que enxerga além das circunstâncias." },
  { verse: "Deus é o nosso refúgio e força, socorro bem presente nas tribulações.", ref: "Salmos 46:1", reflection: "Nos momentos difíceis, corra para Deus antes de qualquer solução humana." },
  { verse: "Nele foram criadas todas as coisas nos céus e na terra, visíveis e invisíveis.", ref: "Colossenses 1:16", reflection: "Tudo tem um Criador. Isso inclui você e sua missão." },
  { verse: "Porque Deus nos deu não um espírito de covardia, mas de poder, de amor e de equilíbrio.", ref: "2 Timóteo 1:7", reflection: "Você tem o que é preciso para avançar hoje." },
  { verse: "O Senhor é bom e justo; por isso ensina o caminho aos pecadores.", ref: "Salmos 25:8", reflection: "Bondade e justiça caminham juntas em Deus — e devem caminhar em nós." },
  { verse: "Aprendam a fazer o bem; procurem a justiça, corrijam o opressor.", ref: "Isaías 1:17", reflection: "A fé autêntica age — especialmente em favor dos vulneráveis." },
  { verse: "Cada um contribua segundo propôs no seu coração, não com tristeza ou por necessidade.", ref: "2 Coríntios 9:7", reflection: "A generosidade alegre é um reflexo do coração de Deus." },
  { verse: "Onde está o teu tesouro, aí estará também o teu coração.", ref: "Mateus 6:21", reflection: "O que você investe tempo e dinheiro revela o que realmente ama." },
  { verse: "A sabedoria do homem lhe prolonga os dias, mas o caminho dos pérfidos é traído por eles mesmos.", ref: "Provérbios 19:3", reflection: "Vivir com sabedoria é a maior eficiência que existe." },
  { verse: "Mas os que esperam no Senhor renovarão as suas forças.", ref: "Isaías 40:31", reflection: "Esperar em Deus não é inércia — é recarga profunda." },
  { verse: "Cristo é o mesmo ontem, hoje e para sempre.", ref: "Hebreus 13:8", reflection: "Numa era de constante mudança, há uma rocha inabalável." },
];

export function getTodaysDevotional() {
  const dayOfYear = Math.floor(
    (Date.now() - new Date(new Date().getFullYear(), 0, 0).getTime()) / 86400000
  );
  return devotionals[dayOfYear % devotionals.length];
}
