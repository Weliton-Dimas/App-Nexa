export const PAGE_OPTIONS = [
  { value: "dashboard", label: "Dashboard" },
  { value: "optimization", label: "Otimização" },
  { value: "kanban", label: "Kanban" },
  { value: "calendar", label: "Calendário" },
  { value: "social_media", label: "Social Media" },
  { value: "email", label: "Email" },
  { value: "financeiro", label: "Financeiro" },
  { value: "criativos", label: "Criativos" },
  { value: "prospeccao", label: "Prospecção" },
];

export const ratingColors: Record<string, string> = {
  ruim: "bg-destructive/15 text-destructive border-destructive/30",
  regular:
    "bg-[hsl(var(--metric-amber))]/15 text-[hsl(var(--metric-amber))] border-[hsl(var(--metric-amber))]/30",
  bom: "bg-[hsl(var(--metric-blue))]/15 text-[hsl(var(--metric-blue))] border-[hsl(var(--metric-blue))]/30",
  ótimo: "bg-primary/15 text-primary border-primary/30",
};

export const ratingLabels: Record<string, string> = {
  ruim: "Ruim",
  regular: "Regular",
  bom: "Bom",
  ótimo: "Ótimo",
};

export const statusLabels: Record<string, string> = {
  em_dia: "Em dia",
  atrasado: "Atrasado",
};

// All client columns except sensitive OAuth tokens (which are revoked from
// the `authenticated` role and only readable by Edge Functions via service role).
export const SAFE_CLIENT_COLUMNS =
  "id,name,status,payment_type,rating,demands_status,payment_status,has_funds,created_at,updated_at,website_url,faturamento,investido,roi,percentual_midia,roas,conversao_custo,conversas,assigned_users,conversoes,has_meta,has_google,last_optimized_at,total_optimization_seconds,active_optimization_started_at,active_optimization_user_id,active_optimization_paused_at,active_optimization_accumulated_seconds,visible_pages,meta_account_id,meta_integration_status,meta_last_validated_at,google_account_id,google_integration_status,google_last_validated_at,monthly_fee,billing_day";

export interface ClientFormState {
  name: string;
  status: "ativo" | "inativo";
  payment_type: string;
  rating: string;
  demands_status: string;
  payment_status: string;
  has_funds: boolean;
  website_url: string;
  has_meta: boolean;
  has_google: boolean;
  visible_pages: string[];
  meta_account_id: string;
  meta_integration_status: string;
  google_account_id: string;
  google_integration_status: string;
  monthly_fee: number;
  billing_day: number | null;
}

export const defaultClientForm: ClientFormState = {
  name: "",
  status: "ativo",
  payment_type: "mensal",
  rating: "bom",
  demands_status: "em_dia",
  payment_status: "em_dia",
  has_funds: true,
  website_url: "",
  has_meta: true,
  has_google: true,
  visible_pages: ["dashboard", "optimization"],
  meta_account_id: "",
  meta_integration_status: "inativo",
  google_account_id: "",
  google_integration_status: "inativo",
  monthly_fee: 0,
  billing_day: 10,
};
