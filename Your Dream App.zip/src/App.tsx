import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/hooks/useAuth";
import ProtectedRoute from "@/components/ProtectedRoute";
import Index from "./pages/Index";
import KanbanPage from "./pages/KanbanPage";
import CalendarPage from "./pages/CalendarPage";
import MetaAdsPage from "./pages/MetaAdsPage";
import ClientsPage from "./pages/ClientsPage";
import ClientDashboardPage from "./pages/ClientDashboardPage";
import AdminUsersPage from "./pages/AdminUsersPage";
import AuthPage from "./pages/AuthPage";
import MeuEspacoPage from "./pages/MeuEspacoPage";
import OptimizationPage from "./pages/OptimizationPage";
import CreativosPage from "./pages/CreativosPage";
import LinksPage from "./pages/LinksPage";
import FinancialPage from "./pages/FinancialPage";
import ProspeccaoPage from "./pages/ProspeccaoPage";
import PricingPage from "./pages/PricingPage";
import ProfilePage from "./pages/ProfilePage";
import PrivacyPage from "./pages/PrivacyPage";
import TermsPage from "./pages/TermsPage";
import OAuthMetaCallbackPage from "./pages/OAuthMetaCallbackPage";
import IntegrationsPage from "./pages/IntegrationsPage";
import NotFound from "./pages/NotFound";
import { AppBrandingProvider } from "@/components/AppBrandingProvider";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <AppBrandingProvider>
          <Routes>
            <Route path="/auth" element={<AuthPage />} />
            <Route path="/privacidade" element={<PrivacyPage />} />
            <Route path="/termos" element={<TermsPage />} />
            <Route path="/oauth/meta/callback" element={<OAuthMetaCallbackPage />} />
            <Route path="/" element={<ProtectedRoute><Index /></ProtectedRoute>} />
            <Route path="/meu-espaco" element={<ProtectedRoute><MeuEspacoPage /></ProtectedRoute>} />
            <Route path="/kanban" element={<ProtectedRoute><KanbanPage /></ProtectedRoute>} />
            <Route path="/calendar" element={<ProtectedRoute><CalendarPage /></ProtectedRoute>} />
            <Route path="/dashboard" element={<ProtectedRoute><MetaAdsPage /></ProtectedRoute>} />
            <Route path="/meta" element={<ProtectedRoute><MetaAdsPage /></ProtectedRoute>} />
            <Route path="/clients" element={<ProtectedRoute><ClientsPage /></ProtectedRoute>} />
            <Route path="/clients/:id" element={<ProtectedRoute><ClientDashboardPage /></ProtectedRoute>} />
            <Route path="/optimization" element={<ProtectedRoute><OptimizationPage /></ProtectedRoute>} />
            <Route path="/criativos" element={<ProtectedRoute><CreativosPage /></ProtectedRoute>} />
            <Route path="/links" element={<ProtectedRoute><LinksPage /></ProtectedRoute>} />
            <Route path="/financeiro" element={<ProtectedRoute><FinancialPage /></ProtectedRoute>} />
            <Route path="/prospeccao" element={<ProtectedRoute><ProspeccaoPage /></ProtectedRoute>} />
            <Route path="/precificacao" element={<ProtectedRoute><PricingPage /></ProtectedRoute>} />
            <Route path="/perfil" element={<ProtectedRoute><ProfilePage /></ProtectedRoute>} />
            <Route path="/admin/users" element={<ProtectedRoute><AdminUsersPage /></ProtectedRoute>} />
            <Route path="/integracoes" element={<ProtectedRoute><IntegrationsPage /></ProtectedRoute>} />
            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
          </AppBrandingProvider>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
