export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.1"
  }
  public: {
    Tables: {
      app_settings: {
        Row: {
          app_name: string
          favicon_url: string | null
          id: string
          logo_url: string | null
          nav_order: Json
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          app_name?: string
          favicon_url?: string | null
          id?: string
          logo_url?: string | null
          nav_order?: Json
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          app_name?: string
          favicon_url?: string | null
          id?: string
          logo_url?: string | null
          nav_order?: Json
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: []
      }
      brainstorm_notes: {
        Row: {
          content: string
          id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          content?: string
          id?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          content?: string
          id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      calendar_tasks: {
        Row: {
          assignee_id: string | null
          client_id: string | null
          color: string
          created_at: string
          created_by: string
          date: string
          description: string | null
          google_event_id: string | null
          google_synced_at: string | null
          id: string
          priority: string
          status: string
          title: string
          updated_at: string
        }
        Insert: {
          assignee_id?: string | null
          client_id?: string | null
          color?: string
          created_at?: string
          created_by: string
          date: string
          description?: string | null
          google_event_id?: string | null
          google_synced_at?: string | null
          id?: string
          priority?: string
          status?: string
          title: string
          updated_at?: string
        }
        Update: {
          assignee_id?: string | null
          client_id?: string | null
          color?: string
          created_at?: string
          created_by?: string
          date?: string
          description?: string | null
          google_event_id?: string | null
          google_synced_at?: string | null
          id?: string
          priority?: string
          status?: string
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "calendar_tasks_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
        ]
      }
      client_contracts: {
        Row: {
          client_id: string
          contract_end: string | null
          contract_start: string | null
          created_at: string
          external_url: string | null
          file_path: string | null
          file_url: string | null
          id: string
          name: string
          notes: string | null
          updated_at: string
          uploaded_by: string
        }
        Insert: {
          client_id: string
          contract_end?: string | null
          contract_start?: string | null
          created_at?: string
          external_url?: string | null
          file_path?: string | null
          file_url?: string | null
          id?: string
          name?: string
          notes?: string | null
          updated_at?: string
          uploaded_by: string
        }
        Update: {
          client_id?: string
          contract_end?: string | null
          contract_start?: string | null
          created_at?: string
          external_url?: string | null
          file_path?: string | null
          file_url?: string | null
          id?: string
          name?: string
          notes?: string | null
          updated_at?: string
          uploaded_by?: string
        }
        Relationships: []
      }
      client_integrations: {
        Row: {
          access_token: string | null
          account_id: string | null
          account_name: string | null
          client_id: string
          connected_by: string | null
          created_at: string
          expires_at: string | null
          extra: Json
          id: string
          last_error: string | null
          last_synced_at: string | null
          provider: string
          refresh_token: string | null
          scope: string | null
          status: string
          updated_at: string
        }
        Insert: {
          access_token?: string | null
          account_id?: string | null
          account_name?: string | null
          client_id: string
          connected_by?: string | null
          created_at?: string
          expires_at?: string | null
          extra?: Json
          id?: string
          last_error?: string | null
          last_synced_at?: string | null
          provider: string
          refresh_token?: string | null
          scope?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          access_token?: string | null
          account_id?: string | null
          account_name?: string | null
          client_id?: string
          connected_by?: string | null
          created_at?: string
          expires_at?: string | null
          extra?: Json
          id?: string
          last_error?: string | null
          last_synced_at?: string | null
          provider?: string
          refresh_token?: string | null
          scope?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "client_integrations_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
        ]
      }
      clients: {
        Row: {
          active_optimization_accumulated_seconds: number
          active_optimization_paused_at: string | null
          active_optimization_started_at: string | null
          active_optimization_user_id: string | null
          assigned_users: string[] | null
          billing_day: number | null
          conversao_custo: number | null
          conversas: number | null
          conversoes: number | null
          created_at: string
          demands_status: string
          faturamento: number | null
          google_access_token: string | null
          google_account_id: string | null
          google_integration_status: string
          google_last_validated_at: string | null
          has_funds: boolean
          has_google: boolean
          has_meta: boolean
          id: string
          investido: number | null
          last_optimized_at: string | null
          meta_access_token: string | null
          meta_account_id: string | null
          meta_integration_status: string
          meta_last_validated_at: string | null
          monthly_fee: number | null
          name: string
          payment_status: string
          payment_type: string
          percentual_midia: number | null
          rating: string
          roas: number | null
          roi: number | null
          status: string
          total_optimization_seconds: number
          updated_at: string
          visible_pages: string[]
          website_url: string | null
        }
        Insert: {
          active_optimization_accumulated_seconds?: number
          active_optimization_paused_at?: string | null
          active_optimization_started_at?: string | null
          active_optimization_user_id?: string | null
          assigned_users?: string[] | null
          billing_day?: number | null
          conversao_custo?: number | null
          conversas?: number | null
          conversoes?: number | null
          created_at?: string
          demands_status?: string
          faturamento?: number | null
          google_access_token?: string | null
          google_account_id?: string | null
          google_integration_status?: string
          google_last_validated_at?: string | null
          has_funds?: boolean
          has_google?: boolean
          has_meta?: boolean
          id?: string
          investido?: number | null
          last_optimized_at?: string | null
          meta_access_token?: string | null
          meta_account_id?: string | null
          meta_integration_status?: string
          meta_last_validated_at?: string | null
          monthly_fee?: number | null
          name: string
          payment_status?: string
          payment_type?: string
          percentual_midia?: number | null
          rating?: string
          roas?: number | null
          roi?: number | null
          status?: string
          total_optimization_seconds?: number
          updated_at?: string
          visible_pages?: string[]
          website_url?: string | null
        }
        Update: {
          active_optimization_accumulated_seconds?: number
          active_optimization_paused_at?: string | null
          active_optimization_started_at?: string | null
          active_optimization_user_id?: string | null
          assigned_users?: string[] | null
          billing_day?: number | null
          conversao_custo?: number | null
          conversas?: number | null
          conversoes?: number | null
          created_at?: string
          demands_status?: string
          faturamento?: number | null
          google_access_token?: string | null
          google_account_id?: string | null
          google_integration_status?: string
          google_last_validated_at?: string | null
          has_funds?: boolean
          has_google?: boolean
          has_meta?: boolean
          id?: string
          investido?: number | null
          last_optimized_at?: string | null
          meta_access_token?: string | null
          meta_account_id?: string | null
          meta_integration_status?: string
          meta_last_validated_at?: string | null
          monthly_fee?: number | null
          name?: string
          payment_status?: string
          payment_type?: string
          percentual_midia?: number | null
          rating?: string
          roas?: number | null
          roi?: number | null
          status?: string
          total_optimization_seconds?: number
          updated_at?: string
          visible_pages?: string[]
          website_url?: string | null
        }
        Relationships: []
      }
      creative_demands: {
        Row: {
          assignee_id: string | null
          briefing: string | null
          briefing_images: string[]
          checklist: Json | null
          client_id: string | null
          completed_at: string | null
          created_at: string
          created_by: string
          deadline: string | null
          element: string
          final_assets: Json
          final_notes: string | null
          id: string
          manager_id: string | null
          priority: string
          reference_links: string[] | null
          status: string
          type: string
          updated_at: string
        }
        Insert: {
          assignee_id?: string | null
          briefing?: string | null
          briefing_images?: string[]
          checklist?: Json | null
          client_id?: string | null
          completed_at?: string | null
          created_at?: string
          created_by: string
          deadline?: string | null
          element: string
          final_assets?: Json
          final_notes?: string | null
          id?: string
          manager_id?: string | null
          priority?: string
          reference_links?: string[] | null
          status?: string
          type: string
          updated_at?: string
        }
        Update: {
          assignee_id?: string | null
          briefing?: string | null
          briefing_images?: string[]
          checklist?: Json | null
          client_id?: string | null
          completed_at?: string | null
          created_at?: string
          created_by?: string
          deadline?: string | null
          element?: string
          final_assets?: Json
          final_notes?: string | null
          id?: string
          manager_id?: string | null
          priority?: string
          reference_links?: string[] | null
          status?: string
          type?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "creative_demands_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
        ]
      }
      creative_library: {
        Row: {
          client_id: string | null
          created_at: string
          file_url: string
          id: string
          media_type: string
          name: string
          notes: string | null
          tags: string[] | null
          thumbnail_url: string | null
          updated_at: string
          uploaded_by: string
        }
        Insert: {
          client_id?: string | null
          created_at?: string
          file_url: string
          id?: string
          media_type?: string
          name: string
          notes?: string | null
          tags?: string[] | null
          thumbnail_url?: string | null
          updated_at?: string
          uploaded_by: string
        }
        Update: {
          client_id?: string | null
          created_at?: string
          file_url?: string
          id?: string
          media_type?: string
          name?: string
          notes?: string | null
          tags?: string[] | null
          thumbnail_url?: string | null
          updated_at?: string
          uploaded_by?: string
        }
        Relationships: [
          {
            foreignKeyName: "creative_library_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
        ]
      }
      daily_devotionals: {
        Row: {
          application: string
          created_at: string
          date: string
          id: string
          prayer: string
          reference: string
          reflection: string
          verse: string
        }
        Insert: {
          application: string
          created_at?: string
          date: string
          id?: string
          prayer: string
          reference: string
          reflection: string
          verse: string
        }
        Update: {
          application?: string
          created_at?: string
          date?: string
          id?: string
          prayer?: string
          reference?: string
          reflection?: string
          verse?: string
        }
        Relationships: []
      }
      financial_commissions: {
        Row: {
          amount: number
          client_id: string | null
          created_at: string
          created_by: string
          description: string
          id: string
          notes: string | null
          paid_date: string | null
          reference_month: string
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          amount?: number
          client_id?: string | null
          created_at?: string
          created_by: string
          description: string
          id?: string
          notes?: string | null
          paid_date?: string | null
          reference_month: string
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          amount?: number
          client_id?: string | null
          created_at?: string
          created_by?: string
          description?: string
          id?: string
          notes?: string | null
          paid_date?: string | null
          reference_month?: string
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "financial_commissions_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
        ]
      }
      financial_expenses: {
        Row: {
          amount: number
          category: string
          created_at: string
          created_by: string
          description: string
          due_date: string
          id: string
          notes: string | null
          paid_date: string | null
          recurrence: string
          status: string
          updated_at: string
        }
        Insert: {
          amount?: number
          category?: string
          created_at?: string
          created_by: string
          description: string
          due_date: string
          id?: string
          notes?: string | null
          paid_date?: string | null
          recurrence?: string
          status?: string
          updated_at?: string
        }
        Update: {
          amount?: number
          category?: string
          created_at?: string
          created_by?: string
          description?: string
          due_date?: string
          id?: string
          notes?: string | null
          paid_date?: string | null
          recurrence?: string
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      financial_revenues: {
        Row: {
          amount: number
          client_id: string | null
          created_at: string
          created_by: string
          description: string
          due_date: string
          id: string
          notes: string | null
          paid_date: string | null
          recurrence: string
          status: string
          updated_at: string
        }
        Insert: {
          amount?: number
          client_id?: string | null
          created_at?: string
          created_by: string
          description: string
          due_date: string
          id?: string
          notes?: string | null
          paid_date?: string | null
          recurrence?: string
          status?: string
          updated_at?: string
        }
        Update: {
          amount?: number
          client_id?: string | null
          created_at?: string
          created_by?: string
          description?: string
          due_date?: string
          id?: string
          notes?: string | null
          paid_date?: string | null
          recurrence?: string
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "financial_revenues_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
        ]
      }
      ideas: {
        Row: {
          author_id: string
          category: string
          client_id: string | null
          created_at: string
          description: string
          id: string
          priority: string
          title: string
          updated_at: string
        }
        Insert: {
          author_id: string
          category: string
          client_id?: string | null
          created_at?: string
          description: string
          id?: string
          priority?: string
          title: string
          updated_at?: string
        }
        Update: {
          author_id?: string
          category?: string
          client_id?: string | null
          created_at?: string
          description?: string
          id?: string
          priority?: string
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      inbox_items: {
        Row: {
          completed: boolean
          content: string
          created_at: string
          id: string
          user_id: string
        }
        Insert: {
          completed?: boolean
          content: string
          created_at?: string
          id?: string
          user_id: string
        }
        Update: {
          completed?: boolean
          content?: string
          created_at?: string
          id?: string
          user_id?: string
        }
        Relationships: []
      }
      kanban_attachments: {
        Row: {
          card_id: string
          created_at: string
          display_text: string | null
          file_path: string | null
          id: string
          kind: string
          uploaded_by: string
          url: string
        }
        Insert: {
          card_id: string
          created_at?: string
          display_text?: string | null
          file_path?: string | null
          id?: string
          kind: string
          uploaded_by: string
          url: string
        }
        Update: {
          card_id?: string
          created_at?: string
          display_text?: string | null
          file_path?: string | null
          id?: string
          kind?: string
          uploaded_by?: string
          url?: string
        }
        Relationships: [
          {
            foreignKeyName: "kanban_attachments_card_id_fkey"
            columns: ["card_id"]
            isOneToOne: false
            referencedRelation: "kanban_cards"
            referencedColumns: ["id"]
          },
        ]
      }
      kanban_boards: {
        Row: {
          created_at: string
          created_by: string
          id: string
          name: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by: string
          id?: string
          name: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string
          id?: string
          name?: string
          updated_at?: string
        }
        Relationships: []
      }
      kanban_card_labels: {
        Row: {
          card_id: string
          label_id: string
        }
        Insert: {
          card_id: string
          label_id: string
        }
        Update: {
          card_id?: string
          label_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "kanban_card_labels_card_id_fkey"
            columns: ["card_id"]
            isOneToOne: false
            referencedRelation: "kanban_cards"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "kanban_card_labels_label_id_fkey"
            columns: ["label_id"]
            isOneToOne: false
            referencedRelation: "kanban_labels"
            referencedColumns: ["id"]
          },
        ]
      }
      kanban_cards: {
        Row: {
          client_id: string | null
          column_id: string
          cover_color: string | null
          created_at: string
          created_by: string
          description: string | null
          due_date: string | null
          id: string
          position: number
          priority: string | null
          reminder: string | null
          start_date: string | null
          title: string
          updated_at: string
        }
        Insert: {
          client_id?: string | null
          column_id: string
          cover_color?: string | null
          created_at?: string
          created_by: string
          description?: string | null
          due_date?: string | null
          id?: string
          position?: number
          priority?: string | null
          reminder?: string | null
          start_date?: string | null
          title: string
          updated_at?: string
        }
        Update: {
          client_id?: string | null
          column_id?: string
          cover_color?: string | null
          created_at?: string
          created_by?: string
          description?: string | null
          due_date?: string | null
          id?: string
          position?: number
          priority?: string | null
          reminder?: string | null
          start_date?: string | null
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "kanban_cards_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "kanban_cards_column_id_fkey"
            columns: ["column_id"]
            isOneToOne: false
            referencedRelation: "kanban_columns"
            referencedColumns: ["id"]
          },
        ]
      }
      kanban_checklist_items: {
        Row: {
          card_id: string
          created_at: string
          done: boolean
          id: string
          position: number
          text: string
        }
        Insert: {
          card_id: string
          created_at?: string
          done?: boolean
          id?: string
          position?: number
          text: string
        }
        Update: {
          card_id?: string
          created_at?: string
          done?: boolean
          id?: string
          position?: number
          text?: string
        }
        Relationships: [
          {
            foreignKeyName: "kanban_checklist_items_card_id_fkey"
            columns: ["card_id"]
            isOneToOne: false
            referencedRelation: "kanban_cards"
            referencedColumns: ["id"]
          },
        ]
      }
      kanban_columns: {
        Row: {
          board_id: string
          created_at: string
          id: string
          position: number
          title: string
          updated_at: string
        }
        Insert: {
          board_id: string
          created_at?: string
          id?: string
          position?: number
          title: string
          updated_at?: string
        }
        Update: {
          board_id?: string
          created_at?: string
          id?: string
          position?: number
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "kanban_columns_board_id_fkey"
            columns: ["board_id"]
            isOneToOne: false
            referencedRelation: "kanban_boards"
            referencedColumns: ["id"]
          },
        ]
      }
      kanban_comments: {
        Row: {
          author_id: string
          body: string
          card_id: string
          created_at: string
          id: string
          updated_at: string
        }
        Insert: {
          author_id: string
          body: string
          card_id: string
          created_at?: string
          id?: string
          updated_at?: string
        }
        Update: {
          author_id?: string
          body?: string
          card_id?: string
          created_at?: string
          id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "kanban_comments_card_id_fkey"
            columns: ["card_id"]
            isOneToOne: false
            referencedRelation: "kanban_cards"
            referencedColumns: ["id"]
          },
        ]
      }
      kanban_labels: {
        Row: {
          board_id: string
          color: string
          created_at: string
          id: string
          name: string
        }
        Insert: {
          board_id: string
          color: string
          created_at?: string
          id?: string
          name?: string
        }
        Update: {
          board_id?: string
          color?: string
          created_at?: string
          id?: string
          name?: string
        }
        Relationships: [
          {
            foreignKeyName: "kanban_labels_board_id_fkey"
            columns: ["board_id"]
            isOneToOne: false
            referencedRelation: "kanban_boards"
            referencedColumns: ["id"]
          },
        ]
      }
      kanban_members: {
        Row: {
          card_id: string
          created_at: string
          user_id: string
        }
        Insert: {
          card_id: string
          created_at?: string
          user_id: string
        }
        Update: {
          card_id?: string
          created_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "kanban_members_card_id_fkey"
            columns: ["card_id"]
            isOneToOne: false
            referencedRelation: "kanban_cards"
            referencedColumns: ["id"]
          },
        ]
      }
      notification_log: {
        Row: {
          id: string
          sent_at: string
          source: string
          source_id: string
          user_id: string
        }
        Insert: {
          id?: string
          sent_at?: string
          source: string
          source_id: string
          user_id: string
        }
        Update: {
          id?: string
          sent_at?: string
          source?: string
          source_id?: string
          user_id?: string
        }
        Relationships: []
      }
      notification_preferences: {
        Row: {
          calendar_enabled: boolean
          calendar_hour: number
          kanban_enabled: boolean
          kanban_minutes_before: number
          prospects_enabled: boolean
          prospects_minutes_before: number
          updated_at: string
          user_id: string
        }
        Insert: {
          calendar_enabled?: boolean
          calendar_hour?: number
          kanban_enabled?: boolean
          kanban_minutes_before?: number
          prospects_enabled?: boolean
          prospects_minutes_before?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          calendar_enabled?: boolean
          calendar_hour?: number
          kanban_enabled?: boolean
          kanban_minutes_before?: number
          prospects_enabled?: boolean
          prospects_minutes_before?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      optimization_sessions: {
        Row: {
          action_audience: boolean
          action_budget: boolean
          action_creative: boolean
          action_monitoring: boolean
          client_id: string
          created_at: string
          duration_seconds: number
          ended_at: string | null
          id: string
          observation: string | null
          optimized_google: boolean
          optimized_meta: boolean
          started_at: string
          user_id: string
        }
        Insert: {
          action_audience?: boolean
          action_budget?: boolean
          action_creative?: boolean
          action_monitoring?: boolean
          client_id: string
          created_at?: string
          duration_seconds?: number
          ended_at?: string | null
          id?: string
          observation?: string | null
          optimized_google?: boolean
          optimized_meta?: boolean
          started_at?: string
          user_id: string
        }
        Update: {
          action_audience?: boolean
          action_budget?: boolean
          action_creative?: boolean
          action_monitoring?: boolean
          client_id?: string
          created_at?: string
          duration_seconds?: number
          ended_at?: string | null
          id?: string
          observation?: string | null
          optimized_google?: boolean
          optimized_meta?: boolean
          started_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "optimization_sessions_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
        ]
      }
      pricing_products: {
        Row: {
          boleto_value: number
          card_pct: number
          client_id: string
          commission_pct: number
          created_at: string
          current_price: number
          desired_margin_pct: number
          extra_costs: Json
          gateway_pct: number
          id: string
          margin_mode: string
          marketing_pct: number
          mix_boleto_pct: number
          mix_card_pct: number
          mix_pix_pct: number
          name: string
          other_deductions_pct: number
          other_inputs_cost: number
          packaging_cost: number
          pix_pct: number
          platform_pct: number
          position: number
          product_cost: number
          selling_cost: number
          shipping_cost: number
          sku: string | null
          taxes_pct: number
          updated_at: string
          user_id: string
        }
        Insert: {
          boleto_value?: number
          card_pct?: number
          client_id: string
          commission_pct?: number
          created_at?: string
          current_price?: number
          desired_margin_pct?: number
          extra_costs?: Json
          gateway_pct?: number
          id?: string
          margin_mode?: string
          marketing_pct?: number
          mix_boleto_pct?: number
          mix_card_pct?: number
          mix_pix_pct?: number
          name?: string
          other_deductions_pct?: number
          other_inputs_cost?: number
          packaging_cost?: number
          pix_pct?: number
          platform_pct?: number
          position?: number
          product_cost?: number
          selling_cost?: number
          shipping_cost?: number
          sku?: string | null
          taxes_pct?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          boleto_value?: number
          card_pct?: number
          client_id?: string
          commission_pct?: number
          created_at?: string
          current_price?: number
          desired_margin_pct?: number
          extra_costs?: Json
          gateway_pct?: number
          id?: string
          margin_mode?: string
          marketing_pct?: number
          mix_boleto_pct?: number
          mix_card_pct?: number
          mix_pix_pct?: number
          name?: string
          other_deductions_pct?: number
          other_inputs_cost?: number
          packaging_cost?: number
          pix_pct?: number
          platform_pct?: number
          position?: number
          product_cost?: number
          selling_cost?: number
          shipping_cost?: number
          sku?: string | null
          taxes_pct?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      pricing_scenarios: {
        Row: {
          avg_ticket: number | null
          client_id: string
          conversion_rate: number
          created_at: string
          estimated_cpa: number
          fixed_costs_pct: number
          id: string
          monthly_profit_goal: number
          name: string
          product_cost: number
          profit_margin_pct: number
          taxes_pct: number
          updated_at: string
          user_id: string
        }
        Insert: {
          avg_ticket?: number | null
          client_id: string
          conversion_rate?: number
          created_at?: string
          estimated_cpa?: number
          fixed_costs_pct?: number
          id?: string
          monthly_profit_goal?: number
          name?: string
          product_cost?: number
          profit_margin_pct?: number
          taxes_pct?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          avg_ticket?: number | null
          client_id?: string
          conversion_rate?: number
          created_at?: string
          estimated_cpa?: number
          fixed_costs_pct?: number
          id?: string
          monthly_profit_goal?: number
          name?: string
          product_cost?: number
          profit_margin_pct?: number
          taxes_pct?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      pricing_settings: {
        Row: {
          boleto_fee_value: number
          client_id: string
          column_kinds: Json
          column_widths: Json
          created_at: string
          gateway_pct: number
          hidden_columns: Json
          id: string
          installment_rates: Json
          max_installments: number
          mix_boleto_pct: number
          mix_card_pct: number
          mix_pix_pct: number
          old_price_discount_pct: number
          pix_discount_pct: number
          pix_fee_pct: number
          updated_at: string
          user_id: string
        }
        Insert: {
          boleto_fee_value?: number
          client_id: string
          column_kinds?: Json
          column_widths?: Json
          created_at?: string
          gateway_pct?: number
          hidden_columns?: Json
          id?: string
          installment_rates?: Json
          max_installments?: number
          mix_boleto_pct?: number
          mix_card_pct?: number
          mix_pix_pct?: number
          old_price_discount_pct?: number
          pix_discount_pct?: number
          pix_fee_pct?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          boleto_fee_value?: number
          client_id?: string
          column_kinds?: Json
          column_widths?: Json
          created_at?: string
          gateway_pct?: number
          hidden_columns?: Json
          id?: string
          installment_rates?: Json
          max_installments?: number
          mix_boleto_pct?: number
          mix_card_pct?: number
          mix_pix_pct?: number
          old_price_discount_pct?: number
          pix_discount_pct?: number
          pix_fee_pct?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string | null
          bio: string | null
          created_at: string
          display_name: string | null
          id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          avatar_url?: string | null
          bio?: string | null
          created_at?: string
          display_name?: string | null
          id?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          avatar_url?: string | null
          bio?: string | null
          created_at?: string
          display_name?: string | null
          id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      prospects: {
        Row: {
          bant_authority: boolean
          bant_budget: boolean
          bant_need: boolean
          bant_timeline: boolean
          company_name: string
          contact_name: string | null
          contact_role: string | null
          created_at: string
          email: string | null
          estimated_value: number | null
          id: string
          instagram_url: string | null
          linkedin_url: string | null
          next_action: string | null
          next_action_at: string | null
          notes: string | null
          phone: string | null
          position: number
          source: string | null
          status: string
          temperature: string | null
          updated_at: string
          user_id: string
          website_url: string | null
        }
        Insert: {
          bant_authority?: boolean
          bant_budget?: boolean
          bant_need?: boolean
          bant_timeline?: boolean
          company_name: string
          contact_name?: string | null
          contact_role?: string | null
          created_at?: string
          email?: string | null
          estimated_value?: number | null
          id?: string
          instagram_url?: string | null
          linkedin_url?: string | null
          next_action?: string | null
          next_action_at?: string | null
          notes?: string | null
          phone?: string | null
          position?: number
          source?: string | null
          status?: string
          temperature?: string | null
          updated_at?: string
          user_id: string
          website_url?: string | null
        }
        Update: {
          bant_authority?: boolean
          bant_budget?: boolean
          bant_need?: boolean
          bant_timeline?: boolean
          company_name?: string
          contact_name?: string | null
          contact_role?: string | null
          created_at?: string
          email?: string | null
          estimated_value?: number | null
          id?: string
          instagram_url?: string | null
          linkedin_url?: string | null
          next_action?: string | null
          next_action_at?: string | null
          notes?: string | null
          phone?: string | null
          position?: number
          source?: string | null
          status?: string
          temperature?: string | null
          updated_at?: string
          user_id?: string
          website_url?: string | null
        }
        Relationships: []
      }
      push_subscriptions: {
        Row: {
          auth: string
          created_at: string
          endpoint: string
          id: string
          last_used_at: string | null
          p256dh: string
          user_agent: string | null
          user_id: string
        }
        Insert: {
          auth: string
          created_at?: string
          endpoint: string
          id?: string
          last_used_at?: string | null
          p256dh: string
          user_agent?: string | null
          user_id: string
        }
        Update: {
          auth?: string
          created_at?: string
          endpoint?: string
          id?: string
          last_used_at?: string | null
          p256dh?: string
          user_agent?: string | null
          user_id?: string
        }
        Relationships: []
      }
      reminders: {
        Row: {
          completed: boolean
          content: string
          created_at: string
          id: string
          priority: string
          user_id: string
        }
        Insert: {
          completed?: boolean
          content: string
          created_at?: string
          id?: string
          priority?: string
          user_id: string
        }
        Update: {
          completed?: boolean
          content?: string
          created_at?: string
          id?: string
          priority?: string
          user_id?: string
        }
        Relationships: []
      }
      user_google_calendar_tokens: {
        Row: {
          access_token: string
          calendar_id: string
          created_at: string
          expires_at: string
          google_email: string | null
          id: string
          last_synced_at: string | null
          refresh_token: string
          scope: string | null
          sync_token: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          access_token: string
          calendar_id?: string
          created_at?: string
          expires_at: string
          google_email?: string | null
          id?: string
          last_synced_at?: string | null
          refresh_token: string
          scope?: string | null
          sync_token?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          access_token?: string
          calendar_id?: string
          created_at?: string
          expires_at?: string
          google_email?: string | null
          id?: string
          last_synced_at?: string | null
          refresh_token?: string
          scope?: string | null
          sync_token?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_page_permissions: {
        Row: {
          created_at: string
          id: string
          page_slug: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          page_slug: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          page_slug?: string
          user_id?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      workspace_integrations: {
        Row: {
          access_token: string | null
          available_accounts: Json
          available_businesses: Json
          business_id: string | null
          business_name: string | null
          connected_by: string | null
          created_at: string
          expires_at: string | null
          id: string
          last_error: string | null
          last_synced_at: string | null
          provider: string
          refresh_token: string | null
          scope: string | null
          status: string
          updated_at: string
        }
        Insert: {
          access_token?: string | null
          available_accounts?: Json
          available_businesses?: Json
          business_id?: string | null
          business_name?: string | null
          connected_by?: string | null
          created_at?: string
          expires_at?: string | null
          id?: string
          last_error?: string | null
          last_synced_at?: string | null
          provider: string
          refresh_token?: string | null
          scope?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          access_token?: string | null
          available_accounts?: Json
          available_businesses?: Json
          business_id?: string | null
          business_name?: string | null
          connected_by?: string | null
          created_at?: string
          expires_at?: string | null
          id?: string
          last_error?: string | null
          last_synced_at?: string | null
          provider?: string
          refresh_token?: string | null
          scope?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      workspace_magazord_stores: {
        Row: {
          base_url: string
          created_at: string
          created_by: string
          id: string
          label: string
          password_encrypted: string
          updated_at: string
          username: string
        }
        Insert: {
          base_url: string
          created_at?: string
          created_by: string
          id?: string
          label: string
          password_encrypted: string
          updated_at?: string
          username: string
        }
        Update: {
          base_url?: string
          created_at?: string
          created_by?: string
          id?: string
          label?: string
          password_encrypted?: string
          updated_at?: string
          username?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      can_access_financial: { Args: { _user_id: string }; Returns: boolean }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "admin" | "user"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "user"],
    },
  },
} as const
