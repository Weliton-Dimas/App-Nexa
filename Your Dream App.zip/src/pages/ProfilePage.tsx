import { useEffect, useState } from "react";
import { z } from "zod";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { DashboardSidebar } from "@/components/DashboardSidebar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { AvatarUpload } from "@/components/AvatarUpload";
import { NotificationSettings } from "@/components/NotificationSettings";
import { useQueryClient } from "@tanstack/react-query";

const profileSchema = z.object({
  display_name: z.string().trim().min(1, "Nome obrigatório").max(60, "Máx. 60 caracteres"),
  bio: z.string().trim().max(280, "Máx. 280 caracteres").optional().or(z.literal("")),
});

const ProfilePage = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();

  const [displayName, setDisplayName] = useState("");
  const [bio, setBio] = useState("");
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const [pendingAvatar, setPendingAvatar] = useState<File | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const load = async () => {
      if (!user) return;
      const { data, error } = await supabase
        .from("profiles")
        .select("display_name, bio, avatar_url")
        .eq("user_id", user.id)
        .maybeSingle();
      if (!error && data) {
        setDisplayName(data.display_name ?? "");
        setBio(data.bio ?? "");
        setAvatarUrl(data.avatar_url);
      }
      setLoading(false);
    };
    load();
  }, [user]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    const parsed = profileSchema.safeParse({ display_name: displayName, bio });
    if (!parsed.success) {
      toast({
        title: "Dados inválidos",
        description: parsed.error.errors[0].message,
        variant: "destructive",
      });
      return;
    }

    setSaving(true);
    try {
      let newAvatarUrl = avatarUrl;
      if (pendingAvatar) {
        const ext = pendingAvatar.name.split(".").pop() || "png";
        const path = `${user.id}/avatar-${Date.now()}.${ext}`;
        const { error: upErr } = await supabase.storage
          .from("avatars")
          .upload(path, pendingAvatar, { upsert: true, contentType: pendingAvatar.type });
        if (upErr) throw upErr;
        const { data: pub } = supabase.storage.from("avatars").getPublicUrl(path);
        newAvatarUrl = pub.publicUrl;
      }

      const { error } = await supabase
        .from("profiles")
        .update({
          display_name: parsed.data.display_name,
          bio: parsed.data.bio || null,
          avatar_url: newAvatarUrl,
        })
        .eq("user_id", user.id);
      if (error) throw error;

      setAvatarUrl(newAvatarUrl);
      setPendingAvatar(null);
      qc.invalidateQueries({ queryKey: ["profile", user.id] });
      toast({ title: "Perfil atualizado!" });
      // Reload sidebar profile name
      window.dispatchEvent(new Event("profile-updated"));
    } catch (err: any) {
      toast({ title: "Erro ao salvar", description: err.message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="flex min-h-screen bg-background">
      <DashboardSidebar />
      <main className="flex-1 p-6 overflow-auto">
        <div className="max-w-2xl mx-auto space-y-6">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Meu Perfil</h1>
            <p className="text-sm text-muted-foreground">Atualize suas informações pessoais</p>
          </div>

          {loading ? (
            <div className="flex justify-center py-12">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
            </div>
          ) : (
            <Card>
              <CardHeader>
                <CardTitle>Aparência</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSave} className="space-y-6">
                  <div className="space-y-2">
                    <Label>Foto de perfil</Label>
                    <AvatarUpload
                      currentUrl={avatarUrl}
                      onFileSelected={setPendingAvatar}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="display_name">Nome de exibição</Label>
                    <Input
                      id="display_name"
                      value={displayName}
                      onChange={(e) => setDisplayName(e.target.value)}
                      placeholder="Seu nome"
                      maxLength={60}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="bio">Biografia</Label>
                    <Textarea
                      id="bio"
                      value={bio}
                      onChange={(e) => setBio(e.target.value)}
                      placeholder="Conte um pouco sobre você"
                      maxLength={280}
                      rows={4}
                    />
                    <p className="text-xs text-muted-foreground text-right">{bio.length}/280</p>
                  </div>

                  <div className="space-y-2">
                    <Label>E-mail</Label>
                    <Input value={user?.email ?? ""} disabled />
                  </div>

                  <Button type="submit" disabled={saving} className="w-full">
                    {saving ? "Salvando..." : "Salvar alterações"}
                  </Button>
                </form>
              </CardContent>
            </Card>
          )}

          <NotificationSettings />
        </div>
      </main>
    </div>
  );
};

export default ProfilePage;
