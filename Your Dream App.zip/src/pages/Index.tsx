import { CheckCircle2, Clock, AlertTriangle, Calendar, TrendingUp, RefreshCw, Sparkles, BookOpen, ArrowRight, MessageCircle, Users, MousePointerClick, DollarSign, Eye, Megaphone, Heart, Sunrise, Loader2 } from "lucide-react";
import { DashboardSidebar } from "@/components/DashboardSidebar";
import { MetricCard } from "@/components/MetricCard";
import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { cn } from "@/lib/utils";
import { getTodaysDevotional } from "@/lib/devotionals";
import { useMetaAdsMetrics } from "@/hooks/useMetaAdsMetrics";
import { useDailyDevotional } from "@/hooks/useDailyDevotional";
import { MetaAdsMiniDashboard } from "@/components/MetaAdsMiniDashboard";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useAppSettings } from "@/hooks/useAppSettings";
import { useUserPermissions } from "@/hooks/useUserPermissions";

const weekDays = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];
const today = new Date();
const dayOfWeek = today.getDay();
const devotional = getTodaysDevotional();

function startOfDay(d: Date) { const x = new Date(d); x.setHours(0,0,0,0); return x; }
function endOfDay(d: Date) { const x = new Date(d); x.setHours(23,59,59,999); return x; }
function startOfWeek(d: Date) { const x = startOfDay(d); x.setDate(x.getDate() - x.getDay()); return x; }
function classifyColumn(title: string): "done" | "progress" | "todo" {
  const t = title.toLowerCase();
  if (/finaliz|conclu[ií]|aprovad|done|entregue/.test(t)) return "done";
  if (/progress|andamento|fazendo|doing|execu/.test(t)) return "progress";
  return "todo";
}

const datePresetLabels: Record<string, string> = {
  last_7d: "Últimos 7 dias",
  last_14d: "Últimos 14 dias",
  last_30d: "Últimos 30 dias",
  this_month: "Este mês",
  last_month: "Mês passado",
};

export default function Index() {
  const { user } = useAuth();
  const { data: appSettings } = useAppSettings();
  const appName = appSettings?.app_name || "Centralize";

  const { data: profile } = useQuery({
    queryKey: ["profile", user?.id],
    enabled: !!user?.id,
    queryFn: async () => {
      const { data } = await supabase.from("profiles").select("display_name").eq("user_id", user!.id).maybeSingle();
      return data;
    },
  });
  const firstName = (profile?.display_name || user?.email?.split("@")[0] || "").split(" ")[0] || "por aí";

  const [perfTab, setPerfTab] = useState<"Semana" | "Mês" | "Ano">("Semana");
  const [expandedDevSection, setExpandedDevSection] = useState<"reflection" | "prayer" | "application" | null>(null);
  const [adsPreset, setAdsPreset] = useState("last_7d");
  const [selectedClientId, setSelectedClientId] = useState<string | null>(
    () => localStorage.getItem("meta_dashboard_client_id"),
  );

  const { data: perms } = useUserPermissions();
  const { data: metaClients = [] } = useQuery({
    queryKey: ["meta-integrated-clients", user?.id, perms?.isAdmin],
    enabled: !!user,
    queryFn: async () => {
      let query = supabase
        .from("clients")
        .select("id, name, meta_integration_status, meta_account_id, assigned_users")
        .eq("has_meta", true)
        .order("name");
      if (!perms?.isAdmin && user) {
        query = query.contains("assigned_users", [user.id]);
      }
      const { data, error } = await query;
      if (error) throw error;
      return (data ?? []).filter(
        (c) => !!c.meta_account_id && c.meta_integration_status === "ativo",
      );
    },
  });

  useEffect(() => {
    if (!selectedClientId && metaClients.length > 0) {
      const active = metaClients.find((c) => c.meta_integration_status === "ativo") ?? metaClients[0];
      setSelectedClientId(active.id);
    }
  }, [metaClients, selectedClientId]);

  useEffect(() => {
    if (selectedClientId) localStorage.setItem("meta_dashboard_client_id", selectedClientId);
  }, [selectedClientId]);

  const { data: adsMetrics, isLoading: adsLoading, refetch: refetchAds, error: adsError } = useMetaAdsMetrics(adsPreset, selectedClientId);
  const { data: aiDevotional, isLoading: devLoading, error: devError } = useDailyDevotional();
  const fallback = devotional;

  const dateStr = today.toLocaleDateString("pt-BR", {
    weekday: "long",
    day: "2-digit",
    month: "long",
  });

  // Demandas (kanban) integradas
  const { data: demandStats } = useQuery({
    queryKey: ["dashboard-demand-stats", user?.id, perms?.isAdmin],
    enabled: !!user,
    queryFn: async () => {
      const [{ data: cols }, { data: cards }, { data: memb }] = await Promise.all([
        supabase.from("kanban_columns").select("id, title"),
        supabase.from("kanban_cards").select("id, title, due_date, created_by, created_at, updated_at, column_id"),
        supabase.from("kanban_members").select("card_id, user_id"),
      ]);
      const colStatus = new Map<string, "done" | "progress" | "todo">();
      (cols ?? []).forEach((c: any) => colStatus.set(c.id, classifyColumn(c.title)));
      const myCardIds = new Set<string>((memb ?? []).filter((m: any) => m.user_id === user!.id).map((m: any) => m.card_id));
      const visible = (cards ?? []).filter((c: any) => perms?.isAdmin || c.created_by === user!.id || myCardIds.has(c.id));

      const now = new Date();
      const todayStart = startOfDay(now);
      const todayEnd = endOfDay(now);
      const weekStart = startOfWeek(now);
      const prevWeekStart = new Date(weekStart); prevWeekStart.setDate(weekStart.getDate() - 7);
      const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
      const yearStart = new Date(now.getFullYear(), 0, 1);

      let cwDone = 0, cwProgress = 0, cwOverdue = 0, cwToday = 0;
      let pwDone = 0, pwOverdue = 0, pwDurationSum = 0, pwDurationCount = 0;
      const pwDoneByDay = [0, 0, 0, 0, 0, 0, 0];
      const cwDoneByDay = [0, 0, 0, 0, 0, 0, 0];
      let perfWeek = 0, perfMonth = 0, perfYear = 0;
      const priorities: { id: string; title: string; due: Date | null; status: "done" | "progress" | "todo" }[] = [];

      for (const c of visible) {
        const status = colStatus.get(c.column_id) ?? "todo";
        const due = c.due_date ? new Date(c.due_date) : null;
        const updated = new Date(c.updated_at);
        const created = new Date(c.created_at);

        if (status === "done") {
          if (updated >= weekStart) { cwDone++; cwDoneByDay[updated.getDay()]++; }
          if (updated >= prevWeekStart && updated < weekStart) {
            pwDone++;
            pwDoneByDay[updated.getDay()]++;
            pwDurationSum += updated.getTime() - created.getTime();
            pwDurationCount++;
          }
          if (updated >= weekStart) perfWeek++;
          if (updated >= monthStart) perfMonth++;
          if (updated >= yearStart) perfYear++;
        } else {
          if (status === "progress") cwProgress++;
          if (due) {
            if (due < now) cwOverdue++;
            else if (due >= todayStart && due <= todayEnd) cwToday++;
            if (due >= prevWeekStart && due < weekStart) pwOverdue++;
          }
          priorities.push({ id: c.id, title: c.title, due, status });
        }
      }

      priorities.sort((a, b) => {
        if (a.due && b.due) return a.due.getTime() - b.due.getTime();
        if (a.due) return -1;
        if (b.due) return 1;
        return 0;
      });

      const avgMs = pwDurationCount ? pwDurationSum / pwDurationCount : 0;
      const avgDays = avgMs / 86400000;
      const bestDayIdx = pwDoneByDay.indexOf(Math.max(...pwDoneByDay));
      const bestDay = pwDone > 0 ? weekDays[bestDayIdx] : "—";

      return {
        cwDone, cwProgress, cwOverdue, cwToday,
        pwDone, pwOverdue, avgDays, bestDay,
        perfWeek, perfMonth, perfYear,
        cwDoneByDay,
        priorities: priorities.slice(0, 6),
        totalVisible: visible.length,
      };
    },
  });

  const perfValue = perfTab === "Semana" ? demandStats?.perfWeek ?? 0 : perfTab === "Mês" ? demandStats?.perfMonth ?? 0 : demandStats?.perfYear ?? 0;
  const perfTotal = demandStats?.totalVisible ?? 0;
  const perfPct = perfTotal > 0 ? Math.round((perfValue / perfTotal) * 100) : 0;
  const maxBar = Math.max(1, ...(demandStats?.cwDoneByDay ?? [0]));

  const formatCurrency = (value: number) =>
    value.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

  const formatNumber = (value: number) =>
    value.toLocaleString("pt-BR");

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      <DashboardSidebar />

      {/* Main content */}
      <div className="flex-1 flex flex-col overflow-hidden min-w-0">
        {/* Top bar */}
        <header className="flex items-center justify-between gap-2 pl-14 pr-3 md:px-6 py-3 border-b border-border shrink-0">
          <div className="min-w-0">
            <h1 className="text-foreground text-base md:text-lg font-semibold leading-none truncate">Painel do Dia</h1>
            <p className="text-muted-foreground text-[11px] md:text-xs mt-1 capitalize truncate">{dateStr}</p>
          </div>
          <button
            onClick={() => refetchAds()}
            className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors px-2.5 py-1.5 rounded-lg hover:bg-secondary shrink-0"
          >
            <RefreshCw size={12} className={adsLoading ? "animate-spin" : ""} />
            <span className="hidden sm:inline">Atualizar</span>
          </button>
        </header>

        {/* Scrollable body */}
        <div className="flex-1 overflow-y-auto p-3 md:p-5 space-y-4">

          {/* Welcome card */}
          <div className="rounded-xl border border-accent/30 bg-accent/5 p-4 flex gap-4">
            <div className="w-9 h-9 rounded-lg bg-accent/20 flex items-center justify-center shrink-0 mt-0.5">
              <Sparkles size={18} className="text-accent" />
            </div>
            <div>
              <p className="text-foreground font-semibold text-sm">Olá, {firstName}!</p>
              <p className="text-muted-foreground text-sm mt-1 leading-relaxed max-w-2xl">
                Bem-vindo ao <strong className="text-foreground">{appName}</strong>. Hoje é um novo dia para fazer acontecer.
                Adicione suas demandas no <strong className="text-foreground">Kanban</strong> e acompanhe o progresso por aqui.
              </p>
            </div>
          </div>

          {/* Devotional card */}
          {(() => {
            const verse = aiDevotional?.verse ?? fallback.verse;
            const ref = aiDevotional?.reference ?? fallback.ref;
            const reflection = aiDevotional?.reflection ?? fallback.reflection;
            const prayer = aiDevotional?.prayer;
            const application = aiDevotional?.application;
            const showLoading = devLoading && !aiDevotional;

            return (
              <div className="relative overflow-hidden rounded-2xl border border-accent/30 bg-gradient-to-br from-accent/15 via-card to-primary/10 p-5">
                <div className="pointer-events-none absolute -top-16 -right-16 w-48 h-48 rounded-full bg-accent/20 blur-3xl" />
                <div className="pointer-events-none absolute -bottom-20 -left-12 w-56 h-56 rounded-full bg-primary/10 blur-3xl" />

                <div className="relative flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-accent/20 border border-accent/30 flex items-center justify-center">
                      <Sunrise size={15} className="text-accent" />
                    </div>
                    <div>
                      <p className="text-[10px] text-accent font-semibold uppercase tracking-widest">Devocional do dia</p>
                      <p className="text-[10px] text-muted-foreground capitalize">{dateStr}</p>
                    </div>
                  </div>
                  {showLoading && (
                    <div className="flex items-center gap-1.5 text-[10px] text-muted-foreground">
                      <Loader2 size={11} className="animate-spin" />
                      Gerando…
                    </div>
                  )}
                </div>

                <div className="relative pl-4 border-l-2 border-accent/50 mb-4">
                  <p className="text-foreground text-base leading-relaxed font-serif italic">
                    "{verse}"
                  </p>
                  <p className="text-accent text-xs font-semibold mt-1.5">— {ref}</p>
                </div>

                <div className="relative grid gap-3 md:grid-cols-3">
                  <button
                    type="button"
                    onClick={() => setExpandedDevSection(expandedDevSection === "reflection" ? null : "reflection")}
                    className="text-left rounded-lg border border-border/60 bg-background/40 p-3 hover:border-metric-blue/50 hover:bg-background/60 transition-colors"
                  >
                    <div className="flex items-center gap-1.5 mb-1.5">
                      <BookOpen size={11} className="text-metric-blue" />
                      <p className="text-[10px] font-semibold text-metric-blue uppercase tracking-wider">Reflexão</p>
                    </div>
                    <p className={`text-muted-foreground text-xs leading-relaxed ${expandedDevSection === "reflection" ? "" : "line-clamp-3"}`}>{reflection}</p>
                  </button>

                  <button
                    type="button"
                    onClick={() => setExpandedDevSection(expandedDevSection === "prayer" ? null : "prayer")}
                    className="text-left rounded-lg border border-border/60 bg-background/40 p-3 hover:border-metric-red/50 hover:bg-background/60 transition-colors"
                  >
                    <div className="flex items-center gap-1.5 mb-1.5">
                      <Heart size={11} className="text-metric-red" />
                      <p className="text-[10px] font-semibold text-metric-red uppercase tracking-wider">Oração</p>
                    </div>
                    <p className={`text-muted-foreground text-xs leading-relaxed italic ${expandedDevSection === "prayer" ? "" : "line-clamp-3"}`}>
                      {prayer ?? "Senhor, guia meus passos hoje e me dá sabedoria para viver a Tua Palavra."}
                    </p>
                  </button>

                  <button
                    type="button"
                    onClick={() => setExpandedDevSection(expandedDevSection === "application" ? null : "application")}
                    className="text-left rounded-lg border border-border/60 bg-background/40 p-3 hover:border-metric-green/50 hover:bg-background/60 transition-colors"
                  >
                    <div className="flex items-center gap-1.5 mb-1.5">
                      <Sparkles size={11} className="text-metric-green" />
                      <p className="text-[10px] font-semibold text-metric-green uppercase tracking-wider">Aplicação</p>
                    </div>
                    <p className={`text-foreground text-xs leading-relaxed font-medium ${expandedDevSection === "application" ? "" : "line-clamp-3"}`}>
                      {application ?? "Pratique esse versículo em uma decisão concreta hoje."}
                    </p>
                  </button>
                </div>

                {devError && (
                  <p className="relative text-[10px] text-muted-foreground mt-3">
                    Mostrando devocional offline (não foi possível gerar com IA agora).
                  </p>
                )}
              </div>
            );
          })()}


          {/* Meta Ads Metrics Section */}
          <div className="rounded-xl border border-border bg-card p-4">
            <div className="flex items-center justify-between mb-4 gap-3 flex-wrap">
              <div className="flex items-center gap-2">
                <Megaphone size={16} className="text-primary" />
                <p className="text-sm font-semibold text-foreground">Dashboard</p>
                {metaClients.length > 0 && (
                  <select
                    value={selectedClientId ?? ""}
                    onChange={(e) => setSelectedClientId(e.target.value || null)}
                    className="ml-2 px-2 py-1 text-xs bg-secondary border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-accent"
                  >
                    {metaClients.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}{c.meta_integration_status !== "ativo" ? " (inativo)" : ""}
                      </option>
                    ))}
                  </select>
                )}
              </div>
              <div className="flex items-center gap-1">
                {Object.entries(datePresetLabels).map(([key, label]) => (
                  <button
                    key={key}
                    onClick={() => setAdsPreset(key)}
                    className={cn(
                      "px-2.5 py-1 text-[11px] font-medium rounded-lg transition-all",
                      adsPreset === key
                        ? "bg-foreground text-background"
                        : "text-muted-foreground hover:text-foreground"
                    )}
                  >
                    {label}
                  </button>
                ))}
              </div>
            </div>

            {metaClients.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-sm text-muted-foreground">Nenhum cliente com integração Meta cadastrada.</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Cadastre o token e o Ad Account ID na aba <strong>Integração</strong> de um cliente.
                </p>
              </div>
            ) : adsError ? (
              <div className="text-center py-6">
                <p className="text-sm text-destructive">Erro ao carregar métricas</p>
                <p className="text-xs text-muted-foreground mt-1">{(adsError as Error).message}</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
                <MetricCard
                  value={adsLoading ? "..." : formatNumber(adsMetrics?.conversations ?? 0)}
                  label="Conversas"
                  icon={<MessageCircle size={20} />}
                  variant="green"
                />
                <MetricCard
                  value={adsLoading ? "..." : formatNumber(adsMetrics?.messages ?? 0)}
                  label="Mensagens"
                  icon={<MessageCircle size={20} />}
                  variant="blue"
                />
                <MetricCard
                  value={adsLoading ? "..." : formatNumber(adsMetrics?.reach ?? 0)}
                  label="Alcance"
                  icon={<Users size={20} />}
                  variant="amber"
                />
                <MetricCard
                  value={adsLoading ? "..." : formatNumber(adsMetrics?.impressions ?? 0)}
                  label="Impressões"
                  icon={<Eye size={20} />}
                  variant="default"
                />
                <MetricCard
                  value={adsLoading ? "..." : formatNumber(adsMetrics?.clicks ?? 0)}
                  label="Cliques"
                  icon={<MousePointerClick size={20} />}
                  variant="default"
                />
                <MetricCard
                  value={adsLoading ? "..." : formatCurrency(adsMetrics?.spend ?? 0)}
                  label="Investido"
                  icon={<DollarSign size={20} />}
                  variant="red"
                />
              </div>
            )}

            {/* Cost per result row */}
            {adsMetrics && !adsError && (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-3">
                <div className="rounded-lg border border-border bg-secondary/30 p-3 text-center">
                  <p className="text-lg font-bold text-foreground tabular-nums">
                    {formatCurrency(adsMetrics.costPerConversation)}
                  </p>
                  <p className="text-[10px] text-muted-foreground font-medium">Custo/Conversa</p>
                </div>
                <div className="rounded-lg border border-border bg-secondary/30 p-3 text-center">
                  <p className="text-lg font-bold text-foreground tabular-nums">
                    {formatCurrency(adsMetrics.costPerMessage)}
                  </p>
                  <p className="text-[10px] text-muted-foreground font-medium">Custo/Mensagem</p>
                </div>
                <div className="rounded-lg border border-border bg-secondary/30 p-3 text-center">
                  <p className="text-lg font-bold text-foreground tabular-nums">
                    {adsMetrics.ctr.toFixed(2)}%
                  </p>
                  <p className="text-[10px] text-muted-foreground font-medium">CTR</p>
                </div>
                <div className="rounded-lg border border-border bg-secondary/30 p-3 text-center">
                  <p className="text-lg font-bold text-foreground tabular-nums">
                    {formatCurrency(adsMetrics.cpc)}
                  </p>
                  <p className="text-[10px] text-muted-foreground font-medium">CPC</p>
                </div>
              </div>
            )}

            {!adsError && <MetaAdsMiniDashboard metrics={adsMetrics} loading={adsLoading} />}
          </div>

          {/* Stats row */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Previous week stats */}
            <div className="md:col-span-1 rounded-xl border border-border bg-card p-4">
              <p className="text-xs text-muted-foreground font-medium mb-3">Semana Anterior</p>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <div className="flex items-center gap-1.5 mb-1">
                    <CheckCircle2 size={13} className="text-metric-green" />
                    <span className="text-xs text-muted-foreground">Concluídas</span>
                  </div>
                  <p className="text-2xl font-bold text-foreground">{demandStats?.pwDone ?? 0}</p>
                </div>
                <div>
                  <div className="flex items-center gap-1.5 mb-1">
                    <Clock size={13} className="text-metric-blue" />
                    <span className="text-xs text-muted-foreground">Tempo Médio</span>
                  </div>
                  <p className="text-2xl font-bold text-foreground">
                    {demandStats && demandStats.pwDone > 0 ? `${demandStats.avgDays.toFixed(1)}d` : "—"}
                  </p>
                </div>
                <div>
                  <div className="flex items-center gap-1.5 mb-1">
                    <AlertTriangle size={13} className="text-metric-amber" />
                    <span className="text-xs text-muted-foreground">Atrasadas</span>
                  </div>
                  <p className="text-2xl font-bold text-foreground">{demandStats?.pwOverdue ?? 0}</p>
                </div>
                <div>
                  <div className="flex items-center gap-1.5 mb-1">
                    <Calendar size={13} className="text-primary" />
                    <span className="text-xs text-muted-foreground">Melhor Dia</span>
                  </div>
                  <p className="text-lg font-bold text-foreground">{demandStats?.bestDay ?? "—"}</p>
                </div>
              </div>
            </div>

            {/* Performance card */}
            <div className="md:col-span-2 rounded-xl border border-border bg-card p-4">
              <div className="flex items-center gap-1 mb-4">
                {(["Semana", "Mês", "Ano"] as const).map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setPerfTab(tab)}
                    className={cn(
                      "px-3 py-1.5 text-xs font-medium rounded-lg transition-all",
                      perfTab === tab
                        ? "bg-foreground text-background"
                        : "text-muted-foreground hover:text-foreground"
                    )}
                  >
                    {tab}
                  </button>
                ))}
              </div>

              <p className="text-xs text-muted-foreground mb-2">Performance {perfTab}</p>
              <div className="flex items-end justify-between">
                <div>
                  <p className="text-3xl font-bold text-foreground">
                    {perfValue} <span className="text-base font-normal text-muted-foreground">demandas</span>
                  </p>
                  <div className="flex items-center gap-1 mt-1">
                    <TrendingUp size={13} className="text-metric-green" />
                    <span className="text-xs text-metric-green font-medium">
                      {perfValue === 0 ? "Pronto para começar" : `${perfPct}% do total visível`}
                    </span>
                  </div>
                </div>
                <div className="w-16 h-16 rounded-full bg-metric-green/10 border border-metric-green/30 flex items-center justify-center">
                  <span className="text-sm font-bold text-metric-green">{perfPct}%</span>
                </div>
              </div>

              {/* Mini bar chart (concluídas por dia da semana atual) */}
              <div className="mt-4 flex items-end gap-1.5 h-10">
                {(demandStats?.cwDoneByDay ?? [0,0,0,0,0,0,0]).map((h, i) => (
                  <div
                    key={i}
                    className={cn(
                      "flex-1 rounded-t-sm transition-all",
                      i === dayOfWeek ? "bg-primary/60" : "bg-secondary"
                    )}
                    style={{ height: `${Math.max((h / maxBar) * 100, 8)}%` }}
                  />
                ))}
              </div>
              <div className="flex gap-1.5 mt-1">
                {weekDays.map((d, i) => (
                  <p key={d} className={cn("flex-1 text-center text-[10px]", i === dayOfWeek ? "text-primary" : "text-muted-foreground/50")}>
                    {d}
                  </p>
                ))}
              </div>
            </div>
          </div>

          {/* Current week metric cards */}
          <div className="rounded-xl border border-border bg-card p-4">
            <p className="text-xs text-muted-foreground font-medium mb-3">Semana Atual</p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <MetricCard value={demandStats?.cwDone ?? 0} label="Concluídas" icon={<CheckCircle2 size={22} />} variant="green" />
              <MetricCard value={demandStats?.cwProgress ?? 0} label="Em Andamento" icon={<TrendingUp size={22} />} variant="blue" />
              <MetricCard value={demandStats?.cwOverdue ?? 0} label="Em Atraso" icon={<AlertTriangle size={22} />} variant="red" />
              <MetricCard value={demandStats?.cwToday ?? 0} label="Para Hoje" icon={<Calendar size={22} />} variant="amber" />
            </div>
          </div>

          {/* Mobile-only priorities list */}
          <div className="lg:hidden rounded-xl border border-border bg-card overflow-hidden">
            <div className="px-4 py-3 border-b border-border flex items-center justify-between">
              <p className="text-sm font-semibold text-foreground">Prioridades do Dia</p>
              <Link to="/kanban" className="text-xs text-accent hover:text-accent/80 font-medium flex items-center gap-1">
                Ver Todas <ArrowRight size={11} />
              </Link>
            </div>
            <div className="divide-y divide-border">
              {(demandStats?.priorities ?? []).slice(0, 6).map((p) => {
                const overdue = p.due && p.due < new Date();
                const dueLabel = p.due
                  ? p.due.toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" })
                  : "Sem prazo";
                return (
                  <Link key={p.id} to="/kanban" className="block px-4 py-3 hover:bg-secondary/50 transition-colors">
                    <div className="flex items-start gap-2.5">
                      <div className={cn(
                        "w-1.5 h-1.5 rounded-full mt-1.5 shrink-0",
                        overdue ? "bg-metric-red" : p.status === "progress" ? "bg-metric-blue" : "bg-metric-amber"
                      )} />
                      <div className="flex-1 min-w-0">
                        <p className="text-[11px] text-muted-foreground truncate">
                          {p.status === "progress" ? "Em andamento" : "A fazer"}
                        </p>
                        <p className="text-sm font-medium text-foreground truncate">{p.title}</p>
                      </div>
                      <span className={cn(
                        "text-[10px] font-medium px-2 py-0.5 rounded-md border shrink-0",
                        overdue
                          ? "border-metric-red/40 text-metric-red bg-metric-red/10"
                          : "border-metric-blue/40 text-metric-blue bg-metric-blue/10"
                      )}>
                        {dueLabel}
                      </span>
                    </div>
                  </Link>
                );
              })}
              {(!demandStats?.priorities || demandStats.priorities.length === 0) && (
                <div className="px-4 py-6 text-center">
                  <p className="text-xs text-muted-foreground/60">Nenhuma demanda pendente.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Priorities sidebar (desktop only) */}
      <div className="hidden lg:flex w-64 shrink-0 border-l border-border bg-card flex-col overflow-hidden">
        <div className="px-4 py-3 border-b border-border flex items-center justify-between">
          <p className="text-sm font-semibold text-foreground">Prioridades do Dia</p>
          <Link to="/kanban" className="text-xs text-accent hover:text-accent/80 font-medium flex items-center gap-1">
            Ver Todas <ArrowRight size={11} />
          </Link>
        </div>
        <div className="flex-1 overflow-y-auto divide-y divide-border">
          {(demandStats?.priorities ?? []).map((p) => {
            const overdue = p.due && p.due < new Date();
            const dueLabel = p.due
              ? p.due.toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" })
              : "Sem prazo";
            return (
              <Link
                key={p.id}
                to="/kanban"
                className="block px-4 py-3 hover:bg-secondary/50 transition-colors"
              >
                <div className="flex items-start gap-2.5">
                  <div className={cn(
                    "w-1.5 h-1.5 rounded-full mt-1.5 shrink-0",
                    overdue ? "bg-metric-red" : p.status === "progress" ? "bg-metric-blue" : "bg-metric-amber"
                  )} />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs text-muted-foreground truncate">
                      {p.status === "progress" ? "Em andamento" : "A fazer"}
                    </p>
                    <p className="text-sm font-medium text-foreground truncate">{p.title}</p>
                  </div>
                  <span className={cn(
                    "text-[10px] font-medium px-2 py-0.5 rounded-md border shrink-0",
                    overdue
                      ? "border-metric-red/40 text-metric-red bg-metric-red/10"
                      : "border-metric-blue/40 text-metric-blue bg-metric-blue/10"
                  )}>
                    {dueLabel}
                  </span>
                </div>
              </Link>
            );
          })}
        </div>
        {(!demandStats?.priorities || demandStats.priorities.length === 0) && (
          <div className="px-4 py-6 flex flex-col items-center text-center gap-2">
            <p className="text-xs text-muted-foreground/60">Nenhuma demanda pendente.</p>
            <p className="text-xs text-muted-foreground/40">Acesse o Kanban para criar suas primeiras tarefas.</p>
          </div>
        )}
      </div>
    </div>
  );
}
