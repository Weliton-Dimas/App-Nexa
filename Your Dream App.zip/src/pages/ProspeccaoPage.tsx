import { useMemo, useState } from "react";
import { DashboardSidebar } from "@/components/DashboardSidebar";
import { useProspects, Prospect, useUpsertProspect } from "@/hooks/useProspects";
import ProspectCard from "@/components/prospects/ProspectCard";
import ProspectModal from "@/components/prospects/ProspectModal";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Search, Target } from "lucide-react";
import {
  DndContext,
  DragEndEvent,
  PointerSensor,
  useDroppable,
  useSensor,
  useSensors,
} from "@dnd-kit/core";
import { useQueryClient } from "@tanstack/react-query";

const COLUMNS = [
  { key: "novo", label: "Novo" },
  { key: "em_contato", label: "Em Contato" },
  { key: "qualificado", label: "Qualificado" },
  { key: "negociacao", label: "Negociação" },
  { key: "ganho", label: "Ganho" },
  { key: "perdido", label: "Perdido" },
];

function DroppableColumn({
  id,
  children,
}: {
  id: string;
  children: React.ReactNode;
}) {
  const { setNodeRef, isOver } = useDroppable({ id });
  return (
    <div
      ref={setNodeRef}
      className={`flex-1 overflow-y-auto p-2 space-y-2 transition-colors ${
        isOver ? "bg-accent/10 ring-2 ring-accent rounded-md" : ""
      }`}
    >
      {children}
    </div>
  );
}

export default function ProspeccaoPage() {
  const { data: prospects = [], isLoading } = useProspects();
  const upsert = useUpsertProspect();
  const qc = useQueryClient();
  const [search, setSearch] = useState("");
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Prospect | null>(null);
  const [defaultStatus, setDefaultStatus] = useState<string>("novo");

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 5 } }),
  );

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return prospects;
    return prospects.filter(
      (p) =>
        p.company_name.toLowerCase().includes(q) ||
        (p.contact_name ?? "").toLowerCase().includes(q),
    );
  }, [prospects, search]);

  const grouped = useMemo(() => {
    const m: Record<string, Prospect[]> = {};
    COLUMNS.forEach((c) => (m[c.key] = []));
    filtered.forEach((p) => {
      (m[p.status] ?? (m[p.status] = [])).push(p);
    });
    return m;
  }, [filtered]);

  const openNew = (status: string) => {
    setEditing(null);
    setDefaultStatus(status);
    setModalOpen(true);
  };

  const openEdit = (p: Prospect) => {
    setEditing(p);
    setModalOpen(true);
  };

  const handleDragEnd = (e: DragEndEvent) => {
    const { active, over } = e;
    if (!over) return;
    const newStatus = String(over.id);
    const oldStatus = (active.data.current as any)?.status;
    if (!newStatus || newStatus === oldStatus) return;

    // Optimistic update
    qc.setQueryData<Prospect[]>(["prospects"], (old) =>
      (old ?? []).map((p) => (p.id === active.id ? { ...p, status: newStatus } : p)),
    );

    upsert.mutate({ id: String(active.id), status: newStatus });
  };

  return (
    <div className="flex h-screen bg-background">
      <DashboardSidebar />
      <main className="flex-1 flex flex-col overflow-hidden">
        <header className="px-6 py-4 border-b border-border flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <Target className="w-5 h-5 text-accent" />
            <div>
              <h1 className="text-xl font-bold">Prospecção</h1>
              <p className="text-xs text-muted-foreground">{prospects.length} leads no pipeline</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="w-4 h-4 absolute left-2 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Buscar empresa ou contato..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-8 w-72"
              />
            </div>
            <Button onClick={() => openNew("novo")}>
              <Plus className="w-4 h-4 mr-1" /> Novo Prospect
            </Button>
          </div>
        </header>

        <div className="flex-1 overflow-x-auto p-4">
          {isLoading ? (
            <p className="text-sm text-muted-foreground">Carregando...</p>
          ) : (
            <DndContext sensors={sensors} onDragEnd={handleDragEnd}>
              <div className="flex gap-3 h-full min-w-max">
                {COLUMNS.map((col) => (
                  <div key={col.key} className="w-72 shrink-0 flex flex-col bg-muted/30 rounded-lg border border-border">
                    <div className="px-3 py-2 border-b border-border flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <h2 className="text-xs font-semibold uppercase tracking-wider">{col.label}</h2>
                        <span className="text-[10px] text-muted-foreground bg-muted px-1.5 rounded">
                          {grouped[col.key]?.length ?? 0}
                        </span>
                      </div>
                      <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => openNew(col.key)}>
                        <Plus className="w-3 h-3" />
                      </Button>
                    </div>
                    <DroppableColumn id={col.key}>
                      {(grouped[col.key] ?? []).map((p) => (
                        <ProspectCard key={p.id} prospect={p} onEdit={() => openEdit(p)} />
                      ))}
                      {(grouped[col.key] ?? []).length === 0 && (
                        <p className="text-xs text-muted-foreground text-center py-6">Sem leads</p>
                      )}
                    </DroppableColumn>
                  </div>
                ))}
              </div>
            </DndContext>
          )}
        </div>
      </main>

      <ProspectModal
        open={modalOpen}
        onOpenChange={setModalOpen}
        prospect={editing}
        defaultStatus={defaultStatus}
      />
    </div>
  );
}
