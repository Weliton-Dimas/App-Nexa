const PrivacyPage = () => {
  return (
    <main className="min-h-screen bg-background text-foreground">
      <div className="max-w-3xl mx-auto px-6 py-12">
        <h1 className="text-3xl font-bold mb-2">Política de Privacidade</h1>
        <p className="text-sm text-muted-foreground mb-8">
          Última atualização: {new Date().toLocaleDateString("pt-BR")}
        </p>

        <section className="space-y-6 text-sm leading-relaxed">
          <div>
            <h2 className="text-lg font-semibold mb-2">1. Quem somos</h2>
            <p>
              A Nexa Performance ("nós") opera a plataforma disponível em{" "}
              <strong>app.agencianexaperformance.com.br</strong>, destinada à gestão interna
              de campanhas, clientes e operações da agência.
            </p>
          </div>

          <div>
            <h2 className="text-lg font-semibold mb-2">2. Dados que coletamos</h2>
            <ul className="list-disc pl-5 space-y-1">
              <li>Dados de cadastro: nome, e-mail e foto de perfil.</li>
              <li>Dados operacionais inseridos pelos usuários (clientes, tarefas, métricas).</li>
              <li>
                Tokens de acesso às plataformas conectadas (Meta Ads, Google Ads, Magazord),
                armazenados de forma criptografada e usados exclusivamente para sincronizar
                dados das contas autorizadas.
              </li>
            </ul>
          </div>

          <div>
            <h2 className="text-lg font-semibold mb-2">3. Como usamos os dados</h2>
            <p>
              Utilizamos os dados apenas para operar a plataforma, autenticar usuários,
              sincronizar métricas das contas conectadas e gerar relatórios internos. Não
              vendemos nem compartilhamos dados com terceiros para fins de marketing.
            </p>
          </div>

          <div>
            <h2 className="text-lg font-semibold mb-2">4. Integrações com Meta e Google</h2>
            <p>
              Quando você conecta uma conta Meta Ads ou Google Ads, solicitamos somente os
              escopos necessários para leitura de campanhas e métricas. Os tokens podem ser
              revogados a qualquer momento dentro da plataforma ou diretamente nas
              configurações da conta de origem.
            </p>
          </div>

          <div>
            <h2 className="text-lg font-semibold mb-2">5. Armazenamento e segurança</h2>
            <p>
              Os dados são armazenados em infraestrutura Supabase, com Row-Level Security e
              acesso restrito por função. Aplicamos boas práticas de segurança, mas nenhum
              sistema é 100% imune a falhas.
            </p>
          </div>

          <div>
            <h2 className="text-lg font-semibold mb-2">6. Seus direitos</h2>
            <p>
              Você pode solicitar acesso, correção ou exclusão dos seus dados a qualquer
              momento, entrando em contato pelo e-mail abaixo.
            </p>
          </div>

          <div>
            <h2 className="text-lg font-semibold mb-2">7. Contato</h2>
            <p>
              Dúvidas sobre privacidade:{" "}
              <a className="text-primary underline" href="mailto:welitondimas16@gmail.com">
                welitondimas16@gmail.com
              </a>
            </p>
          </div>
        </section>
      </div>
    </main>
  );
};

export default PrivacyPage;
