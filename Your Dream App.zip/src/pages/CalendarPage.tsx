import { useEffect, useMemo, useState, useCallback } from "react";
import { DashboardSidebar } from "@/components/DashboardSidebar";
import { ChevronLeft, ChevronRight, RefreshCw, Sparkles, Flag, Plus, Calendar as CalendarIcon, LayoutList, GanttChart, KanbanSquare } from "lucide-react";
import { cn } from "@/lib/utils";
import { supabase } from "@/integrations/supabase/client";
import { CalendarTaskModal, type CalendarTask } from "@/components/CalendarTaskModal";
import { getHolidaysForMonth, getHolidaysForDay, type HolidayEntry } from "@/lib/holidays";
import { toast } from "sonner";
import { GoogleCalendarConnect } from "@/components/GoogleCalendarConnect";
import { useUnifiedTasks, type UnifiedTask, toIsoDate } from "@/hooks/useUnifiedTasks";
import { ByDayView } from "@/components/calendar/ByDayView";
import { TimelineView } from "@/components/calendar/TimelineView";
import { ByProgressView } from "@/components/calendar/ByProgressView";
import { useNavigate } from "react-router-dom";

const WEEKDAYS = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];
const MONTHS = ["Janeiro","Fevereiro","Março","Abril","Maio","Junho","Julho","Agosto","Setembro","Outubro","Novembro","Dezembro"];

const colorMap: Record<string, string> = {
  green: "bg-metric-green/20 text-metric-green border-metric-green/30",
  blue: "bg-metric-blue/20 text-metric-blue border-metric-blue/30",
  amber: "bg-metric-amber/20 text-metric-amber border-metric-amber/30",
  red: "bg-metric-red/20 text-metric-red border-metric-red/30",
  purple: "bg-purple-500/20 text-purple-400 border-purple-500/30",
  pink: "bg-pink-500/20 text-pink-400 border-pink-500/30",
};

interface ClientOpt { id: string; name: string }
interface UserOpt { user_id: string; display_name: string | null }

type ViewKey = "calendar" | "byDay" | "timeline" | "byProgress";

const VIEW_TABS: { key: ViewKey; label: string; icon: any }[] = [
  { key: "calendar", label: "Calendário", icon: CalendarIcon },
  { key: "byDay", label: "Por Dia", icon: LayoutList },
  { key: "timeline", label: "Cronograma", icon: GanttChart },
  { key: "byProgress", label: "Por Progresso", icon: KanbanSquare },
];

export default function CalendarPage() {
  const now = new Date();
  const navigate = useNavigate();
  const [view, setView] = useState<ViewKey>(() => {
    const saved = localStorage.getItem("calendar_view");
    if (saved === "calendar" || saved === "byDay" || saved === "timeline" || saved === "byProgress") return saved;
    return "calendar";
  });
  useEffect(() => { localStorage.setItem("calendar_view", view); }, [view]);

  const [currentDate, setCurrentDate] = useState(new Date(now.getFullYear(), now.getMonth(), 1));
  const [clients, setClients] = useState<ClientOpt[]>([]);
  const [users, setUsers] = useState<UserOpt[]>([]);
  const [modalDate, setModalDate] = useState<Date | null>(null);
  const [editingTask, setEditingTask] = useState<CalendarTask | null>(null);

  const { tasks: unified, progressGroups, refetchCalendar, isLoading } = useUnifiedTasks();

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();
  const monthHolidays = useMemo(() => getHolidaysForMonth(year, month), [year, month]);

  useEffect(() => {
    (async () => {
      const [c, p] = await Promise.all([
        supabase.from("clients").select("id, name").order("name"),
        supabase.from("profiles").select("user_id, display_name"),
      ]);
      if (c.data) setClients(c.data as ClientOpt[]);
      if (p.data) setUsers(p.data as UserOpt[]);
    })();
  }, []);

  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const daysInPrev = new Date(year, month, 0).getDate();

  const cells: { day: number; current: boolean; date: Date }[] = [];
  for (let i = firstDay - 1; i >= 0; i--) {
    const d = daysInPrev - i;
    cells.push({ day: d, current: false, date: new Date(year, month - 1, d) });
  }
  for (let i = 1; i <= daysInMonth; i++) {
    cells.push({ day: i, current: true, date: new Date(year, month, i) });
  }
  let fillDay = 1;
  while (cells.length % 7 !== 0) {
    cells.push({ day: fillDay, current: false, date: new Date(year, month + 1, fillDay) });
    fillDay++;
  }

  const prevMonth = () => setCurrentDate(new Date(year, month - 1, 1));
  const nextMonth = () => setCurrentDate(new Date(year, month + 1, 1));
  const goToday = () => setCurrentDate(new Date(now.getFullYear(), now.getMonth(), 1));

  const tasksForDay = (d: Date) => unified.filter((t) => t.date === toIsoDate(d));
  const holidaysForDay = (d: Date) => getHolidaysForDay(d.getFullYear(), d.getMonth(), d.getDate());
  const isToday = (d: Date) =>
    d.getDate() === now.getDate() && d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();

  const openNewCalendarTask = (d: Date) => { setEditingTask(null); setModalDate(d); };

  const handleTaskClick = useCallback((t: UnifiedTask) => {
    if (t.source === "calendar") {
      const raw = t.raw as CalendarTask;
      const [y, m, dd] = raw.date.split("-").map(Number);
      setEditingTask(raw);
      setModalDate(new Date(y, m - 1, dd));
    } else {
      // kanban task → redireciona para o kanban
      navigate("/kanban");
    }
  }, [navigate]);

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      <DashboardSidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="flex flex-wrap items-center justify-between pl-14 pr-3 md:px-6 py-3 border-b border-border shrink-0 gap-2 md:gap-3">
          <div className="min-w-0">
            <h1 className="text-foreground text-base md:text-lg font-semibold leading-none truncate">Calendário</h1>
            <p className="text-muted-foreground text-[10px] md:text-xs mt-1 hidden sm:block">Tarefas, feriados e sazonalidades</p>
          </div>

          {/* Tabs de visualização */}
          <div className="order-3 md:order-none w-full md:w-auto overflow-x-auto">
            <div className="flex items-center bg-secondary rounded-lg p-0.5 w-max md:w-auto">
              {VIEW_TABS.map(({ key, label, icon: Icon }) => (
                <button
                  key={key}
                  onClick={() => setView(key)}
                  className={cn(
                    "flex items-center gap-1.5 text-xs px-2.5 md:px-3 py-1.5 rounded-md transition-colors whitespace-nowrap",
                    view === key
                      ? "bg-card text-foreground shadow-sm"
                      : "text-muted-foreground hover:text-foreground"
                  )}
                >
                  <Icon size={12} /> {label}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-1.5 md:gap-3 flex-wrap justify-end">
            <div className="hidden md:block">
              <GoogleCalendarConnect onSynced={refetchCalendar} />
            </div>
            <div className="hidden lg:flex items-center gap-3 text-[10px] text-muted-foreground">
              <span className="flex items-center gap-1"><Flag size={10} className="text-metric-red" /> Feriado</span>
              <span className="flex items-center gap-1"><Sparkles size={10} className="text-accent" /> Sazonal</span>
            </div>

            {(view === "calendar" || view === "timeline") && (
              <div className="flex items-center gap-1">
                <button onClick={prevMonth} className="p-1.5 rounded-lg hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors">
                  <ChevronLeft size={14} />
                </button>
                <span className="text-xs md:text-sm font-semibold text-foreground min-w-[100px] md:min-w-[130px] text-center">
                  {MONTHS[month]} {year}
                </span>
                <button onClick={nextMonth} className="p-1.5 rounded-lg hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors">
                  <ChevronRight size={14} />
                </button>
              </div>
            )}

            <button onClick={goToday} className="hidden sm:flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors px-2.5 md:px-3 py-1.5 rounded-lg hover:bg-secondary">
              <RefreshCw size={12} className={isLoading ? "animate-spin" : ""} /> Hoje
            </button>

            <button
              onClick={() => openNewCalendarTask(new Date())}
              className="flex items-center gap-1.5 text-xs bg-accent text-accent-foreground px-2.5 md:px-3 py-1.5 rounded-lg font-medium hover:bg-accent/90 transition-colors"
            >
              <Plus size={12} /> Nova
            </button>
          </div>
        </header>

        <div className="flex-1 overflow-hidden p-2 md:p-5">
          {view === "calendar" && (
            <div className="h-full flex flex-col rounded-xl border border-border bg-card overflow-hidden">
              <div className="grid grid-cols-7 border-b border-border">
                {WEEKDAYS.map((d) => (
                  <div key={d} className="py-2 text-center text-[10px] md:text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">
                    <span className="md:hidden">{d.charAt(0)}</span>
                    <span className="hidden md:inline">{d}</span>
                  </div>
                ))}
              </div>

              <div className="flex-1 grid grid-cols-7 auto-rows-fr overflow-y-auto">
                {cells.map((cell, idx) => {
                  const dayTasks = tasksForDay(cell.date);
                  const dayHolidays = cell.current ? holidaysForDay(cell.date) : [];
                  const today = isToday(cell.date);
                  return (
                    <div
                      key={idx}
                      onClick={() => cell.current && openNewCalendarTask(cell.date)}
                      className={cn(
                        "border-b border-r border-border p-1 md:p-1.5 min-h-[64px] md:min-h-[100px] transition-colors group cursor-pointer",
                        cell.current ? "hover:bg-secondary/40" : "bg-secondary/10",
                        idx % 7 === 6 && "border-r-0",
                      )}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <div className={cn(
                          "w-5 h-5 md:w-6 md:h-6 rounded-full flex items-center justify-center text-[11px] md:text-xs font-medium",
                          today && cell.current
                            ? "bg-accent text-accent-foreground"
                            : cell.current ? "text-foreground" : "text-muted-foreground/30"
                        )}>
                          {cell.day}
                        </div>
                        {dayHolidays.length > 0 && cell.current && (
                          <div className="flex items-center gap-0.5">
                            {dayHolidays.some((h) => h.kind === "feriado") && (
                              <Flag size={10} className="text-metric-red" />
                            )}
                            {dayHolidays.some((h) => h.kind === "sazonalidade") && (
                              <Sparkles size={10} className="text-accent" />
                            )}
                          </div>
                        )}
                      </div>

                      {/* Mobile: dots in a single aligned row */}
                      <div className="md:hidden flex items-center gap-1 flex-wrap leading-none">
                        {dayHolidays.slice(0, 2).map((h) => (
                          <span
                            key={h.name}
                            className={cn(
                              "w-1.5 h-1.5 rounded-full shrink-0",
                              h.kind === "feriado" ? "bg-metric-red" : "bg-accent"
                            )}
                          />
                        ))}
                        {dayTasks.slice(0, 4).map((t) => (
                          <button
                            key={t.id}
                            onClick={(e) => { e.stopPropagation(); handleTaskClick(t); }}
                            className={cn(
                              "w-1.5 h-1.5 rounded-full shrink-0",
                              t.color === "green" && "bg-metric-green",
                              t.color === "blue" && "bg-metric-blue",
                              t.color === "amber" && "bg-metric-amber",
                              t.color === "red" && "bg-metric-red",
                              t.color === "purple" && "bg-purple-400",
                              t.color === "pink" && "bg-pink-400",
                              !["green","blue","amber","red","purple","pink"].includes(t.color) && "bg-metric-blue",
                            )}
                          />
                        ))}
                        {dayTasks.length > 4 && (
                          <span className="text-[9px] leading-none text-muted-foreground/70 ml-0.5 shrink-0">
                            +{dayTasks.length - 4}
                          </span>
                        )}
                      </div>

                      {/* Desktop: full chips */}
                      <div className="hidden md:flex flex-col gap-0.5 min-w-0">
                        {dayHolidays.slice(0, 1).map((h) => (
                          <div
                            key={h.name}
                            title={h.name}
                            className={cn(
                              "text-[10px] leading-tight px-1.5 py-0.5 rounded border truncate",
                              h.kind === "feriado"
                                ? "bg-metric-red/10 text-metric-red border-metric-red/30"
                                : "bg-accent/10 text-accent border-accent/30"
                            )}
                          >
                            {h.name}
                          </div>
                        ))}
                        {dayTasks.slice(0, 3).map((t) => (
                          <button
                            key={t.id}
                            onClick={(e) => { e.stopPropagation(); handleTaskClick(t); }}
                            title={`${t.title}${t.source === "kanban" ? " (Kanban)" : ""}`}
                            className={cn(
                              "w-full min-w-0 text-left text-[10px] leading-tight px-1.5 py-0.5 rounded border hover:opacity-80 flex items-center gap-1",
                              colorMap[t.color] ?? colorMap.blue,
                            )}
                          >
                            {t.source === "kanban" && <KanbanSquare size={8} className="shrink-0 opacity-70" />}
                            <span className="truncate flex-1 min-w-0">{t.title}</span>
                          </button>
                        ))}
                        {(dayTasks.length + dayHolidays.length) > 4 && (
                          <p className="text-[10px] leading-none text-muted-foreground/60 pl-1 pt-0.5">
                            +{dayTasks.length + dayHolidays.length - 4} mais
                          </p>
                        )}
                      </div>

                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {view === "byDay" && (
            <ByDayView
              tasks={unified}
              onTaskClick={handleTaskClick}
              onAddForDate={openNewCalendarTask}
            />
          )}

          {view === "timeline" && (
            <TimelineView
              tasks={unified}
              year={year}
              month={month}
              onTaskClick={handleTaskClick}
            />
          )}

          {view === "byProgress" && (
            <ByProgressView
              tasks={unified}
              groups={progressGroups}
              onTaskClick={handleTaskClick}
            />
          )}
        </div>
      </div>

      {/* Holidays sidebar - escondido em views horizontais para dar espaço */}
      {view === "calendar" && (
        <aside className="hidden lg:flex w-64 shrink-0 border-l border-border bg-card flex-col overflow-hidden">
          <div className="px-4 py-3 border-b border-border">
            <p className="text-sm font-semibold text-foreground">{MONTHS[month]}</p>
            <p className="text-xs text-muted-foreground mt-0.5">Feriados e sazonalidades</p>
          </div>
          <div className="flex-1 overflow-y-auto divide-y divide-border">
            {monthHolidays.length === 0 ? (
              <p className="px-4 py-6 text-xs text-muted-foreground/60 text-center">
                Nenhum feriado neste mês.
              </p>
            ) : (
              monthHolidays
                .sort((a: HolidayEntry, b: HolidayEntry) => a.date.getDate() - b.date.getDate())
                .map((h) => (
                  <div key={`${h.name}-${h.date.toISOString()}`} className="px-4 py-2.5 hover:bg-secondary/40 transition-colors">
                    <div className="flex items-start gap-2">
                      {h.kind === "feriado" ? (
                        <Flag size={11} className="text-metric-red mt-1 shrink-0" />
                      ) : (
                        <Sparkles size={11} className="text-accent mt-1 shrink-0" />
                      )}
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-medium text-foreground truncate">{h.name}</p>
                        <p className="text-[10px] text-muted-foreground">
                          {h.date.toLocaleDateString("pt-BR", { weekday: "short", day: "2-digit", month: "short" })}
                        </p>
                      </div>
                    </div>
                  </div>
                ))
            )}
          </div>
        </aside>
      )}

      {modalDate && (
        <CalendarTaskModal
          open={!!modalDate}
          onClose={() => { setModalDate(null); setEditingTask(null); }}
          date={modalDate}
          task={editingTask}
          clients={clients}
          users={users}
          onSaved={refetchCalendar}
        />
      )}
    </div>
  );
}
