import { useState, useCallback, useMemo } from "react";
import { DashboardSidebar } from "@/components/DashboardSidebar";
import { cn } from "@/lib/utils";
import { supabase } from "@/integrations/supabase/client";
import { SAFE_CLIENT_COLUMNS } from "@/lib/clientConstants";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { useUserPermissions } from "@/hooks/useUserPermissions";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { Checkbox } from "@/components/ui/checkbox";
import {
  RefreshCw,
  SlidersHorizontal,
  Calendar as CalendarIcon,
  ArrowLeftRight,
  LayoutGrid,
  Info,
  Clock,
  Pencil,
  Check,
  X,
  Search,
  ArrowUpDown,
  ChevronDown,
} from "lucide-react";
import { toast } from "sonner";
import { AreaChart, Area, BarChart, Bar, ResponsiveContainer } from "recharts";
import type { DateRange } from "react-day-picker";

interface Client {
  id: string;
  name: string;
  status: "ativo" | "inativo";
  website_url: string | null;
  faturamento: number;
  investido: number;
  roi: number;
  percentual_midia: number;
  roas: number;
  conversas: number;
  conversoes: number;
}

const formatCurrency = (value: number) =>
  value.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

const formatNumber = (value: number, digits = 2) =>
  value.toLocaleString("pt-BR", { minimumFractionDigits: digits, maximumFractionDigits: digits });

type ChartFormat = "area" | "bars";
type Grouping = "day" | "week" | "month";

function Sparkline({
  color = "hsl(var(--metric-blue))",
  seed = 1,
  format = "area",
  grouping = "day",
}: {
  color?: string;
  seed?: number;
  format?: ChartFormat;
  grouping?: Grouping;
}) {
  const points = grouping === "day" ? 24 : grouping === "week" ? 12 : 6;
  const data = Array.from({ length: points }, (_, i) => ({
    x: i,
    y: 30 + Math.sin(i / 2 + seed) * 15 + Math.cos(i / 3 + seed * 2) * 10 + (seed % 5) * 2,
  }));
  const id = `spark-${seed}-${format}-${grouping}-${color.replace(/[^a-z0-9]/gi, "")}`;
  if (format === "bars") {
    return (
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 4, right: 0, left: 0, bottom: 0 }}>
          <Bar dataKey="y" fill={color} radius={[2, 2, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    );
  }
  return (
    <ResponsiveContainer width="100%" height="100%">
      <AreaChart data={data} margin={{ top: 4, right: 0, left: 0, bottom: 0 }}>
        <defs>
          <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity={0.35} />
            <stop offset="100%" stopColor={color} stopOpacity={0} />
          </linearGradient>
        </defs>
        <Area type="monotone" dataKey="y" stroke={color} strokeWidth={2} fill={`url(#${id})`} dot={false} />
      </AreaChart>
    </ResponsiveContainer>
  );
}

interface KpiCardProps {
  label: string;
  value: string;
  color?: string;
  seed?: number;
  showProgress?: boolean;
  format?: ChartFormat;
  grouping?: Grouping;
}

function KpiCard({ label, value, color = "hsl(var(--metric-blue))", seed = 1, showProgress, format = "area", grouping = "day" }: KpiCardProps) {
  return (
    <div className="rounded-2xl bg-card border border-border/60 p-5 flex flex-col justify-between min-h-[180px] relative overflow-hidden">
      <div className="flex items-center gap-1.5">
        <p className="text-sm text-muted-foreground font-medium">{label}</p>
        <Info size={12} className="text-muted-foreground/60" />
      </div>
      <p className="text-3xl font-bold text-foreground tabular-nums tracking-tight mt-2">{value}</p>
      <div className="h-16 -mx-1 mt-2">
        <Sparkline color={color} seed={seed} format={format} grouping={grouping} />
      </div>
      {showProgress && (
        <div className="absolute bottom-0 left-0 h-1 bg-primary" style={{ width: "55%" }} />
      )}
    </div>
  );
}

function IconButton({ children, onClick, active }: { children: React.ReactNode; onClick?: () => void; active?: boolean }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "w-10 h-10 rounded-xl border border-border/60 flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors",
        active && "bg-secondary text-foreground"
      )}
    >
      {children}
    </button>
  );
}

function ClientLogo({ name, url }: { name: string; url: string | null }) {
  const initial = name.charAt(0).toUpperCase();
  const domain = url ? url.replace(/^https?:\/\//, "").replace(/\/.*$/, "") : null;
  const favicon = domain ? `https://www.google.com/s2/favicons?domain=${domain}&sz=64` : null;
  return (
    <div className="w-9 h-9 rounded-lg bg-secondary border border-border/60 flex items-center justify-center overflow-hidden shrink-0">
      {favicon ? (
        <img
          src={favicon}
          alt={name}
          className="w-full h-full object-cover"
          onError={(e) => {
            (e.currentTarget as HTMLImageElement).style.display = "none";
            (e.currentTarget.parentElement as HTMLElement).innerText = initial;
          }}
        />
      ) : (
        <span className="text-sm font-bold text-foreground">{initial}</span>
      )}
    </div>
  );
}

interface ClientCardProps {
  client: Client;
  onOpen: () => void;
  isEditing: boolean;
  startEdit: () => void;
  cancelEdit: () => void;
  saveEdit: () => void;
  editConversas: number;
  editConversoes: number;
  setEditConversas: (n: number) => void;
  setEditConversoes: (n: number) => void;
}

function ClientCard({
  client: c,
  onOpen,
  isEditing,
  startEdit,
  cancelEdit,
  saveEdit,
  editConversas,
  editConversoes,
  setEditConversas,
  setEditConversoes,
}: ClientCardProps) {
  const fatProgress = Math.min(100, ((c.faturamento || 0) / 5_000_000) * 100);
  const invProgress = Math.min(100, ((c.investido || 0) / 1_000_000) * 100);
  const googleRoas = c.roas || 0;
  const facebookRoas = (c.roi || 0) * 0.85;

  return (
    <div className="rounded-2xl bg-card border border-border/60 p-5 flex flex-col gap-4 hover:border-border transition-colors">
      {/* Header */}
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3 min-w-0 flex-1">
          <ClientLogo name={c.name} url={c.website_url} />
          <div className="min-w-0">
            <h3 className="text-foreground font-bold text-sm uppercase tracking-wide truncate">{c.name}</h3>
            {c.website_url && (
              <a
                href={c.website_url}
                target="_blank"
                rel="noopener noreferrer"
                onClick={(e) => e.stopPropagation()}
                className="text-xs text-metric-blue hover:underline truncate block"
              >
                {c.website_url.replace(/^https?:\/\//, "")}
              </a>
            )}
          </div>
        </div>
        <button
          onClick={onOpen}
          className="px-4 py-1.5 text-xs font-semibold rounded-lg bg-secondary text-foreground hover:bg-secondary/70 transition-colors shrink-0"
        >
          Dashboard
        </button>
      </div>

      {/* Faturamento + Investido com progress */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <p className="text-xs text-muted-foreground flex items-center gap-1">
            Faturamento Aprovado <Info size={10} className="opacity-60" />
          </p>
          <p className="text-base font-bold text-foreground tabular-nums mt-1">{formatCurrency(c.faturamento || 0)}</p>
          <div className="h-1 bg-secondary rounded-full mt-2 overflow-hidden">
            <div className="h-full bg-metric-blue rounded-full" style={{ width: `${fatProgress}%` }} />
          </div>
        </div>
        <div>
          <p className="text-xs text-muted-foreground flex items-center gap-1">
            Total Investido <Info size={10} className="opacity-60" />
          </p>
          <p className="text-base font-bold text-foreground tabular-nums mt-1">{formatCurrency(c.investido || 0)}</p>
          <div className="h-1 bg-secondary rounded-full mt-2 overflow-hidden">
            <div className="h-full bg-metric-blue rounded-full" style={{ width: `${invProgress}%` }} />
          </div>
        </div>
      </div>

      {/* ROI + % Mídia */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <p className="text-xs text-muted-foreground">ROI Global</p>
          <p className="text-base font-bold text-foreground tabular-nums mt-1">{formatNumber(c.roi || 0)}</p>
        </div>
        <div>
          <p className="text-xs text-muted-foreground">% de Mídia</p>
          <p className="text-base font-bold text-metric-amber tabular-nums mt-1">{formatNumber(c.percentual_midia || 0)}%</p>
        </div>
      </div>

      {/* ROAS Google + Facebook */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <p className="text-xs text-muted-foreground">Google ROAS</p>
          <p className="text-base font-bold text-foreground tabular-nums mt-1">{formatNumber(googleRoas)}</p>
        </div>
        <div>
          <p className="text-xs text-muted-foreground">Facebook ROAS</p>
          <p className="text-base font-bold text-foreground tabular-nums mt-1">{formatNumber(facebookRoas)}</p>
        </div>
      </div>

      {/* Conversas / Conversões edit area */}
      {isEditing ? (
        <div className="grid grid-cols-2 gap-3 pt-3 border-t border-border/40">
          <div>
            <p className="text-[10px] text-muted-foreground">Conversas</p>
            <input
              type="number"
              value={editConversas}
              onChange={(e) => setEditConversas(Number(e.target.value))}
              className="w-full mt-1 px-2 py-1 text-sm font-bold bg-secondary border border-border rounded-md text-foreground tabular-nums"
            />
          </div>
          <div>
            <p className="text-[10px] text-muted-foreground">Conversões</p>
            <input
              type="number"
              value={editConversoes}
              onChange={(e) => setEditConversoes(Number(e.target.value))}
              className="w-full mt-1 px-2 py-1 text-sm font-bold bg-secondary border border-border rounded-md text-foreground tabular-nums"
            />
          </div>
          <div className="col-span-2 flex justify-end gap-2">
            <button
              onClick={cancelEdit}
              className="flex items-center gap-1 text-[11px] text-muted-foreground hover:text-foreground px-2 py-1 rounded-md hover:bg-secondary"
            >
              <X size={12} /> Cancelar
            </button>
            <button
              onClick={saveEdit}
              className="flex items-center gap-1 text-[11px] text-metric-green hover:text-foreground px-2 py-1 rounded-md hover:bg-metric-green/15"
            >
              <Check size={12} /> Salvar
            </button>
          </div>
        </div>
      ) : (
        <div className="flex items-center justify-between pt-2 mt-auto">
          <Clock size={14} className="text-muted-foreground/50" />
          <button
            onClick={startEdit}
            className="flex items-center gap-1 text-[11px] text-muted-foreground hover:text-foreground transition-colors"
          >
            <Pencil size={10} /> Editar
          </button>
        </div>
      )}
    </div>
  );
}

type SortKey = "name" | "faturamento" | "investido" | "roi" | "percentual_midia";

const SORT_OPTIONS: { value: SortKey; label: string }[] = [
  { value: "faturamento", label: "Faturamento" },
  { value: "investido", label: "Investido" },
  { value: "roi", label: "ROI" },
  { value: "percentual_midia", label: "% de Mídia" },
  { value: "name", label: "Nome" },
];

function startOfDay(d: Date) {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
}

const DATE_PRESETS = [
  { label: "Hoje", get: () => { const t = startOfDay(new Date()); return { from: t, to: t }; } },
  { label: "Ontem", get: () => { const y = startOfDay(new Date()); y.setDate(y.getDate() - 1); return { from: y, to: y }; } },
  { label: "Últimos 7 dias", get: () => { const to = startOfDay(new Date()); const from = new Date(to); from.setDate(from.getDate() - 6); return { from, to }; } },
  { label: "Últimos 15 dias", get: () => { const to = startOfDay(new Date()); const from = new Date(to); from.setDate(from.getDate() - 14); return { from, to }; } },
  { label: "Este mês", get: () => { const t = startOfDay(new Date()); return { from: new Date(t.getFullYear(), t.getMonth(), 1), to: t }; } },
  { label: "Mês passado", get: () => { const t = new Date(); const from = new Date(t.getFullYear(), t.getMonth() - 1, 1); const to = new Date(t.getFullYear(), t.getMonth(), 0); return { from, to }; } },
  { label: "Este ano", get: () => { const t = startOfDay(new Date()); return { from: new Date(t.getFullYear(), 0, 1), to: t }; } },
  { label: "Ano passado", get: () => { const t = new Date(); return { from: new Date(t.getFullYear() - 1, 0, 1), to: new Date(t.getFullYear() - 1, 11, 31) }; } },
];

export default function MetaAdsPage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const { data: perms } = useUserPermissions();
  const [editingClientId, setEditingClientId] = useState<string | null>(null);
  const [editConversas, setEditConversas] = useState(0);
  const [editConversoes, setEditConversoes] = useState(0);

  // Filter state
  const today = useMemo(() => startOfDay(new Date()), []);
  const initialFrom = useMemo(() => { const d = new Date(today); d.setDate(1); return d; }, [today]);
  const [dateRange, setDateRange] = useState<DateRange | undefined>({ from: initialFrom, to: today });
  const [grouping, setGrouping] = useState<Grouping>("day");
  const [chartFormat, setChartFormat] = useState<ChartFormat>("area");
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [squad, setSquad] = useState<string>("all");
  const [search, setSearch] = useState("");
  const [sortBy, setSortBy] = useState<SortKey>("faturamento");
  const [showGoals, setShowGoals] = useState(true);

  const startEditing = useCallback((c: Client) => {
    setEditingClientId(c.id);
    setEditConversas(c.conversas || 0);
    setEditConversoes(c.conversoes || 0);
  }, []);

  const cancelEditing = useCallback(() => setEditingClientId(null), []);

  const saveEditing = useCallback(
    async (clientId: string) => {
      const { error } = await supabase
        .from("clients")
        .update({ conversas: editConversas, conversoes: editConversoes })
        .eq("id", clientId);
      if (error) {
        toast.error("Erro ao salvar");
        return;
      }
      toast.success("Atualizado com sucesso");
      setEditingClientId(null);
      queryClient.invalidateQueries({ queryKey: ["clients"] });
    },
    [editConversas, editConversoes, queryClient]
  );

  const { data: clients = [], isLoading, refetch } = useQuery({
    queryKey: ["clients", "dashboard", user?.id, perms?.isAdmin],
    enabled: !!user,
    queryFn: async () => {
      let query = supabase
        .from("clients")
        .select(SAFE_CLIENT_COLUMNS)
        .contains("visible_pages", ["dashboard"])
        .order("name");
      if (!perms?.isAdmin && user) {
        query = query.contains("assigned_users", [user.id]);
      }
      const { data, error } = await query;
      if (error) throw error;
      return data as Client[];
    },
  });

  const filteredClients = useMemo(() => {
    let list = [...clients];
    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter((c) => c.name.toLowerCase().includes(q));
    }
    list.sort((a, b) => {
      if (sortBy === "name") return a.name.localeCompare(b.name);
      return ((b[sortBy] as number) || 0) - ((a[sortBy] as number) || 0);
    });
    return list;
  }, [clients, search, sortBy]);

  const activeClients = filteredClients.filter((c) => c.status === "ativo");
  const totalFaturamento = activeClients.reduce((s, c) => s + (c.faturamento || 0), 0);
  const totalInvestido = activeClients.reduce((s, c) => s + (c.investido || 0), 0);
  const avgPercentualMidia = totalFaturamento > 0 ? (totalInvestido / totalFaturamento) * 100 : 0;
  const avgRoi = totalInvestido > 0 ? totalFaturamento / totalInvestido : 0;

  const fmt = (d: Date) => d.toLocaleDateString("pt-BR");
  const dateRangeLabel =
    dateRange?.from && dateRange?.to
      ? `${fmt(dateRange.from)} - ${fmt(dateRange.to)}`
      : "Selecionar período";

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      <DashboardSidebar />

      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top bar */}
        <header className="flex items-center justify-between px-6 py-4 border-b border-border/60 shrink-0">
          <h1 className="text-foreground text-base font-medium">Dashboard</h1>
        </header>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Filters row */}
          <div className="flex items-center justify-between gap-3 flex-wrap">
            <button
              onClick={() => setFiltersOpen((v) => !v)}
              className={cn(
                "flex items-center gap-2 px-4 py-2.5 rounded-xl border text-sm transition-colors",
                filtersOpen
                  ? "bg-primary text-primary-foreground border-primary"
                  : "border-border/60 text-foreground hover:bg-secondary"
              )}
            >
              <SlidersHorizontal size={14} />
              Filtros
            </button>

            <div className="flex items-center gap-2">
              {/* Date range popover */}
              <Popover>
                <PopoverTrigger asChild>
                  <button className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-border/60 text-sm text-foreground hover:bg-secondary transition-colors">
                    <CalendarIcon size={14} className="text-muted-foreground" />
                    <span className="tabular-nums">{dateRangeLabel}</span>
                  </button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="end">
                  <div className="flex">
                    <div className="flex flex-col py-2 border-r border-border min-w-[160px]">
                      {DATE_PRESETS.map((p) => (
                        <button
                          key={p.label}
                          onClick={() => setDateRange(p.get())}
                          className="text-left px-4 py-2 text-sm text-foreground hover:bg-secondary transition-colors"
                        >
                          {p.label}
                        </button>
                      ))}
                    </div>
                    <Calendar
                      mode="range"
                      numberOfMonths={2}
                      selected={dateRange}
                      onSelect={setDateRange}
                      defaultMonth={dateRange?.from}
                    />
                  </div>
                </PopoverContent>
              </Popover>

              <IconButton><ArrowLeftRight size={14} /></IconButton>

              {/* View options popover */}
              <Popover>
                <PopoverTrigger asChild>
                  <button className="w-10 h-10 rounded-xl border border-border/60 flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
                    <SlidersHorizontal size={14} />
                  </button>
                </PopoverTrigger>
                <PopoverContent className="w-64 p-4 space-y-4" align="end">
                  <div>
                    <p className="text-[10px] font-bold uppercase text-muted-foreground tracking-wider mb-2">
                      Agrupamento Temporal
                    </p>
                    <div className="flex bg-secondary rounded-lg p-1">
                      {(["day", "week", "month"] as Grouping[]).map((g) => (
                        <button
                          key={g}
                          onClick={() => setGrouping(g)}
                          className={cn(
                            "flex-1 text-xs font-semibold py-1.5 rounded-md transition-colors",
                            grouping === g
                              ? "bg-primary text-primary-foreground"
                              : "text-muted-foreground hover:text-foreground"
                          )}
                        >
                          {g === "day" ? "Dia" : g === "week" ? "Semana" : "Mês"}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <p className="text-[10px] font-bold uppercase text-muted-foreground tracking-wider mb-2">
                      Formato do Gráfico de Linhas
                    </p>
                    <div className="flex bg-secondary rounded-lg p-1">
                      {(["area", "bars"] as ChartFormat[]).map((f) => (
                        <button
                          key={f}
                          onClick={() => setChartFormat(f)}
                          className={cn(
                            "flex-1 text-xs font-semibold py-1.5 rounded-md transition-colors",
                            chartFormat === f
                              ? "bg-primary text-primary-foreground"
                              : "text-muted-foreground hover:text-foreground"
                          )}
                        >
                          {f === "area" ? "Área" : "Colunas"}
                        </button>
                      ))}
                    </div>
                  </div>
                </PopoverContent>
              </Popover>

              <IconButton><LayoutGrid size={14} /></IconButton>
              <IconButton onClick={() => refetch()}>
                <RefreshCw size={14} className={isLoading ? "animate-spin" : ""} />
              </IconButton>
            </div>
          </div>

          {/* Expanded filters */}
          {filtersOpen && (
            <div className="flex items-center gap-3 flex-wrap">
              <div className="relative">
                <select
                  value={squad}
                  onChange={(e) => setSquad(e.target.value)}
                  className="appearance-none pl-4 pr-10 py-2.5 rounded-xl border border-border/60 bg-card text-sm text-foreground hover:bg-secondary transition-colors cursor-pointer"
                >
                  <option value="all">Todos os squads</option>
                  <option value="squad1">Squad 1</option>
                  <option value="squad2">Squad 2</option>
                </select>
                <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
              </div>

              <div className="relative flex-1 max-w-md min-w-[200px]">
                <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <input
                  type="text"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Digite o nome do cliente..."
                  className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-border/60 bg-card text-sm text-foreground placeholder:text-muted-foreground"
                />
              </div>

              <div className="relative">
                <ArrowUpDown size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as SortKey)}
                  className="appearance-none pl-9 pr-10 py-2.5 rounded-xl border border-border/60 bg-card text-sm text-foreground hover:bg-secondary transition-colors cursor-pointer"
                >
                  {SORT_OPTIONS.map((o) => (
                    <option key={o.value} value={o.value}>{o.label}</option>
                  ))}
                </select>
                <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
              </div>

              <label className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-border/60 bg-card text-sm text-foreground cursor-pointer hover:bg-secondary transition-colors">
                <Checkbox
                  checked={showGoals}
                  onCheckedChange={(v) => setShowGoals(Boolean(v))}
                />
                Metas
              </label>
            </div>
          )}

          {/* KPI Row */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            <KpiCard
              label="Faturamento Aprovado"
              value={formatCurrency(totalFaturamento)}
              color="hsl(var(--metric-blue))"
              seed={1}
              showProgress={showGoals}
              format={chartFormat}
              grouping={grouping}
            />
            <KpiCard
              label="Total Investido"
              value={formatCurrency(totalInvestido)}
              color="hsl(var(--metric-blue))"
              seed={2}
              format={chartFormat}
              grouping={grouping}
            />
            <KpiCard
              label="% de Mídia"
              value={`${formatNumber(avgPercentualMidia)}%`}
              color="hsl(var(--metric-blue))"
              seed={3}
              format={chartFormat}
              grouping={grouping}
            />
            <KpiCard
              label="ROI Global"
              value={formatNumber(avgRoi)}
              color="hsl(var(--metric-blue))"
              seed={4}
              format={chartFormat}
              grouping={grouping}
            />
            <KpiCard
              label="Clientes"
              value={String(filteredClients.length)}
              color="hsl(var(--metric-blue))"
              seed={5}
              format={chartFormat}
              grouping={grouping}
            />
          </div>

          {/* Client cards grid */}
          {filteredClients.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-12">Nenhum cliente encontrado</p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
              {filteredClients.map((c) => (
                <ClientCard
                  key={c.id}
                  client={c}
                  onOpen={() => navigate(`/clients/${c.id}`)}
                  isEditing={editingClientId === c.id}
                  startEdit={() => startEditing(c)}
                  cancelEdit={cancelEditing}
                  saveEdit={() => saveEditing(c.id)}
                  editConversas={editConversas}
                  editConversoes={editConversoes}
                  setEditConversas={setEditConversas}
                  setEditConversoes={setEditConversoes}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
