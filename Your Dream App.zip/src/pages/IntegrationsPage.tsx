import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useUserPermissions } from "@/hooks/useUserPermissions";
import { useNavigate } from "react-router-dom";
import { DashboardSidebar } from "@/components/DashboardSidebar";
import { toast } from "sonner";
import { Loader2, CheckCircle2, XCircle, RefreshCw, Unlink, ExternalLink, Building2, Plus, Trash2, Save } from "lucide-react";
import { cn } from "@/lib/utils";

type WsProvider = "meta" | "google" | "google_analytics";

interface Account { account_id: string; name: string }
interface Business { id: string; name: string }
interface Integration {
  provider: string;
  status: string;
  business_id: string | null;
  business_name: string | null;
  available_accounts: Account[];
  available_businesses: Business[];
  last_synced_at: string | null;
  last_error: string | null;
}

interface MagazordStore { id: string; label: string; base_url: string; username: string }

const PROVIDERS: Array<{ id: WsProvider; label: string; color: string; initial: string; description: string }> = [
  { id: "meta",             label: "Meta Ads",         color: "#1877F2", initial: "f", description: "Conecte a Business Manager. Cada cliente escolhe uma ad account dela." },
  { id: "google",           label: "Google Ads",       color: "#EA4335", initial: "G", description: "Conecte sua conta Google. Cada cliente vincula um Customer ID." },
  { id: "google_analytics", label: "Google Analytics", color: "#F9AB00", initial: "A", description: "Conecte o Google Analytics. Cada cliente escolhe uma propriedade GA4." },
];

const FN_BASE = "https://xfmudoopaspsbdrceqdl.supabase.co/functions/v1";

export default function IntegrationsPage() {
  const { data: perms, isLoading: permsLoading } = useUserPermissions();
  const navigate = useNavigate();
  const [integrations, setIntegrations] = useState<Record<WsProvider, Integration | null>>({ meta: null, google: null, google_analytics: null });
  const [stores, setStores] = useState<MagazordStore[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);
  const [showStoreForm, setShowStoreForm] = useState(false);
  const [storeForm, setStoreForm] = useState({ label: "", base_url: "", username: "", password: "" });

  useEffect(() => {
    if (!permsLoading && perms && !perms.isAdmin) navigate("/");
  }, [perms, permsLoading, navigate]);

  const fetchAll = useCallback(async () => {
    setLoading(true);
    const { data: sess } = await supabase.auth.getSession();
    const token = sess.session?.access_token;
    if (!token) { setLoading(false); return; }
    try {
      const results = await Promise.all([
        ...PROVIDERS.map(async (p) => {
          const r = await fetch(`${FN_BASE}/workspace-list-accounts?provider=${p.id}`, { headers: { Authorization: `Bearer ${token}` } });
          const j = await r.json();
          return [p.id, j.integration ?? null] as const;
        }),
        (async () => {
          const r = await fetch(`${FN_BASE}/workspace-magazord-stores`, { headers: { Authorization: `Bearer ${token}` } });
          const j = await r.json();
          return ["__stores__", j.stores ?? []] as const;
        })(),
      ]);
      const next: Record<WsProvider, Integration | null> = { meta: null, google: null, google_analytics: null };
      for (const [k, v] of results) {
        if (k === "__stores__") setStores(v as MagazordStore[]);
        else next[k as WsProvider] = v as Integration | null;
      }
      setIntegrations(next);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { if (perms?.isAdmin) fetchAll(); }, [perms, fetchAll]);

  useEffect(() => {
    const handler = (ev: MessageEvent) => {
      const data = ev.data;
      if (!data || data.source !== "lovable-oauth" || data.scope !== "workspace") return;
      setBusy(null);
      if (!data.ok) toast.error(data.message || "Falha na conexão");
      else if (data.needsBusinessSelection) toast.message("Selecione qual Business Manager usar.");
      else toast.success(`Conectado (${data.accountsCount ?? 0} contas/propriedades disponíveis)`);
      fetchAll();
    };
    window.addEventListener("message", handler);
    return () => window.removeEventListener("message", handler);
  }, [fetchAll]);

  const startOAuth = async (provider: WsProvider) => {
    const { data: sess } = await supabase.auth.getSession();
    const token = sess.session?.access_token;
    if (!token) { toast.error("Sessão expirada"); return; }
    setBusy(`oauth-${provider}`);
    const w = window.open(
      `${FN_BASE}/workspace-oauth-start?provider=${provider}&token=${encodeURIComponent(token)}`,
      "lovable-ws-oauth", "width=600,height=750,popup=yes",
    );
    if (!w) { setBusy(null); toast.error("Permita pop-ups para conectar."); return; }
    const t = setInterval(() => { if (w.closed) { clearInterval(t); setBusy((b) => b === `oauth-${provider}` ? null : b); } }, 1000);
  };

  const refresh = async (provider: WsProvider) => {
    setBusy(`refresh-${provider}`);
    const { data, error } = await supabase.functions.invoke("workspace-set-business", { body: { provider } });
    setBusy(null);
    if (error || (data as { error?: string })?.error) {
      toast.error((data as { error?: string })?.error || error?.message || "Falha"); return;
    }
    toast.success(`${(data as { accounts?: unknown[] }).accounts?.length ?? 0} contas atualizadas`);
    fetchAll();
  };

  const setMetaBusiness = async (businessId: string) => {
    setBusy(`biz-${businessId}`);
    const { data, error } = await supabase.functions.invoke("workspace-set-business", { body: { provider: "meta", business_id: businessId } });
    setBusy(null);
    if (error || (data as { error?: string })?.error) { toast.error((data as { error?: string })?.error || error?.message || "Falha"); return; }
    toast.success("Business Manager selecionada");
    fetchAll();
  };

  const disconnect = async (provider: WsProvider) => {
    if (!confirm(`Desconectar ${PROVIDERS.find(p => p.id === provider)?.label}?`)) return;
    setBusy(`dc-${provider}`);
    await supabase.functions.invoke("workspace-disconnect", { body: { provider } });
    setBusy(null);
    toast.success("Desconectado");
    fetchAll();
  };

  const addStore = async () => {
    if (!storeForm.label.trim() || !storeForm.base_url.trim() || !storeForm.username.trim() || !storeForm.password.trim()) {
      toast.error("Preencha todos os campos"); return;
    }
    setBusy("store-add");
    const { data: sess } = await supabase.auth.getSession();
    const token = sess.session?.access_token;
    const r = await fetch(`${FN_BASE}/workspace-magazord-stores`, {
      method: "POST",
      headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
      body: JSON.stringify(storeForm),
    });
    const j = await r.json();
    setBusy(null);
    if (!r.ok || j.error) { toast.error(j.error || "Falha"); return; }
    toast.success("Loja adicionada");
    setStoreForm({ label: "", base_url: "", username: "", password: "" });
    setShowStoreForm(false);
    fetchAll();
  };

  const deleteStore = async (id: string) => {
    if (!confirm("Remover esta loja?")) return;
    setBusy(`store-${id}`);
    const { data: sess } = await supabase.auth.getSession();
    const token = sess.session?.access_token;
    await fetch(`${FN_BASE}/workspace-magazord-stores?id=${id}`, { method: "DELETE", headers: { Authorization: `Bearer ${token}` } });
    setBusy(null);
    toast.success("Removido");
    fetchAll();
  };

  return (
    <div className="flex min-h-screen bg-background">
      <DashboardSidebar />
      <main className="flex-1 p-8 max-w-5xl">
        <header className="mb-6">
          <h1 className="text-2xl font-semibold text-foreground">Integrações do Workspace</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Conecte uma vez cada plataforma. Em cada cliente, você só seleciona qual conta/propriedade usar.
          </p>
        </header>

        {loading || permsLoading ? (
          <div className="flex justify-center py-16"><Loader2 className="animate-spin text-muted-foreground" /></div>
        ) : (
          <div className="space-y-4">
            {PROVIDERS.map((p) => {
              const meta = integrations[p.id];
              const connected = meta?.status === "connected";
              const pendingBiz = meta?.status === "pending_business_selection";
              return (
                <div key={p.id} className="rounded-xl border border-border bg-secondary/30 p-5 space-y-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <span className="w-10 h-10 rounded-lg text-white text-lg font-bold flex items-center justify-center" style={{ backgroundColor: p.color }}>{p.initial}</span>
                      <div>
                        <div className="text-base font-semibold text-foreground">{p.label}</div>
                        <div className="text-xs text-muted-foreground">{p.description}</div>
                      </div>
                    </div>
                    <span className={cn(
                      "text-[11px] px-2.5 py-1 rounded-full border flex items-center gap-1",
                      connected ? "bg-primary/15 text-primary border-primary/30"
                      : pendingBiz ? "bg-[hsl(var(--metric-amber))]/15 text-[hsl(var(--metric-amber))] border-[hsl(var(--metric-amber))]/30"
                      : "bg-destructive/10 text-destructive border-destructive/30",
                    )}>
                      {connected ? <CheckCircle2 size={12} /> : <XCircle size={12} />}
                      {connected ? "Conectado" : pendingBiz ? "Selecione a BM" : "Não conectado"}
                    </span>
                  </div>

                  {meta?.last_error && (
                    <div className="text-xs text-destructive bg-destructive/10 border border-destructive/30 rounded-lg px-3 py-2">{meta.last_error}</div>
                  )}

                  {connected && p.id === "meta" && meta?.business_name && (
                    <div className="rounded-lg bg-background/40 border border-border/60 px-3 py-2 text-xs">
                      <div className="text-muted-foreground flex items-center gap-1.5"><Building2 size={12}/> Business Manager</div>
                      <div className="text-foreground mt-0.5">{meta.business_name}<span className="text-muted-foreground font-mono"> ({meta.business_id})</span></div>
                      <div className="text-muted-foreground mt-1">{meta.available_accounts.length} ad accounts disponíveis</div>
                    </div>
                  )}

                  {connected && p.id !== "meta" && (
                    <div className="rounded-lg bg-background/40 border border-border/60 px-3 py-2 text-xs">
                      <div className="text-muted-foreground">{meta?.available_accounts.length ?? 0} {p.id === "google_analytics" ? "propriedades" : "contas"} disponíveis</div>
                    </div>
                  )}

                  {pendingBiz && meta?.available_businesses && meta.available_businesses.length > 0 && (
                    <div className="space-y-2">
                      <div className="text-xs text-muted-foreground">Sua conta tem várias Business Managers. Escolha uma:</div>
                      {meta.available_businesses.map((b) => (
                        <button key={b.id} onClick={() => setMetaBusiness(b.id)} disabled={busy === `biz-${b.id}`}
                          className="w-full text-left px-3 py-2.5 rounded-lg border border-border bg-background/40 hover:bg-secondary/50 hover:border-primary/50 transition flex items-center justify-between disabled:opacity-50">
                          <div>
                            <div className="text-sm text-foreground">{b.name}</div>
                            <div className="text-[11px] font-mono text-muted-foreground">{b.id}</div>
                          </div>
                          {busy === `biz-${b.id}` && <Loader2 size={14} className="animate-spin text-primary" />}
                        </button>
                      ))}
                    </div>
                  )}

                  {connected && meta && meta.available_accounts.length > 0 && (
                    <details className="rounded-lg border border-border/60 bg-background/40">
                      <summary className="cursor-pointer px-3 py-2 text-xs text-muted-foreground hover:text-foreground">
                        Ver {meta.available_accounts.length} {p.id === "google_analytics" ? "propriedades" : "contas"}
                      </summary>
                      <ul className="px-3 pb-3 space-y-1 max-h-64 overflow-y-auto">
                        {meta.available_accounts.map((a) => (
                          <li key={a.account_id} className="text-xs flex justify-between gap-2 py-1 border-b border-border/30 last:border-0">
                            <span className="text-foreground truncate">{a.name}</span>
                            <span className="font-mono text-muted-foreground shrink-0">{a.account_id}</span>
                          </li>
                        ))}
                      </ul>
                    </details>
                  )}

                  <div className="flex gap-2 pt-1">
                    {!connected && !pendingBiz && (
                      <button onClick={() => startOAuth(p.id)} disabled={busy === `oauth-${p.id}`}
                        className="flex-1 py-2.5 rounded-lg bg-accent text-accent-foreground text-sm font-medium hover:bg-accent/90 transition flex items-center justify-center gap-2 disabled:opacity-50">
                        {busy === `oauth-${p.id}` ? <Loader2 size={14} className="animate-spin"/> : <ExternalLink size={14}/>}
                        Conectar {p.label}
                      </button>
                    )}
                    {connected && (
                      <>
                        <button onClick={() => refresh(p.id)} disabled={busy === `refresh-${p.id}`}
                          className="flex-1 py-2.5 rounded-lg bg-secondary text-foreground text-sm font-medium hover:bg-secondary/80 border border-border transition flex items-center justify-center gap-2 disabled:opacity-50">
                          {busy === `refresh-${p.id}` ? <Loader2 size={14} className="animate-spin"/> : <RefreshCw size={14}/>}
                          Atualizar
                        </button>
                        <button onClick={() => startOAuth(p.id)} disabled={busy === `oauth-${p.id}`}
                          className="flex-1 py-2.5 rounded-lg bg-secondary text-foreground text-sm font-medium hover:bg-secondary/80 border border-border transition flex items-center justify-center gap-2 disabled:opacity-50">
                          {busy === `oauth-${p.id}` ? <Loader2 size={14} className="animate-spin"/> : <ExternalLink size={14}/>}
                          Reconectar
                        </button>
                        <button onClick={() => disconnect(p.id)} disabled={busy === `dc-${p.id}`}
                          className="py-2.5 px-4 rounded-lg bg-destructive/15 text-destructive text-sm font-medium hover:bg-destructive/25 transition flex items-center justify-center gap-2 disabled:opacity-50">
                          <Unlink size={14}/> Desconectar
                        </button>
                      </>
                    )}
                  </div>
                </div>
              );
            })}

            {/* ===== MAGAZORD ===== */}
            <div className="rounded-xl border border-border bg-secondary/30 p-5 space-y-4">
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <span className="w-10 h-10 rounded-lg text-white text-lg font-bold flex items-center justify-center" style={{ backgroundColor: "#7C3AED" }}>M</span>
                  <div>
                    <div className="text-base font-semibold text-foreground">Magazord</div>
                    <div className="text-xs text-muted-foreground">Cadastre cada loja Magazord uma vez. Em cada cliente, vincule a loja correspondente.</div>
                  </div>
                </div>
                <button onClick={() => setShowStoreForm((s) => !s)}
                  className="text-xs px-3 py-1.5 rounded-lg bg-accent/15 text-accent hover:bg-accent/25 transition flex items-center gap-1.5">
                  <Plus size={12}/> Nova loja
                </button>
              </div>

              {showStoreForm && (
                <div className="rounded-lg bg-background/40 border border-border/60 p-3 space-y-2">
                  <input type="text" value={storeForm.label} onChange={(e) => setStoreForm((s) => ({ ...s, label: e.target.value }))}
                    placeholder="Nome (ex: Loja Made Arte)" className="w-full px-3 py-2 rounded-lg bg-background/60 border border-border text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary" />
                  <input type="text" value={storeForm.base_url} onChange={(e) => setStoreForm((s) => ({ ...s, base_url: e.target.value }))}
                    placeholder="https://loja.painel.magazord.com.br" className="w-full px-3 py-2 rounded-lg bg-background/60 border border-border text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary font-mono" />
                  <div className="grid grid-cols-2 gap-2">
                    <input type="text" autoComplete="off" value={storeForm.username} onChange={(e) => setStoreForm((s) => ({ ...s, username: e.target.value }))}
                      placeholder="Usuário API" className="px-3 py-2 rounded-lg bg-background/60 border border-border text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary font-mono" />
                    <input type="password" autoComplete="new-password" value={storeForm.password} onChange={(e) => setStoreForm((s) => ({ ...s, password: e.target.value }))}
                      placeholder="Senha API" className="px-3 py-2 rounded-lg bg-background/60 border border-border text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary font-mono" />
                  </div>
                  <button onClick={addStore} disabled={busy === "store-add"}
                    className="w-full py-2 rounded-lg bg-accent text-accent-foreground text-xs font-medium hover:bg-accent/90 transition flex items-center justify-center gap-2 disabled:opacity-50">
                    {busy === "store-add" ? <Loader2 size={12} className="animate-spin"/> : <Save size={12}/>} Salvar e validar
                  </button>
                </div>
              )}

              {stores.length === 0 ? (
                <div className="text-xs text-muted-foreground text-center py-3">Nenhuma loja cadastrada.</div>
              ) : (
                <ul className="space-y-1.5">
                  {stores.map((s) => (
                    <li key={s.id} className="flex items-center justify-between rounded-lg bg-background/40 border border-border/60 px-3 py-2">
                      <div className="min-w-0">
                        <div className="text-sm text-foreground truncate">{s.label}</div>
                        <div className="text-[11px] font-mono text-muted-foreground truncate">{s.base_url}</div>
                      </div>
                      <button onClick={() => deleteStore(s.id)} disabled={busy === `store-${s.id}`}
                        className="ml-2 p-1.5 rounded-md hover:bg-destructive/15 text-muted-foreground hover:text-destructive transition disabled:opacity-50">
                        <Trash2 size={14}/>
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
