import { useEffect } from "react";

const EDGE_CALLBACK_URL = "https://xfmudoopaspsbdrceqdl.supabase.co/functions/v1/oauth-callback";

export default function OAuthMetaCallbackPage() {
  useEffect(() => {
    window.location.replace(`${EDGE_CALLBACK_URL}${window.location.search}`);
  }, []);

  return (
    <main className="min-h-screen bg-background text-foreground flex items-center justify-center px-6">
      <section className="max-w-sm text-center space-y-3">
        <h1 className="text-xl font-semibold">Finalizando conexão</h1>
        <p className="text-sm text-muted-foreground">
          Aguarde enquanto concluímos a autorização do Meta Ads.
        </p>
      </section>
    </main>
  );
}