import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { DashboardSidebar } from "@/components/DashboardSidebar";
import { UserPlus, Pencil, Trash2, Shield, User as UserIcon, Eye, EyeOff } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { AppSettingsTab } from "@/components/admin/AppSettingsTab";
import { supabase } from "@/integrations/supabase/client";

interface ManagedUser {
  id: string;
  email: string;
  displayName: string;
  avatarUrl: string | null;
  roles: string[];
  pages: string[];
  clientIds: string[];
  createdAt: string;
}

interface ClientOption {
  id: string;
  name: string;
  assigned_users: string[];
}

const AVAILABLE_PAGES = [
  { slug: "dashboard", label: "Painel do Dia", path: "/" },
  { slug: "meu-espaco", label: "Meu Espaço", path: "/meu-espaco" },
  { slug: "kanban", label: "Kanban", path: "/kanban" },
  { slug: "calendar", label: "Calendário", path: "/calendar" },
  { slug: "clients", label: "Clientes", path: "/clients" },
  { slug: "analysis-dashboard", label: "Dashboard", path: "/dashboard" },
  { slug: "meta", label: "Meta Ads", path: "/meta" },
  { slug: "optimization", label: "Otimização", path: "/optimization" },
  { slug: "criativos", label: "Criativos", path: "/criativos" },
  { slug: "links", label: "Links", path: "/links" },
  { slug: "financial", label: "Financeiro", path: "/financeiro" },
  { slug: "pricing", label: "Precificação", path: "/precificacao" },
  { slug: "prospeccao", label: "Prospecção", path: "/prospeccao" },
];

export { AVAILABLE_PAGES };

const AdminUsersPage = () => {
  const { session } = useAuth();
  const { toast } = useToast();
  const [users, setUsers] = useState<ManagedUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editUser, setEditUser] = useState<ManagedUser | null>(null);
  const [showPassword, setShowPassword] = useState(false);

  const [formEmail, setFormEmail] = useState("");
  const [formPassword, setFormPassword] = useState("");
  const [formDisplayName, setFormDisplayName] = useState("");
  const [formRole, setFormRole] = useState<"admin" | "user">("user");
  const [formPages, setFormPages] = useState<string[]>([]);
  const [formClients, setFormClients] = useState<string[]>([]);
  const [clients, setClients] = useState<ClientOption[]>([]);
  const [submitting, setSubmitting] = useState(false);

  const fetchClients = async () => {
    const { data } = await supabase
      .from("clients")
      .select("id, name, assigned_users")
      .order("name");
    setClients((data ?? []) as ClientOption[]);
  };

  const fetchUsers = async () => {
    if (!session) return;
    try {
      const projectId = import.meta.env.VITE_SUPABASE_PROJECT_ID;
      const res = await fetch(
        `https://${projectId}.supabase.co/functions/v1/admin-users?action=list`,
        {
          headers: {
            Authorization: `Bearer ${session.access_token}`,
            apikey: import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
          },
        }
      );
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error);
      }
      const data = await res.json();
      setUsers(data);
    } catch (err: any) {
      toast({ title: "Erro", description: err.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
    fetchClients();
  }, [session]);

  const openCreate = () => {
    setEditUser(null);
    setFormEmail("");
    setFormPassword("");
    setFormDisplayName("");
    setFormRole("user");
    setFormPages([]);
    setFormClients([]);
    setDialogOpen(true);
  };

  const openEdit = (u: ManagedUser) => {
    setEditUser(u);
    setFormEmail(u.email);
    setFormPassword("");
    setFormDisplayName(u.displayName);
    setFormRole(u.roles.includes("admin") ? "admin" : "user");
    setFormPages(u.pages || []);
    setFormClients(
      clients.filter((c) => (c.assigned_users ?? []).includes(u.id)).map((c) => c.id),
    );
    setDialogOpen(true);
  };

  const toggleClient = (id: string) => {
    setFormClients((prev) =>
      prev.includes(id) ? prev.filter((s) => s !== id) : [...prev, id],
    );
  };
  const allClientsSelected = clients.length > 0 && clients.every((c) => formClients.includes(c.id));
  const toggleAllClients = () => {
    setFormClients(allClientsSelected ? [] : clients.map((c) => c.id));
  };

  const togglePage = (slug: string) => {
    setFormPages((prev) =>
      prev.includes(slug) ? prev.filter((s) => s !== slug) : [...prev, slug]
    );
  };

  const allPageSlugs = AVAILABLE_PAGES.map((page) => page.slug);
  const allPagesSelected = allPageSlugs.every((slug) => formPages.includes(slug));

  const toggleAllPages = () => {
    setFormPages(allPagesSelected ? [] : allPageSlugs);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!session) return;
    setSubmitting(true);

    try {
      const projectId = import.meta.env.VITE_SUPABASE_PROJECT_ID;
      const baseUrl = `https://${projectId}.supabase.co/functions/v1/admin-users`;
      const headers = {
        Authorization: `Bearer ${session.access_token}`,
        apikey: import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
        "Content-Type": "application/json",
      };

      if (editUser) {
        const body: any = {
          targetUserId: editUser.id,
          displayName: formDisplayName,
          pages: formPages,
          role: formRole,
          clientIds: formClients,
        };
        if (formEmail !== editUser.email) body.email = formEmail;
        if (formPassword) body.password = formPassword;

        const res = await fetch(`${baseUrl}?action=update`, {
          method: "PUT",
          headers,
          body: JSON.stringify(body),
        });
        if (!res.ok) {
          const err = await res.json();
          throw new Error(err.error);
        }
        toast({ title: "Usuário atualizado!" });
      } else {
        const res = await fetch(`${baseUrl}?action=create`, {
          method: "POST",
          headers,
          body: JSON.stringify({
            email: formEmail,
            password: formPassword,
            displayName: formDisplayName,
            role: formRole,
            pages: formPages,
            clientIds: formClients,
          }),
        });
        if (!res.ok) {
          const err = await res.json();
          throw new Error(err.error);
        }
        toast({ title: "Usuário criado!" });
      }

      setDialogOpen(false);
      fetchUsers();
      fetchClients();
    } catch (err: any) {
      toast({ title: "Erro", description: err.message, variant: "destructive" });
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (userId: string) => {
    if (!session || !confirm("Tem certeza que deseja excluir este usuário?")) return;

    try {
      const projectId = import.meta.env.VITE_SUPABASE_PROJECT_ID;
      const res = await fetch(
        `https://${projectId}.supabase.co/functions/v1/admin-users?action=delete`,
        {
          method: "DELETE",
          headers: {
            Authorization: `Bearer ${session.access_token}`,
            apikey: import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ targetUserId: userId }),
        }
      );
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error);
      }
      toast({ title: "Usuário excluído!" });
      fetchUsers();
    } catch (err: any) {
      toast({ title: "Erro", description: err.message, variant: "destructive" });
    }
  };

  return (
    <div className="flex min-h-screen bg-background">
      <DashboardSidebar />
      <main className="flex-1 p-6 overflow-auto">
        <div className="max-w-4xl mx-auto space-y-6">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Painel Admin</h1>
            <p className="text-sm text-muted-foreground">Gerencie usuários e configurações globais do sistema</p>
          </div>

          <Tabs defaultValue="users" className="space-y-6">
            <TabsList>
              <TabsTrigger value="users">Usuários</TabsTrigger>
              <TabsTrigger value="settings">Configurações do App</TabsTrigger>
            </TabsList>

            <TabsContent value="users" className="space-y-4">
              <div className="flex items-center justify-between">
                <p className="text-sm text-muted-foreground">Adicione, edite ou remova usuários do sistema</p>
                <Button onClick={openCreate} className="gap-2">
                  <UserPlus className="h-4 w-4" /> Novo Usuário
                </Button>
              </div>

              {loading ? (
                <div className="flex justify-center py-12">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
                </div>
              ) : (
                <div className="grid gap-3">
                  {users.map((u) => (
                    <Card key={u.id} className="border-border bg-card">
                      <CardContent className="flex items-center gap-4 py-4">
                        <div className="w-10 h-10 rounded-full bg-accent/20 flex items-center justify-center shrink-0 overflow-hidden">
                          {u.avatarUrl ? (
                            <img src={u.avatarUrl} alt="" className="w-full h-full object-cover" />
                          ) : (
                            <UserIcon className="h-5 w-5 text-accent" />
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-foreground truncate">{u.displayName}</p>
                          <p className="text-xs text-muted-foreground truncate">{u.email}</p>
                          {u.pages && u.pages.length > 0 && (
                            <div className="flex flex-wrap gap-1 mt-1">
                              {u.pages.map((slug) => {
                                const page = AVAILABLE_PAGES.find((p) => p.slug === slug);
                                return (
                                  <Badge key={slug} variant="outline" className="text-[10px] px-1.5 py-0">
                                    {page?.label || slug}
                                  </Badge>
                                );
                              })}
                            </div>
                          )}
                        </div>
                        <div className="flex items-center gap-2">
                          {u.roles.includes("admin") && (
                            <Badge variant="secondary" className="gap-1 text-xs">
                              <Shield className="h-3 w-3" /> Admin
                            </Badge>
                          )}
                          <Button variant="ghost" size="icon" onClick={() => openEdit(u)}>
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" onClick={() => handleDelete(u.id)} className="text-destructive hover:text-destructive">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                  {users.length === 0 && (
                    <p className="text-center text-muted-foreground py-8">Nenhum usuário cadastrado.</p>
                  )}
                </div>
              )}
            </TabsContent>

            <TabsContent value="settings">
              <AppSettingsTab />
            </TabsContent>
          </Tabs>
        </div>

        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogContent className="bg-card border-border max-h-[calc(100vh-2rem)] overflow-y-auto sm:max-w-lg">
            <DialogHeader>
              <DialogTitle>{editUser ? "Editar Usuário" : "Novo Usuário"}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label>Nome</Label>
                <Input
                  value={formDisplayName}
                  onChange={(e) => setFormDisplayName(e.target.value)}
                  placeholder="Nome do usuário"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label>E-mail</Label>
                <Input
                  type="email"
                  value={formEmail}
                  onChange={(e) => setFormEmail(e.target.value)}
                  placeholder="email@exemplo.com"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label>{editUser ? "Nova senha (deixe vazio para manter)" : "Senha"}</Label>
                <div className="relative">
                  <Input
                    type={showPassword ? "text" : "password"}
                    value={formPassword}
                    onChange={(e) => setFormPassword(e.target.value)}
                    placeholder="••••••••"
                    required={!editUser}
                    minLength={6}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>
              <div className="space-y-2">
                <Label>Função</Label>
                <div className="flex gap-2">
                  <Button
                    type="button"
                    variant={formRole === "user" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setFormRole("user")}
                  >
                    Usuário
                  </Button>
                  <Button
                    type="button"
                    variant={formRole === "admin" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setFormRole("admin")}
                  >
                    Admin
                  </Button>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Páginas com acesso</Label>
                <p className="text-xs text-muted-foreground">Selecione quais páginas este usuário poderá acessar</p>
                <div className="grid gap-2 mt-1">
                  <label className="flex items-center gap-2 px-3 py-2 rounded-md border border-primary/40 bg-primary/10 hover:bg-primary/15 cursor-pointer transition-colors">
                    <Checkbox checked={allPagesSelected} onCheckedChange={toggleAllPages} />
                    <span className="text-sm font-medium text-foreground">Todos os acessos</span>
                    <span className="text-xs text-muted-foreground ml-auto">{AVAILABLE_PAGES.length} páginas</span>
                  </label>
                  {AVAILABLE_PAGES.map((page) => (
                    <label
                      key={page.slug}
                      className="flex items-center gap-2 px-3 py-2 rounded-md border border-border hover:bg-accent/10 cursor-pointer transition-colors"
                    >
                      <Checkbox
                        checked={formPages.includes(page.slug)}
                        onCheckedChange={() => togglePage(page.slug)}
                      />
                      <span className="text-sm text-foreground">{page.label}</span>
                      <span className="text-xs text-muted-foreground ml-auto">{page.path}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <Label>Clientes com acesso</Label>
                {formRole === "admin" ? (
                  <p className="text-xs text-muted-foreground border border-border rounded-md p-3">
                    Admins têm acesso a todos os clientes automaticamente.
                  </p>
                ) : (
                  <>
                    <p className="text-xs text-muted-foreground">
                      Selecione quais clientes este usuário poderá visualizar e editar
                    </p>
                    <div className="grid gap-2 mt-1">
                      {clients.length > 0 && (
                        <label className="flex items-center gap-2 px-3 py-2 rounded-md border border-primary/40 bg-primary/10 hover:bg-primary/15 cursor-pointer transition-colors">
                          <Checkbox checked={allClientsSelected} onCheckedChange={toggleAllClients} />
                          <span className="text-sm font-medium text-foreground">Todos os clientes</span>
                          <span className="text-xs text-muted-foreground ml-auto">{clients.length}</span>
                        </label>
                      )}
                      {clients.map((c) => (
                        <label
                          key={c.id}
                          className="flex items-center gap-2 px-3 py-2 rounded-md border border-border hover:bg-accent/10 cursor-pointer transition-colors"
                        >
                          <Checkbox
                            checked={formClients.includes(c.id)}
                            onCheckedChange={() => toggleClient(c.id)}
                          />
                          <span className="text-sm text-foreground">{c.name}</span>
                        </label>
                      ))}
                      {clients.length === 0 && (
                        <p className="text-xs text-muted-foreground">Nenhum cliente cadastrado.</p>
                      )}
                    </div>
                  </>
                )}
              </div>

              <Button type="submit" className="w-full" disabled={submitting}>
                {submitting ? (
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-primary-foreground" />
                ) : editUser ? "Salvar" : "Criar Usuário"}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </main>
    </div>
  );
};

export default AdminUsersPage;
