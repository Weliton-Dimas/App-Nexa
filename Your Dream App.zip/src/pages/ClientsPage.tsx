import { useEffect, useMemo, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { DashboardSidebar } from "@/components/DashboardSidebar";
import { supabase } from "@/integrations/supabase/client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Users, Plus, Pencil, Trash2, Search, ExternalLink, AlertCircle, CheckCircle2, XCircle } from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { ClientFormModal } from "@/components/ClientFormModal";
import {
  defaultClientForm,
  ratingColors,
  ratingLabels,
  statusLabels,
  SAFE_CLIENT_COLUMNS,
  type ClientFormState,
} from "@/lib/clientConstants";

const OPT_INTERVAL_DAYS = 7;

interface Client extends ClientFormState {
  id: string;
  last_optimized_at: string | null;
  created_at: string;
  updated_at: string;
}

export default function ClientsPage() {
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const [canFinancial, setCanFinancial] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState<ClientFormState>(defaultClientForm);
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    if (!user) return;
    (async () => {
      const { data } = await supabase.rpc("can_access_financial", { _user_id: user.id });
      setCanFinancial(!!data);
    })();
  }, [user]);

  const { data: clients = [], isLoading } = useQuery({
    queryKey: ["clients"],
    queryFn: async () => {
      const { data, error } = await supabase.from("clients").select(SAFE_CLIENT_COLUMNS).order("name");
      if (error) throw error;
      return data as unknown as Client[];
    },
  });

  const upsertMutation = useMutation({
    mutationFn: async (values: ClientFormState & { id?: string }) => {
      const payload = {
        ...values,
        website_url: values.website_url || null,
        monthly_fee: Number(values.monthly_fee) || 0,
        billing_day: values.billing_day ?? null,
      };
      if (values.id) {
        const { id, ...rest } = payload;
        const { error } = await supabase.from("clients").update(rest).eq("id", id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("clients").insert(payload);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["clients"] });
      setShowForm(false);
      setEditingId(null);
      setForm(defaultClientForm);
      toast.success(editingId ? "Cliente atualizado!" : "Cliente adicionado!");
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Erro ao salvar cliente"),
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("clients").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["clients"] });
      toast.success("Cliente removido!");
    },
  });

  const handleEdit = (c: Client) => {
    setForm({
      name: c.name,
      status: c.status as "ativo" | "inativo",
      payment_type: c.payment_type,
      rating: c.rating,
      demands_status: c.demands_status,
      payment_status: c.payment_status,
      has_funds: c.has_funds,
      website_url: c.website_url || "",
      has_meta: c.has_meta ?? true,
      has_google: c.has_google ?? true,
      visible_pages: c.visible_pages?.length ? c.visible_pages : ["dashboard", "optimization"],
      meta_account_id: c.meta_account_id || "",
      meta_integration_status: c.meta_integration_status || "inativo",
      google_account_id: c.google_account_id || "",
      google_integration_status: c.google_integration_status || "inativo",
      monthly_fee: Number((c as any).monthly_fee ?? 0),
      billing_day: (c as any).billing_day ?? 10,
    });
    setEditingId(c.id);
    setShowForm(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    upsertMutation.mutate(editingId ? { ...form, id: editingId } : form);
  };

  // Auto-compute demand: optimization overdue (> 7 days since last_optimized_at)
  const computeDemand = (c: Client) => {
    if (!c.last_optimized_at) return { overdue: true, days: null };
    const days = Math.floor((Date.now() - new Date(c.last_optimized_at).getTime()) / 86400000);
    return { overdue: days >= OPT_INTERVAL_DAYS, days };
  };

  const filteredClients = useMemo(
    () => clients.filter((c) => c.name.toLowerCase().includes(searchQuery.toLowerCase())),
    [clients, searchQuery],
  );

  const activeCount = clients.filter((c) => c.status === "ativo").length;

  return (
    <div className="flex h-screen bg-background">
      <DashboardSidebar />
      <main className="flex-1 overflow-y-auto">
        <div className="p-6 max-w-6xl mx-auto space-y-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-accent/15 flex items-center justify-center">
                <Users size={20} className="text-accent" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-foreground">Clientes</h1>
                <p className="text-xs text-muted-foreground">
                  {activeCount} ativos de {clients.length} clientes
                </p>
              </div>
            </div>
            <button
              onClick={() => {
                setForm(defaultClientForm);
                setEditingId(null);
                setShowForm(true);
              }}
              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-accent text-accent-foreground text-sm font-medium hover:opacity-90 transition"
            >
              <Plus size={16} /> Novo Cliente
            </button>
          </div>

          <div className="relative max-w-sm">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input
              type="text"
              placeholder="Buscar cliente..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 rounded-lg bg-secondary border border-border text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-accent"
            />
          </div>

          {isLoading ? (
            <div className="flex justify-center py-12">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
            </div>
          ) : filteredClients.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              {searchQuery ? "Nenhum cliente encontrado" : "Nenhum cliente cadastrado"}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
              {filteredClients.map((c) => {
                const demand = computeDemand(c);
                return (
                  <div
                    key={c.id}
                    onClick={() => handleEdit(c)}
                    className="rounded-xl border border-border bg-card p-4 space-y-3 hover:border-accent/30 transition cursor-pointer"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <p className="text-foreground font-semibold truncate">{c.name}</p>
                        {c.website_url && (
                          <a
                            href={c.website_url}
                            target="_blank"
                            rel="noopener noreferrer"
                            onClick={(e) => e.stopPropagation()}
                            className="text-[11px] text-accent hover:underline flex items-center gap-1 truncate"
                          >
                            {c.website_url.replace(/^https?:\/\//, "")} <ExternalLink size={9} />
                          </a>
                        )}
                      </div>
                      <Badge
                        variant="outline"
                        className={cn(
                          "text-[10px] shrink-0",
                          c.status === "ativo"
                            ? "bg-primary/15 text-primary border-primary/30"
                            : "bg-muted text-muted-foreground",
                        )}
                      >
                        {c.status === "ativo" ? "Ativo" : "Inativo"}
                      </Badge>
                    </div>

                    {/* Demand auto */}
                    <div
                      className={cn(
                        "flex items-center gap-2 text-xs px-2 py-1.5 rounded-lg border",
                        demand.overdue
                          ? "bg-destructive/10 border-destructive/30 text-destructive"
                          : "bg-primary/10 border-primary/30 text-primary",
                      )}
                    >
                      <AlertCircle size={12} />
                      <span className="flex-1">
                        {demand.overdue
                          ? c.last_optimized_at
                            ? `Otimização atrasada (${demand.days}d)`
                            : "Nunca otimizado"
                          : `Otimizado há ${demand.days}d`}
                      </span>
                    </div>

                    {/* Integration badges */}
                    {(c.has_meta || c.has_google) && (
                      <div className="flex gap-2">
                        {c.has_meta && (
                          <span
                            className={cn(
                              "flex items-center gap-1 text-[10px] px-2 py-1 rounded border",
                              c.meta_integration_status === "ativo"
                                ? "bg-primary/15 text-primary border-primary/30"
                                : "bg-destructive/10 text-destructive border-destructive/30",
                            )}
                          >
                            <span className="w-3 h-3 rounded bg-[#1877F2] text-white text-[8px] font-bold flex items-center justify-center">
                              f
                            </span>
                            {c.meta_integration_status === "ativo" ? (
                              <CheckCircle2 size={9} />
                            ) : (
                              <XCircle size={9} />
                            )}
                            Meta
                          </span>
                        )}
                        {c.has_google && (
                          <span
                            className={cn(
                              "flex items-center gap-1 text-[10px] px-2 py-1 rounded border",
                              c.google_integration_status === "ativo"
                                ? "bg-primary/15 text-primary border-primary/30"
                                : "bg-destructive/10 text-destructive border-destructive/30",
                            )}
                          >
                            <span className="w-3 h-3 rounded bg-[#EA4335] text-white text-[8px] font-bold flex items-center justify-center">
                              G
                            </span>
                            {c.google_integration_status === "ativo" ? (
                              <CheckCircle2 size={9} />
                            ) : (
                              <XCircle size={9} />
                            )}
                            Google
                          </span>
                        )}
                      </div>
                    )}

                    <div className="flex items-center justify-between pt-2 border-t border-border">
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className={cn("text-[10px]", ratingColors[c.rating])}>
                          {ratingLabels[c.rating] || c.rating}
                        </Badge>
                        <span
                          className={cn(
                            "text-[10px]",
                            c.payment_status === "em_dia" ? "text-primary" : "text-destructive",
                          )}
                        >
                          {statusLabels[c.payment_status] || c.payment_status}
                        </span>
                      </div>
                      <div className="flex items-center gap-1">
                        <button
                          onClick={(e) => { e.stopPropagation(); handleEdit(c); }}
                          className="p-1.5 rounded-lg hover:bg-secondary text-muted-foreground hover:text-foreground transition"
                        >
                          <Pencil size={13} />
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            if (confirm("Remover este cliente?")) deleteMutation.mutate(c.id);
                          }}
                          className="p-1.5 rounded-lg hover:bg-destructive/15 text-muted-foreground hover:text-destructive transition"
                        >
                          <Trash2 size={13} />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {showForm && (
          <ClientFormModal
            form={form}
            setForm={setForm}
            editingId={editingId}
            isPending={upsertMutation.isPending}
            canFinancial={canFinancial}
            onClose={() => {
              setShowForm(false);
              setEditingId(null);
            }}
            onSubmit={handleSubmit}
          />
        )}
      </main>
    </div>
  );
}
