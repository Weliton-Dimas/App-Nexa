import { useEffect, useMemo, useState } from "react";
import { DashboardSidebar } from "@/components/DashboardSidebar";
import { supabase } from "@/integrations/supabase/client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "@/hooks/use-toast";
import {
  Star,
  Clock,
  Play,
  Pause,
  Square,
  History,
  TrendingUp,
  Trophy,
  Zap,
  Calendar,
  AlertCircle,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { OptimizationFinishModal, type FinishPayload } from "@/components/OptimizationFinishModal";
import { OptimizationHistoryModal } from "@/components/OptimizationHistoryModal";

const OPT_INTERVAL_DAYS = 7;

type Client = {
  id: string;
  name: string;
  status: string;
  rating: string;
  has_meta: boolean;
  has_google: boolean;
  assigned_users: string[] | null;
  last_optimized_at: string | null;
  total_optimization_seconds: number;
  active_optimization_started_at: string | null;
  active_optimization_user_id: string | null;
  active_optimization_paused_at: string | null;
  active_optimization_accumulated_seconds: number;
};

type Profile = {
  user_id: string;
  display_name: string | null;
  avatar_url: string | null;
};

type OptSession = {
  id: string;
  client_id: string;
  user_id: string;
  started_at: string;
  ended_at: string | null;
  duration_seconds: number;
};

const formatDuration = (seconds: number) => {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
};

const daysSince = (iso: string | null) => {
  if (!iso) return null;
  const diff = Date.now() - new Date(iso).getTime();
  return Math.floor(diff / (1000 * 60 * 60 * 24));
};

const formatDateBR = (iso: string | null) => {
  if (!iso) return "—";
  const d = new Date(iso);
  return `${String(d.getDate()).padStart(2, "0")}/${String(d.getMonth() + 1).padStart(2, "0")} ${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
};

const addDays = (iso: string | null, days: number) => {
  if (!iso) return null;
  const d = new Date(iso);
  d.setDate(d.getDate() + days);
  return `${String(d.getDate()).padStart(2, "0")}/${String(d.getMonth() + 1).padStart(2, "0")}`;
};

type OptStatus = "atrasada" | "dia_otimizar" | "otimizada" | "otimizando";

function getStatus(client: Client): OptStatus {
  if (client.active_optimization_started_at) return "otimizando";
  const days = daysSince(client.last_optimized_at);
  if (days === null) return "atrasada";
  if (days > OPT_INTERVAL_DAYS) return "atrasada";
  if (days >= OPT_INTERVAL_DAYS) return "dia_otimizar";
  return "otimizada";
}

export default function OptimizationPage() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [tick, setTick] = useState(0);

  // tick every second to refresh active timers
  useEffect(() => {
    const i = setInterval(() => setTick((t) => t + 1), 1000);
    return () => clearInterval(i);
  }, []);

  const { data: clients = [] } = useQuery({
    queryKey: ["opt-clients"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("clients")
        .select("id,name,status,rating,has_meta,has_google,assigned_users,last_optimized_at,total_optimization_seconds,active_optimization_started_at,active_optimization_user_id,active_optimization_paused_at,active_optimization_accumulated_seconds,visible_pages")
        .eq("status", "ativo")
        .contains("visible_pages", ["optimization"])
        .order("name");
      if (error) throw error;
      return (data || []) as Client[];
    },
  });

  const { data: profiles = [] } = useQuery({
    queryKey: ["opt-profiles"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("profiles")
        .select("user_id,display_name,avatar_url");
      if (error) throw error;
      return (data || []) as Profile[];
    },
  });

  const { data: sessions = [] } = useQuery({
    queryKey: ["opt-sessions"],
    queryFn: async () => {
      const since = new Date();
      since.setDate(since.getDate() - 7);
      const { data, error } = await supabase
        .from("optimization_sessions")
        .select("*")
        .gte("started_at", since.toISOString())
        .order("started_at", { ascending: false });
      if (error) throw error;
      return (data || []) as OptSession[];
    },
  });

  const { data: lastSessions = [] } = useQuery({
    queryKey: ["opt-last-sessions"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("optimization_sessions")
        .select("client_id,user_id,ended_at")
        .not("ended_at", "is", null)
        .order("ended_at", { ascending: false })
        .limit(1000);
      if (error) throw error;
      return (data || []) as { client_id: string; user_id: string; ended_at: string }[];
    },
  });

  const lastSessionUserByClient = useMemo(() => {
    const m = new Map<string, string>();
    lastSessions.forEach((s) => {
      if (!m.has(s.client_id)) m.set(s.client_id, s.user_id);
    });
    return m;
  }, [lastSessions]);

  const profileById = useMemo(() => {
    const m: Record<string, Profile> = {};
    profiles.forEach((p) => (m[p.user_id] = p));
    return m;
  }, [profiles]);

  const stats = useMemo(() => {
    let atrasadas = 0;
    let diaOtimizar = 0;
    let otimizando = 0;
    const todayStr = new Date().toDateString();
    let concluidasHoje = sessions.filter(
      (s) => s.ended_at && new Date(s.ended_at).toDateString() === todayStr,
    ).length;

    clients.forEach((c) => {
      const st = getStatus(c);
      if (st === "atrasada") atrasadas++;
      else if (st === "dia_otimizar") diaOtimizar++;
      else if (st === "otimizando") otimizando++;
    });

    return { atrasadas, diaOtimizar, otimizando, concluidasHoje };
  }, [clients, sessions]);

  const ranking = useMemo(() => {
    const todayStr = new Date().toDateString();
    const yesterdayStr = new Date(Date.now() - 86400000).toDateString();
    const map: Record<string, { hoje: number; ontem: number; semana: number }> = {};
    sessions
      .filter((s) => s.ended_at)
      .forEach((s) => {
        if (!map[s.user_id]) map[s.user_id] = { hoje: 0, ontem: 0, semana: 0 };
        map[s.user_id].semana++;
        const d = new Date(s.ended_at!).toDateString();
        if (d === todayStr) map[s.user_id].hoje++;
        if (d === yesterdayStr) map[s.user_id].ontem++;
      });
    return Object.entries(map)
      .map(([uid, v]) => ({ user: profileById[uid], ...v }))
      .filter((r) => r.user)
      .sort((a, b) => b.semana - a.semana);
  }, [sessions, profileById]);

  const [finishModal, setFinishModal] = useState<Client | null>(null);
  const [historyModal, setHistoryModal] = useState<Client | null>(null);

  const startOptimization = async (client: Client) => {
    if (!user) return;
    if (client.active_optimization_started_at) return;
    const { error } = await supabase
      .from("clients")
      .update({
        active_optimization_started_at: new Date().toISOString(),
        active_optimization_user_id: user.id,
        active_optimization_paused_at: null,
        active_optimization_accumulated_seconds: 0,
      })
      .eq("id", client.id);
    if (error) {
      toast({ title: "Erro ao iniciar", description: error.message, variant: "destructive" });
      return;
    }
    queryClient.invalidateQueries({ queryKey: ["opt-clients"] });
  };

  const pauseOptimization = async (client: Client) => {
    if (!client.active_optimization_started_at || client.active_optimization_paused_at) return;
    const elapsed = Math.floor(
      (Date.now() - new Date(client.active_optimization_started_at).getTime()) / 1000,
    );
    const { error } = await supabase
      .from("clients")
      .update({
        active_optimization_paused_at: new Date().toISOString(),
        active_optimization_accumulated_seconds:
          (client.active_optimization_accumulated_seconds || 0) + elapsed,
      })
      .eq("id", client.id);
    if (error) {
      toast({ title: "Erro ao pausar", description: error.message, variant: "destructive" });
      return;
    }
    queryClient.invalidateQueries({ queryKey: ["opt-clients"] });
  };

  const resumeOptimization = async (client: Client) => {
    if (!client.active_optimization_paused_at) return;
    const { error } = await supabase
      .from("clients")
      .update({
        active_optimization_started_at: new Date().toISOString(),
        active_optimization_paused_at: null,
      })
      .eq("id", client.id);
    if (error) {
      toast({ title: "Erro ao retomar", description: error.message, variant: "destructive" });
      return;
    }
    queryClient.invalidateQueries({ queryKey: ["opt-clients"] });
  };

  const finishOptimization = async (client: Client, payload: FinishPayload) => {
    if (!user || !client.active_optimization_started_at) return;
    const endedAt = new Date();
    const accumulated = client.active_optimization_accumulated_seconds || 0;
    const currentRun = client.active_optimization_paused_at
      ? 0
      : Math.floor((endedAt.getTime() - new Date(client.active_optimization_started_at).getTime()) / 1000);
    const duration = accumulated + currentRun;
    const startedAt = new Date(endedAt.getTime() - duration * 1000);

    const { error: sessErr } = await supabase.from("optimization_sessions").insert({
      client_id: client.id,
      user_id: client.active_optimization_user_id || user.id,
      started_at: startedAt.toISOString(),
      ended_at: endedAt.toISOString(),
      duration_seconds: duration,
      ...payload,
    });
    if (sessErr) {
      toast({ title: "Erro ao salvar sessão", description: sessErr.message, variant: "destructive" });
      return;
    }

    const { error } = await supabase
      .from("clients")
      .update({
        active_optimization_started_at: null,
        active_optimization_user_id: null,
        active_optimization_paused_at: null,
        active_optimization_accumulated_seconds: 0,
        last_optimized_at: endedAt.toISOString(),
        total_optimization_seconds: (client.total_optimization_seconds || 0) + duration,
      })
      .eq("id", client.id);
    if (error) {
      toast({ title: "Erro ao finalizar", description: error.message, variant: "destructive" });
      return;
    }
    toast({ title: "Otimização registrada", description: `${client.name} — ${formatDuration(duration)}` });
    setFinishModal(null);
    queryClient.invalidateQueries({ queryKey: ["opt-clients"] });
    queryClient.invalidateQueries({ queryKey: ["opt-sessions"] });
  };

  const sortedClients = useMemo(() => {
    const order: Record<OptStatus, number> = { otimizando: 0, atrasada: 1, dia_otimizar: 2, otimizada: 3 };
    return [...clients].sort((a, b) => order[getStatus(a)] - order[getStatus(b)]);
  }, [clients]);

  return (
    <div className="flex h-screen bg-background">
      <DashboardSidebar />
      <main className="flex-1 overflow-y-auto">
        <div className="p-6 max-w-[1600px] mx-auto space-y-6">
          {/* Header */}
          <div className="flex items-start justify-between">
            <div>
              <h1 className="text-2xl font-bold text-foreground">Otimização de Clientes</h1>
              <p className="text-sm text-muted-foreground mt-1">
                Controle diário de otimizações — Visão Admin
              </p>
            </div>
          </div>

          {/* Stats cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
            <StatCard
              label="ATRASADAS"
              value={stats.atrasadas}
              color="text-destructive"
              icon={<AlertCircle size={16} className="text-destructive" />}
            />
            <StatCard
              label="DIA DE OTIMIZAR"
              value={stats.diaOtimizar}
              color="text-[hsl(var(--metric-amber))]"
              icon={<Calendar size={16} className="text-[hsl(var(--metric-amber))]" />}
            />
            <StatCard
              label="OTIMIZANDO"
              value={stats.otimizando}
              color="text-[hsl(var(--metric-blue))]"
              icon={<Zap size={16} className="text-[hsl(var(--metric-blue))]" />}
            />
            <StatCard
              label="CONCLUÍDAS HOJE"
              value={stats.concluidasHoje}
              color="text-[hsl(var(--metric-green))]"
              icon={<Trophy size={16} className="text-[hsl(var(--metric-green))]" />}
            />
          </div>

          {/* Insights */}
          <div className="bg-card rounded-xl border border-border p-4">
            <div className="flex items-center gap-2 mb-3">
              <TrendingUp size={16} className="text-muted-foreground" />
              <h3 className="text-sm font-semibold text-foreground">Insights</h3>
            </div>
            <div className="space-y-2">
              <div className="bg-[hsl(var(--metric-green))]/10 border border-[hsl(var(--metric-green))]/20 rounded-lg px-3 py-2 flex items-center gap-2">
                <Zap size={14} className="text-[hsl(var(--metric-green))]" />
                <span className="text-xs text-[hsl(var(--metric-green))]">
                  {stats.concluidasHoje} otimizaç{stats.concluidasHoje === 1 ? "ão concluída" : "ões concluídas"} hoje
                </span>
              </div>
              <div className="bg-secondary/50 border border-border rounded-lg px-3 py-2 flex items-center gap-2">
                <TrendingUp size={14} className="text-muted-foreground" />
                <span className="text-xs text-muted-foreground">
                  Ciclo de otimização: a cada {OPT_INTERVAL_DAYS} dias
                </span>
              </div>
            </div>
          </div>

          {/* Ranking */}
          {ranking.length > 0 && (
            <div className="bg-card rounded-xl border border-border p-4">
              <div className="flex items-center gap-2 mb-3">
                <Trophy size={16} className="text-[hsl(var(--metric-amber))]" />
                <h3 className="text-sm font-semibold text-foreground">Ranking de Gestores</h3>
                <span className="text-xs text-muted-foreground">por otimizações concluídas</span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                {ranking.map((r, idx) => (
                  <div
                    key={r.user.user_id}
                    className="flex items-center gap-3 bg-secondary/40 rounded-lg p-3 border border-border relative"
                  >
                    <div className={cn(
                      "absolute -top-1 -left-1 w-5 h-5 rounded-full text-[10px] font-bold flex items-center justify-center",
                      idx === 0 && "bg-[hsl(var(--metric-amber))] text-background",
                      idx === 1 && "bg-muted-foreground text-background",
                      idx >= 2 && "bg-secondary text-foreground border border-border",
                    )}>{idx + 1}</div>
                    <Avatar profile={r.user} size={36} />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-foreground truncate">
                        {r.user.display_name || "Gestor"}
                      </p>
                      <div className="flex gap-3 text-[10px] text-muted-foreground mt-0.5">
                        <span><span className="text-foreground font-bold">{r.hoje}</span> hoje</span>
                        <span><span className="text-foreground font-bold">{r.ontem}</span> ontem</span>
                        <span><span className="text-foreground font-bold">{r.semana}</span> 7d</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-xl font-bold text-foreground tabular-nums">{r.semana}</p>
                      <p className="text-[9px] text-muted-foreground uppercase">clientes</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Clients table */}
          <div className="bg-card rounded-xl border border-border overflow-hidden">
            <div className="grid grid-cols-[2fr_1fr_1fr_1.4fr_1fr_1fr_1.2fr] gap-3 px-4 py-3 border-b border-border text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
              <div>Cliente</div>
              <div>Status</div>
              <div>Canais</div>
              <div>Cronograma</div>
              <div>Gestor</div>
              <div className="flex items-center gap-1"><Clock size={11} /> Tempo</div>
              <div className="text-right">Ações</div>
            </div>
            {sortedClients.length === 0 && (
              <div className="px-4 py-12 text-center text-sm text-muted-foreground">
                Nenhum cliente ativo encontrado.
              </div>
            )}
            {sortedClients.map((client) => {
              const status = getStatus(client);
              const days = daysSince(client.last_optimized_at);
              const managerId =
                client.active_optimization_user_id ||
                lastSessionUserByClient.get(client.id) ||
                client.assigned_users?.[0];
              const manager = managerId ? profileById[managerId] : undefined;
              const managerLabel = client.active_optimization_user_id
                ? "Otimizando"
                : lastSessionUserByClient.has(client.id)
                  ? "Última otimização"
                  : client.assigned_users?.[0]
                    ? "Designado"
                    : "";
              const isRunning = !!client.active_optimization_started_at;
              const isPaused = !!client.active_optimization_paused_at;
              const liveSeconds = isRunning
                ? client.total_optimization_seconds +
                  (client.active_optimization_accumulated_seconds || 0) +
                  (isPaused
                    ? 0
                    : Math.floor(
                        (Date.now() - new Date(client.active_optimization_started_at!).getTime()) / 1000,
                      ))
                : client.total_optimization_seconds;

              return (
                <div
                  key={client.id + tick}
                  className={cn(
                    "grid grid-cols-[2fr_1fr_1fr_1.4fr_1fr_1fr_1.2fr] gap-3 px-4 py-3 border-b border-border/50 last:border-b-0 items-center hover:bg-secondary/30 transition-colors relative",
                    isRunning && "bg-[hsl(var(--metric-blue))]/5",
                    status === "atrasada" && "border-l-2 border-l-destructive",
                    status === "dia_otimizar" && "border-l-2 border-l-[hsl(var(--metric-amber))]",
                  )}
                >
                  {/* Cliente */}
                  <div className="flex items-center gap-2 min-w-0">
                    <Star
                      size={14}
                      className={cn(
                        client.rating === "ótimo" && "text-[hsl(var(--metric-amber))] fill-[hsl(var(--metric-amber))]",
                        client.rating === "bom" && "text-[hsl(var(--metric-blue))]",
                        (client.rating === "regular" || client.rating === "ruim") && "text-muted-foreground",
                      )}
                    />
                    <div className="min-w-0">
                      <p className="text-sm font-bold text-foreground uppercase truncate">{client.name}</p>
                      <p className={cn(
                        "text-[10px]",
                        status === "atrasada" && "text-destructive",
                        status === "dia_otimizar" && "text-[hsl(var(--metric-amber))]",
                        status !== "atrasada" && status !== "dia_otimizar" && "text-muted-foreground",
                      )}>
                        {days === null ? "Nunca otimizado" : `${days}d sem otimizar`}
                      </p>
                    </div>
                  </div>

                  {/* Status */}
                  <div>
                    <StatusBadge status={status} />
                  </div>

                  {/* Canais */}
                  <div className="flex items-center gap-1.5">
                    <ChannelIcon active={client.has_meta} type="meta" />
                    <ChannelIcon active={client.has_google} type="google" />
                  </div>

                  {/* Cronograma */}
                  <div className="text-[11px] space-y-0.5">
                    <p className="text-muted-foreground">
                      Última: <span className="text-foreground">{formatDateBR(client.last_optimized_at)}</span>
                    </p>
                    <p className="text-muted-foreground">
                      Próxima: <span className="text-foreground">{addDays(client.last_optimized_at, OPT_INTERVAL_DAYS) || "—"}</span>
                    </p>
                  </div>

                  {/* Gestor */}
                  <div>
                    {manager ? (
                      <div className="flex items-center gap-2" title={manager.display_name || ""}>
                        <Avatar profile={manager} size={32} />
                        <div className="min-w-0">
                          <p className="text-[11px] font-medium text-foreground truncate max-w-[110px]">
                            {manager.display_name || "Gestor"}
                          </p>
                          {managerLabel && (
                            <p className={cn(
                              "text-[9px] uppercase tracking-wider",
                              client.active_optimization_user_id
                                ? "text-[hsl(var(--metric-blue))]"
                                : "text-muted-foreground",
                            )}>
                              {managerLabel}
                            </p>
                          )}
                        </div>
                      </div>
                    ) : (
                      <div className="w-8 h-8 rounded-full bg-secondary border border-border" />
                    )}
                  </div>

                  {/* Tempo */}
                  <div className={cn(
                    "flex items-center gap-1.5 text-sm font-mono tabular-nums",
                    isRunning && !isPaused ? "text-[hsl(var(--metric-blue))]" : isPaused ? "text-[hsl(var(--metric-amber))]" : "text-foreground",
                  )}>
                    <Clock size={12} className={isRunning && !isPaused ? "text-[hsl(var(--metric-blue))]" : isPaused ? "text-[hsl(var(--metric-amber))]" : "text-muted-foreground"} />
                    {formatDuration(liveSeconds)}
                  </div>

                  {/* Ações */}
                  <div className="flex items-center gap-1.5 justify-end">
                    <button
                      onClick={() => setHistoryModal(client)}
                      title="Histórico"
                      className="p-1.5 rounded-md hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors"
                    >
                      <History size={14} />
                    </button>
                    {isRunning ? (
                      <>
                        {isPaused ? (
                          <button
                            onClick={() => resumeOptimization(client)}
                            className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-secondary border border-border text-foreground text-xs font-semibold hover:bg-accent/15 hover:border-accent/40 hover:text-accent transition-colors"
                          >
                            <Play size={12} /> Retomar
                          </button>
                        ) : (
                          <button
                            onClick={() => pauseOptimization(client)}
                            className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-secondary border border-border text-foreground text-xs font-semibold hover:bg-secondary/70 transition-colors"
                          >
                            <Pause size={12} /> Pausar
                          </button>
                        )}
                        <button
                          onClick={() => setFinishModal(client)}
                          className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-[hsl(var(--metric-amber))]/10 border border-[hsl(var(--metric-amber))]/40 text-[hsl(var(--metric-amber))] text-xs font-semibold hover:bg-[hsl(var(--metric-amber))]/20 transition-colors"
                        >
                          <Square size={12} /> Finalizar
                        </button>
                      </>
                    ) : (
                      <button
                        onClick={() => startOptimization(client)}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-secondary border border-border text-foreground text-xs font-semibold hover:bg-accent/15 hover:border-accent/40 hover:text-accent transition-colors"
                      >
                        <Play size={12} /> Iniciar
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </main>

      <OptimizationFinishModal
        open={!!finishModal}
        clientName={finishModal?.name || ""}
        hasMeta={finishModal?.has_meta ?? true}
        hasGoogle={finishModal?.has_google ?? true}
        onClose={() => setFinishModal(null)}
        onSave={(payload) => finishModal && finishOptimization(finishModal, payload)}
      />

      <OptimizationHistoryModal
        open={!!historyModal}
        clientId={historyModal?.id || null}
        clientName={historyModal?.name || ""}
        profileById={profileById}
        onClose={() => setHistoryModal(null)}
      />
    </div>
  );
}

function StatCard({ label, value, color, icon }: { label: string; value: number; color: string; icon: React.ReactNode }) {
  return (
    <div className="bg-card rounded-xl border border-border p-4">
      <div className="flex items-center gap-2 mb-2">
        {icon}
        <p className="text-[10px] font-semibold tracking-wider text-muted-foreground uppercase">{label}</p>
      </div>
      <p className={cn("text-4xl font-bold tabular-nums", color)}>{value}</p>
    </div>
  );
}

function StatusBadge({ status }: { status: OptStatus }) {
  const config = {
    otimizada: { label: "Otimizada", color: "bg-[hsl(var(--metric-green))]/15 text-[hsl(var(--metric-green))] border-[hsl(var(--metric-green))]/30", dot: "bg-[hsl(var(--metric-green))]" },
    otimizando: { label: "Otimizando", color: "bg-[hsl(var(--metric-blue))]/15 text-[hsl(var(--metric-blue))] border-[hsl(var(--metric-blue))]/30", dot: "bg-[hsl(var(--metric-blue))] animate-pulse" },
    dia_otimizar: { label: "Dia de Otimizar", color: "bg-[hsl(var(--metric-amber))]/15 text-[hsl(var(--metric-amber))] border-[hsl(var(--metric-amber))]/30", dot: "bg-[hsl(var(--metric-amber))]" },
    atrasada: { label: "Atrasada", color: "bg-destructive/15 text-destructive border-destructive/30", dot: "bg-destructive" },
  }[status];
  return (
    <span className={cn("inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[11px] font-medium border", config.color)}>
      <span className={cn("w-1.5 h-1.5 rounded-full", config.dot)} />
      {config.label}
    </span>
  );
}

function ChannelIcon({ active, type }: { active: boolean; type: "meta" | "google" }) {
  return (
    <div
      className={cn(
        "w-7 h-7 rounded-md flex items-center justify-center text-xs font-bold",
        active
          ? type === "meta"
            ? "bg-[#1877F2]/15 text-[#1877F2]"
            : "bg-[#EA4335]/15 text-[#EA4335]"
          : "bg-secondary/40 text-muted-foreground/40",
      )}
      title={type === "meta" ? "Meta Ads" : "Google Ads"}
    >
      {type === "meta" ? "f" : "G"}
    </div>
  );
}

function Avatar({ profile, size }: { profile: Profile; size: number }) {
  const initial = (profile.display_name || "?").charAt(0).toUpperCase();
  if (profile.avatar_url) {
    return (
      <img
        src={profile.avatar_url}
        alt={profile.display_name || "Gestor"}
        className="rounded-full object-cover border border-border"
        style={{ width: size, height: size }}
      />
    );
  }
  return (
    <div
      className="rounded-full bg-accent/20 text-accent flex items-center justify-center font-semibold border border-border"
      style={{ width: size, height: size, fontSize: size * 0.4 }}
      title={profile.display_name || "Gestor"}
    >
      {initial}
    </div>
  );
}
