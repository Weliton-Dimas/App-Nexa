const TermsPage = () => {
  return (
    <main className="min-h-screen bg-background text-foreground">
      <div className="max-w-3xl mx-auto px-6 py-12">
        <h1 className="text-3xl font-bold mb-2">Termos de Serviço</h1>
        <p className="text-sm text-muted-foreground mb-8">
          Última atualização: {new Date().toLocaleDateString("pt-BR")}
        </p>

        <section className="space-y-6 text-sm leading-relaxed">
          <div>
            <h2 className="text-lg font-semibold mb-2">1. Aceitação</h2>
            <p>
              Ao utilizar a plataforma disponível em{" "}
              <strong>app.agencianexaperformance.com.br</strong>, você concorda com estes
              Termos de Serviço. Se não concorda, não utilize a plataforma.
            </p>
          </div>

          <div>
            <h2 className="text-lg font-semibold mb-2">2. Uso permitido</h2>
            <p>
              A plataforma é de uso interno da Nexa Performance e seus usuários autorizados.
              É proibido tentar acessar dados de outros usuários, realizar engenharia reversa
              ou utilizar o sistema para fins ilegais.
            </p>
          </div>

          <div>
            <h2 className="text-lg font-semibold mb-2">3. Contas e acesso</h2>
            <p>
              O cadastro de novos usuários é restrito a administradores. Você é responsável
              por manter suas credenciais em segurança e por todas as atividades realizadas
              em sua conta.
            </p>
          </div>

          <div>
            <h2 className="text-lg font-semibold mb-2">4. Integrações de terceiros</h2>
            <p>
              Conexões com Meta Ads, Google Ads e Magazord são opcionais. O usuário declara
              ter autorização para conectar as contas escolhidas e pode revogar o acesso a
              qualquer momento.
            </p>
          </div>

          <div>
            <h2 className="text-lg font-semibold mb-2">5. Disponibilidade</h2>
            <p>
              Nos esforçamos para manter a plataforma disponível, mas não garantimos
              funcionamento ininterrupto. Manutenções e instabilidades podem ocorrer.
            </p>
          </div>

          <div>
            <h2 className="text-lg font-semibold mb-2">6. Limitação de responsabilidade</h2>
            <p>
              A plataforma é fornecida "como está". Não nos responsabilizamos por perdas
              decorrentes de decisões tomadas com base nos dados exibidos, falhas de
              integrações de terceiros ou indisponibilidades.
            </p>
          </div>

          <div>
            <h2 className="text-lg font-semibold mb-2">7. Alterações</h2>
            <p>
              Estes termos podem ser atualizados a qualquer momento. Mudanças relevantes
              serão comunicadas dentro da plataforma.
            </p>
          </div>

          <div>
            <h2 className="text-lg font-semibold mb-2">8. Contato</h2>
            <p>
              Dúvidas:{" "}
              <a className="text-primary underline" href="mailto:welitondimas16@gmail.com">
                welitondimas16@gmail.com
              </a>
            </p>
          </div>
        </section>
      </div>
    </main>
  );
};

export default TermsPage;
