import { useEffect, useMemo, useRef, useState } from "react";
import { DashboardSidebar } from "@/components/DashboardSidebar";
import { supabase } from "@/integrations/supabase/client";
import { useQuery } from "@tanstack/react-query";
import {
  Calculator, Target, PieChart as PieIcon,
  Plus, Trash2, Copy, Sparkles, X, Settings, CreditCard, Wallet, Download,
  Eye, RotateCcw, Pin, PinOff,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter,
} from "@/components/ui/dialog";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Checkbox } from "@/components/ui/checkbox";
import {
  PieChart, Pie, Cell, ResponsiveContainer, Tooltip,
} from "recharts";

import {
  computeProductPricing, computeBreakEven, computeSensitivity,
  computeCurrentProfit, computeInstallments, computePaymentBreakdown,
  computeSuggestedByMethod, computePixWithDiscount,
  fmtBRL, fmtPct, type ExtraCost, type PricingProductRow,
  DEFAULT_SETTINGS, DEFAULT_INSTALLMENT_RATES, type InstallmentRate, type PricingSettings,
  effectiveKind, NATIVE_KIND, type ColumnKinds, type TogglableField,
} from "@/lib/pricingMath";
import {
  usePricingProducts, useUpsertProduct, useDeleteProduct, type PricingProduct,
} from "@/hooks/usePricingProducts";
import { usePricingSettings, useUpsertSettings, type PricingSettingsRow } from "@/hooks/usePricingSettings";
import { useAuth } from "@/hooks/useAuth";
import { useUserPermissions } from "@/hooks/useUserPermissions";

const PIE_COLORS = ["hsl(var(--metric-blue))", "hsl(var(--metric-amber))", "hsl(var(--metric-red))", "hsl(var(--metric-green))"];

// ─── Column groups ────────────────────────────────────────────────────────────
type ColDef = { key: keyof PricingProduct; label: string; suffix?: string };

const GROUP_PRODUCT: ColDef[] = [
  { key: "product_cost", label: "Custo", suffix: "R$" },
];
const GROUP_PAYMENT: ColDef[] = [
  { key: "card_pct", label: "Cartão", suffix: "%" },
  { key: "gateway_pct", label: "Gateway", suffix: "%" },
  { key: "pix_pct", label: "Pix", suffix: "%" },
  { key: "boleto_value", label: "Boleto", suffix: "R$" },
];
const GROUP_PLATFORM: ColDef[] = [
  { key: "taxes_pct", label: "Impostos", suffix: "%" },
  { key: "platform_pct", label: "Plataforma", suffix: "%" },
  { key: "commission_pct", label: "Comissão", suffix: "%" },
  { key: "other_deductions_pct", label: "Outras", suffix: "%" },
];
const GROUP_LOGISTICS: ColDef[] = [
  { key: "selling_cost", label: "Custo venda", suffix: "R$" },
  { key: "shipping_cost", label: "Frete", suffix: "R$" },
  { key: "packaging_cost", label: "Embalagem", suffix: "R$" },
  { key: "other_inputs_cost", label: "Outros insumos", suffix: "R$" },
];
const GROUP_MARKETING: ColDef[] = [
  { key: "marketing_pct", label: "Marketing", suffix: "%" },
];

const DEFAULT_PRODUCT = {
  name: "Novo produto",
  sku: "",
  product_cost: 0,
  taxes_pct: 6,
  card_pct: 3.5, gateway_pct: 0, pix_pct: 0, boleto_value: 0,
  mix_card_pct: 70, mix_pix_pct: 25, mix_boleto_pct: 5,
  platform_pct: 0, marketing_pct: 10,
  commission_pct: 0, other_deductions_pct: 0,
  selling_cost: 0, shipping_cost: 0, packaging_cost: 0, other_inputs_cost: 0,
  desired_margin_pct: 20,
  margin_mode: "margin" as "margin" | "markup",
  current_price: 0,
  extra_costs: [] as ExtraCost[],
};

const PricingPage = () => {
  const { toast } = useToast();
  const upsert = useUpsertProduct();
  const del = useDeleteProduct();
  const upsertSettings = useUpsertSettings();

  const { user } = useAuth();
  const { data: perms } = useUserPermissions();

  const { data: clients } = useQuery({
    queryKey: ["clients-min-pricing", user?.id, perms?.isAdmin],
    enabled: !!user && perms !== undefined,
    queryFn: async () => {
      let q = supabase.from("clients").select("id, name").order("name");
      if (!perms?.isAdmin) {
        q = q.contains("assigned_users", [user!.id]);
      }
      const { data, error } = await q;
      if (error) throw error;
      return (data ?? []) as { id: string; name: string }[];
    },
  });

  const [clientId, setClientId] = useState<string | null>(null);
  useEffect(() => { if (!clientId && clients?.length) setClientId(clients[0].id); }, [clients, clientId]);

  const { data: products } = usePricingProducts(clientId);
  const { data: settingsRow } = usePricingSettings(clientId);
  const settings: PricingSettings = settingsRow ?? DEFAULT_SETTINGS;

  // ───── Column layout (Excel-like resize + hide) ─────────────────────────────
  const hiddenSet = useMemo(
    () => new Set(settings.hidden_columns ?? []),
    [settings.hidden_columns],
  );
  const isHidden = (id: string) => hiddenSet.has(id);
  const persistedWidths = settings.column_widths ?? {};
  const [localWidths, setLocalWidths] = useState<Record<string, number>>({});
  const widthFor = (id: string, def: number) =>
    localWidths[id] ?? persistedWidths[id] ?? def;

  const saveLayout = (patch: { hidden_columns?: string[]; column_widths?: Record<string, number> }) => {
    if (!clientId) return;
    upsertSettings.mutate({ ...(settingsRow ?? {}), ...patch, client_id: clientId } as any);
  };
  const toggleHidden = (id: string, hidden: boolean) => {
    const cur = new Set(settings.hidden_columns ?? []);
    if (hidden) cur.add(id); else cur.delete(id);
    saveLayout({ hidden_columns: Array.from(cur) });
  };
  const resetColumnLayout = () => {
    setLocalWidths({});
    saveLayout({ hidden_columns: [], column_widths: {} });
  };

  const dragRef = useRef<{ id: string; startX: number; startW: number; lastW: number } | null>(null);
  const onResizeMouseDown =
    (id: string, defaultW: number) => (e: React.MouseEvent) => {
      e.preventDefault(); e.stopPropagation();
      const startW = localWidths[id] ?? persistedWidths[id] ?? defaultW;
      dragRef.current = { id, startX: e.clientX, startW, lastW: startW };
      document.body.style.cursor = "col-resize";
      document.body.style.userSelect = "none";
      const onMove = (ev: MouseEvent) => {
        const d = dragRef.current; if (!d) return;
        const next = Math.max(60, Math.round(d.startW + (ev.clientX - d.startX)));
        d.lastW = next;
        setLocalWidths((w) => (w[d.id] === next ? w : { ...w, [d.id]: next }));
      };
      const onUp = () => {
        document.removeEventListener("mousemove", onMove);
        document.removeEventListener("mouseup", onUp);
        document.body.style.cursor = "";
        document.body.style.userSelect = "";
        const d = dragRef.current; dragRef.current = null;
        if (d) {
          saveLayout({
            column_widths: { ...(settings.column_widths ?? {}), [d.id]: d.lastW },
          });
        }
      };
      document.addEventListener("mousemove", onMove);
      document.addEventListener("mouseup", onUp);
    };
  const onResizeDoubleClick = (id: string) => (e: React.MouseEvent) => {
    e.preventDefault(); e.stopPropagation();
    setLocalWidths((w) => { const { [id]: _drop, ...rest } = w; return rest; });
    const cur = { ...(settings.column_widths ?? {}) };
    delete cur[id];
    saveLayout({ column_widths: cur });
  };

  const Resizer = ({ id, defaultW }: { id: string; defaultW: number }) => (
    <span
      role="separator"
      aria-label="Redimensionar coluna"
      onMouseDown={onResizeMouseDown(id, defaultW)}
      onDoubleClick={onResizeDoubleClick(id)}
      onClick={(e) => e.stopPropagation()}
      className="absolute top-0 right-0 h-full w-1.5 cursor-col-resize select-none hover:bg-accent/60 active:bg-accent transition-colors z-20"
    />
  );

  // Column id helpers
  const groupColId = (groupId: string, key: string) => `${groupId}:${key}`;
  const RES_COL_IDS = [
    "res:margin_input", "res:old_price", "res:sug_card1x", "res:sug_pix",
    "res:sug_boleto", "res:profit", "res:margin_real",
    "res:current_price", "res:current_profit", "res:current_margin",
  ] as const;
  const DEFAULT_WIDTHS: Record<string, number> = {
    "meta:name": 220, "meta:sku": 120,
    "prod:product_cost": 100,
    "pay:card_pct": 100, "pay:gateway_pct": 100, "pay:pix_pct": 100, "pay:boleto_value": 100,
    "plat:taxes_pct": 110, "plat:platform_pct": 120, "plat:commission_pct": 110, "plat:other_deductions_pct": 120,
    "log:selling_cost": 130, "log:shipping_cost": 100, "log:packaging_cost": 130, "log:other_inputs_cost": 150,
    "mkt:marketing_pct": 110,
    "res:margin_input": 140, "res:old_price": 120, "res:sug_card1x": 130,
    "res:sug_pix": 130, "res:sug_boleto": 130, "res:profit": 110, "res:margin_real": 100,
    "res:current_price": 120, "res:current_profit": 110, "res:current_margin": 100,
  };
  const widthStyle = (id: string): React.CSSProperties => {
    const def = DEFAULT_WIDTHS[id] ?? 110;
    const w = widthFor(id, def);
    return { width: w, minWidth: w, maxWidth: w };
  };

  // ───── Freeze panes (Excel-like) ────────────────────────────────────────────
  const FREEZE_ROWS_LS = (cid: string) => `pricing.freezeRows.${cid}`;
  const FREEZE_COLS_LS = (cid: string) => `pricing.freezeCols.${cid}`;
  const FREEZE_LEGACY_LS = (cid: string) => `pricing.freeze.${cid}`;
  const [freezeRows, setFreezeRows] = useState(false);
  const [freezeCols, setFreezeCols] = useState(false);
  useEffect(() => {
    if (!clientId) return;
    const rows = localStorage.getItem(FREEZE_ROWS_LS(clientId));
    const cols = localStorage.getItem(FREEZE_COLS_LS(clientId));
    if (rows === null && cols === null) {
      const legacy = localStorage.getItem(FREEZE_LEGACY_LS(clientId)) === "1";
      setFreezeRows(legacy);
      setFreezeCols(legacy);
    } else {
      setFreezeRows(rows === "1");
      setFreezeCols(cols === "1");
    }
  }, [clientId]);
  const toggleFreezeRows = (v: boolean) => {
    if (!clientId) return;
    setFreezeRows(v);
    try { localStorage.setItem(FREEZE_ROWS_LS(clientId), v ? "1" : "0"); } catch {}
  };
  const toggleFreezeCols = (v: boolean) => {
    if (!clientId) return;
    setFreezeCols(v);
    try { localStorage.setItem(FREEZE_COLS_LS(clientId), v ? "1" : "0"); } catch {}
  };
  const freezeActive = freezeRows || freezeCols;
  const ACTIONS_W = 72;
  const INDEX_W = 56;
  type FrozenId = "actions" | "index" | "meta:name" | "meta:sku";
  const frozenLeft = (id: FrozenId): number => {
    const nameVisible = !isHidden("meta:name");
    const nameW = widthFor("meta:name", DEFAULT_WIDTHS["meta:name"]);
    if (id === "actions") return 0;
    if (id === "index") return ACTIONS_W;
    if (id === "meta:name") return ACTIONS_W + INDEX_W;
    // sku
    return ACTIONS_W + INDEX_W + (nameVisible ? nameW : 0);
  };
  const stickyCol = (
    id: FrozenId,
    kind: "header" | "body" | "footer" = "body",
  ): React.CSSProperties => {
    if (!freezeCols) return {};
    return {
      position: "sticky",
      left: frozenLeft(id),
      zIndex: kind === "header" ? 31 : kind === "footer" ? 21 : 11,
    };
  };
  const stickyBg = (kind: "header" | "body" | "footer" = "body") =>
    freezeCols ? (kind === "header" ? "bg-secondary" : kind === "footer" ? "bg-secondary" : "bg-card") : "";




  // Local edit buffer
  const [drafts, setDrafts] = useState<Record<string, Partial<PricingProduct>>>({});
  const timers = useRef<Record<string, number>>({});

  useEffect(() => () => {
    Object.values(timers.current).forEach((t) => clearTimeout(t));
  }, []);

  const merged = useMemo(() => {
    return (products ?? []).map((p) => ({ ...p, ...(drafts[p.id] ?? {}) })) as PricingProduct[];
  }, [products, drafts]);

  const updateField = <K extends keyof PricingProduct>(p: PricingProduct, key: K, value: PricingProduct[K]) => {
    setDrafts((d) => ({ ...d, [p.id]: { ...d[p.id], [key]: value } }));
    if (timers.current[p.id]) clearTimeout(timers.current[p.id]);
    timers.current[p.id] = window.setTimeout(async () => {
      try {
        await upsert.mutateAsync({ id: p.id, client_id: p.client_id, ...(drafts[p.id] ?? {}), [key]: value } as any);
        setDrafts((d) => { const { [p.id]: _, ...rest } = d; return rest; });
      } catch (e: any) {
        toast({ title: "Erro ao salvar", description: e.message, variant: "destructive" });
      }
    }, 800);
  };

  const addProduct = async () => {
    if (!clientId) return;
    const position = (products?.length ?? 0) + 1;
    try {
      await upsert.mutateAsync({ client_id: clientId, position, ...DEFAULT_PRODUCT } as any);
    } catch (e: any) {
      toast({ title: "Erro", description: e.message, variant: "destructive" });
    }
  };

  const removeProduct = async (p: PricingProduct) => {
    if (!confirm(`Excluir "${p.name}"?`)) return;
    await del.mutateAsync({ id: p.id, client_id: p.client_id });
  };

  const duplicateProduct = async (p: PricingProduct) => {
    if (!clientId) return;
    const { id, created_at, updated_at, user_id, position, ...rest } = p as any;
    const newPos = (products?.length ?? 0) + 1;
    try {
      await upsert.mutateAsync({
        ...rest,
        client_id: p.client_id,
        position: newPos,
        name: `${p.name} (cópia)`,
      } as any);
      toast({ title: "Produto duplicado" });
    } catch (e: any) {
      toast({ title: "Erro", description: e.message, variant: "destructive" });
    }
  };

  // Extra columns
  type ColumnDef = { id: string; label: string; kind: "pct" | "value" };
  const extraColumns: ColumnDef[] = useMemo(() => {
    const map = new Map<string, ColumnDef>();
    merged.forEach((p) => p.extra_costs?.forEach((c) => {
      if (!map.has(c.id)) map.set(c.id, { id: c.id, label: c.label, kind: c.kind });
    }));
    return Array.from(map.values());
  }, [merged]);

  const setExtra = (p: PricingProduct, colId: string, value: number) => {
    const list = [...(p.extra_costs ?? [])];
    const i = list.findIndex((c) => c.id === colId);
    const def = extraColumns.find((c) => c.id === colId);
    if (i >= 0) list[i] = { ...list[i], value };
    else if (def) list.push({ id: colId, label: def.label, kind: def.kind, value });
    updateField(p, "extra_costs", list as any);
  };

  const addExtraColumn = async (label: string, kind: "pct" | "value") => {
    if (!clientId || !products?.length) {
      toast({ title: "Adicione um produto primeiro", variant: "destructive" });
      return;
    }
    const id = `ec_${Date.now().toString(36)}`;
    const first = products[0];
    const list = [...(first.extra_costs ?? []), { id, label, kind, value: 0 }];
    await upsert.mutateAsync({ id: first.id, client_id: first.client_id, extra_costs: list } as any);
  };

  const removeExtraColumn = async (colId: string) => {
    if (!confirm("Remover esta coluna de todos os produtos?")) return;
    if (!products) return;
    for (const p of products) {
      if (p.extra_costs?.some((c) => c.id === colId)) {
        const list = (p.extra_costs ?? []).filter((c) => c.id !== colId);
        await upsert.mutateAsync({ id: p.id, client_id: p.client_id, extra_costs: list } as any);
      }
    }
  };

  const toggleExtraColumnKind = async (colId: string) => {
    if (!products) return;
    const current = extraColumns.find((c) => c.id === colId);
    if (!current) return;
    const newKind: "pct" | "value" = current.kind === "pct" ? "value" : "pct";
    const round2 = (n: number) => Math.round(n * 100) / 100;
    for (const p of products) {
      // Reference price for conversion: current price if set, else suggested.
      const currentPrice = Number(p.current_price) || 0;
      let refPrice = currentPrice;
      if (refPrice <= 0) {
        const base = computeProductPricing(rowOf(p), settings.column_kinds);
        refPrice = base.sellingPrice || 0;
      }
      const list = (p.extra_costs ?? []).map((c) => {
        if (c.id !== colId) return c;
        const v = Number(c.value) || 0;
        let newValue = v;
        if (refPrice > 0) {
          newValue =
            newKind === "value"
              ? round2(refPrice * (v / 100)) // pct -> R$
              : round2((v / refPrice) * 100); // R$ -> pct
        }
        return { ...c, kind: newKind, value: newValue };
      });
      // ensure column exists in this product so kind change is persisted globally
      if (!list.some((c) => c.id === colId)) {
        list.push({ id: colId, label: current.label, kind: newKind, value: 0 });
      }
      await upsert.mutateAsync({ id: p.id, client_id: p.client_id, extra_costs: list } as any);
    }
  };

  /** Toggle % ↔ R$ for a fixed (built-in) column. Persists kind globally
   *  in pricing_settings.column_kinds and converts each product's value. */
  const toggleFixedColumnKind = async (field: TogglableField) => {
    if (!products || !clientId) return;
    const currentKind = effectiveKind(settings.column_kinds, field);
    const newKind: "pct" | "value" = currentKind === "pct" ? "value" : "pct";
    const round2 = (n: number) => Math.round(n * 100) / 100;
    const nextKinds: ColumnKinds = { ...(settings.column_kinds ?? {}) };
    // If new kind matches the native default, drop the override; otherwise set it.
    if (newKind === NATIVE_KIND[field]) delete nextKinds[field];
    else nextKinds[field] = newKind;
    try {
      await upsertSettings.mutateAsync({
        ...(settingsRow ?? {}),
        client_id: clientId,
        column_kinds: nextKinds,
      } as any);
      // Convert each product's value using its reference price.
      for (const p of products) {
        const currentPrice = Number(p.current_price) || 0;
        let refPrice = currentPrice;
        if (refPrice <= 0) {
          const base = computeProductPricing(rowOf(p), settings.column_kinds);
          refPrice = base.sellingPrice || 0;
        }
        const v = Number((p as any)[field]) || 0;
        let newValue = v;
        if (refPrice > 0 && v > 0) {
          newValue =
            newKind === "value"
              ? round2(refPrice * (v / 100))
              : round2((v / refPrice) * 100);
        }
        await upsert.mutateAsync({ id: p.id, client_id: p.client_id, [field]: newValue } as any);
      }
    } catch (e: any) {
      toast({ title: "Erro ao alternar coluna", description: e.message, variant: "destructive" });
    }
  };

  // Search + multi-selection for export
  const [searchText, setSearchText] = useState("");
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const filteredProducts = useMemo(() => {
    const q = searchText.trim().toLowerCase();
    if (!q) return merged;
    return merged.filter((p) =>
      (p.name ?? "").toLowerCase().includes(q) ||
      (p.sku ?? "").toLowerCase().includes(q),
    );
  }, [merged, searchText]);
  // Drop selections for products that disappeared
  useEffect(() => {
    if (!selectedIds.size) return;
    const validIds = new Set(merged.map((p) => p.id));
    let changed = false;
    const next = new Set<string>();
    selectedIds.forEach((id) => {
      if (validIds.has(id)) next.add(id);
      else changed = true;
    });
    if (changed) setSelectedIds(next);
  }, [merged, selectedIds]);
  const toggleSelect = (id: string) =>
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  const allFilteredSelected =
    filteredProducts.length > 0 && filteredProducts.every((p) => selectedIds.has(p.id));
  const toggleSelectAllFiltered = () =>
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (allFilteredSelected) filteredProducts.forEach((p) => next.delete(p.id));
      else filteredProducts.forEach((p) => next.add(p.id));
      return next;
    });

  // Selected product (for analytics panel)
  const [selectedId, setSelectedId] = useState<string | null>(null);
  useEffect(() => {
    if (!selectedId && merged.length) setSelectedId(merged[0].id);
  }, [merged, selectedId]);
  const selected = merged.find((p) => p.id === selectedId) ?? merged[0];

  const rowOf = (p: PricingProduct): PricingProductRow => ({
    product_cost: Number(p.product_cost),
    taxes_pct: Number(p.taxes_pct),
    card_pct: Number(p.card_pct),
    gateway_pct: Number(p.gateway_pct ?? 0),
    pix_pct: Number(p.pix_pct ?? 0),
    boleto_value: Number(p.boleto_value ?? 0),
    // Preço sugerido base usa Pix puro (mix 100% Pix). Cartão 1x e Boleto
    // são exibidos como preços paralelos via computeSuggestedByMethod.
    mix_card_pct: 0,
    mix_pix_pct: 100,
    mix_boleto_pct: 0,
    platform_pct: Number(p.platform_pct),
    marketing_pct: Number(p.marketing_pct),
    commission_pct: Number(p.commission_pct),
    other_deductions_pct: Number(p.other_deductions_pct),
    selling_cost: Number(p.selling_cost),
    shipping_cost: Number(p.shipping_cost),
    packaging_cost: Number(p.packaging_cost),
    other_inputs_cost: Number(p.other_inputs_cost),
    desired_margin_pct: Number(p.desired_margin_pct),
    margin_mode: (p.margin_mode === "markup" ? "markup" : "margin"),
    extra_costs: p.extra_costs ?? [],
  });

  const selectedRow = selected ? rowOf(selected) : null;
  // O preço cheio passa a ser o Sug. Cartão 1x (referência do site, padrão e-commerce).
  // O Sug. Pix é derivado como desconto promocional sobre ele.
  const sel = selectedRow ? computeSuggestedByMethod(selectedRow, settings, "card1x") : null;
  const be = sel ? computeBreakEven(sel) : null;
  const sensitivity = sel && selectedRow ? computeSensitivity(sel, selectedRow) : [];
  const currentCmp = sel ? computeCurrentProfit(sel, Number(selected?.current_price ?? 0)) : null;

  // Installment / payment breakdown
  const [installmentPriceMode, setInstallmentPriceMode] = useState<"sug" | "atual">("sug");
  const installmentPrice = sel
    ? installmentPriceMode === "atual" && Number(selected?.current_price) > 0
      ? Number(selected!.current_price)
      : sel.sellingPrice
    : 0;
  const installments = sel && selectedRow
    ? computeInstallments(selectedRow, sel, settings, installmentPrice)
    : [];
  const paymentBreakdown = sel && selectedRow
    ? computePaymentBreakdown(selectedRow, sel, settings, installmentPrice)
    : [];

  const composition = sel ? [
    { name: "Custos fixos", value: sel.totalFixedCosts, color: PIE_COLORS[0] },
    { name: "Deduções (sem ads)", value: sel.deductionsAmount - sel.adsBudgetPerUnit, color: PIE_COLORS[1] },
    { name: "Verba de ads reservada", value: sel.adsBudgetPerUnit, color: PIE_COLORS[2] },
    { name: "Lucro líquido", value: Math.max(0, sel.netProfit), color: PIE_COLORS[3] },
  ] : [];

  // Totals use card1x as base price (preço cheio do site).
  const totals = merged.reduce((acc, p) => {
    const r = computeSuggestedByMethod(rowOf(p), settings, "card1x");
    const cur = computeCurrentProfit(r, Number(p.current_price));
    return {
      price: acc.price + r.sellingPrice,
      profit: acc.profit + r.netProfit,
      count: acc.count + 1,
      avgMargin: acc.avgMargin + r.netMarginPct,
      currentPrice: acc.currentPrice + (cur.hasPrice ? Number(p.current_price) : 0),
      currentProfit: acc.currentProfit + (cur.hasPrice ? cur.netProfit : 0),
      currentCount: acc.currentCount + (cur.hasPrice ? 1 : 0),
      currentMarginSum: acc.currentMarginSum + (cur.hasPrice ? cur.netMarginPct : 0),
    };
  }, { price: 0, profit: 0, count: 0, avgMargin: 0, currentPrice: 0, currentProfit: 0, currentCount: 0, currentMarginSum: 0 });

  // Group helper for header & cells
  const groups: { id: string; label: string; cols: ColDef[]; tone: string; cellTone: string }[] = [
    { id: "product", label: "Produto", cols: GROUP_PRODUCT, tone: "bg-metric-green/15 text-metric-green", cellTone: "bg-metric-green/[0.04]" },
    { id: "payment", label: "Pagamento", cols: GROUP_PAYMENT, tone: "bg-metric-blue/15 text-metric-blue", cellTone: "bg-metric-blue/[0.04]" },
    { id: "platform", label: "Plataforma & Impostos", cols: GROUP_PLATFORM, tone: "bg-metric-amber/15 text-metric-amber", cellTone: "bg-metric-amber/[0.04]" },
    { id: "logistics", label: "Logística & Embalagem", cols: GROUP_LOGISTICS, tone: "bg-accent/15 text-accent", cellTone: "bg-accent/[0.04]" },
    { id: "marketing", label: "Marketing", cols: GROUP_MARKETING, tone: "bg-metric-red/15 text-metric-red", cellTone: "bg-metric-red/[0.04]" },
  ];
  const totalCols = 1 /*ações*/ + 1 /*#*/ + 2 /*nome+sku*/
    + groups.reduce((a, g) => a + g.cols.length, 0)
    + extraColumns.length
    + 1 /*margem desejada*/ + 9 /*resultado: preço antigo + 3 sug + lucro + margem + atual*3*/;

  const productsToExport = selectedIds.size
    ? filteredProducts.filter((p) => selectedIds.has(p.id))
    : filteredProducts;

  const exportCsv = () => {
    if (!productsToExport.length) {
      toast({ title: "Nada para exportar", description: "Ajuste a busca ou marque produtos.", variant: "destructive" });
      return;
    }
    const sep = ";";
    const fmtN = (v: number, d = 2) =>
      Number.isFinite(v) ? v.toFixed(d).replace(".", ",") : "";
    const esc = (s: any) => {
      const str = String(s ?? "");
      return /[";\n]/.test(str) ? `"${str.replace(/"/g, '""')}"` : str;
    };
    const headers = [
      "Produto", "SKU",
      "Custo (R$)",
      "Cartão", "Gateway", "Pix", "Boleto",
      "Impostos", "Plataforma", "Comissão", "Outras deduções",
      "Custo venda (R$)", "Frete (R$)", "Embalagem (R$)", "Outros insumos (R$)",
      "Marketing",
      ...extraColumns.map((c) => `${c.label} (${c.kind === "pct" ? "%" : "R$"})`),
      "Margem/Markup", "Modo (margem/markup)",
      "Sug. preço antigo (R$)",
      "Sug. Cartão 1x (R$) (preço cheio)", "Margem Sug. Cartão 1x (%)",
      "Sug. Pix (R$)", "Desconto Pix (%)", "Margem Sug. Pix (%)",
      "Sug. Boleto (R$)", "Margem Sug. Boleto (%)",
      "Lucro/un sugerido (R$)", "Margem real (%)",
      "Preço atual (R$)", "Lucro atual (R$)", "Margem atual (%)",
      "Custos fixos totais (R$)", "Deduções totais (%)",
    ];
    const rows = productsToExport.map((p) => {
      const row = rowOf(p);
      const r = computeSuggestedByMethod(row, settings, "card1x");
      const pix = computePixWithDiscount(r.sellingPrice, row, settings);
      const sBoleto = computeSuggestedByMethod(row, settings, "boleto");
      const cur = computeCurrentProfit(r, Number(p.current_price));
      return [
        esc(p.name), esc(p.sku ?? ""),
        fmtN(p.product_cost),
        fmtN(p.card_pct), fmtN(p.gateway_pct), fmtN(p.pix_pct), fmtN(p.boleto_value),
        fmtN(p.taxes_pct), fmtN(p.platform_pct), fmtN(p.commission_pct), fmtN(p.other_deductions_pct),
        fmtN(p.selling_cost), fmtN(p.shipping_cost), fmtN(p.packaging_cost), fmtN(p.other_inputs_cost),
        fmtN(p.marketing_pct),
        ...extraColumns.map((c) => fmtN(p.extra_costs?.find((e) => e.id === c.id)?.value ?? 0)),
        fmtN(p.desired_margin_pct), p.margin_mode === "markup" ? "markup" : "margem",
        (() => {
          const disc = Number(settings.old_price_discount_pct ?? 0);
          return disc > 0 && disc < 100 && r.sellingPrice > 0 ? fmtN(r.sellingPrice / (1 - disc / 100)) : "";
        })(),
        fmtN(r.sellingPrice), fmtN(r.netMarginPct),
        fmtN(pix.sellingPrice), fmtN(pix.discountPct), fmtN(pix.netMarginPct),
        fmtN(sBoleto.sellingPrice), fmtN(sBoleto.netMarginPct),
        fmtN(r.netProfit), fmtN(r.netMarginPct),
        cur.hasPrice ? fmtN(Number(p.current_price)) : "",
        cur.hasPrice ? fmtN(cur.netProfit) : "",
        cur.hasPrice ? fmtN(cur.netMarginPct) : "",
        fmtN(r.totalFixedCosts), fmtN(r.totalDeductionsPct),
      ].join(sep);
    });
    const csv = "\uFEFF" + [headers.join(sep), ...rows].join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    const clientName = clients?.find((c) => c.id === clientId)?.name ?? "cliente";
    const slug = clientName.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
    const date = new Date().toISOString().slice(0, 10);
    a.href = url;
    a.download = `precificacao_${slug}_${date}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex min-h-screen bg-background">
      <DashboardSidebar />
      <main className="flex-1 p-6 overflow-auto">
        <div className="w-full mx-auto space-y-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
            <div>
              <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
                <Calculator size={22} className="text-accent" /> Precificação
              </h1>
              <p className="text-sm text-muted-foreground">
                Planilha de produtos por cliente — custos agrupados, parcelamento detalhado e análise de margem.
              </p>
            </div>
            <div className="flex flex-wrap gap-2 items-center">
              <select
                value={clientId ?? ""}
                onChange={(e) => { setClientId(e.target.value); setSelectedId(null); }}
                className="bg-secondary border border-border rounded-lg px-3 py-2 text-sm text-foreground"
              >
                {clients?.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
              <SettingsDialog
                clientId={clientId}
                current={settingsRow}
                onSave={async (s) => {
                  if (!clientId) return;
                  try {
                    await upsertSettings.mutateAsync({ ...(settingsRow ?? {}), ...s, client_id: clientId });
                    toast({ title: "Configurações salvas" });
                  } catch (e: any) {
                    toast({ title: "Erro", description: e.message, variant: "destructive" });
                  }
                }}
              />
              <ExtraColumnDialog onAdd={addExtraColumn} />
              <Input
                placeholder="Buscar por nome ou SKU…"
                value={searchText}
                onChange={(e) => setSearchText(e.target.value)}
                className="h-9 w-56"
              />
              {selectedIds.size > 0 && (
                <Button size="sm" variant="ghost" onClick={() => setSelectedIds(new Set())}>
                  Limpar seleção ({selectedIds.size})
                </Button>
              )}
              <Button size="sm" variant="outline" onClick={exportCsv} disabled={!productsToExport.length}
                title={selectedIds.size
                  ? `Exportar ${productsToExport.length} produto(s) selecionado(s)`
                  : searchText
                    ? `Exportar ${productsToExport.length} resultado(s) do filtro`
                    : `Exportar todos os ${productsToExport.length} produto(s)`}>
                <Download size={14} className="mr-1" />
                Baixar CSV{productsToExport.length ? ` (${productsToExport.length})` : ""}
              </Button>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    size="sm"
                    variant={freezeActive ? "default" : "outline"}
                    title="Configurar fixação de cabeçalho e colunas"
                  >
                    {freezeActive ? <PinOff size={14} className="mr-1" /> : <Pin size={14} className="mr-1" />}
                    {freezeActive ? "Fixado" : "Fixar"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-60 p-3" align="end">
                  <div className="text-xs font-semibold mb-2 text-muted-foreground">Fixar painéis</div>
                  <label className="flex items-center gap-2 py-1.5 cursor-pointer text-sm">
                    <Checkbox
                      checked={freezeRows}
                      onCheckedChange={(v) => toggleFreezeRows(!!v)}
                    />
                    Fixar cabeçalho (vertical)
                  </label>
                  <label className="flex items-center gap-2 py-1.5 cursor-pointer text-sm">
                    <Checkbox
                      checked={freezeCols}
                      onCheckedChange={(v) => toggleFreezeCols(!!v)}
                    />
                    Fixar colunas (horizontal)
                  </label>
                </PopoverContent>
              </Popover>
              <Button size="sm" onClick={addProduct}><Plus size={14} className="mr-1" />Produto</Button>
            </div>
          </div>

          {/* Spreadsheet */}
          <div className="bg-card border border-border rounded-xl overflow-hidden shadow-sm">
            <div
              className={`overflow-auto thick-scrollbar pb-1 ${freezeRows ? "max-h-[calc(100vh-220px)]" : ""}`}
            >
              <table className="text-sm border-collapse min-w-max w-full">
                {/* Group header row */}
                <thead className={freezeRows ? "sticky top-0 z-30" : ""}>
                  {(() => {
                    // Visibility helpers per group
                    const groupVisible = (groupId: string, cols: ColDef[]) =>
                      cols.filter((c) => !isHidden(groupColId(groupId, c.key as string)));
                    const visibleExtras = extraColumns.filter((c) => !isHidden(`extra:${c.id}`));
                    const visibleResCount = RES_COL_IDS.filter((id) => !isHidden(id)).length;
                    const idCols = 2 /*actions+index*/ + (isHidden("meta:name") ? 0 : 1) + (isHidden("meta:sku") ? 0 : 1);
                    return (
                      <tr className="text-[11px] uppercase tracking-wider">
                        {idCols > 0 && (
                          <th
                            colSpan={idCols}
                            className="bg-secondary/80 px-3 py-2 text-left text-muted-foreground border-b border-border"
                            style={stickyCol("actions", "header")}
                          >
                            Identificação
                          </th>
                        )}
                        {groups.map((g) => {
                          const vis = groupVisible(g.id, g.cols);
                          if (vis.length === 0) return null;
                          return (
                            <th key={g.id} colSpan={vis.length}
                              className={`${g.tone} px-3 py-2 text-center font-bold border-b border-border border-l border-border/40`}>
                              {g.label}
                            </th>
                          );
                        })}
                        {visibleExtras.length > 0 && (
                          <th colSpan={visibleExtras.length} className="bg-secondary/80 px-3 py-2 text-center text-muted-foreground border-b border-border border-l border-border/40">
                            Extras
                          </th>
                        )}
                        {visibleResCount > 0 && (
                          <th colSpan={visibleResCount} className="bg-accent/15 text-accent px-3 py-2 text-center font-bold border-b border-border border-l border-border/40">
                            Resultado
                          </th>
                        )}
                      </tr>
                    );
                  })()}
                  {/* Column header row */}
                  <tr className="bg-secondary/50 text-foreground text-xs">
                    <th
                      className={`px-2 py-3 text-center font-semibold relative ${stickyBg("header")}`}
                      style={{ width: ACTIONS_W, minWidth: ACTIONS_W, ...stickyCol("actions", "header") }}
                    >
                      <Popover>
                        <PopoverTrigger asChild>
                          <button
                            type="button"
                            title="Mostrar/ocultar colunas"
                            className="p-1 rounded text-muted-foreground hover:text-accent hover:bg-accent/10 transition"
                          >
                            <Eye size={14} />
                          </button>
                        </PopoverTrigger>
                        <PopoverContent align="start" className="w-72 max-h-[70vh] overflow-auto p-3">
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-xs font-semibold text-foreground">Colunas visíveis</span>
                            <button
                              type="button"
                              onClick={resetColumnLayout}
                              className="inline-flex items-center gap-1 text-[10px] px-2 py-1 rounded bg-secondary hover:bg-accent/20 hover:text-accent text-muted-foreground transition"
                              title="Mostrar todas + restaurar larguras padrão"
                            >
                              <RotateCcw size={11} /> Restaurar padrão
                            </button>
                          </div>
                          {(() => {
                            const sections: { title: string; items: { id: string; label: string; alwaysOn?: boolean }[] }[] = [
                              { title: "Identificação", items: [
                                { id: "meta:name", label: "Produto", alwaysOn: true },
                                { id: "meta:sku", label: "SKU" },
                              ]},
                              { title: "Produto", items: GROUP_PRODUCT.map(c => ({ id: groupColId("product", c.key as string), label: c.label })) },
                              { title: "Pagamento", items: GROUP_PAYMENT.map(c => ({ id: groupColId("payment", c.key as string), label: c.label })) },
                              { title: "Plataforma & Impostos", items: GROUP_PLATFORM.map(c => ({ id: groupColId("platform", c.key as string), label: c.label })) },
                              { title: "Logística & Embalagem", items: GROUP_LOGISTICS.map(c => ({ id: groupColId("logistics", c.key as string), label: c.label })) },
                              { title: "Marketing", items: GROUP_MARKETING.map(c => ({ id: groupColId("marketing", c.key as string), label: c.label })) },
                              ...(extraColumns.length ? [{ title: "Extras", items: extraColumns.map(c => ({ id: `extra:${c.id}`, label: c.label })) }] : []),
                              { title: "Resultado", items: [
                                { id: "res:margin_input", label: "Margem / Markup" },
                                { id: "res:old_price", label: "Sug. preço antigo" },
                                { id: "res:sug_card1x", label: "Sug. Cartão 1x" },
                                { id: "res:sug_pix", label: "Sug. Pix" },
                                { id: "res:sug_boleto", label: "Sug. Boleto" },
                                { id: "res:profit", label: "Lucro/un sugerido" },
                                { id: "res:margin_real", label: "Margem real" },
                                { id: "res:current_price", label: "Preço atual" },
                                { id: "res:current_profit", label: "Lucro atual" },
                                { id: "res:current_margin", label: "Margem atual" },
                              ]},
                            ];
                            return sections.map((s) => (
                              <div key={s.title} className="mb-3 last:mb-0">
                                <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">{s.title}</div>
                                <div className="space-y-1">
                                  {s.items.map((it) => (
                                    <label key={it.id} className={`flex items-center gap-2 text-xs ${it.alwaysOn ? "opacity-60" : "cursor-pointer hover:text-foreground"}`}>
                                      <Checkbox
                                        checked={!isHidden(it.id)}
                                        disabled={it.alwaysOn}
                                        onCheckedChange={(v) => toggleHidden(it.id, !v)}
                                      />
                                      <span>{it.label}</span>
                                    </label>
                                  ))}
                                </div>
                              </div>
                            ));
                          })()}
                        </PopoverContent>
                      </Popover>
                    </th>
                    <th
                      className={`px-3 py-3 text-left font-semibold ${stickyBg("header")}`}
                      style={{ width: INDEX_W, minWidth: INDEX_W, ...stickyCol("index", "header") }}
                    >
                      <div className="flex items-center gap-1.5">
                        <input
                          type="checkbox"
                          aria-label="Selecionar todos visíveis"
                          checked={allFilteredSelected}
                          onChange={toggleSelectAllFiltered}
                          className="h-3.5 w-3.5 accent-accent cursor-pointer"
                        />
                        <span>#</span>
                      </div>
                    </th>
                    {!isHidden("meta:name") && (
                      <th
                        className={`px-3 py-3 text-left font-semibold relative ${stickyBg("header")}`}
                        style={{ ...widthStyle("meta:name"), ...stickyCol("meta:name", "header") }}
                      >
                        Produto
                        <Resizer id="meta:name" defaultW={DEFAULT_WIDTHS["meta:name"]} />
                      </th>
                    )}
                    {!isHidden("meta:sku") && (
                      <th
                        className={`px-3 py-3 text-left font-semibold relative ${stickyBg("header")}`}
                        style={{ ...widthStyle("meta:sku"), ...stickyCol("meta:sku", "header") }}
                      >
                        SKU
                        <Resizer id="meta:sku" defaultW={DEFAULT_WIDTHS["meta:sku"]} />
                      </th>
                    )}
                    {groups.map((g) =>
                      g.cols.map((c) => {
                        const id = groupColId(g.id, c.key as string);
                        if (isHidden(id)) return null;
                        const isToggable = (c.key as string) in NATIVE_KIND;
                        const field = c.key as TogglableField;
                        const kind = isToggable ? effectiveKind(settings.column_kinds, field) : null;
                        const dynSuffix = kind ? (kind === "pct" ? "%" : "R$") : c.suffix;
                        return (
                          <th key={String(c.key)} className="px-2 py-3 text-right font-semibold whitespace-nowrap group relative" style={widthStyle(id)}>
                            <div>{c.label}</div>
                            <div className="text-[10px] font-normal text-muted-foreground">{dynSuffix}</div>
                            {isToggable && (
                              <button
                                onClick={() => toggleFixedColumnKind(field)}
                                title="Alternar entre % e R$"
                                className="text-[9px] font-semibold mt-1 px-1.5 py-0.5 rounded bg-secondary hover:bg-accent/20 hover:text-accent text-muted-foreground transition"
                              >
                                {kind === "pct" ? "%" : "R$"} ⇄
                              </button>
                            )}
                            <Resizer id={id} defaultW={DEFAULT_WIDTHS[id] ?? 110} />
                          </th>
                        );
                      })
                    )}
                    {extraColumns.map((c) => {
                      const id = `extra:${c.id}`;
                      if (isHidden(id)) return null;
                      return (
                        <th key={c.id} className="px-2 py-3 text-right font-semibold whitespace-nowrap group relative" style={widthStyle(id)}>
                          <div className="inline-flex items-center gap-1 justify-end">
                            {c.label}
                            <button onClick={() => removeExtraColumn(c.id)} className="opacity-0 group-hover:opacity-100 transition text-metric-red" title="Remover coluna">
                              <X size={11} />
                            </button>
                          </div>
                          <button
                            onClick={() => toggleExtraColumnKind(c.id)}
                            title="Alternar entre % e R$"
                            className="text-[10px] font-semibold mt-0.5 px-1.5 py-0.5 rounded bg-secondary hover:bg-accent/20 hover:text-accent text-muted-foreground transition"
                          >
                            {c.kind === "pct" ? "%" : "R$"} ⇄
                          </button>
                          <Resizer id={id} defaultW={DEFAULT_WIDTHS[id] ?? 110} />
                        </th>
                      );
                    })}
                    {!isHidden("res:margin_input") && (
                      <th className="px-2 py-3 text-right font-semibold relative" style={widthStyle("res:margin_input")}>
                        <div>Margem / Markup</div>
                        <div className="text-[10px] font-normal text-muted-foreground">% ou multiplicador ×</div>
                        <Resizer id="res:margin_input" defaultW={DEFAULT_WIDTHS["res:margin_input"]} />
                      </th>
                    )}
                    {!isHidden("res:old_price") && (
                      <th className="px-2 py-3 text-right font-semibold text-muted-foreground relative" style={widthStyle("res:old_price")}>
                        <div>Sug. preço antigo</div>
                        <div className="text-[10px] font-normal opacity-70">R$ (de) · −{(settings.old_price_discount_pct ?? 15)}%</div>
                        <Resizer id="res:old_price" defaultW={DEFAULT_WIDTHS["res:old_price"]} />
                      </th>
                    )}
                    {!isHidden("res:sug_card1x") && (
                      <th className="px-2 py-3 text-right font-semibold text-metric-blue relative" style={widthStyle("res:sug_card1x")}>
                        <div>Sug. Cartão 1x</div>
                        <div className="text-[10px] font-normal opacity-70">R$ (preço cheio)</div>
                        <Resizer id="res:sug_card1x" defaultW={DEFAULT_WIDTHS["res:sug_card1x"]} />
                      </th>
                    )}
                    {!isHidden("res:sug_pix") && (
                      <th className="px-2 py-3 text-right font-semibold text-accent relative" style={widthStyle("res:sug_pix")}>
                        <div>Sug. Pix</div>
                        <div className="text-[10px] font-normal opacity-70">
                          {(settings.pix_discount_pct ?? 0) > 0
                            ? `R$ · −${settings.pix_discount_pct}% Pix`
                            : "R$"}
                        </div>
                        <Resizer id="res:sug_pix" defaultW={DEFAULT_WIDTHS["res:sug_pix"]} />
                      </th>
                    )}
                    {!isHidden("res:sug_boleto") && (
                      <th className="px-2 py-3 text-right font-semibold text-metric-amber relative" style={widthStyle("res:sug_boleto")}>
                        <div>Sug. Boleto</div>
                        <div className="text-[10px] font-normal opacity-70">R$</div>
                        <Resizer id="res:sug_boleto" defaultW={DEFAULT_WIDTHS["res:sug_boleto"]} />
                      </th>
                    )}
                    {!isHidden("res:profit") && (
                      <th className="px-2 py-3 text-right font-semibold text-accent relative" style={widthStyle("res:profit")}>
                        <div>Lucro/un</div>
                        <div className="text-[10px] font-normal opacity-70">R$</div>
                        <Resizer id="res:profit" defaultW={DEFAULT_WIDTHS["res:profit"]} />
                      </th>
                    )}
                    {!isHidden("res:margin_real") && (
                      <th className="px-2 py-3 text-right font-semibold relative" style={widthStyle("res:margin_real")}>
                        <div>Margem</div>
                        <div className="text-[10px] font-normal text-muted-foreground">real %</div>
                        <Resizer id="res:margin_real" defaultW={DEFAULT_WIDTHS["res:margin_real"]} />
                      </th>
                    )}
                    {!isHidden("res:current_price") && (
                      <th className="px-2 py-3 text-right font-semibold text-metric-blue relative" style={widthStyle("res:current_price")}>
                        <div>Preço atual</div>
                        <div className="text-[10px] font-normal opacity-70">R$</div>
                        <Resizer id="res:current_price" defaultW={DEFAULT_WIDTHS["res:current_price"]} />
                      </th>
                    )}
                    {!isHidden("res:current_profit") && (
                      <th className="px-2 py-3 text-right font-semibold text-metric-blue relative" style={widthStyle("res:current_profit")}>
                        <div>Lucro atual</div>
                        <div className="text-[10px] font-normal opacity-70">R$</div>
                        <Resizer id="res:current_profit" defaultW={DEFAULT_WIDTHS["res:current_profit"]} />
                      </th>
                    )}
                    {!isHidden("res:current_margin") && (
                      <th className="px-2 py-3 text-right font-semibold text-metric-blue relative" style={widthStyle("res:current_margin")}>
                        <div>Margem</div>
                        <div className="text-[10px] font-normal opacity-70">atual %</div>
                        <Resizer id="res:current_margin" defaultW={DEFAULT_WIDTHS["res:current_margin"]} />
                      </th>
                    )}
                  </tr>
                </thead>
                <tbody>
                  {merged.length === 0 && (
                    <tr><td colSpan={totalCols} className="text-center py-12 text-muted-foreground text-sm">
                      Nenhum produto. Clique em <strong>+ Produto</strong> para começar.
                    </td></tr>
                  )}
                  {merged.length > 0 && filteredProducts.length === 0 && (
                    <tr><td colSpan={totalCols} className="text-center py-12 text-muted-foreground text-sm">
                      Nenhum produto corresponde a “{searchText}”.
                    </td></tr>
                  )}
                  {filteredProducts.map((p, idx) => {
                    // Preço cheio = Sug. Cartão 1x. Sug. Pix é desconto promocional sobre ele.
                    const r = computeSuggestedByMethod(rowOf(p), settings, "card1x");
                    const isSel = p.id === selectedId;
                    const isChecked = selectedIds.has(p.id);
                    const cur = computeCurrentProfit(r, Number(p.current_price));
                    return (
                      <tr key={p.id}
                        onClick={() => setSelectedId(p.id)}
                        className={`border-t border-border cursor-pointer transition-colors ${isSel ? "bg-accent/10" : "hover:bg-secondary/40"}`}>
                        <td
                          className={`px-2 py-2 ${stickyBg("body")}`}
                          style={{ width: ACTIONS_W, minWidth: ACTIONS_W, ...stickyCol("actions", "body") }}
                        >
                          <div className="flex items-center gap-1 justify-center" onClick={(e) => e.stopPropagation()}>
                            <button
                              onClick={() => removeProduct(p)}
                              title="Excluir produto"
                              className="p-1 rounded text-muted-foreground hover:text-metric-red hover:bg-metric-red/10 transition"
                            >
                              <Trash2 size={14} />
                            </button>
                            <button
                              onClick={() => duplicateProduct(p)}
                              title="Duplicar produto"
                              className="p-1 rounded text-muted-foreground hover:text-accent hover:bg-accent/10 transition"
                            >
                              <Copy size={14} />
                            </button>
                          </div>
                        </td>
                        <td
                          className={`px-3 py-2 text-muted-foreground text-xs ${stickyBg("body")}`}
                          style={{ width: INDEX_W, minWidth: INDEX_W, ...stickyCol("index", "body") }}
                        >
                          <div className="flex items-center gap-1.5">
                            <input
                              type="checkbox"
                              aria-label={`Selecionar ${p.name}`}
                              checked={isChecked}
                              onClick={(e) => e.stopPropagation()}
                              onChange={() => toggleSelect(p.id)}
                              className="h-3.5 w-3.5 accent-accent cursor-pointer"
                            />
                            <span>{idx + 1}</span>
                          </div>
                        </td>
                        {!isHidden("meta:name") && (
                          <td
                            className={`px-3 py-2 ${stickyBg("body")}`}
                            style={{ ...widthStyle("meta:name"), ...stickyCol("meta:name", "body") }}
                          >
                            <CellInput value={p.name} onChange={(v) => updateField(p, "name", v as any)} text />
                          </td>
                        )}
                        {!isHidden("meta:sku") && (
                          <td
                            className={`px-3 py-2 ${stickyBg("body")}`}
                            style={{ ...widthStyle("meta:sku"), ...stickyCol("meta:sku", "body") }}
                          >
                            <CellInput value={p.sku ?? ""} onChange={(v) => updateField(p, "sku", v as any)} text />
                          </td>
                        )}
                        {groups.map((g) =>
                          g.cols.map((c) => {
                            const id = groupColId(g.id, c.key as string);
                            if (isHidden(id)) return null;
                            return (
                              <td key={String(c.key)} className={`px-2 py-2 ${g.cellTone}`} style={widthStyle(id)}>
                                <CellInput value={p[c.key] as number} onChange={(v) => updateField(p, c.key, v as any)} />
                              </td>
                            );
                          })
                        )}
                        {extraColumns.map((c) => {
                          const id = `extra:${c.id}`;
                          if (isHidden(id)) return null;
                          const found = p.extra_costs?.find((e) => e.id === c.id);
                          return (
                            <td key={c.id} className="px-2 py-2 bg-secondary/20" style={widthStyle(id)}>
                              <CellInput value={found?.value ?? 0} onChange={(v) => setExtra(p, c.id, v as number)} />
                            </td>
                          );
                        })}
                        {!isHidden("res:margin_input") && (
                          <td className="px-2 py-2" style={widthStyle("res:margin_input")}>
                            <div className="flex items-center gap-1 justify-end">
                              <CellInput value={p.desired_margin_pct} onChange={(v) => updateField(p, "desired_margin_pct", v as any)} />
                              <span className="text-[10px] text-muted-foreground shrink-0 w-3">
                                {p.margin_mode === "markup" ? "×" : "%"}
                              </span>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  const cur = Number(p.desired_margin_pct) || 0;
                                  if (p.margin_mode === "markup") {
                                    const pct = cur > 0 ? Math.round((1 - 1 / cur) * 1000) / 10 : 20;
                                    setDrafts((d) => ({ ...d, [p.id]: { ...d[p.id], margin_mode: "margin", desired_margin_pct: pct } }));
                                    upsert.mutateAsync({ id: p.id, client_id: p.client_id, margin_mode: "margin", desired_margin_pct: pct } as any)
                                      .then(() => setDrafts((d) => { const { [p.id]: _, ...rest } = d; return rest; }));
                                  } else {
                                    const mult = cur < 100 ? Math.round((1 / (1 - cur / 100)) * 100) / 100 : 2;
                                    setDrafts((d) => ({ ...d, [p.id]: { ...d[p.id], margin_mode: "markup", desired_margin_pct: mult } }));
                                    upsert.mutateAsync({ id: p.id, client_id: p.client_id, margin_mode: "markup", desired_margin_pct: mult } as any)
                                      .then(() => setDrafts((d) => { const { [p.id]: _, ...rest } = d; return rest; }));
                                  }
                                }}
                                title={p.margin_mode === "markup"
                                  ? "Markup: multiplicador sobre o custo (ex: 2 = preço 2× o custo). Clique para usar Margem %."
                                  : "Margem: % sobre o preço de venda (máx. <100%). Clique para usar Markup ×."}
                                className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-secondary hover:bg-accent/20 hover:text-accent text-muted-foreground transition shrink-0"
                              >
                                {p.margin_mode === "markup" ? "×" : "%"} ⇄
                              </button>
                            </div>
                          </td>
                        )}
                        {(() => {
                          const isMarkup = p.margin_mode === "markup";
                          const impossible =
                            r.sellingPrice === 0 &&
                            r.totalFixedCosts > 0 &&
                            (isMarkup
                              ? r.totalDeductionsPct >= 100
                              : (r.totalDeductionsPct + Number(p.desired_margin_pct || 0)) >= 100);
                          if (impossible) {
                            // Span only the visible suggestion/result cells (excluding margin_input which is already rendered)
                            const span = ["res:old_price", "res:sug_card1x", "res:sug_pix", "res:sug_boleto", "res:profit", "res:margin_real"]
                              .filter((id) => !isHidden(id)).length;
                            if (span === 0) return null;
                            return (
                              <td colSpan={span} className="px-2 py-2 text-right text-xs bg-metric-red/10 text-metric-red font-medium"
                                title={isMarkup
                                  ? `Deduções (${r.totalDeductionsPct.toFixed(1)}%) ≥ 100% — impossível precificar mesmo em modo markup. Reduza as deduções.`
                                  : `Margem desejada (${Number(p.desired_margin_pct).toFixed(1)}%) + deduções (${r.totalDeductionsPct.toFixed(1)}%) somam ${(r.totalDeductionsPct + Number(p.desired_margin_pct||0)).toFixed(1)}% — impossível precificar. Reduza a margem, troque para Markup, ou reduza as deduções.`}>
                                ⚠ {isMarkup ? "Deduções ≥ 100%" : "Margem + deduções ≥ 100%"} — impossível
                              </td>
                            );
                          }
                          const sBoleto = computeSuggestedByMethod(rowOf(p), settings, "boleto");
                          const pix = computePixWithDiscount(r.sellingPrice, rowOf(p), settings);
                          const disc = Number(settings.old_price_discount_pct ?? 0);
                          const oldPrice = disc > 0 && disc < 100 && r.sellingPrice > 0
                            ? r.sellingPrice / (1 - disc / 100)
                            : 0;
                          return (
                            <>
                              {!isHidden("res:old_price") && (
                                <td className="px-2 py-2 text-right font-semibold text-muted-foreground bg-secondary/30 whitespace-nowrap" style={widthStyle("res:old_price")}>
                                  <div className="line-through opacity-80">{oldPrice > 0 ? fmtBRL(oldPrice) : "—"}</div>
                                  {oldPrice > 0 && (
                                    <div className="text-[10px] font-normal opacity-70">−{disc}%</div>
                                  )}
                                </td>
                              )}
                              {!isHidden("res:sug_card1x") && (
                                <td className="px-2 py-2 text-right font-semibold text-metric-blue bg-metric-blue/[0.04] whitespace-nowrap" style={widthStyle("res:sug_card1x")}>
                                  <div>{fmtBRL(r.sellingPrice)}</div>
                                  <div className="text-[10px] font-normal text-muted-foreground">{fmtPct(r.netMarginPct)}</div>
                                </td>
                              )}
                              {!isHidden("res:sug_pix") && (
                                <td className="px-2 py-2 text-right font-semibold text-accent bg-accent/[0.04] whitespace-nowrap" style={widthStyle("res:sug_pix")}>
                                  <div>{pix.sellingPrice > 0 ? fmtBRL(pix.sellingPrice) : "—"}</div>
                                  <div className="text-[10px] font-normal text-muted-foreground">
                                    {pix.sellingPrice > 0
                                      ? (pix.discountPct > 0 ? `−${pix.discountPct}% · ${fmtPct(pix.netMarginPct)}` : fmtPct(pix.netMarginPct))
                                      : ""}
                                  </div>
                                </td>
                              )}
                              {!isHidden("res:sug_boleto") && (
                                <td className="px-2 py-2 text-right font-semibold text-metric-amber bg-metric-amber/[0.04] whitespace-nowrap" style={widthStyle("res:sug_boleto")}>
                                  <div>{sBoleto.sellingPrice > 0 ? fmtBRL(sBoleto.sellingPrice) : "—"}</div>
                                  <div className="text-[10px] font-normal text-muted-foreground">{sBoleto.sellingPrice > 0 ? fmtPct(sBoleto.netMarginPct) : ""}</div>
                                </td>
                              )}
                              {!isHidden("res:profit") && (
                                <td className={`px-2 py-2 text-right font-semibold bg-accent/[0.04] ${r.netProfit > 0 ? "text-metric-green" : "text-metric-red"}`} style={widthStyle("res:profit")}>
                                  {fmtBRL(r.netProfit)}
                                </td>
                              )}
                              {!isHidden("res:margin_real") && (
                                <td className="px-2 py-2 text-right text-muted-foreground bg-accent/[0.04]" style={widthStyle("res:margin_real")}>{fmtPct(r.netMarginPct)}</td>
                              )}
                            </>
                          );
                        })()}
                        {!isHidden("res:current_price") && (
                          <td className="px-2 py-2 bg-metric-blue/[0.06]" style={widthStyle("res:current_price")}>
                            <CellInput value={p.current_price ?? 0} onChange={(v) => updateField(p, "current_price", v as any)} />
                          </td>
                        )}
                        {!isHidden("res:current_profit") && (
                          <td className={`px-2 py-2 text-right font-semibold bg-metric-blue/[0.06] ${!cur.hasPrice ? "text-muted-foreground" : cur.netProfit > 0 ? "text-metric-green" : "text-metric-red"}`} style={widthStyle("res:current_profit")}>
                            {cur.hasPrice ? fmtBRL(cur.netProfit) : "—"}
                          </td>
                        )}
                        {!isHidden("res:current_margin") && (
                          <td className={`px-2 py-2 text-right bg-metric-blue/[0.06] ${!cur.hasPrice ? "text-muted-foreground" : cur.netProfit > 0 ? "text-metric-green" : "text-metric-red"}`} style={widthStyle("res:current_margin")}>
                            {cur.hasPrice ? fmtPct(cur.netMarginPct) : "—"}
                          </td>
                        )}
                      </tr>
                    );
                  })}
                </tbody>
                {merged.length > 0 && (() => {
                  // Leading cells: actions + index + (name) + (sku) + visible group cols + visible extras + margin_input
                  const leadingSpan =
                    2
                    + (isHidden("meta:name") ? 0 : 1)
                    + (isHidden("meta:sku") ? 0 : 1)
                    + groups.reduce((a, g) => a + g.cols.filter((c) => !isHidden(groupColId(g.id, c.key as string))).length, 0)
                    + extraColumns.filter((c) => !isHidden(`extra:${c.id}`)).length
                    + (isHidden("res:margin_input") ? 0 : 1);
                  return (
                    <tfoot className="bg-secondary/60 text-foreground border-t-2 border-border">
                      <tr>
                        <td
                          colSpan={leadingSpan}
                          className={`px-3 py-3 font-bold text-sm ${stickyBg("footer")}`}
                          style={stickyCol("actions", "footer")}
                        >
                          Totais ({totals.count} produtos)
                        </td>
                        {!isHidden("res:old_price") && (
                          <td className="px-2 py-3 text-right text-muted-foreground text-xs bg-secondary/30">—</td>
                        )}
                        {!isHidden("res:sug_card1x") && (
                          <td className="px-2 py-3 text-right font-bold text-accent">{fmtBRL(totals.price)}</td>
                        )}
                        {!isHidden("res:sug_pix") && (
                          <td className="px-2 py-3 text-right text-muted-foreground text-xs">—</td>
                        )}
                        {!isHidden("res:sug_boleto") && (
                          <td className="px-2 py-3 text-right text-muted-foreground text-xs">—</td>
                        )}
                        {!isHidden("res:profit") && (
                          <td className="px-2 py-3 text-right font-bold text-metric-green">{fmtBRL(totals.profit)}</td>
                        )}
                        {!isHidden("res:margin_real") && (
                          <td className="px-2 py-3 text-right text-muted-foreground text-xs">
                            {fmtPct(totals.count ? totals.avgMargin / totals.count : 0)} médio
                          </td>
                        )}
                        {!isHidden("res:current_price") && (
                          <td className="px-2 py-3 text-right font-bold text-metric-blue">{fmtBRL(totals.currentPrice)}</td>
                        )}
                        {!isHidden("res:current_profit") && (
                          <td className={`px-2 py-3 text-right font-bold ${totals.currentProfit >= 0 ? "text-metric-green" : "text-metric-red"}`}>{fmtBRL(totals.currentProfit)}</td>
                        )}
                        {!isHidden("res:current_margin") && (
                          <td className="px-2 py-3 text-right text-muted-foreground text-xs">
                            {totals.currentCount ? `${fmtPct(totals.currentMarginSum / totals.currentCount)} médio` : "—"}
                          </td>
                        )}
                      </tr>
                    </tfoot>
                  );
                })()}

              </table>
            </div>
          </div>

          {/* Detail panel */}
          {selected && sel && be && (
            <>
              <div className="flex items-center gap-2 pt-2">
                <Sparkles size={16} className="text-accent" />
                <h2 className="text-sm font-semibold text-foreground">
                  Análise — <span className="text-accent">{selected.name}</span>
                </h2>
              </div>

              {currentCmp && currentCmp.hasPrice && (
                <div className="bg-card border border-border rounded-xl p-5">
                  <h3 className="text-sm font-semibold text-foreground mb-3">Preço sugerido vs Preço atual</h3>
                  <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                    <Stat label="Preço sugerido" value={fmtBRL(sel.sellingPrice)} accent />
                    <Stat label="Preço atual" value={fmtBRL(Number(selected.current_price))} />
                    <Stat
                      label={currentCmp.diffVsSuggested >= 0 ? "Acima do sugerido" : "Abaixo do sugerido"}
                      value={`${currentCmp.diffVsSuggested >= 0 ? "+" : ""}${fmtBRL(currentCmp.diffVsSuggested)} (${currentCmp.diffPct >= 0 ? "+" : ""}${currentCmp.diffPct.toFixed(1)}%)`}
                      accent={currentCmp.diffVsSuggested >= 0}
                      danger={currentCmp.diffVsSuggested < 0}
                    />
                    <Stat label="Lucro/un atual" value={fmtBRL(currentCmp.netProfit)}
                      accent={currentCmp.netProfit > 0} danger={currentCmp.netProfit <= 0} />
                    <Stat label="Lucro/un sugerido" value={fmtBRL(sel.netProfit)} />
                  </div>
                </div>
              )}

              {/* Installments */}
              <div className="bg-card border border-border rounded-xl p-5">
                <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
                  <div className="flex items-center gap-2">
                    <CreditCard size={16} className="text-metric-blue" />
                    <h3 className="text-sm font-semibold text-foreground">Parcelamento no cartão</h3>
                    <span className="text-xs text-muted-foreground">— calculado sobre {fmtBRL(installmentPrice)}</span>
                  </div>
                  <div className="inline-flex bg-secondary rounded-lg p-1">
                    <button
                      onClick={() => setInstallmentPriceMode("sug")}
                      className={`px-3 py-1 text-xs rounded ${installmentPriceMode === "sug" ? "bg-background text-foreground shadow-sm" : "text-muted-foreground"}`}
                    >Preço sugerido</button>
                    <button
                      onClick={() => setInstallmentPriceMode("atual")}
                      disabled={!Number(selected.current_price)}
                      className={`px-3 py-1 text-xs rounded ${installmentPriceMode === "atual" ? "bg-background text-foreground shadow-sm" : "text-muted-foreground"} disabled:opacity-40`}
                    >Preço atual</button>
                  </div>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="text-muted-foreground border-b border-border">
                        <th className="text-left py-2 px-2 font-semibold">Parcelas</th>
                        <th className="text-right py-2 px-2 font-semibold">Valor da parcela</th>
                        <th className="text-right py-2 px-2 font-semibold">Taxa total</th>
                        <th className="text-right py-2 px-2 font-semibold">Líquido recebido</th>
                        <th className="text-right py-2 px-2 font-semibold">Lucro/un</th>
                        <th className="text-right py-2 px-2 font-semibold">Margem</th>
                      </tr>
                    </thead>
                    <tbody>
                      {installments.map((i) => (
                        <tr key={i.n} className={`border-b border-border/40 ${i.netProfit <= 0 ? "bg-metric-red/5" : ""}`}>
                          <td className="py-2 px-2 font-semibold text-foreground">{i.n}x</td>
                          <td className="py-2 px-2 text-right text-foreground">{fmtBRL(i.installmentValue)}</td>
                          <td className="py-2 px-2 text-right text-muted-foreground">{fmtPct(i.rate, 2)}</td>
                          <td className="py-2 px-2 text-right text-foreground">{fmtBRL(i.netReceived)}</td>
                          <td className={`py-2 px-2 text-right font-semibold ${i.netProfit > 0 ? "text-metric-green" : "text-metric-red"}`}>{fmtBRL(i.netProfit)}</td>
                          <td className={`py-2 px-2 text-right ${i.netMarginPct > 0 ? "text-metric-green" : "text-metric-red"}`}>{fmtPct(i.netMarginPct)}</td>
                        </tr>
                      ))}
                      {installments.length === 0 && (
                        <tr><td colSpan={6} className="py-4 text-center text-muted-foreground">
                          Configure as taxas em <strong>Configurar taxas</strong> no topo.
                        </td></tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Payment breakdown */}
              <div className="bg-card border border-border rounded-xl p-5">
                <div className="flex items-center gap-2 mb-4">
                  <Wallet size={16} className="text-metric-green" />
                  <h3 className="text-sm font-semibold text-foreground">Quanto sobra por meio de pagamento</h3>
                  <span className="text-xs text-muted-foreground">— sobre {fmtBRL(installmentPrice)}</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
                  {paymentBreakdown.map((m) => (
                    <div key={m.method} className="bg-secondary/40 border border-border rounded-lg p-3">
                      <p className="text-xs text-muted-foreground font-semibold">{m.label}</p>
                      <p className="text-sm font-bold text-foreground mt-1">{fmtBRL(m.netReceived)}</p>
                      <p className="text-[10px] uppercase tracking-wider text-muted-foreground mt-2">Lucro/un</p>
                      <p className={`text-sm font-semibold ${m.netProfit > 0 ? "text-metric-green" : "text-metric-red"}`}>
                        {fmtBRL(m.netProfit)} <span className="text-[10px] opacity-70">({fmtPct(m.netMarginPct)})</span>
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                {/* Composition */}
                <div className="bg-card border border-border rounded-xl p-5">
                  <div className="flex items-center gap-2 mb-3">
                    <PieIcon size={16} className="text-accent" />
                    <h3 className="text-sm font-semibold text-foreground">Composição do Preço</h3>
                  </div>
                  <div className="h-56">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie data={composition} dataKey="value" nameKey="name" innerRadius={45} outerRadius={80} paddingAngle={2}>
                          {composition.map((c, i) => <Cell key={i} fill={c.color} />)}
                        </Pie>
                        <Tooltip formatter={(v: number) => fmtBRL(v)} contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8 }} />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                  <ul className="space-y-1.5 mt-2">
                    {composition.map((c) => (
                      <li key={c.name} className="flex items-center justify-between text-xs">
                        <span className="flex items-center gap-2 text-muted-foreground">
                          <span className="w-2.5 h-2.5 rounded-sm" style={{ background: c.color }} />{c.name}
                        </span>
                        <span className="text-foreground font-medium">{fmtBRL(c.value)}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Break-even */}
                <div className="bg-card border border-border rounded-xl p-5 space-y-3">
                  <div className="flex items-center gap-2">
                    <Target size={16} className="text-metric-amber" />
                    <h3 className="text-sm font-semibold text-foreground">Ponto de Equilíbrio</h3>
                  </div>
                  <Stat label="ROAS mínimo" value={Number.isFinite(be.minRoas) ? `${be.minRoas.toFixed(2)}x` : "—"} accent />
                  <Stat label="CPA máximo" value={fmtBRL(be.maxCpa)} accent />
                  <Stat label="Verba de ads embutida no preço (por venda)" value={fmtBRL(sel.adsBudgetPerUnit)} />
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    Ads pago acima de <strong className="text-foreground">{fmtBRL(be.maxCpa)}</strong> por venda zera o lucro.
                  </p>
                </div>

                {/* Sensitivity */}
                <div className="bg-card border border-border rounded-xl p-5">
                  <div className="flex items-center gap-2 mb-3">
                    <Sparkles size={16} className="text-accent" />
                    <h3 className="text-sm font-semibold text-foreground">Sensibilidade de Preço</h3>
                  </div>
                  <table className="w-full text-xs">
                    <thead className="text-muted-foreground">
                      <tr className="border-b border-border">
                        <th className="text-left py-1.5">Δ</th>
                        <th className="text-right py-1.5">Novo preço</th>
                        <th className="text-right py-1.5">Lucro/un</th>
                      </tr>
                    </thead>
                    <tbody>
                      {sensitivity.map((row) => (
                        <tr key={row.delta} className={`border-b border-border/50 ${row.delta === 0 ? "bg-secondary/40" : ""}`}>
                          <td className={`py-1.5 font-medium ${row.delta > 0 ? "text-metric-green" : row.delta < 0 ? "text-metric-red" : "text-foreground"}`}>
                            {row.delta > 0 ? "+" : ""}{row.delta}%
                          </td>
                          <td className="text-right text-foreground">{fmtBRL(row.newPrice)}</td>
                          <td className="text-right text-foreground">{fmtBRL(row.newProfit)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          )}
        </div>
      </main>
    </div>
  );
};

function CellInput({ value, onChange, text }: { value: string | number; onChange: (v: string | number) => void; text?: boolean }) {
  const [local, setLocal] = useState(String(value ?? ""));
  useEffect(() => { setLocal(String(value ?? "")); }, [value]);
  return (
    <input
      type={text ? "text" : "number"}
      step={text ? undefined : "0.5"}
      value={local}
      onClick={(e) => e.stopPropagation()}
      onFocus={(e) => e.currentTarget.select()}
      onChange={(e) => setLocal(e.target.value)}
      onBlur={() => {
        const v = text ? local : (parseFloat(local) || 0);
        if (v !== value) onChange(v);
      }}
      className="w-full bg-transparent border border-transparent hover:border-border focus:border-accent rounded px-2 py-1.5 text-foreground text-sm text-right focus:outline-none focus:bg-background"
      style={text ? { textAlign: "left" } : undefined}
    />
  );
}

function Stat({ label, value, accent, danger }: { label: string; value: string; accent?: boolean; danger?: boolean }) {
  return (
    <div className="bg-secondary/40 border border-border rounded-lg p-3">
      <p className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</p>
      <p className={`text-base font-bold mt-1 ${danger ? "text-metric-red" : accent ? "text-accent" : "text-foreground"}`}>{value}</p>
    </div>
  );
}

function ExtraColumnDialog({ onAdd }: { onAdd: (label: string, kind: "pct" | "value") => void }) {
  const [open, setOpen] = useState(false);
  const [label, setLabel] = useState("");
  const [kind, setKind] = useState<"pct" | "value">("pct");
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="sm" variant="outline"><Plus size={14} className="mr-1" />Coluna</Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader><DialogTitle>Nova coluna de custo</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div>
            <Label className="text-xs">Nome da coluna</Label>
            <Input value={label} onChange={(e) => setLabel(e.target.value)} placeholder="Ex: Comissão Vendedor" />
          </div>
          <div>
            <Label className="text-xs">Tipo</Label>
            <div className="flex gap-2 mt-1">
              <Button size="sm" variant={kind === "pct" ? "default" : "outline"} onClick={() => setKind("pct")}>Percentual (%)</Button>
              <Button size="sm" variant={kind === "value" ? "default" : "outline"} onClick={() => setKind("value")}>Valor R$</Button>
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button onClick={() => { if (label.trim()) { onAdd(label.trim(), kind); setLabel(""); setOpen(false); } }}>
            Adicionar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function SettingsDialog({
  clientId, current, onSave,
}: {
  clientId: string | null;
  current: PricingSettingsRow | null | undefined;
  onSave: (s: Partial<PricingSettingsRow>) => Promise<void>;
}) {
  const [open, setOpen] = useState(false);
  const initial = current ?? { ...DEFAULT_SETTINGS, installment_rates: DEFAULT_INSTALLMENT_RATES };
  const [rates, setRates] = useState<InstallmentRate[]>(initial.installment_rates);
  const [mixCard, setMixCard] = useState(initial.mix_card_pct);
  const [mixPix, setMixPix] = useState(initial.mix_pix_pct);
  const [mixBoleto, setMixBoleto] = useState(initial.mix_boleto_pct);
  const [pixFee, setPixFee] = useState(initial.pix_fee_pct);
  const [boletoFee, setBoletoFee] = useState(initial.boleto_fee_value);
  const [gatewayPct, setGatewayPct] = useState(initial.gateway_pct);
  const [oldDiscount, setOldDiscount] = useState<number>(initial.old_price_discount_pct ?? 15);
  const [pixDiscount, setPixDiscount] = useState<number>(initial.pix_discount_pct ?? 5);
  const [kinds, setKinds] = useState<Record<string, "pct" | "value">>(
    (initial.column_kinds as any) ?? {},
  );
  const kindOf = (f: "pix_pct" | "boleto_value" | "gateway_pct"): "pct" | "value" =>
    kinds[f] ?? (f === "boleto_value" ? "value" : "pct");
  const toggleKind = (f: "pix_pct" | "boleto_value" | "gateway_pct") =>
    setKinds((k) => ({ ...k, [f]: kindOf(f) === "pct" ? "value" : "pct" }));

  useEffect(() => {
    if (!open) return;
    const i = current ?? { ...DEFAULT_SETTINGS, installment_rates: DEFAULT_INSTALLMENT_RATES };
    setRates(i.installment_rates);
    setMixCard(i.mix_card_pct); setMixPix(i.mix_pix_pct); setMixBoleto(i.mix_boleto_pct);
    setPixFee(i.pix_fee_pct); setBoletoFee(i.boleto_fee_value); setGatewayPct(i.gateway_pct);
    setOldDiscount(i.old_price_discount_pct ?? 15);
    setPixDiscount(i.pix_discount_pct ?? 5);
    setKinds(((i as any).column_kinds as any) ?? {});
  }, [open, current]);

  const setRate = (n: number, rate: number) => {
    setRates((rs) => {
      const copy = [...rs];
      const idx = copy.findIndex((r) => r.n === n);
      if (idx >= 0) copy[idx] = { n, rate };
      else copy.push({ n, rate });
      return copy.sort((a, b) => a.n - b.n);
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="sm" variant="outline" disabled={!clientId}>
          <Settings size={14} className="mr-1" /> Configurar taxas
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
        <DialogHeader><DialogTitle>Taxas e meios de pagamento</DialogTitle></DialogHeader>
        <div className="space-y-5">
          <div>
            <h4 className="text-sm font-semibold mb-2">Taxas padrão</h4>
            <div className="grid grid-cols-3 gap-3">
              {([
                { f: "pix_pct" as const, label: "Pix", value: pixFee, set: setPixFee, step: "0.1" },
                { f: "boleto_value" as const, label: "Boleto", value: boletoFee, set: setBoletoFee, step: "0.5" },
                { f: "gateway_pct" as const, label: "Gateway", value: gatewayPct, set: setGatewayPct, step: "0.1" },
              ]).map((it) => {
                const k = kindOf(it.f);
                return (
                  <div key={it.f}>
                    <div className="flex items-center justify-between mb-1">
                      <Label className="text-xs">{it.label} ({k === "pct" ? "%" : "R$"})</Label>
                      <button
                        type="button"
                        onClick={() => toggleKind(it.f)}
                        className="text-[10px] px-1.5 py-0.5 rounded border border-border hover:bg-muted text-muted-foreground"
                        title="Alternar entre % e R$"
                      >
                        {k === "pct" ? "→ R$" : "→ %"}
                      </button>
                    </div>
                    <Input type="number" step={it.step} value={it.value} onChange={(e) => it.set(parseFloat(e.target.value) || 0)} />
                  </div>
                );
              })}
            </div>
            <p className="text-[11px] text-muted-foreground mt-1">Estes valores podem ser sobrescritos por produto.</p>
          </div>

          <div>
            <h4 className="text-sm font-semibold mb-2">Desconto Pix promocional</h4>
            <div className="flex items-end gap-3">
              <div className="flex-1 max-w-[180px]">
                <Label className="text-xs">Desconto Pix (%)</Label>
                <Input
                  type="number"
                  step="0.5"
                  min={0}
                  max={99}
                  value={pixDiscount}
                  onChange={(e) => setPixDiscount(Math.min(99, Math.max(0, parseFloat(e.target.value) || 0)))}
                />
              </div>
              <p className="text-[11px] text-muted-foreground pb-2">
                Padrão e-commerce: <strong>Cartão</strong> é o preço cheio do site e <strong>Pix</strong> ganha
                desconto promocional (ex.: 5% off). Use 0 para desativar.
              </p>
            </div>
          </div>

          <div>
            <h4 className="text-sm font-semibold mb-2">Preço antigo (de/por)</h4>
            <div className="flex items-end gap-3">
              <div className="flex-1 max-w-[180px]">
                <Label className="text-xs">Desconto (%)</Label>
                <Input
                  type="number"
                  step="0.5"
                  min={0}
                  max={99}
                  value={oldDiscount}
                  onChange={(e) => setOldDiscount(Math.min(99, Math.max(0, parseFloat(e.target.value) || 0)))}
                />
              </div>
              <p className="text-[11px] text-muted-foreground pb-2">
                Usado na coluna <strong>Sug. preço antigo</strong> para calcular o preço cheio
                (Sug. Cartão ÷ (1 − desconto%)). Define o "de" do produto.
              </p>
            </div>
          </div>

          <div>
            <h4 className="text-sm font-semibold mb-2">Taxas de parcelamento (1x até 12x)</h4>
            <div className="grid grid-cols-2 gap-2">
              {Array.from({ length: 12 }, (_, i) => i + 1).map((n) => {
                const r = rates.find((x) => x.n === n)?.rate ?? 0;
                return (
                  <div key={n} className="flex items-center gap-2">
                    <span className="text-xs text-muted-foreground w-10">{n}x</span>
                    <Input type="number" step="0.1" value={r} onChange={(e) => setRate(n, parseFloat(e.target.value) || 0)} className="h-9" />
                    <span className="text-xs text-muted-foreground">%</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>Cancelar</Button>
          <Button onClick={async () => {
            await onSave({
              installment_rates: rates,
              mix_card_pct: mixCard, mix_pix_pct: mixPix, mix_boleto_pct: mixBoleto,
              pix_fee_pct: pixFee, boleto_fee_value: boletoFee, gateway_pct: gatewayPct,
              max_installments: 12,
              old_price_discount_pct: oldDiscount,
              pix_discount_pct: pixDiscount,
              column_kinds: { ...(current?.column_kinds ?? {}), ...kinds } as any,
            });
            setOpen(false);
          }}>Salvar</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export default PricingPage;
