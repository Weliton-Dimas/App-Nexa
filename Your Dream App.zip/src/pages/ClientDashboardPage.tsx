import { useParams, useNavigate } from "react-router-dom";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { SAFE_CLIENT_COLUMNS } from "@/lib/clientConstants";
import { useQuery } from "@tanstack/react-query";
import {
  ArrowLeft,
  LayoutGrid,
  ShoppingCart,
  ClipboardList,
  Activity,
  TrendingUp,
  Megaphone,
  Package,
  Users,
  ChevronDown,
  ChevronLeft,
  Pencil,
  Calendar as CalendarIcon,
  ArrowLeftRight,
  FileText,
  SlidersHorizontal,
  RefreshCw,
  Info,
  BarChart3,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { AreaChart, Area, BarChart, Bar, ResponsiveContainer } from "recharts";
import { ClientCampaignsTab } from "@/components/ClientCampaignsTab";
import { MetaAccountPicker } from "@/components/MetaAccountPicker";
import { GaMetricsWidget } from "@/components/GaMetricsWidget";
import { MetaAdsMiniDashboard } from "@/components/MetaAdsMiniDashboard";
import { useMetaAdsMetrics } from "@/hooks/useMetaAdsMetrics";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { format, subMonths, startOfMonth, endOfMonth } from "date-fns";
import { ptBR } from "date-fns/locale";
import type { DateRange } from "react-day-picker";

type Grouping = "day" | "week" | "month";
type ChartFormat = "area" | "bar";

interface CardConfig {
  visible: boolean;
}

const DEFAULT_CARD_CONFIG: CardConfig = { visible: true };

interface GlobalChartConfig {
  grouping: Grouping;
  format: ChartFormat;
}

const formatCurrency = (value: number) =>
  value.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
const formatNumber = (value: number, digits = 2) =>
  value.toLocaleString("pt-BR", { minimumFractionDigits: digits, maximumFractionDigits: digits });
const formatInt = (value: number) => Math.round(value).toLocaleString("pt-BR");

function Sparkline({ seed = 1, grouping = "day", format = "area" }: { seed?: number; grouping?: Grouping; format?: ChartFormat }) {
  const points = grouping === "month" ? 12 : grouping === "week" ? 12 : 28;
  const data = Array.from({ length: points }, (_, i) => ({
    x: i,
    y: 30 + Math.sin(i / 2 + seed) * 14 + Math.cos(i / 3 + seed * 2) * 10 + (seed % 5) * 2,
  }));
  const id = `csp-${seed}-${grouping}-${format}`;
  return (
    <ResponsiveContainer width="100%" height="100%">
      {format === "bar" ? (
        <BarChart data={data} margin={{ top: 4, right: 0, left: 0, bottom: 0 }}>
          <Bar dataKey="y" fill="hsl(var(--metric-blue))" radius={[2, 2, 0, 0]} />
        </BarChart>
      ) : (
        <AreaChart data={data} margin={{ top: 4, right: 0, left: 0, bottom: 0 }}>
          <defs>
            <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="hsl(var(--metric-blue))" stopOpacity={0.35} />
              <stop offset="100%" stopColor="hsl(var(--metric-blue))" stopOpacity={0} />
            </linearGradient>
          </defs>
          <Area type="monotone" dataKey="y" stroke="hsl(var(--metric-blue))" strokeWidth={2} fill={`url(#${id})`} dot={false} />
        </AreaChart>
      )}
    </ResponsiveContainer>
  );
}

function PlatformBadge({ type }: { type: "meta" | "google" | "mixed" | "shopify" }) {
  if (type === "meta") {
    return (
      <div className="w-5 h-5 rounded-full bg-[#1877F2]/15 flex items-center justify-center text-[10px] font-bold text-[#1877F2]">
        ƒ
      </div>
    );
  }
  if (type === "google") {
    return (
      <div className="w-5 h-5 rounded-full bg-[#FBBC05]/15 flex items-center justify-center text-[9px] font-bold text-[#FBBC05]">
        G
      </div>
    );
  }
  if (type === "shopify") {
    return (
      <div className="w-5 h-5 rounded-full bg-[#95BF47]/15 flex items-center justify-center text-[10px] font-bold text-[#95BF47]">
        S
      </div>
    );
  }
  return (
    <div className="flex -space-x-1">
      <div className="w-5 h-5 rounded-full bg-[#FBBC05] border border-card" />
      <div className="w-5 h-5 rounded-full bg-[#EA4335] border border-card" />
      <div className="w-5 h-5 rounded-full bg-[#1877F2] border border-card" />
      <div className="w-5 h-5 rounded-full bg-foreground/80 border border-card" />
    </div>
  );
}

function GlobalChartSettingsPopover({
  config,
  onChange,
}: {
  config: GlobalChartConfig;
  onChange: (c: GlobalChartConfig) => void;
}) {
  return (
    <Popover>
      <PopoverTrigger asChild>
        <button className="w-10 h-10 rounded-xl border border-border/60 flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
          <SlidersHorizontal size={14} />
        </button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-72 p-4 space-y-4">
        <div>
          <p className="text-[10px] font-bold uppercase text-muted-foreground tracking-wider mb-2">Agrupamento Temporal</p>
          <div className="grid grid-cols-3 gap-1 p-1 bg-secondary rounded-lg">
            {(["day", "week", "month"] as Grouping[]).map((g) => (
              <button
                key={g}
                onClick={() => onChange({ ...config, grouping: g })}
                className={cn(
                  "text-xs font-medium py-1.5 rounded-md transition-colors",
                  config.grouping === g ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"
                )}
              >
                {g === "day" ? "Dia" : g === "week" ? "Semana" : "Mês"}
              </button>
            ))}
          </div>
        </div>
        <div>
          <p className="text-[10px] font-bold uppercase text-muted-foreground tracking-wider mb-2">Formato do Gráfico</p>
          <div className="grid grid-cols-2 gap-1 p-1 bg-secondary rounded-lg">
            {(["area", "bar"] as ChartFormat[]).map((f) => (
              <button
                key={f}
                onClick={() => onChange({ ...config, format: f })}
                className={cn(
                  "text-xs font-medium py-1.5 rounded-md transition-colors",
                  config.format === f ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"
                )}
              >
                {f === "area" ? "Área" : "Colunas"}
              </button>
            ))}
          </div>
        </div>
      </PopoverContent>
    </Popover>
  );
}

interface MetricCardProps {
  cardKey: string;
  label: string;
  value: string;
  platform?: "meta" | "google" | "mixed" | "shopify";
  seed?: number;
  config: CardConfig;
  onConfigChange: (c: CardConfig) => void;
  globalChart: GlobalChartConfig;
}

function ClientMetricCard({ label, value, platform = "mixed", seed = 1, config, onConfigChange, globalChart }: MetricCardProps) {
  return (
    <div className="rounded-2xl bg-card border border-border/60 p-5 flex flex-col min-h-[180px] relative overflow-hidden">
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-center gap-1.5">
          <p className="text-sm text-foreground font-semibold">{label}</p>
          <Info size={11} className="text-muted-foreground/60" />
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => onConfigChange({ ...config, visible: !config.visible })}
            className="text-muted-foreground/60 hover:text-foreground transition-colors"
            title={config.visible ? "Ocultar gráfico" : "Mostrar gráfico"}
          >
            <BarChart3 size={12} />
          </button>
          <PlatformBadge type={platform} />
        </div>
      </div>
      <p className="text-3xl font-bold text-foreground tabular-nums tracking-tight mt-3">{value}</p>
      {config.visible && (
        <div className="flex-1 -mx-1 mt-2 min-h-[60px]">
          <Sparkline seed={seed} grouping={globalChart.grouping} format={globalChart.format} />
        </div>
      )}
    </div>
  );
}

interface SmallMetricProps {
  cardKey: string;
  label: string;
  value: string;
  platform?: "meta" | "google" | "mixed" | "shopify";
  seed?: number;
  config: CardConfig;
  onConfigChange: (c: CardConfig) => void;
  globalChart: GlobalChartConfig;
}

function SmallMetricCard({ label, value, platform = "mixed", seed = 1, config, onConfigChange, globalChart }: SmallMetricProps) {
  return (
    <div className={cn("rounded-2xl bg-card border border-border/60 p-5 flex flex-col", config.visible ? "min-h-[200px]" : "min-h-[120px]")}>
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-center gap-1.5">
          <p className="text-sm text-foreground font-semibold">{label}</p>
          <Info size={11} className="text-muted-foreground/60" />
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => onConfigChange({ ...config, visible: !config.visible })}
            className="text-muted-foreground/60 hover:text-foreground transition-colors"
            title={config.visible ? "Ocultar gráfico" : "Mostrar gráfico"}
          >
            <BarChart3 size={12} />
          </button>
          <PlatformBadge type={platform} />
        </div>
      </div>
      <p className="text-2xl font-bold text-foreground tabular-nums tracking-tight mt-3">{value}</p>
      {config.visible && (
        <div className="flex-1 -mx-1 mt-2 min-h-[60px]">
          <Sparkline seed={seed} grouping={globalChart.grouping} format={globalChart.format} />
        </div>
      )}
    </div>
  );
}

interface NavItem {
  key: string;
  label: string;
  icon: typeof LayoutGrid;
  hasChevron?: boolean;
}

const NAV_ITEMS: NavItem[] = [
  { key: "resumo", label: "Resumo", icon: LayoutGrid },
  { key: "ecommerce", label: "Ecommerce", icon: ShoppingCart, hasChevron: true },
  { key: "lancamentos", label: "Lançamentos Manuais", icon: ClipboardList },
  { key: "trafego", label: "Tráfego", icon: Activity },
  { key: "growth", label: "Growth", icon: TrendingUp },
  { key: "campanhas", label: "Campanhas", icon: Megaphone },
  { key: "produtos", label: "Produtos", icon: Package, hasChevron: true },
  { key: "influencers", label: "Influencers", icon: Users },
];

function IconBtn({ children, onClick }: { children: React.ReactNode; onClick?: () => void }) {
  return (
    <button
      onClick={onClick}
      className="w-10 h-10 rounded-xl border border-border/60 flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors"
    >
      {children}
    </button>
  );
}

export default function ClientDashboardPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [activeNav, setActiveNav] = useState("resumo");
  const [collapsed, setCollapsed] = useState(false);

  const today = new Date();
  const [dateRange, setDateRange] = useState<DateRange | undefined>({
    from: startOfMonth(today),
    to: today,
  });
  const [compareRange, setCompareRange] = useState<DateRange | undefined>(undefined);
  const [compareMode, setCompareMode] = useState(false);

  const [cardConfigs, setCardConfigs] = useState<Record<string, CardConfig>>({});
  const getConfig = (key: string): CardConfig => cardConfigs[key] ?? DEFAULT_CARD_CONFIG;
  const setConfig = (key: string) => (c: CardConfig) =>
    setCardConfigs((prev) => ({ ...prev, [key]: c }));

  const [globalChart, setGlobalChart] = useState<GlobalChartConfig>({ grouping: "day", format: "area" });

  const { data: client, isLoading } = useQuery({
    queryKey: ["client", id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("clients")
        .select(SAFE_CLIENT_COLUMNS)
        .eq("id", id!)
        .single();
      if (error) throw error;
      return data;
    },
    enabled: !!id,
  });

  const { data: allClients } = useQuery({
    queryKey: ["clients-list"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("clients")
        .select("id, name")
        .order("name", { ascending: true });
      if (error) throw error;
      return data;
    },
  });

  const { data: gaLink } = useQuery({
    queryKey: ["client-ga-link", id],
    enabled: !!id,
    queryFn: async () => {
      const { data } = await supabase
        .from("client_integrations")
        .select("account_id, status")
        .eq("client_id", id!)
        .eq("provider", "google_analytics")
        .maybeSingle();
      return data;
    },
  });

  const fmtDate = (d?: Date) => (d ? format(d, "dd/MM/yyyy") : "");
  const toApiDate = (d?: Date) => (d ? format(d, "yyyy-MM-dd") : null);
  const since = toApiDate(dateRange?.from);
  const until = toApiDate(dateRange?.to);

  const { data: metaMetrics, isLoading: metaLoading, error: metaError } = useMetaAdsMetrics({
    clientId: id,
    since,
    until,
  });

  if (isLoading) {
    return (
      <div className="flex h-screen bg-background items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }

  if (!client) {
    return (
      <div className="flex h-screen bg-background items-center justify-center">
        <div className="text-center space-y-2">
          <p className="text-foreground font-semibold">Cliente não encontrado</p>
          <button onClick={() => navigate("/dashboard")} className="text-sm text-accent hover:underline">
            Voltar ao Dashboard
          </button>
        </div>
      </div>
    );
  }

  const m = metaMetrics;
  const resultLabel =
    m?.resultType === "purchase"
      ? "Compras"
      : m?.resultType === "lead"
      ? "Leads"
      : m?.resultType === "conversation"
      ? "Conversas"
      : "Resultados";

  const dateRangeLabel =
    dateRange?.from && dateRange?.to ? `${fmtDate(dateRange.from)} - ${fmtDate(dateRange.to)}` : "Selecionar período";
  const compareRangeLabel =
    compareRange?.from && compareRange?.to ? `${fmtDate(compareRange.from)} - ${fmtDate(compareRange.to)}` : "";

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      {/* Client sidebar */}
      <aside
        className={cn(
          "shrink-0 border-r border-border/60 bg-background flex flex-col transition-all",
          collapsed ? "w-16" : "w-60"
        )}
      >
        <button
          onClick={() => navigate("/dashboard")}
          className="flex items-center gap-3 px-4 py-4 text-sm text-foreground hover:bg-secondary transition-colors border-b border-border/60"
        >
          <ArrowLeft size={16} className="text-muted-foreground shrink-0" />
          {!collapsed && <span className="truncate">Voltar ao Dashboard</span>}
        </button>

        <nav className="flex-1 overflow-y-auto py-3 px-2 space-y-0.5">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const active = activeNav === item.key;
            return (
              <button
                key={item.key}
                onClick={() => setActiveNav(item.key)}
                className={cn(
                  "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors",
                  active
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:text-foreground hover:bg-secondary"
                )}
              >
                <Icon size={16} className="shrink-0" />
                {!collapsed && (
                  <>
                    <span className="flex-1 text-left truncate">{item.label}</span>
                    {item.hasChevron && <ChevronDown size={14} className="opacity-60" />}
                  </>
                )}
              </button>
            );
          })}
        </nav>

        <button
          onClick={() => setCollapsed((v) => !v)}
          className="border-t border-border/60 px-4 py-3 text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors flex items-center justify-center"
        >
          <ChevronLeft size={16} className={cn("transition-transform", collapsed && "rotate-180")} />
        </button>
      </aside>

      {/* Main */}
      <main className="flex-1 overflow-y-auto">
        {/* Header */}
        <header className="flex items-center justify-between gap-3 px-6 py-4 border-b border-border/60 sticky top-0 bg-background z-10">
          <div className="flex items-center gap-2">
            <LayoutGrid size={16} className="text-muted-foreground" />
            <Select value={id} onValueChange={(v) => navigate(`/clients/${v}`)}>
              <SelectTrigger className="h-9 w-auto min-w-[220px] gap-2 border border-border bg-secondary/40 hover:bg-secondary px-3 text-base font-semibold text-foreground transition-colors">
                <SelectValue>{client.name}</SelectValue>
              </SelectTrigger>
              <SelectContent className="max-h-[400px]">
                {allClients?.map((c) => (
                  <SelectItem key={c.id} value={c.id}>
                    {c.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <button className="p-1 rounded-md hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors">
              <Pencil size={12} />
            </button>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {id && <MetaAccountPicker clientId={id} />}
            <Popover>
              <PopoverTrigger asChild>
                <button className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-border/60 text-sm text-foreground hover:bg-secondary transition-colors">
                  <CalendarIcon size={14} className="text-muted-foreground" />
                  <span className="tabular-nums">{dateRangeLabel}</span>
                </button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="end">
                <Calendar
                  mode="range"
                  selected={dateRange}
                  onSelect={setDateRange}
                  numberOfMonths={2}
                  locale={ptBR}
                  className={cn("p-3 pointer-events-auto")}
                />
              </PopoverContent>
            </Popover>

            {compareMode && compareRange?.from && compareRange?.to && (
              <Popover>
                <PopoverTrigger asChild>
                  <button className="flex items-center gap-2 px-3 py-2 rounded-xl border border-primary/40 bg-primary/10 text-sm text-primary hover:bg-primary/20 transition-colors">
                    <CalendarIcon size={14} />
                    <span className="text-xs">vs</span>
                    <span className="tabular-nums">{compareRangeLabel}</span>
                    <span
                      role="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setCompareMode(false);
                        setCompareRange(undefined);
                      }}
                      className="ml-1 hover:bg-primary/20 rounded p-0.5"
                    >
                      <X size={12} />
                    </span>
                  </button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="end">
                  <Calendar
                    mode="range"
                    selected={compareRange}
                    onSelect={setCompareRange}
                    numberOfMonths={2}
                    locale={ptBR}
                    className={cn("p-3 pointer-events-auto")}
                  />
                </PopoverContent>
              </Popover>
            )}

            <IconBtn
              onClick={() => {
                if (compareMode) {
                  setCompareMode(false);
                  setCompareRange(undefined);
                } else {
                  if (dateRange?.from && dateRange?.to) {
                    setCompareRange({
                      from: startOfMonth(subMonths(dateRange.from, 1)),
                      to: endOfMonth(subMonths(dateRange.from, 1)),
                    });
                  }
                  setCompareMode(true);
                }
              }}
            >
              <ArrowLeftRight size={14} className={cn(compareMode && "text-primary")} />
            </IconBtn>
            <IconBtn><FileText size={14} /></IconBtn>
            <GlobalChartSettingsPopover config={globalChart} onChange={setGlobalChart} />
            <IconBtn><RefreshCw size={14} /></IconBtn>
          </div>
        </header>

        {/* Content */}
        <div className="p-6 space-y-8">
          {activeNav === "campanhas" ? (
            <ClientCampaignsTab clientName={client.name} />
          ) : activeNav === "resumo" ? (
            <>
              {metaError && (
                <div className="rounded-lg border border-destructive/40 bg-destructive/10 p-4 text-sm text-destructive">
                  Não foi possível carregar métricas do Meta: {(metaError as Error).message}
                </div>
              )}

              {/* GERAL META */}
              <section>
                <div className="flex items-center justify-between mb-4">
                  <p className="text-xs font-bold uppercase text-muted-foreground tracking-wider">Meta Ads — Geral</p>
                  {metaLoading && (
                    <span className="text-[10px] text-muted-foreground">Atualizando...</span>
                  )}
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <ClientMetricCard cardKey="m-inv" label="Investido" value={formatCurrency(m?.spend ?? 0)} platform="meta" seed={1} config={getConfig("m-inv")} onConfigChange={setConfig("m-inv")} globalChart={globalChart} />
                  <ClientMetricCard cardKey="m-results" label={resultLabel} value={formatInt(m?.results ?? 0)} platform="meta" seed={2} config={getConfig("m-results")} onConfigChange={setConfig("m-results")} globalChart={globalChart} />
                  <ClientMetricCard cardKey="m-cpr" label={`Custo por ${resultLabel.replace(/s$/, "")}`} value={formatCurrency(m?.costPerResult ?? 0)} platform="meta" seed={3} config={getConfig("m-cpr")} onConfigChange={setConfig("m-cpr")} globalChart={globalChart} />
                  <ClientMetricCard cardKey="m-roas" label={m && m.purchaseValue > 0 ? "ROAS" : "Valor de Compras"} value={m && m.purchaseValue > 0 ? formatNumber(m.roas) : formatCurrency(m?.purchaseValue ?? 0)} platform="meta" seed={4} config={getConfig("m-roas")} onConfigChange={setConfig("m-roas")} globalChart={globalChart} />
                </div>
              </section>

              {/* ALCANCE & ENTREGA */}
              <section>
                <p className="text-xs font-bold uppercase text-muted-foreground tracking-wider mb-4">Alcance & Entrega</p>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <SmallMetricCard cardKey="m-reach" label="Alcance" value={formatInt(m?.reach ?? 0)} platform="meta" seed={5} config={getConfig("m-reach")} onConfigChange={setConfig("m-reach")} globalChart={globalChart} />
                  <SmallMetricCard cardKey="m-freq" label="Frequência" value={formatNumber(m?.frequency ?? 0)} platform="meta" seed={6} config={getConfig("m-freq")} onConfigChange={setConfig("m-freq")} globalChart={globalChart} />
                  <SmallMetricCard cardKey="m-impr" label="Impressões" value={formatInt(m?.impressions ?? 0)} platform="meta" seed={7} config={getConfig("m-impr")} onConfigChange={setConfig("m-impr")} globalChart={globalChart} />
                  <SmallMetricCard cardKey="m-cpm" label="CPM" value={formatCurrency(m?.cpm ?? 0)} platform="meta" seed={8} config={getConfig("m-cpm")} onConfigChange={setConfig("m-cpm")} globalChart={globalChart} />
                </div>
              </section>

              {/* ENGAJAMENTO & CLIQUES */}
              <section>
                <p className="text-xs font-bold uppercase text-muted-foreground tracking-wider mb-4">Engajamento & Cliques</p>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <SmallMetricCard cardKey="m-clicks" label="Cliques" value={formatInt(m?.clicks ?? 0)} platform="meta" seed={9} config={getConfig("m-clicks")} onConfigChange={setConfig("m-clicks")} globalChart={globalChart} />
                  <SmallMetricCard cardKey="m-ctr" label="CTR" value={`${formatNumber(m?.ctr ?? 0)}%`} platform="meta" seed={10} config={getConfig("m-ctr")} onConfigChange={setConfig("m-ctr")} globalChart={globalChart} />
                  <SmallMetricCard cardKey="m-cpc" label="CPC" value={formatCurrency(m?.cpc ?? 0)} platform="meta" seed={11} config={getConfig("m-cpc")} onConfigChange={setConfig("m-cpc")} globalChart={globalChart} />
                  <SmallMetricCard cardKey="m-link" label="Cliques no link" value={formatInt(m?.linkClicks ?? 0)} platform="meta" seed={12} config={getConfig("m-link")} onConfigChange={setConfig("m-link")} globalChart={globalChart} />
                </div>
              </section>

              {/* CONVERSÕES */}
              <section>
                <p className="text-xs font-bold uppercase text-muted-foreground tracking-wider mb-4">Conversões</p>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <SmallMetricCard cardKey="m-purchases" label="Compras" value={formatInt(m?.purchases ?? 0)} platform="meta" seed={13} config={getConfig("m-purchases")} onConfigChange={setConfig("m-purchases")} globalChart={globalChart} />
                  <SmallMetricCard cardKey="m-leads" label="Leads" value={formatInt(m?.leads ?? 0)} platform="meta" seed={14} config={getConfig("m-leads")} onConfigChange={setConfig("m-leads")} globalChart={globalChart} />
                  <SmallMetricCard cardKey="m-atc" label="Add to Cart" value={formatInt(m?.addToCart ?? 0)} platform="meta" seed={15} config={getConfig("m-atc")} onConfigChange={setConfig("m-atc")} globalChart={globalChart} />
                  <SmallMetricCard cardKey="m-ic" label="Initiate Checkout" value={formatInt(m?.initiateCheckout ?? 0)} platform="meta" seed={16} config={getConfig("m-ic")} onConfigChange={setConfig("m-ic")} globalChart={globalChart} />
                </div>
              </section>

              {/* MENSAGENS */}
              {(m?.conversations ?? 0) + (m?.messages ?? 0) > 0 && (
                <section>
                  <p className="text-xs font-bold uppercase text-muted-foreground tracking-wider mb-4">Mensagens</p>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    <SmallMetricCard cardKey="m-conv" label="Conversas" value={formatInt(m?.conversations ?? 0)} platform="meta" seed={17} config={getConfig("m-conv")} onConfigChange={setConfig("m-conv")} globalChart={globalChart} />
                    <SmallMetricCard cardKey="m-msg" label="Mensagens" value={formatInt(m?.messages ?? 0)} platform="meta" seed={18} config={getConfig("m-msg")} onConfigChange={setConfig("m-msg")} globalChart={globalChart} />
                    <SmallMetricCard cardKey="m-cpconv" label="Custo / Conversa" value={formatCurrency(m?.costPerConversation ?? 0)} platform="meta" seed={19} config={getConfig("m-cpconv")} onConfigChange={setConfig("m-cpconv")} globalChart={globalChart} />
                    <SmallMetricCard cardKey="m-cpmsg" label="Custo / Mensagem" value={formatCurrency(m?.costPerMessage ?? 0)} platform="meta" seed={20} config={getConfig("m-cpmsg")} onConfigChange={setConfig("m-cpmsg")} globalChart={globalChart} />
                  </div>
                </section>
              )}

              {/* BREAKDOWNS */}
              <section>
                <p className="text-xs font-bold uppercase text-muted-foreground tracking-wider mb-2">
                  Distribuição
                </p>
                <MetaAdsMiniDashboard metrics={m} loading={metaLoading} />
              </section>

              {/* GOOGLE ANALYTICS 4 */}
              {gaLink?.account_id && gaLink.status === "connected" && (
                <GaMetricsWidget clientId={id!} datePreset="last_30d" />
              )}
            </>
          ) : (
            <div className="py-24 text-center text-sm text-muted-foreground">
              A seção <span className="text-foreground font-semibold capitalize">{activeNav}</span> ainda não está disponível.
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
