import { useState, useMemo, useEffect } from "react";
import { DashboardSidebar } from "@/components/DashboardSidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Link2, Copy, Check, ExternalLink, History, Trash2, AlertTriangle, Search } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

type PresetFilter =
  | "lancamentos"
  | "maisvendidos"
  | "novidades"
  | "maioresdescontos"
  | "menorpreco"
  | "maiorpreco"
  | "personalizado";

const FILTER_PRESETS: { value: PresetFilter; label: string; suffix: string }[] = [
  { value: "lancamentos", label: "Lançamentos", suffix: "lancamentos" },
  { value: "maisvendidos", label: "Mais vendidos", suffix: "vendas" },
  { value: "novidades", label: "Novidades", suffix: "novidades" },
  { value: "maioresdescontos", label: "Maiores Descontos", suffix: "maioresdescontos" },
  { value: "menorpreco", label: "Preço menor", suffix: "menorpreco" },
  { value: "maiorpreco", label: "Preço maior", suffix: "maiorpreco" },
  { value: "personalizado", label: "Personalizado", suffix: "" },
];

const GENDER_PRESETS = [
  { value: "none", label: "Nenhum" },
  { value: "masculino", label: "Masculino" },
  { value: "feminino", label: "Feminino" },
  { value: "unissex", label: "Unissex" },
  { value: "menino", label: "Menino" },
  { value: "menina", label: "Menina" },
];

function safeTrimLines(text: string) {
  return text.split("\n").map((l) => l.trim()).filter(Boolean);
}

function normalizeUrl(input: string) {
  const trimmed = input.trim();
  if (!trimmed) return "";
  try { return new URL(trimmed).toString(); } catch { return trimmed; }
}

function toBaseSku(rawSku: string): string {
  const sku = (rawSku || "").trim();
  if (!sku) return "";
  return sku.split("-")[0].trim();
}

type ItemResult = {
  productUrl: string;
  sku?: string;
  name?: string;
  status: "ok" | "error";
  message?: string;
};

type HistoryProduct = { url: string; sku: string; name: string };
type HistoryItem = {
  id: string;
  createdAt: number;
  site: string;
  pageUrl: string;
  filter: string;
  skuCount: number;
  finalUrl: string;
  products: HistoryProduct[];
};

const HISTORY_KEY = "centralize_links_history_v1";

export default function LinksPage() {
  const { toast } = useToast();
  const [pageUrl, setPageUrl] = useState("");
  const [productUrlsText, setProductUrlsText] = useState("");
  const [filterPreset, setFilterPreset] = useState<PresetFilter>("lancamentos");
  const [customFilter, setCustomFilter] = useState("lancamentos");
  const [genderFilter, setGenderFilter] = useState("none");
  const [useBaseSku, setUseBaseSku] = useState(false);
  const [useDeepId, setUseDeepId] = useState(false);
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<ItemResult[]>([]);
  const [finalUrl, setFinalUrl] = useState<string>("");
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [copiedMain, setCopiedMain] = useState(false);
  const [copiedHistoryId, setCopiedHistoryId] = useState<string | null>(null);

  const productUrls = useMemo(
    () => safeTrimLines(productUrlsText).slice(0, 25),
    [productUrlsText],
  );

  const activeFilterSuffix = useMemo(() => {
    if (filterPreset === "personalizado") return customFilter.trim();
    return FILTER_PRESETS.find((f) => f.value === filterPreset)?.suffix || "";
  }, [filterPreset, customFilter]);

  const canGenerate = useMemo(
    () => Boolean(pageUrl.trim() && productUrls.length > 0),
    [pageUrl, productUrls.length],
  );

  useEffect(() => {
    try {
      const raw = localStorage.getItem(HISTORY_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) setHistory(parsed);
      }
    } catch {}
  }, []);

  function saveHistory(items: HistoryItem[]) {
    localStorage.setItem(HISTORY_KEY, JSON.stringify(items));
  }

  function addToHistory(item: Omit<HistoryItem, "id">) {
    const newItem: HistoryItem = {
      id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
      ...item,
    };
    setHistory((prev) => {
      const next = [newItem, ...prev].slice(0, 50);
      saveHistory(next);
      return next;
    });
  }

  function removeFromHistory(id: string) {
    setHistory((prev) => {
      const next = prev.filter((x) => x.id !== id);
      saveHistory(next);
      return next;
    });
  }

  function clearHistory() {
    setHistory([]);
    localStorage.removeItem(HISTORY_KEY);
  }

  async function handleGenerate() {
    setLoading(true);
    setResults([]);
    setFinalUrl("");

    const page = normalizeUrl(pageUrl);
    let pageParsed: URL;
    try {
      pageParsed = new URL(page);
    } catch {
      setLoading(false);
      setResults([{ productUrl: "", status: "error", message: "O link da página parece inválido." }]);
      return;
    }

    const normalizedProducts = productUrls.map(normalizeUrl);
    const localResults: ItemResult[] = [];
    const skusOk: string[] = [];
    const productsOk: HistoryProduct[] = [];

    const fetchPromises = normalizedProducts.map(async (productUrl): Promise<ItemResult> => {
      try {
        const { data, error } = await supabase.functions.invoke("extract-sku", {
          body: { productUrl },
        });
        if (error) {
          return { productUrl, status: "error", message: error.message || "Erro ao puxar SKU." };
        }
        if ((data as any)?.error) {
          return { productUrl, status: "error", message: (data as any).error };
        }
        const fetchedSku = useDeepId
          ? ((data as any)?.deepId || (data as any)?.sku)
          : ((data as any)?.sku || (data as any)?.deepId);
        const skuString = String(fetchedSku || "").trim();
        const name = String((data as any)?.name || "").trim() || "Produto sem nome";
        if (!skuString) return { productUrl, status: "error", message: "SKU vazio." };
        const finalSku = useBaseSku ? toBaseSku(skuString) : skuString;
        if (!finalSku) return { productUrl, status: "error", message: "SKU inválido." };
        return { productUrl, sku: finalSku, name, status: "ok" };
      } catch {
        return { productUrl, status: "error", message: "Falha de rede." };
      }
    });

    const resolved = await Promise.all(fetchPromises);
    for (const res of resolved) {
      localResults.push(res);
      if (res.status === "ok" && res.sku) {
        skusOk.push(`SKU-${res.sku}`);
        productsOk.push({ url: res.productUrl, sku: res.sku, name: res.name || "Produto sem nome" });
      }
    }
    setResults(localResults);

    if (skusOk.length > 0) {
      const activeFilters: string[] = [];
      if (activeFilterSuffix) activeFilters.push(activeFilterSuffix);

      let url = `${pageParsed.origin}${pageParsed.pathname}?q`;
      if (genderFilter && genderFilter !== "none") {
        url += `&caracteristica=genero%3A${genderFilter}`;
      }
      const ordemParams = [...skusOk, ...activeFilters];
      url += `&ordem=${encodeURIComponent(ordemParams.join(","))}`;

      setFinalUrl(url);

      const combinedFilterName = activeFilters.length > 0 ? activeFilters.join(" + ") : "Nenhum";
      addToHistory({
        createdAt: Date.now(),
        site: pageParsed.hostname,
        pageUrl: pageParsed.toString(),
        filter: combinedFilterName,
        skuCount: skusOk.length,
        finalUrl: url,
        products: productsOk,
      });

      toast({ title: "Link gerado!", description: `${skusOk.length} SKU(s) injetado(s) com sucesso.` });
    } else {
      toast({ title: "Nada gerado", description: "Não foi possível extrair nenhum SKU.", variant: "destructive" });
    }
    setLoading(false);
  }

  async function copyMain(text: string) {
    await navigator.clipboard.writeText(text);
    setCopiedMain(true);
    setTimeout(() => setCopiedMain(false), 2000);
  }

  async function copyHistory(text: string, id: string) {
    await navigator.clipboard.writeText(text);
    setCopiedHistoryId(id);
    setTimeout(() => setCopiedHistoryId(null), 2000);
  }

  const okCount = results.filter((r) => r.status === "ok").length;
  const errCount = results.filter((r) => r.status === "error").length;

  return (
    <div className="flex h-screen bg-background text-foreground">
      <DashboardSidebar />
      <main className="flex-1 overflow-y-auto p-6">
        <div className="max-w-5xl mx-auto space-y-6">
          {/* Header */}
          <div className="flex items-start justify-between gap-4 flex-wrap">
            <div>
              <h1 className="text-2xl font-bold flex items-center gap-2">
                <Link2 className="text-accent" size={22} />
                Reformatador de Links
              </h1>
              <p className="text-sm text-muted-foreground mt-1 max-w-2xl">
                Cole a URL da página de destino e os links de produtos (um por linha). A ferramenta encontra os SKUs ocultos e gera o link para fixar produtos no topo.
              </p>
              <div className="flex gap-2 mt-3 flex-wrap">
                <Badge variant="secondary" className="bg-metric-green/15 text-metric-green border-metric-green/30">
                  Magazord
                </Badge>
                <Badge variant="outline">Vários produtos por vez</Badge>
                <Badge variant="outline">Histórico inteligente</Badge>
              </div>
            </div>
          </div>

          {/* Form */}
          <Card>
            <CardContent className="p-6 space-y-5">
              <div className="space-y-2">
                <Label>Link da página de destino (vitrine/categoria)</Label>
                <Input
                  value={pageUrl}
                  onChange={(e) => setPageUrl(e.target.value)}
                  placeholder="Ex: https://www.loja.com.br/lancamentos"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Ordenação principal</Label>
                  <Select value={filterPreset} onValueChange={(v) => setFilterPreset(v as PresetFilter)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {FILTER_PRESETS.map((f) => (
                        <SelectItem key={f.value} value={f.value}>{f.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {filterPreset === "personalizado" && (
                    <Input
                      value={customFilter}
                      onChange={(e) => setCustomFilter(e.target.value)}
                      placeholder="ex: lancamentos"
                    />
                  )}
                </div>

                <div className="space-y-2">
                  <Label>Filtro de gênero (opcional)</Label>
                  <Select value={genderFilter} onValueChange={setGenderFilter}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {GENDER_PRESETS.map((g) => (
                        <SelectItem key={g.value} value={g.value}>{g.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <p className="text-[11px] text-metric-amber flex items-center gap-1">
                    <AlertTriangle size={11} /> Só use se a categoria original possuir este filtro.
                  </p>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Links dos produtos que ficarão no topo (um por linha)</Label>
                <Textarea
                  value={productUrlsText}
                  onChange={(e) => setProductUrlsText(e.target.value)}
                  placeholder={"https://www.loja.com.br/produto-1\nhttps://www.loja.com.br/produto-2"}
                  className="min-h-[140px]"
                />
                <p className="text-xs text-muted-foreground">{productUrls.length} de 25 links</p>
              </div>

              <div className="space-y-3 border-t border-border pt-4">
                <div className="flex items-center gap-2">
                  <Checkbox
                    id="useBaseSku"
                    checked={useBaseSku}
                    onCheckedChange={(c) => setUseBaseSku(!!c)}
                  />
                  <Label htmlFor="useBaseSku" className="text-sm cursor-pointer font-normal">
                    Cortar sufixo de variação do SKU (ex: <span className="font-mono">"1234-M"</span> vira <span className="font-mono">"1234"</span>)
                  </Label>
                </div>
                <div className="flex items-center gap-2">
                  <Checkbox
                    id="useDeepId"
                    checked={useDeepId}
                    onCheckedChange={(c) => setUseDeepId(!!c)}
                  />
                  <Label htmlFor="useDeepId" className="text-sm cursor-pointer font-normal">
                    Forçar uso do ID interno oculto{" "}
                    <span className="text-muted-foreground">(marque se o site não aceitar SKU com letras).</span>
                  </Label>
                </div>
              </div>

              <div className="flex gap-2 justify-end pt-2">
                <Button
                  variant="outline"
                  onClick={() => { setProductUrlsText(""); setResults([]); setFinalUrl(""); }}
                  disabled={loading}
                >
                  Limpar campos
                </Button>
                <Button onClick={handleGenerate} disabled={loading || !canGenerate}>
                  <Search size={14} />
                  {loading ? "Processando..." : "Gerar link personalizado"}
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Result */}
          {finalUrl && (
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Check className="text-metric-green" size={18} /> Link pronto!
                  </CardTitle>
                  <div className="flex gap-2">
                    <Badge variant="secondary">SKUs injetados: {okCount}</Badge>
                    {errCount > 0 && (
                      <Badge variant="destructive">Erros: {errCount}</Badge>
                    )}
                    <Badge variant="outline">{activeFilterSuffix || "Sem filtro"}</Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="p-3 rounded-md bg-muted/40 border border-border break-all text-sm font-mono">
                  {finalUrl}
                </div>
                <div className="flex gap-2">
                  <Button size="sm" onClick={() => copyMain(finalUrl)}>
                    {copiedMain ? <Check size={14} /> : <Copy size={14} />}
                    {copiedMain ? "Copiado!" : "Copiar link"}
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => window.open(finalUrl, "_blank", "noopener,noreferrer")}>
                    <ExternalLink size={14} /> Abrir
                  </Button>
                </div>

                {results.length > 0 && (
                  <div className="space-y-2 pt-2">
                    {results.map((r, i) => (
                      <div
                        key={i}
                        className={cn(
                          "p-3 rounded-md border text-sm flex items-center justify-between gap-3",
                          r.status === "ok"
                            ? "border-metric-green/30 bg-metric-green/5"
                            : "border-destructive/30 bg-destructive/5",
                        )}
                      >
                        <div className="min-w-0 flex-1">
                          <p className="text-xs text-muted-foreground truncate">{r.productUrl || "—"}</p>
                          {r.status === "ok" ? (
                            <p className="font-medium truncate">
                              <span className="text-metric-green font-mono">SKU-{r.sku}</span>
                              <span className="text-muted-foreground"> — {r.name}</span>
                            </p>
                          ) : (
                            <p className="text-destructive text-xs">{r.message}</p>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* History */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg flex items-center gap-2">
                  <History size={18} /> Histórico ({history.length})
                </CardTitle>
                {history.length > 0 && (
                  <Button size="sm" variant="ghost" onClick={clearHistory}>
                    <Trash2 size={14} /> Limpar tudo
                  </Button>
                )}
              </div>
            </CardHeader>
            <CardContent>
              {history.length === 0 ? (
                <p className="text-sm text-muted-foreground">Nenhum link gerado ainda.</p>
              ) : (
                <div className="space-y-2">
                  {history.map((h) => (
                    <div key={h.id} className="p-3 rounded-md border border-border bg-card/50 space-y-2">
                      <div className="flex items-center justify-between gap-2 flex-wrap">
                        <div className="min-w-0 flex-1">
                          <p className="text-sm font-medium truncate">{h.site}</p>
                          <p className="text-xs text-muted-foreground">
                            {new Date(h.createdAt).toLocaleString("pt-BR")} · {h.skuCount} SKU(s) · {h.filter}
                          </p>
                        </div>
                        <div className="flex gap-1">
                          <Button size="sm" variant="outline" onClick={() => copyHistory(h.finalUrl, h.id)}>
                            {copiedHistoryId === h.id ? <Check size={13} /> : <Copy size={13} />}
                          </Button>
                          <Button size="sm" variant="outline" onClick={() => window.open(h.finalUrl, "_blank", "noopener,noreferrer")}>
                            <ExternalLink size={13} />
                          </Button>
                          <Button size="sm" variant="ghost" onClick={() => removeFromHistory(h.id)}>
                            <Trash2 size={13} />
                          </Button>
                        </div>
                      </div>
                      <p className="text-xs font-mono break-all text-muted-foreground">{h.finalUrl}</p>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
