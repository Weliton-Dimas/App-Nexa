import { useMemo, useState } from "react";
import { DashboardSidebar } from "@/components/DashboardSidebar";
import { Plus, MoreHorizontal, RefreshCw, X, Calendar as CalendarIcon, CheckSquare, MessageSquare, Paperclip, GripVertical } from "lucide-react";
import { cn } from "@/lib/utils";
import {
  DndContext, DragEndEvent, DragOverEvent, DragOverlay, DragStartEvent,
  KeyboardSensor, PointerSensor, useDroppable, useSensor, useSensors,
} from "@dnd-kit/core";
import { SortableContext, sortableKeyboardCoordinates, useSortable, verticalListSortingStrategy, horizontalListSortingStrategy } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { useKanbanBoard, KanbanCard as TCard, KanbanColumn as TColumn, LABEL_COLORS } from "@/hooks/useKanbanBoard";
import { useUserPermissions } from "@/hooks/useUserPermissions";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import CardDetailModal from "@/components/kanban/CardDetailModal";
import { KanbanFilters, EMPTY_FILTERS, KanbanFiltersState, cardMatchesFilters, PRIORITY_OPTIONS } from "@/components/kanban/KanbanFilters";

function colorClass(color: string) {
  return LABEL_COLORS.find(c => c.key === color)?.className || "bg-slate-500";
}

function CardView({ card, k, onClick, dragging, dim }: { card: TCard; k: ReturnType<typeof useKanbanBoard>; onClick?: () => void; dragging?: boolean; dim?: boolean }) {
  const labelIds = k.cardLabels.filter(cl => cl.card_id === card.id).map(cl => cl.label_id);
  const labels = k.labels.filter(l => labelIds.includes(l.id));
  const checklist = k.checklist.filter(i => i.card_id === card.id);
  const checked = checklist.filter(i => i.done).length;
  const memberIds = k.members.filter(m => m.card_id === card.id).map(m => m.user_id);
  const memberProfiles = k.profiles.filter(p => memberIds.includes(p.user_id));
  const attCount = k.attachments.filter(a => a.card_id === card.id).length;
  const cmCount = k.comments.filter(c => c.card_id === card.id).length;

  return (
    <div
      onClick={onClick}
      className={cn(
        "bg-secondary border border-border rounded-lg p-2.5 hover:border-accent transition-all cursor-pointer space-y-2",
        dragging && "opacity-50",
        dim && "opacity-40 hover:opacity-100",
      )}
    >
      {labels.length > 0 && (
        <div className="flex flex-wrap gap-1">
          {labels.map(l => (
            <span key={l.id} className={cn("h-2 min-w-[40px] rounded", colorClass(l.color))} title={l.name}/>
          ))}
        </div>
      )}
      <p className="text-sm text-foreground leading-snug">{card.title}</p>
      {card.priority && (() => {
        const p = PRIORITY_OPTIONS.find(o => o.key === card.priority);
        if (!p) return null;
        return (
          <span className="inline-flex items-center gap-1 text-[10px] text-muted-foreground bg-muted px-1.5 py-0.5 rounded">
            <span className={cn("h-1.5 w-1.5 rounded-full", p.dot)}/> {p.label}
          </span>
        );
      })()}
      {(card.due_date || checklist.length > 0 || attCount > 0 || cmCount > 0 || memberProfiles.length > 0) && (
        <div className="flex items-center gap-2 text-xs text-muted-foreground flex-wrap">
          {card.due_date && (
            <span className="inline-flex items-center gap-1 bg-muted px-1.5 py-0.5 rounded">
              <CalendarIcon size={11}/> {format(new Date(card.due_date), "d MMM", { locale: ptBR })}
            </span>
          )}
          {checklist.length > 0 && (
            <span className="inline-flex items-center gap-1"><CheckSquare size={11}/> {checked}/{checklist.length}</span>
          )}
          {cmCount > 0 && <span className="inline-flex items-center gap-1"><MessageSquare size={11}/> {cmCount}</span>}
          {attCount > 0 && <span className="inline-flex items-center gap-1"><Paperclip size={11}/> {attCount}</span>}
          <div className="ml-auto flex -space-x-1.5">
            {memberProfiles.slice(0,3).map(p => (
              <Avatar key={p.user_id} className="h-5 w-5 ring-2 ring-card">
                {p.avatar_url && <AvatarImage src={p.avatar_url}/>}
                <AvatarFallback className="text-[9px] bg-primary/20 text-primary">{(p.display_name||"?").slice(0,2).toUpperCase()}</AvatarFallback>
              </Avatar>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function SortableCard({ card, k, onOpen, dim }: { card: TCard; k: ReturnType<typeof useKanbanBoard>; onOpen: (c: TCard) => void; dim?: boolean }) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({
    id: card.id, data: { type: "card", card },
  });
  const style = { transform: CSS.Translate.toString(transform), transition };
  return (
    <div ref={setNodeRef} style={style} {...attributes} {...listeners}>
      <CardView card={card} k={k} onClick={() => !isDragging && onOpen(card)} dragging={isDragging} dim={dim} />
    </div>
  );
}

function ColumnView({ col, k, onOpenCard, matchedIds, hasFilters }: { col: TColumn; k: ReturnType<typeof useKanbanBoard>; onOpenCard: (c: TCard) => void; matchedIds: Set<string>; hasFilters: boolean }) {
  const [adding, setAdding] = useState(false);
  const [val, setVal] = useState("");
  const [editingTitle, setEditingTitle] = useState(false);
  const [titleVal, setTitleVal] = useState(col.title);
  const { setNodeRef: setDropRef, isOver } = useDroppable({ id: col.id, data: { type: "column", columnId: col.id } });

  const sortable = useSortable({ id: col.id, data: { type: "column-handle", columnId: col.id } });
  const colStyle = { transform: CSS.Translate.toString(sortable.transform), transition: sortable.transition };

  const submit = () => {
    if (!val.trim()) { setAdding(false); return; }
    k.createCard.mutate({ columnId: col.id, title: val.trim() });
    setVal("");
  };

  // Sort: matched cards first when filters active
  const orderedCards = hasFilters
    ? [...col.cards].sort((a, b) => {
        const am = matchedIds.has(a.id) ? 0 : 1;
        const bm = matchedIds.has(b.id) ? 0 : 1;
        if (am !== bm) return am - bm;
        return a.position - b.position;
      })
    : col.cards;

  return (
    <div
      ref={sortable.setNodeRef}
      style={colStyle}
      className={cn("w-72 min-w-[280px] shrink-0 bg-card border border-border rounded-xl p-2 flex flex-col max-h-full", sortable.isDragging && "opacity-50")}
    >
      <div className="flex items-center justify-between px-2 py-1.5 gap-1">
        <button
          {...sortable.attributes}
          {...sortable.listeners}
          className="text-muted-foreground hover:text-foreground p-0.5 -ml-1 cursor-grab active:cursor-grabbing rounded hover:bg-secondary"
          title="Arrastar coluna"
          aria-label="Arrastar coluna"
        >
          <GripVertical size={14}/>
        </button>
        {editingTitle ? (
          <Input
            autoFocus value={titleVal} onChange={(e)=>setTitleVal(e.target.value)}
            onBlur={()=>{ if (titleVal.trim() && titleVal !== col.title) k.updateColumn.mutate({ id: col.id, title: titleVal.trim() }); setEditingTitle(false); }}
            onKeyDown={(e)=>e.key==="Enter" && (e.target as HTMLInputElement).blur()}
            className="h-7 text-sm font-semibold bg-secondary"
          />
        ) : (
          <button onClick={()=>setEditingTitle(true)} className="text-sm font-semibold text-foreground text-left flex-1 truncate">
            {col.title} <span className="ml-2 text-xs font-normal text-muted-foreground">{col.cards.length}</span>
          </button>
        )}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="text-muted-foreground hover:text-foreground p-1 rounded hover:bg-secondary"><MoreHorizontal size={16}/></button>
          </DropdownMenuTrigger>
          <DropdownMenuContent>
            <DropdownMenuItem onClick={()=>setAdding(true)}>Adicionar cartão</DropdownMenuItem>
            <DropdownMenuItem onClick={()=>setEditingTitle(true)}>Renomear lista</DropdownMenuItem>
            <DropdownMenuItem className="text-destructive" onClick={()=>{ if (confirm("Excluir esta lista e todos os cartões?")) k.deleteColumn.mutate(col.id); }}>Excluir lista</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <div ref={setDropRef} className={cn("flex flex-col gap-2 overflow-y-auto px-1 py-1 flex-1 min-h-[40px] rounded-md transition-colors", isOver && "bg-secondary/40")}>
        <SortableContext items={orderedCards.map(c=>c.id)} strategy={verticalListSortingStrategy}>
          {orderedCards.map(card => (
            <SortableCard key={card.id} card={card} k={k} onOpen={onOpenCard} dim={hasFilters && !matchedIds.has(card.id)}/>
          ))}
        </SortableContext>
      </div>

      <div className="px-1 pt-1">
        {adding ? (
          <div className="bg-secondary rounded-lg p-2 space-y-2">
            <textarea
              autoFocus value={val} onChange={(e)=>setVal(e.target.value)}
              onKeyDown={(e)=>{ if (e.key==="Enter" && !e.shiftKey){ e.preventDefault(); submit(); } if (e.key==="Escape"){ setAdding(false); setVal(""); } }}
              placeholder="Insira um título para este cartão..."
              className="w-full bg-card text-sm text-foreground placeholder:text-muted-foreground outline-none resize-none min-h-[60px] rounded p-2 border border-border"
            />
            <div className="flex items-center gap-2">
              <Button size="sm" onClick={submit}>Adicionar cartão</Button>
              <button onClick={()=>{ setAdding(false); setVal(""); }} className="text-muted-foreground hover:text-foreground p-1.5"><X size={16}/></button>
            </div>
          </div>
        ) : (
          <button onClick={()=>setAdding(true)} className="w-full flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground hover:bg-secondary/50 rounded-md px-2 py-1.5 transition-colors">
            <Plus size={14}/> Adicionar um cartão
          </button>
        )}
      </div>
    </div>
  );
}


export default function KanbanPage() {
  const k = useKanbanBoard();
  const { user } = useAuth();
  const { data: perms } = useUserPermissions();
  const isAdmin = !!perms?.isAdmin;
  const [activeCard, setActiveCard] = useState<TCard | null>(null);
  const [openCard, setOpenCard] = useState<TCard | null>(null);
  const [newColumnTitle, setNewColumnTitle] = useState("");
  const [addingCol, setAddingCol] = useState(false);
  const [myOnly, setMyOnly] = useState(true);
  const [filters, setFilters] = useState<KanbanFiltersState>({ priorities: [], date: { kind: "preset", value: "hoje" } });

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 5 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates }),
  );

  // Filter columns by membership/creator for non-admins (or when admin toggles "Meus")
  const showMine = !isAdmin || myOnly;
  const { visibleColumns, totalCount, matchedIds, matchedCount } = useMemo(() => {
    let total = 0;
    const matched = new Set<string>();
    const cols = k.columns.map(col => {
      const cards = col.cards.filter(c => {
        if (showMine && user) {
          const isMine = c.created_by === user.id || k.members.some(m => m.card_id === c.id && m.user_id === user.id);
          if (!isMine) return false;
        }
        total++;
        if (cardMatchesFilters(c, filters)) matched.add(c.id);
        return true;
      });
      return { ...col, cards };
    });
    return { visibleColumns: cols, totalCount: total, matchedIds: matched, matchedCount: matched.size };
  }, [k.columns, k.members, user, showMine, filters]);
  const hasActiveFilters = filters.priorities.length > 0 || filters.date !== null;

  const taskIndex = useMemo(() => {
    const map = new Map<string, { colId: string; index: number; card: TCard }>();
    visibleColumns.forEach(c => c.cards.forEach((card, i) => map.set(card.id, { colId: c.id, index: i, card })));
    return map;
  }, [visibleColumns]);

  const findContainer = (id: string): string | undefined =>
    visibleColumns.some(c => c.id === id) ? id : taskIndex.get(id)?.colId;

  const handleDragStart = (e: DragStartEvent) => {
    const t = taskIndex.get(String(e.active.id));
    if (t) setActiveCard(t.card);
  };

  const handleDragOver = (_e: DragOverEvent) => { /* visual only via sortable */ };

  const handleDragEnd = (e: DragEndEvent) => {
    setActiveCard(null);
    const { active, over } = e;
    if (!over) return;
    const activeId = String(active.id);
    const overId = String(over.id);

    // Column reorder
    const isColumnDrag = active.data.current?.type === "column-handle";
    if (isColumnDrag) {
      const cols = visibleColumns;
      const oldIndex = cols.findIndex(c => c.id === activeId);
      const overIsCol = cols.some(c => c.id === overId);
      const newIndex = overIsCol ? cols.findIndex(c => c.id === overId) : oldIndex;
      if (oldIndex < 0 || newIndex < 0 || oldIndex === newIndex) return;
      // Convert to insertion index excluding the dragged item
      const insertIndex = oldIndex < newIndex ? newIndex + 1 : newIndex;
      k.moveColumn.mutate({ columnId: activeId, newIndex: insertIndex });
      return;
    }

    const fromCol = findContainer(activeId);
    const toCol = findContainer(overId);
    if (!fromCol || !toCol) return;
    const targetCol = visibleColumns.find(c => c.id === toCol)!;
    const overIsColumn = visibleColumns.some(c => c.id === overId);
    let newIndex: number;
    if (overIsColumn) newIndex = targetCol.cards.length;
    else {
      newIndex = targetCol.cards.findIndex(c => c.id === overId);
      if (newIndex < 0) newIndex = targetCol.cards.length;
    }
    if (fromCol === toCol) {
      const oldIndex = targetCol.cards.findIndex(c => c.id === activeId);
      if (oldIndex === newIndex) return;
    }
    k.moveCard.mutate({ cardId: activeId, toColumnId: toCol, newIndex });
  };

  // Refresh openCard when underlying data changes
  const liveOpenCard = openCard ? taskIndex.get(openCard.id)?.card || null : null;
  const liveOpenColumn = liveOpenCard ? k.columns.find(c => c.id === liveOpenCard.column_id) : null;

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      <DashboardSidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="flex items-center justify-between px-6 py-3 border-b border-border shrink-0">
          <div>
            <h1 className="text-foreground text-lg font-semibold leading-none">Kanban de Tarefas</h1>
            <p className="text-muted-foreground text-xs mt-1">
              {hasActiveFilters
                ? `${matchedCount} de ${totalCount} cartões em destaque${showMine ? " (apenas seus)" : ""}`
                : (showMine ? "Mostrando apenas seus cartões" : "Mostrando todos os cartões")}
            </p>
          </div>
          <div className="flex items-center gap-2">
            {isAdmin && (
              <div className="flex items-center bg-secondary rounded-lg p-0.5">
                <button
                  onClick={() => setMyOnly(true)}
                  className={cn("px-3 py-1 rounded-md text-xs", myOnly ? "bg-card text-foreground" : "text-muted-foreground")}
                >
                  Meus
                </button>
                <button
                  onClick={() => setMyOnly(false)}
                  className={cn("px-3 py-1 rounded-md text-xs", !myOnly ? "bg-card text-foreground" : "text-muted-foreground")}
                >
                  Todos
                </button>
              </div>
            )}
            <button onClick={()=>k.refetch()} className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors px-3 py-1.5 rounded-lg hover:bg-secondary">
              <RefreshCw size={12}/> Atualizar
            </button>
          </div>
        </header>

        <div className="px-6 py-2.5 border-b border-border bg-card/30 shrink-0">
          <KanbanFilters state={filters} onChange={setFilters} />
        </div>



        <div className="flex-1 overflow-x-auto overflow-y-hidden bg-muted/20 p-5">
          {k.isLoading ? (
            <div className="text-muted-foreground text-sm">Carregando quadro...</div>
          ) : (
            <DndContext sensors={sensors} onDragStart={handleDragStart} onDragOver={handleDragOver} onDragEnd={handleDragEnd} onDragCancel={()=>setActiveCard(null)}>
              <div className="flex items-start gap-4 h-full min-w-max">
                <SortableContext items={visibleColumns.map(c=>c.id)} strategy={horizontalListSortingStrategy}>
                  {visibleColumns.map(col => <ColumnView key={col.id} col={col} k={k} onOpenCard={setOpenCard} matchedIds={matchedIds} hasFilters={hasActiveFilters}/>)}
                </SortableContext>

                {/* Add column */}
                <div className="w-72 min-w-[280px] shrink-0">
                  {addingCol ? (
                    <div className="bg-card border border-border rounded-xl p-2 space-y-2">
                      <Input autoFocus value={newColumnTitle} onChange={(e)=>setNewColumnTitle(e.target.value)} placeholder="Nome da lista" className="h-8"/>
                      <div className="flex gap-2">
                        <Button size="sm" onClick={()=>{ if (newColumnTitle.trim()) { k.createColumn.mutate(newColumnTitle.trim()); setNewColumnTitle(""); setAddingCol(false); } }}>Adicionar lista</Button>
                        <button onClick={()=>{ setAddingCol(false); setNewColumnTitle(""); }} className="text-muted-foreground hover:text-foreground p-1.5"><X size={16}/></button>
                      </div>
                    </div>
                  ) : (
                    <button onClick={()=>setAddingCol(true)} className="w-full flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground bg-card/40 hover:bg-card border border-dashed border-border rounded-xl px-3 py-2.5 transition-colors">
                      <Plus size={14}/> Adicionar outra lista
                    </button>
                  )}
                </div>
              </div>
              <DragOverlay>
                {activeCard ? <div className="rotate-2"><CardView card={activeCard} k={k}/></div> : null}
              </DragOverlay>
            </DndContext>
          )}
        </div>
      </div>

      {liveOpenCard && liveOpenColumn && (
        <CardDetailModal card={liveOpenCard} column={liveOpenColumn} open={!!openCard} onClose={()=>setOpenCard(null)}/>
      )}
    </div>
  );
}
