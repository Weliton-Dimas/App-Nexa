import { useState, useEffect, useMemo } from "react";
import { DashboardSidebar } from "@/components/DashboardSidebar";
import { CreativeDemandModal } from "@/components/CreativeDemandModal";
import { CreativeLibrary } from "@/components/CreativeLibrary";
import { CreativeAIGenerator } from "@/components/CreativeAIGenerator";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useUserPermissions } from "@/hooks/useUserPermissions";
import { toast } from "@/hooks/use-toast";
import {
  Plus, AlertTriangle, CheckCircle2, TrendingUp, Clock, Calendar as CalIcon,
  Filter, Layers, Search, MoreHorizontal, Trash2, Edit3, Users, ListChecks, Link as LinkIcon, ChevronRight,
} from "lucide-react";
import { cn } from "@/lib/utils";

type Tab = "demandas" | "biblioteca" | "ia";

interface Demand {
  id: string;
  type: string;
  element: string;
  client_id: string | null;
  assignee_id: string | null;
  manager_id: string | null;
  priority: string;
  status: string;
  deadline: string | null;
  briefing: string | null;
  reference_links: string[];
  checklist: { id: string; text: string; done: boolean }[];
  created_by: string;
  completed_at: string | null;
  created_at: string;
  updated_at: string;
}
interface Client { id: string; name: string }
interface Profile { user_id: string; display_name: string | null; avatar_url: string | null }

const COLUMNS = [
  { id: "backlog", label: "Backlog", color: "border-t-border", dot: "bg-muted-foreground" },
  { id: "em_producao", label: "Em Produção", color: "border-t-accent", dot: "bg-accent" },
  { id: "em_revisao", label: "Em Revisão", color: "border-t-metric-amber", dot: "bg-metric-amber" },
  { id: "concluido", label: "Concluídos", color: "border-t-metric-green", dot: "bg-metric-green" },
];

const PRIORITY_STYLE: Record<string, string> = {
  urgente: "bg-metric-red/15 text-metric-red border-metric-red/30",
  alta: "bg-metric-amber/15 text-metric-amber border-metric-amber/30",
  media: "bg-metric-blue/15 text-metric-blue border-metric-blue/30",
  baixa: "bg-metric-green/15 text-metric-green border-metric-green/30",
};

export default function CreativosPage() {
  const { user } = useAuth();
  const { data: perms } = useUserPermissions();
  const isAdmin = !!perms?.isAdmin;
  const [tab, setTab] = useState<Tab>("demandas");
  const [demands, setDemands] = useState<Demand[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Demand | null>(null);

  const [filter, setFilter] = useState<"todos" | "meus" | "vencendo" | "atrasados">("meus");
  const [search, setSearch] = useState("");
  const [view, setView] = useState<"kanban" | "lista">("kanban");
  const [dragging, setDragging] = useState<{ id: string; from: string } | null>(null);

  useEffect(() => {
    fetchAll();
    const channel = supabase.channel("creative_demands_realtime")
      .on("postgres_changes", { event: "*", schema: "public", table: "creative_demands" }, () => fetchAll())
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, []);

  const fetchAll = async () => {
    setLoading(true);
    const [d, c, p] = await Promise.all([
      supabase.from("creative_demands").select("*").order("created_at", { ascending: false }),
      supabase.from("clients").select("id, name").order("name"),
      supabase.from("profiles").select("user_id, display_name, avatar_url"),
    ]);
    setDemands((d.data || []) as unknown as Demand[]);
    setClients(c.data || []);
    setProfiles(p.data || []);
    setLoading(false);
  };

  const todayStr = new Date().toISOString().slice(0, 10);
  const weekFromNow = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10);

  const filteredDemands = useMemo(() => {
    return demands.filter((d) => {
      if (search && !d.element.toLowerCase().includes(search.toLowerCase()) && !d.type.toLowerCase().includes(search.toLowerCase())) return false;
      // Non-admins always see only their own demands, regardless of filter
      if (!isAdmin && d.assignee_id !== user?.id && d.manager_id !== user?.id && d.created_by !== user?.id) return false;
      if (filter === "meus" && d.assignee_id !== user?.id && d.manager_id !== user?.id && d.created_by !== user?.id) return false;
      if (filter === "vencendo" && (!d.deadline || d.deadline > weekFromNow || d.status === "concluido")) return false;
      if (filter === "atrasados" && (!d.deadline || d.deadline >= todayStr || d.status === "concluido")) return false;
      return true;
    });
  }, [demands, search, filter, user, isAdmin, todayStr, weekFromNow]);

  const stats = useMemo(() => {
    const inProd = demands.filter((d) => d.status === "em_producao").length;
    const lateCount = demands.filter((d) => d.deadline && d.deadline < todayStr && d.status !== "concluido").length;
    const completedToday = demands.filter((d) => d.completed_at && d.completed_at.startsWith(todayStr)).length;
    const dueThisWeek = demands.filter((d) => d.deadline && d.deadline >= todayStr && d.deadline <= weekFromNow && d.status !== "concluido").length;

    const completed7d = demands.filter((d) => {
      if (!d.completed_at) return false;
      const diff = (Date.now() - new Date(d.completed_at).getTime()) / (1000 * 60 * 60);
      return diff <= 24 * 7;
    });
    const avgHours = completed7d.length === 0 ? 0 : completed7d.reduce((sum, d) => {
      return sum + (new Date(d.completed_at!).getTime() - new Date(d.created_at).getTime()) / (1000 * 60 * 60);
    }, 0) / completed7d.length;

    const myActive = demands.filter((d) => (d.assignee_id === user?.id || d.manager_id === user?.id) && d.status !== "concluido").length;

    return { inProd, lateCount, completedToday, dueThisWeek, avgHours, myActive };
  }, [demands, todayStr, weekFromNow, user]);

  const updateStatus = async (id: string, status: string) => {
    const payload: any = { status };
    if (status === "concluido") payload.completed_at = new Date().toISOString();
    if (status !== "concluido") payload.completed_at = null;
    await supabase.from("creative_demands").update(payload).eq("id", id);
  };

  const deleteDemand = async (id: string) => {
    if (!confirm("Excluir esta demanda?")) return;
    const { error } = await supabase.from("creative_demands").delete().eq("id", id);
    if (error) toast({ title: "Erro", description: error.message, variant: "destructive" });
  };

  const onDragStart = (e: React.DragEvent<HTMLElement>, id: string, from: string) => {
    e.currentTarget.classList.add("opacity-60");
    if (e.dataTransfer) {
      e.dataTransfer.effectAllowed = "move";
      e.dataTransfer.setData("text/plain", id);
    }
    setDragging({ id, from });
  };

  const onDrop = (toCol: string) => {
    if (!dragging || dragging.from === toCol) { setDragging(null); return; }
    setDemands((items) => items.map((item) => item.id === dragging.id ? {
      ...item,
      status: toCol,
      completed_at: toCol === "concluido" ? new Date().toISOString() : null,
    } : item));
    updateStatus(dragging.id, toCol);
    setDragging(null);
  };

  const getClient = (id: string | null) => clients.find((c) => c.id === id);
  const getProfile = (id: string | null) => profiles.find((p) => p.user_id === id);
  const getInitials = (name: string | null | undefined) => (name || "??").slice(0, 2).toUpperCase();

  const formatHours = (h: number) => h < 1 ? `${Math.round(h * 60)}m` : h < 24 ? `${Math.floor(h)}h ${Math.round((h % 1) * 60)}m` : `${Math.floor(h / 24)}d ${Math.floor(h % 24)}h`;

  const isLate = (d: Demand) => d.deadline && d.deadline < todayStr && d.status !== "concluido";

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      <DashboardSidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="px-6 pt-6 pb-4 border-b border-border shrink-0">
          <div className="flex items-start justify-between gap-4 mb-4">
            <div>
              <h1 className="text-2xl font-bold text-foreground">Criativos</h1>
              <p className="text-sm text-muted-foreground mt-0.5">Gestão de demandas e produção criativa</p>
              <p className="text-xs text-muted-foreground mt-1">
                Você tem <span className="text-foreground font-medium">{stats.myActive}</span> demandas ativas · <span className="text-metric-amber font-medium">{stats.dueThisWeek}</span> vencem esta semana
              </p>
            </div>
          </div>

          {/* Tabs */}
          <div className="flex items-center gap-1 border-b border-border -mb-4">
            {[
              { id: "demandas", label: "Demandas" },
              { id: "biblioteca", label: "Biblioteca" },
              { id: "ia", label: "Gerar Conteúdo (IA)" },
            ].map((t) => (
              <button key={t.id} onClick={() => setTab(t.id as Tab)} className={cn(
                "px-4 py-2.5 text-sm font-medium border-b-2 transition-colors -mb-px",
                tab === t.id ? "border-accent text-accent" : "border-transparent text-muted-foreground hover:text-foreground"
              )}>
                {t.label}
              </button>
            ))}
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-6 space-y-5">
          {tab === "demandas" && (
            <>
              {/* Metric cards */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                <MetricCard icon={<AlertTriangle size={16} />} value={stats.lateCount} label="EM ATRASO" tone="red" />
                <MetricCard icon={<CheckCircle2 size={16} />} value={stats.completedToday} label="CONCLUÍDAS HOJE" tone="green" />
                <MetricCard icon={<TrendingUp size={16} />} value={stats.inProd} label="EM PRODUÇÃO" tone="accent" />
                <MetricCard icon={<Clock size={16} />} value={formatHours(stats.avgHours)} label="TEMPO MÉDIO · 7d" tone="blue" small />
              </div>

              {/* Filters bar */}
              <div className="flex flex-wrap items-center gap-2">
                {[
                  { id: "todos", label: "Todos", adminOnly: true },
                  { id: "meus", label: "Meus" },
                  { id: "vencendo", label: "Vencendo" },
                  { id: "atrasados", label: "Atrasados" },
                ].filter((f) => !f.adminOnly || isAdmin).map((f) => (
                  <button key={f.id} onClick={() => setFilter(f.id as any)} className={cn(
                    "px-3 py-1.5 rounded-full text-xs font-medium transition-colors",
                    filter === f.id ? "bg-accent text-accent-foreground" : "bg-secondary text-muted-foreground hover:text-foreground"
                  )}>
                    {f.label}
                  </button>
                ))}
                <div className="relative ml-2 flex-1 min-w-[180px] max-w-xs">
                  <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                  <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Buscar..." className="w-full bg-secondary border border-border rounded-lg pl-9 pr-3 py-1.5 text-xs text-foreground" />
                </div>
                <div className="ml-auto flex items-center gap-2">
                  <div className="flex items-center bg-secondary rounded-lg p-0.5">
                    <button onClick={() => setView("kanban")} className={cn("px-3 py-1 rounded-md text-xs flex items-center gap-1", view === "kanban" ? "bg-card text-foreground" : "text-muted-foreground")}>
                      <Layers size={12} /> Kanban
                    </button>
                    <button onClick={() => setView("lista")} className={cn("px-3 py-1 rounded-md text-xs flex items-center gap-1", view === "lista" ? "bg-card text-foreground" : "text-muted-foreground")}>
                      <Filter size={12} /> Lista
                    </button>
                  </div>
                  <button onClick={() => { setEditing(null); setModalOpen(true); }} className="bg-accent text-accent-foreground px-4 py-1.5 rounded-lg text-xs font-medium hover:bg-accent/90 flex items-center gap-1.5">
                    <Plus size={13} /> Nova Demanda
                  </button>
                </div>
              </div>

              {/* Kanban or list */}
              {loading ? (
                <div className="text-center py-20 text-muted-foreground text-sm">Carregando...</div>
              ) : view === "kanban" ? (
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
                  {COLUMNS.map((col) => {
                    const colDemands = filteredDemands.filter((d) => d.status === col.id);
                    return (
                      <div key={col.id}
                        onDragOver={(e) => { e.preventDefault(); e.dataTransfer.dropEffect = "move"; }}
                        onDragEnter={(e) => e.preventDefault()}
                        onDrop={(e) => { e.preventDefault(); onDrop(col.id); }}
                        className={cn("flex flex-col rounded-xl transition-colors", dragging && dragging.from !== col.id && "ring-2 ring-accent/40")}>
                        <div className={cn("rounded-t-xl border-t-2 border-x border-border bg-card px-3 py-2.5 flex items-center justify-between", col.color)}>
                          <div className="flex items-center gap-2">
                            <span className={cn("w-1.5 h-1.5 rounded-full", col.dot)} />
                            <span className="text-xs font-semibold uppercase tracking-wider text-foreground">{col.label}</span>
                            <span className="text-[10px] bg-secondary text-muted-foreground px-1.5 py-0.5 rounded-full">{colDemands.length}</span>
                          </div>
                        </div>
                        <div
                          onDragOver={(e) => { e.preventDefault(); e.dataTransfer.dropEffect = "move"; }}
                          onDrop={(e) => { e.preventDefault(); onDrop(col.id); }}
                          className="flex-1 border-x border-b border-border rounded-b-xl bg-secondary/20 p-2 space-y-2 min-h-[400px]">
                          {colDemands.map((d) => {
                            const client = getClient(d.client_id);
                            const assignee = getProfile(d.assignee_id);
                            const checklistDone = d.checklist?.filter((i) => i.done).length || 0;
                            const checklistTotal = d.checklist?.length || 0;
                            return (
                              <div key={d.id} draggable onDragStart={(e) => onDragStart(e, d.id, col.id)} onDragEnd={(e) => { e.currentTarget.classList.remove("opacity-60"); setDragging(null); }}
                                onClick={() => { setEditing(d); setModalOpen(true); }}
                                className="group bg-card border border-border rounded-lg p-3 cursor-pointer hover:border-accent/40 transition-colors select-none">
                                <div className="flex items-start justify-between gap-1 mb-2">
                                  <div className="flex-1 min-w-0">
                                    <p className="text-[10px] uppercase tracking-wider text-muted-foreground">{d.type}</p>
                                    <p className="text-sm font-medium text-foreground leading-tight mt-0.5">{d.element}</p>
                                  </div>
                                  <div className="flex items-center opacity-0 group-hover:opacity-100 transition-opacity">
                                    <button onClick={(e) => { e.stopPropagation(); setEditing(d); setModalOpen(true); }} className="text-muted-foreground hover:text-foreground p-1"><Edit3 size={11} /></button>
                                    <button onClick={(e) => { e.stopPropagation(); deleteDemand(d.id); }} className="text-muted-foreground hover:text-metric-red p-1"><Trash2 size={11} /></button>
                                  </div>
                                </div>
                                {client && <p className="text-[11px] text-muted-foreground mb-2 truncate">📋 {client.name}</p>}

                                <div className="flex items-center gap-1.5 flex-wrap mb-2">
                                  <span className={cn("text-[10px] font-medium px-1.5 py-0.5 rounded border", PRIORITY_STYLE[d.priority])}>
                                    {d.priority.toUpperCase()}
                                  </span>
                                  {isLate(d) && <span className="text-[10px] font-medium px-1.5 py-0.5 rounded border bg-metric-red/15 text-metric-red border-metric-red/30">ATRASADA</span>}
                                </div>

                                <div className="flex items-center justify-between text-[10px] text-muted-foreground">
                                  <div className="flex items-center gap-2">
                                    {d.deadline && (
                                      <span className={cn("flex items-center gap-1", isLate(d) && "text-metric-red")}>
                                        <CalIcon size={10} />
                                        {new Date(d.deadline + "T00:00").toLocaleDateString("pt-BR", { day: "2-digit", month: "short" })}
                                      </span>
                                    )}
                                    {checklistTotal > 0 && (
                                      <span className="flex items-center gap-1"><ListChecks size={10} />{checklistDone}/{checklistTotal}</span>
                                    )}
                                    {d.reference_links?.length > 0 && (
                                      <span className="flex items-center gap-1"><LinkIcon size={10} />{d.reference_links.length}</span>
                                    )}
                                  </div>
                                  {assignee && (
                                    <div className="w-5 h-5 rounded-full bg-accent/20 flex items-center justify-center text-[9px] text-accent font-medium" title={assignee.display_name || ""}>
                                      {getInitials(assignee.display_name)}
                                    </div>
                                  )}
                                </div>
                              </div>
                            );
                          })}
                          {colDemands.length === 0 && (
                            <div className="text-center py-8 text-[11px] text-muted-foreground/50">Sem demandas</div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="bg-card border border-border rounded-xl overflow-hidden">
                  <table className="w-full text-sm">
                    <thead className="bg-secondary/50">
                      <tr className="text-left text-[10px] uppercase tracking-wider text-muted-foreground">
                        <th className="px-4 py-2.5">Demanda</th>
                        <th className="px-4 py-2.5">Cliente</th>
                        <th className="px-4 py-2.5">Status</th>
                        <th className="px-4 py-2.5">Prioridade</th>
                        <th className="px-4 py-2.5">Responsável</th>
                        <th className="px-4 py-2.5">Prazo</th>
                        <th className="px-4 py-2.5"></th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredDemands.map((d) => {
                        const client = getClient(d.client_id);
                        const assignee = getProfile(d.assignee_id);
                        const col = COLUMNS.find((c) => c.id === d.status);
                        return (
                          <tr key={d.id} className="border-t border-border hover:bg-secondary/20 cursor-pointer" onClick={() => { setEditing(d); setModalOpen(true); }}>
                            <td className="px-4 py-2.5">
                              <p className="text-[10px] text-muted-foreground uppercase">{d.type}</p>
                              <p className="text-sm text-foreground">{d.element}</p>
                            </td>
                            <td className="px-4 py-2.5 text-xs text-muted-foreground">{client?.name || "—"}</td>
                            <td className="px-4 py-2.5"><span className="text-xs flex items-center gap-1.5"><span className={cn("w-1.5 h-1.5 rounded-full", col?.dot)} />{col?.label}</span></td>
                            <td className="px-4 py-2.5"><span className={cn("text-[10px] font-medium px-1.5 py-0.5 rounded border", PRIORITY_STYLE[d.priority])}>{d.priority.toUpperCase()}</span></td>
                            <td className="px-4 py-2.5 text-xs text-muted-foreground">{assignee?.display_name || "—"}</td>
                            <td className={cn("px-4 py-2.5 text-xs", isLate(d) ? "text-metric-red" : "text-muted-foreground")}>
                              {d.deadline ? new Date(d.deadline + "T00:00").toLocaleDateString("pt-BR") : "—"}
                            </td>
                            <td className="px-4 py-2.5"><ChevronRight size={14} className="text-muted-foreground" /></td>
                          </tr>
                        );
                      })}
                      {filteredDemands.length === 0 && (
                        <tr><td colSpan={7} className="px-4 py-12 text-center text-muted-foreground text-sm">Nenhuma demanda encontrada</td></tr>
                      )}
                    </tbody>
                  </table>
                </div>
              )}
            </>
          )}

          {tab === "biblioteca" && <CreativeLibrary />}
          {tab === "ia" && <CreativeAIGenerator />}
        </div>
      </div>

      <CreativeDemandModal open={modalOpen} onClose={() => { setModalOpen(false); setEditing(null); }} onSaved={fetchAll} initialDemand={editing} />
    </div>
  );
}

function MetricCard({ icon, value, label, tone, small }: { icon: React.ReactNode; value: any; label: string; tone: "red" | "green" | "blue" | "accent"; small?: boolean }) {
  const toneClasses: Record<string, string> = {
    red: "bg-metric-red/15 text-metric-red border-metric-red/20",
    green: "bg-metric-green/15 text-metric-green border-metric-green/20",
    blue: "bg-metric-blue/15 text-metric-blue border-metric-blue/20",
    accent: "bg-accent/15 text-accent border-accent/20",
  };
  return (
    <div className="bg-card border border-border rounded-xl p-4 flex items-center gap-3">
      <div className={cn("w-10 h-10 rounded-lg flex items-center justify-center border", toneClasses[tone])}>{icon}</div>
      <div>
        <p className={cn("font-bold text-foreground", small ? "text-xl" : "text-2xl")}>{value}</p>
        <p className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</p>
      </div>
    </div>
  );
}
