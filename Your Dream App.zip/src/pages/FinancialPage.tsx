import { useEffect, useMemo, useState } from "react";
import { DashboardSidebar } from "@/components/DashboardSidebar";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import {
  DollarSign,
  TrendingUp,
  TrendingDown,
  Plus,
  Trash2,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Receipt,
  Users as UsersIcon,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  Table,
  TableHeader,
  TableBody,
  TableHead,
  TableRow,
  TableCell,
} from "@/components/ui/table";

type Recurrence = "mensal" | "semanal" | "quinzenal" | "anual" | "unico";

const RECURRENCE_OPTIONS: { value: Recurrence; label: string }[] = [
  { value: "mensal", label: "Mensal" },
  { value: "semanal", label: "Semanal" },
  { value: "quinzenal", label: "Quinzenal" },
  { value: "anual", label: "Anual" },
  { value: "unico", label: "Único / Avulso" },
];

type Revenue = {
  id: string;
  client_id: string | null;
  description: string;
  amount: number;
  due_date: string;
  paid_date: string | null;
  status: "pendente" | "pago" | "atrasado";
  recurrence: Recurrence;
  notes: string | null;
};

type Expense = {
  id: string;
  description: string;
  category: string;
  amount: number;
  due_date: string;
  paid_date: string | null;
  status: "pendente" | "pago" | "atrasado";
  recurrence: Recurrence;
  notes: string | null;
};

type Commission = {
  id: string;
  user_id: string;
  client_id: string | null;
  description: string;
  amount: number;
  reference_month: string;
  paid_date: string | null;
  status: "pendente" | "pago";
  notes: string | null;
};

type Client = { id: string; name: string; monthly_fee?: number | null; billing_day?: number | null };
type Profile = { user_id: string; display_name: string | null };

const EXPENSE_CATEGORIES = [
  { value: "ferramentas", label: "Ferramentas" },
  { value: "equipe", label: "Equipe" },
  { value: "marketing", label: "Marketing" },
  { value: "impostos", label: "Impostos" },
  { value: "outros", label: "Outros" },
];

const fmtBRL = (v: number) =>
  v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

const fmtDate = (d: string | null) =>
  d ? new Date(d + "T00:00:00").toLocaleDateString("pt-BR") : "—";

const monthKey = (d: string) => d.slice(0, 7); // YYYY-MM
const currentMonth = () => new Date().toISOString().slice(0, 7);

const computeStatus = (status: string, dueDate: string, paidDate: string | null) => {
  if (paidDate || status === "pago") return "pago";
  const today = new Date().toISOString().slice(0, 10);
  if (dueDate < today) return "atrasado";
  return "pendente";
};

const StatusBadge = ({ status }: { status: string }) => {
  const map: Record<string, { label: string; cls: string; icon: any }> = {
    pago: {
      label: "Pago",
      cls: "border-metric-green/40 text-metric-green bg-metric-green/10",
      icon: CheckCircle2,
    },
    pendente: {
      label: "Pendente",
      cls: "border-metric-amber/40 text-metric-amber bg-metric-amber/10",
      icon: Clock,
    },
    atrasado: {
      label: "Atrasado",
      cls: "border-metric-red/40 text-metric-red bg-metric-red/10",
      icon: AlertTriangle,
    },
  };
  const m = map[status] ?? map.pendente;
  const Icon = m.icon;
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 text-[10px] font-medium px-2 py-0.5 rounded-md border",
        m.cls
      )}
    >
      <Icon size={10} />
      {m.label}
    </span>
  );
};

export default function FinancialPage() {
  const { user } = useAuth();
  const [month, setMonth] = useState(currentMonth());
  const [revenues, setRevenues] = useState<Revenue[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [commissions, setCommissions] = useState<Commission[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);

  const [revOpen, setRevOpen] = useState(false);
  const [expOpen, setExpOpen] = useState(false);
  const [commOpen, setCommOpen] = useState(false);

  const fetchAll = async () => {
    setLoading(true);
    const [r, e, c, cl, pr] = await Promise.all([
      supabase.from("financial_revenues").select("*").order("due_date", { ascending: false }),
      supabase.from("financial_expenses").select("*").order("due_date", { ascending: false }),
      supabase.from("financial_commissions").select("*").order("reference_month", { ascending: false }),
      supabase.from("clients").select("id, name, monthly_fee, billing_day").order("name"),
      supabase.from("profiles").select("user_id, display_name"),
    ]);
    if (r.data) setRevenues(r.data as Revenue[]);
    if (e.data) setExpenses(e.data as Expense[]);
    if (c.data) setCommissions(c.data as Commission[]);
    if (cl.data) setClients(cl.data as Client[]);
    if (pr.data) setProfiles(pr.data as Profile[]);
    setLoading(false);
  };

  useEffect(() => {
    fetchAll();
  }, []);

  const clientName = (id: string | null) =>
    clients.find((c) => c.id === id)?.name ?? "—";
  const profileName = (id: string) =>
    profiles.find((p) => p.user_id === id)?.display_name ?? "Usuário";

  // Receitas virtuais geradas a partir da mensalidade configurada nos clientes.
  // Só aparecem se NÃO houver uma receita real (manual) para o mesmo cliente naquele mês.
  const virtualRevenuesFor = (targetMonth: string): Revenue[] => {
    const [y, m] = targetMonth.split("-").map(Number);
    return clients
      .filter((c) => c.monthly_fee && Number(c.monthly_fee) > 0)
      .filter((c) => {
        // pula se já existe receita real desse cliente nesse mês
        return !revenues.some(
          (r) => r.client_id === c.id && monthKey(r.due_date) === targetMonth
        );
      })
      .map((c) => {
        const day = Math.min(Math.max(c.billing_day ?? 10, 1), 28);
        const due = `${y}-${String(m).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
        return {
          id: `virtual-${c.id}-${targetMonth}`,
          client_id: c.id,
          description: `Mensalidade — ${c.name}`,
          amount: Number(c.monthly_fee),
          due_date: due,
          paid_date: null,
          status: "pendente",
          recurrence: "mensal",
          notes: null,
        } as Revenue;
      });
  };

  // Filtragem por mês (vencimento) — combina reais + virtuais
  const monthRevenues = useMemo(
    () => [
      ...revenues.filter((r) => monthKey(r.due_date) === month),
      ...virtualRevenuesFor(month),
    ],
    [revenues, clients, month]
  );
  const monthExpenses = useMemo(
    () => expenses.filter((e) => monthKey(e.due_date) === month),
    [expenses, month]
  );
  const monthCommissions = useMemo(
    () => commissions.filter((c) => monthKey(c.reference_month) === month),
    [commissions, month]
  );

  // Meses com qualquer dado (reais ou virtuais) — para a navegação
  const monthsWithData = useMemo(() => {
    const set = new Set<string>();
    revenues.forEach((r) => set.add(monthKey(r.due_date)));
    expenses.forEach((e) => set.add(monthKey(e.due_date)));
    commissions.forEach((c) => set.add(monthKey(c.reference_month)));
    if (clients.some((c) => c.monthly_fee && Number(c.monthly_fee) > 0)) {
      set.add(currentMonth());
    }
    return Array.from(set).sort();
  }, [revenues, expenses, commissions, clients]);

  const shiftMonth = (delta: number) => {
    const [y, m] = month.split("-").map(Number);
    const d = new Date(y, m - 1 + delta, 1);
    setMonth(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`);
  };

  // Métricas
  const recebido = monthRevenues
    .filter((r) => computeStatus(r.status, r.due_date, r.paid_date) === "pago")
    .reduce((s, r) => s + Number(r.amount), 0);
  const aReceber = monthRevenues
    .filter((r) => computeStatus(r.status, r.due_date, r.paid_date) !== "pago")
    .reduce((s, r) => s + Number(r.amount), 0);
  const despesasMes = monthExpenses.reduce((s, e) => s + Number(e.amount), 0) +
    monthCommissions.reduce((s, c) => s + Number(c.amount), 0);
  const lucro = recebido - despesasMes;
  const margem = recebido > 0 ? (lucro / recebido) * 100 : 0;

  // Histórico para gráfico (últimos 6 meses)
  const last6 = useMemo(() => {
    const arr: { key: string; label: string; rec: number; desp: number }[] = [];
    const base = new Date();
    base.setDate(1);
    for (let i = 5; i >= 0; i--) {
      const d = new Date(base);
      d.setMonth(d.getMonth() - i);
      const key = d.toISOString().slice(0, 7);
      const label = d.toLocaleDateString("pt-BR", { month: "short" }).replace(".", "");
      const rec = revenues
        .filter((r) => monthKey(r.due_date) === key && computeStatus(r.status, r.due_date, r.paid_date) === "pago")
        .reduce((s, r) => s + Number(r.amount), 0);
      const desp =
        expenses.filter((e) => monthKey(e.due_date) === key).reduce((s, e) => s + Number(e.amount), 0) +
        commissions.filter((c) => monthKey(c.reference_month) === key).reduce((s, c) => s + Number(c.amount), 0);
      arr.push({ key, label, rec, desp });
    }
    return arr;
  }, [revenues, expenses, commissions]);
  const maxBar = Math.max(1, ...last6.flatMap((m) => [m.rec, m.desp]));

  // Toggle pagamento
  const togglePaid = async (
    table: "financial_revenues" | "financial_expenses" | "financial_commissions",
    id: string,
    isPaid: boolean
  ) => {
    const { error } = await supabase
      .from(table)
      .update({
        status: isPaid ? "pendente" : "pago",
        paid_date: isPaid ? null : new Date().toISOString().slice(0, 10),
      })
      .eq("id", id);
    if (error) toast({ title: "Erro", description: error.message, variant: "destructive" });
    else fetchAll();
  };

  const removeRow = async (
    table: "financial_revenues" | "financial_expenses" | "financial_commissions",
    id: string
  ) => {
    if (!confirm("Excluir este lançamento?")) return;
    const { error } = await supabase.from(table).delete().eq("id", id);
    if (error) toast({ title: "Erro", description: error.message, variant: "destructive" });
    else fetchAll();
  };

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      <DashboardSidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="flex items-center justify-between px-6 py-3 border-b border-border shrink-0">
          <div>
            <h1 className="text-foreground text-lg font-semibold leading-none">Financeiro</h1>
            <p className="text-muted-foreground text-xs mt-1">
              Receitas, despesas, comissões e fluxo de caixa
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => shiftMonth(-1)}
              className="h-8 w-8 rounded-lg border border-border hover:bg-secondary flex items-center justify-center text-muted-foreground hover:text-foreground"
              title="Mês anterior"
            >
              <ChevronLeft size={14} />
            </button>
            <Input
              type="month"
              value={month}
              onChange={(e) => setMonth(e.target.value)}
              className="h-8 w-36 text-xs"
            />
            <button
              onClick={() => shiftMonth(1)}
              className="h-8 w-8 rounded-lg border border-border hover:bg-secondary flex items-center justify-center text-muted-foreground hover:text-foreground"
              title="Próximo mês"
            >
              <ChevronRight size={14} />
            </button>
            <button
              onClick={() => setMonth(currentMonth())}
              className="h-8 px-2.5 rounded-lg border border-border hover:bg-secondary text-[11px] text-muted-foreground hover:text-foreground"
            >
              Hoje
            </button>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {/* Métricas */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            <MetricBox
              icon={<DollarSign size={18} />}
              label="Faturamento do mês"
              value={fmtBRL(recebido)}
              tone="green"
            />
            <MetricBox
              icon={<Clock size={18} />}
              label="A receber / pendente"
              value={fmtBRL(aReceber)}
              tone="amber"
            />
            <MetricBox
              icon={<Receipt size={18} />}
              label="Despesas do mês"
              value={fmtBRL(despesasMes)}
              tone="red"
            />
            <MetricBox
              icon={<TrendingUp size={18} />}
              label="Lucro líquido"
              value={fmtBRL(lucro)}
              extra={`Margem ${margem.toFixed(1)}%`}
              tone={lucro >= 0 ? "blue" : "red"}
            />
          </div>

          {/* Fluxo de caixa - últimos 6 meses */}
          <div className="rounded-xl border border-border bg-card p-4">
            <div className="flex items-center justify-between mb-3">
              <p className="text-sm font-semibold text-foreground">Fluxo de Caixa — últimos 6 meses</p>
              <div className="flex items-center gap-3 text-[11px] text-muted-foreground">
                <span className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded-sm bg-metric-green inline-block" /> Recebido
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded-sm bg-metric-red inline-block" /> Despesas
                </span>
              </div>
            </div>
            <div className="flex items-end gap-3 h-40">
              {last6.map((m) => (
                <div key={m.key} className="flex-1 flex flex-col items-center gap-1">
                  <div className="flex items-end gap-1 w-full h-32 justify-center">
                    <div
                      className="w-1/3 rounded-t-sm bg-metric-green/70"
                      style={{ height: `${(m.rec / maxBar) * 100}%` }}
                      title={fmtBRL(m.rec)}
                    />
                    <div
                      className="w-1/3 rounded-t-sm bg-metric-red/70"
                      style={{ height: `${(m.desp / maxBar) * 100}%` }}
                      title={fmtBRL(m.desp)}
                    />
                  </div>
                  <p
                    className={cn(
                      "text-[10px] capitalize",
                      m.key === month ? "text-foreground font-semibold" : "text-muted-foreground"
                    )}
                  >
                    {m.label}
                  </p>
                  <p className="text-[10px] text-muted-foreground tabular-nums">
                    {(m.rec - m.desp >= 0 ? "+" : "") + fmtBRL(m.rec - m.desp)}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Tabs */}
          <Tabs defaultValue="receitas" className="w-full">
            <TabsList className="bg-card border border-border">
              <TabsTrigger value="receitas" className="gap-1.5">
                <TrendingUp size={13} /> Receitas
              </TabsTrigger>
              <TabsTrigger value="despesas" className="gap-1.5">
                <TrendingDown size={13} /> Despesas
              </TabsTrigger>
              <TabsTrigger value="comissoes" className="gap-1.5">
                <UsersIcon size={13} /> Comissões
              </TabsTrigger>
            </TabsList>

            {/* Receitas */}
            <TabsContent value="receitas" className="mt-3">
              <div className="rounded-xl border border-border bg-card">
                <div className="flex items-center justify-between px-4 py-3 border-b border-border">
                  <div>
                    <p className="text-sm font-semibold text-foreground">Receitas do mês</p>
                    <p className="text-xs text-muted-foreground">
                      {monthRevenues.length} lançamento(s) · {fmtBRL(recebido + aReceber)} total
                    </p>
                  </div>
                  <Dialog open={revOpen} onOpenChange={setRevOpen}>
                    <DialogTrigger asChild>
                      <Button size="sm" className="gap-1.5">
                        <Plus size={14} /> Nova receita
                      </Button>
                    </DialogTrigger>
                    <RevenueDialog
                      clients={clients}
                      userId={user?.id}
                      onSaved={() => {
                        setRevOpen(false);
                        fetchAll();
                      }}
                    />
                  </Dialog>
                </div>
                <RevenuesTable
                  rows={monthRevenues}
                  loading={loading}
                  clientName={clientName}
                  onTogglePaid={async (r) => {
                    if (r.id.startsWith("virtual-")) {
                      // Materializa a receita virtual no banco como paga
                      if (!user) return;
                      const { error } = await supabase.from("financial_revenues").insert({
                        created_by: user.id,
                        client_id: r.client_id,
                        description: r.description,
                        amount: r.amount,
                        due_date: r.due_date,
                        recurrence: "mensal",
                        status: "pago",
                        paid_date: new Date().toISOString().slice(0, 10),
                      });
                      if (error) toast({ title: "Erro", description: error.message, variant: "destructive" });
                      else {
                        toast({ title: "Mensalidade registrada como paga" });
                        fetchAll();
                      }
                    } else {
                      togglePaid(
                        "financial_revenues",
                        r.id,
                        computeStatus(r.status, r.due_date, r.paid_date) === "pago"
                      );
                    }
                  }}
                  onDelete={(id) => {
                    if (id.startsWith("virtual-")) {
                      toast({
                        title: "Receita automática",
                        description: "Edite a mensalidade na página do cliente para removê-la.",
                      });
                      return;
                    }
                    removeRow("financial_revenues", id);
                  }}
                />
              </div>
            </TabsContent>

            {/* Despesas */}
            <TabsContent value="despesas" className="mt-3">
              <div className="rounded-xl border border-border bg-card">
                <div className="flex items-center justify-between px-4 py-3 border-b border-border">
                  <div>
                    <p className="text-sm font-semibold text-foreground">Despesas do mês</p>
                    <p className="text-xs text-muted-foreground">
                      {monthExpenses.length} lançamento(s) ·{" "}
                      {fmtBRL(monthExpenses.reduce((s, e) => s + Number(e.amount), 0))} total
                    </p>
                  </div>
                  <Dialog open={expOpen} onOpenChange={setExpOpen}>
                    <DialogTrigger asChild>
                      <Button size="sm" className="gap-1.5">
                        <Plus size={14} /> Nova despesa
                      </Button>
                    </DialogTrigger>
                    <ExpenseDialog
                      userId={user?.id}
                      onSaved={() => {
                        setExpOpen(false);
                        fetchAll();
                      }}
                    />
                  </Dialog>
                </div>
                <ExpensesTable
                  rows={monthExpenses}
                  loading={loading}
                  onTogglePaid={(e) =>
                    togglePaid("financial_expenses", e.id, computeStatus(e.status, e.due_date, e.paid_date) === "pago")
                  }
                  onDelete={(id) => removeRow("financial_expenses", id)}
                />
              </div>
            </TabsContent>

            {/* Comissões */}
            <TabsContent value="comissoes" className="mt-3">
              <div className="rounded-xl border border-border bg-card">
                <div className="flex items-center justify-between px-4 py-3 border-b border-border">
                  <div>
                    <p className="text-sm font-semibold text-foreground">Comissões e pagamentos à equipe</p>
                    <p className="text-xs text-muted-foreground">
                      {monthCommissions.length} lançamento(s) ·{" "}
                      {fmtBRL(monthCommissions.reduce((s, c) => s + Number(c.amount), 0))} total
                    </p>
                  </div>
                  <Dialog open={commOpen} onOpenChange={setCommOpen}>
                    <DialogTrigger asChild>
                      <Button size="sm" className="gap-1.5">
                        <Plus size={14} /> Nova comissão
                      </Button>
                    </DialogTrigger>
                    <CommissionDialog
                      profiles={profiles}
                      clients={clients}
                      userId={user?.id}
                      onSaved={() => {
                        setCommOpen(false);
                        fetchAll();
                      }}
                    />
                  </Dialog>
                </div>
                <CommissionsTable
                  rows={monthCommissions}
                  loading={loading}
                  profileName={profileName}
                  clientName={clientName}
                  onTogglePaid={(c) => togglePaid("financial_commissions", c.id, c.status === "pago")}
                  onDelete={(id) => removeRow("financial_commissions", id)}
                />
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}

/* ----------------------------- Sub-components ----------------------------- */

function MetricBox({
  icon,
  label,
  value,
  extra,
  tone,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  extra?: string;
  tone: "green" | "amber" | "red" | "blue";
}) {
  const map = {
    green: "text-metric-green border-metric-green/30 bg-metric-green/5",
    amber: "text-metric-amber border-metric-amber/30 bg-metric-amber/5",
    red: "text-metric-red border-metric-red/30 bg-metric-red/5",
    blue: "text-metric-blue border-metric-blue/30 bg-metric-blue/5",
  } as const;
  return (
    <div className={cn("rounded-xl border bg-card p-4", map[tone])}>
      <div className="flex items-center justify-between">
        <p className="text-xs text-muted-foreground font-medium">{label}</p>
        <span>{icon}</span>
      </div>
      <p className="text-2xl font-bold text-foreground mt-2 tabular-nums">{value}</p>
      {extra && <p className="text-[11px] text-muted-foreground mt-1">{extra}</p>}
    </div>
  );
}

function RevenuesTable({
  rows,
  loading,
  clientName,
  onTogglePaid,
  onDelete,
}: {
  rows: Revenue[];
  loading: boolean;
  clientName: (id: string | null) => string;
  onTogglePaid: (r: Revenue) => void;
  onDelete: (id: string) => void;
}) {
  if (loading) return <p className="p-6 text-sm text-muted-foreground">Carregando...</p>;
  if (!rows.length)
    return (
      <p className="p-8 text-center text-sm text-muted-foreground">
        Nenhuma receita neste mês. Clique em "Nova receita" para começar.
      </p>
    );
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Descrição</TableHead>
          <TableHead>Cliente</TableHead>
          <TableHead>Vencimento</TableHead>
          <TableHead>Pagamento</TableHead>
          <TableHead>Recorrência</TableHead>
          <TableHead className="text-right">Valor</TableHead>
          <TableHead>Status</TableHead>
          <TableHead className="w-24"></TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {rows.map((r) => {
          const st = computeStatus(r.status, r.due_date, r.paid_date);
          return (
            <TableRow key={r.id}>
              <TableCell className="font-medium">
                {r.description}
                {r.id.startsWith("virtual-") && (
                  <span className="ml-2 text-[10px] px-1.5 py-0.5 rounded border border-accent/30 text-accent bg-accent/5">
                    auto
                  </span>
                )}
              </TableCell>
              <TableCell className="text-muted-foreground">{clientName(r.client_id)}</TableCell>
              <TableCell className="text-muted-foreground">{fmtDate(r.due_date)}</TableCell>
              <TableCell className="text-muted-foreground">{fmtDate(r.paid_date)}</TableCell>
              <TableCell className="text-muted-foreground capitalize">{r.recurrence}</TableCell>
              <TableCell className="text-right font-semibold tabular-nums">{fmtBRL(Number(r.amount))}</TableCell>
              <TableCell>
                <StatusBadge status={st} />
              </TableCell>
              <TableCell>
                <div className="flex items-center justify-end gap-1">
                  <button
                    onClick={() => onTogglePaid(r)}
                    className="p-1.5 rounded hover:bg-secondary text-muted-foreground hover:text-metric-green"
                    title={st === "pago" ? "Marcar como pendente" : "Marcar como pago"}
                  >
                    <CheckCircle2 size={14} />
                  </button>
                  <button
                    onClick={() => onDelete(r.id)}
                    className="p-1.5 rounded hover:bg-secondary text-muted-foreground hover:text-destructive"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </TableCell>
            </TableRow>
          );
        })}
      </TableBody>
    </Table>
  );
}

function ExpensesTable({
  rows,
  loading,
  onTogglePaid,
  onDelete,
}: {
  rows: Expense[];
  loading: boolean;
  onTogglePaid: (e: Expense) => void;
  onDelete: (id: string) => void;
}) {
  if (loading) return <p className="p-6 text-sm text-muted-foreground">Carregando...</p>;
  if (!rows.length)
    return (
      <p className="p-8 text-center text-sm text-muted-foreground">
        Nenhuma despesa neste mês.
      </p>
    );
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Descrição</TableHead>
          <TableHead>Categoria</TableHead>
          <TableHead>Vencimento</TableHead>
          <TableHead>Pagamento</TableHead>
          <TableHead>Recorrência</TableHead>
          <TableHead className="text-right">Valor</TableHead>
          <TableHead>Status</TableHead>
          <TableHead className="w-24"></TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {rows.map((e) => {
          const st = computeStatus(e.status, e.due_date, e.paid_date);
          const cat = EXPENSE_CATEGORIES.find((c) => c.value === e.category)?.label ?? e.category;
          return (
            <TableRow key={e.id}>
              <TableCell className="font-medium">{e.description}</TableCell>
              <TableCell className="text-muted-foreground">{cat}</TableCell>
              <TableCell className="text-muted-foreground">{fmtDate(e.due_date)}</TableCell>
              <TableCell className="text-muted-foreground">{fmtDate(e.paid_date)}</TableCell>
              <TableCell className="text-muted-foreground capitalize">{e.recurrence}</TableCell>
              <TableCell className="text-right font-semibold tabular-nums">{fmtBRL(Number(e.amount))}</TableCell>
              <TableCell>
                <StatusBadge status={st} />
              </TableCell>
              <TableCell>
                <div className="flex items-center justify-end gap-1">
                  <button
                    onClick={() => onTogglePaid(e)}
                    className="p-1.5 rounded hover:bg-secondary text-muted-foreground hover:text-metric-green"
                  >
                    <CheckCircle2 size={14} />
                  </button>
                  <button
                    onClick={() => onDelete(e.id)}
                    className="p-1.5 rounded hover:bg-secondary text-muted-foreground hover:text-destructive"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </TableCell>
            </TableRow>
          );
        })}
      </TableBody>
    </Table>
  );
}

function CommissionsTable({
  rows,
  loading,
  profileName,
  clientName,
  onTogglePaid,
  onDelete,
}: {
  rows: Commission[];
  loading: boolean;
  profileName: (id: string) => string;
  clientName: (id: string | null) => string;
  onTogglePaid: (c: Commission) => void;
  onDelete: (id: string) => void;
}) {
  if (loading) return <p className="p-6 text-sm text-muted-foreground">Carregando...</p>;
  if (!rows.length)
    return (
      <p className="p-8 text-center text-sm text-muted-foreground">
        Nenhuma comissão neste mês.
      </p>
    );
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Beneficiário</TableHead>
          <TableHead>Cliente</TableHead>
          <TableHead>Descrição</TableHead>
          <TableHead>Mês ref.</TableHead>
          <TableHead>Pagamento</TableHead>
          <TableHead className="text-right">Valor</TableHead>
          <TableHead>Status</TableHead>
          <TableHead className="w-24"></TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {rows.map((c) => (
          <TableRow key={c.id}>
            <TableCell className="font-medium">{profileName(c.user_id)}</TableCell>
            <TableCell className="text-muted-foreground">{clientName(c.client_id)}</TableCell>
            <TableCell className="text-muted-foreground">{c.description}</TableCell>
            <TableCell className="text-muted-foreground">
              {new Date(c.reference_month + "T00:00:00").toLocaleDateString("pt-BR", {
                month: "short",
                year: "numeric",
              })}
            </TableCell>
            <TableCell className="text-muted-foreground">{fmtDate(c.paid_date)}</TableCell>
            <TableCell className="text-right font-semibold tabular-nums">{fmtBRL(Number(c.amount))}</TableCell>
            <TableCell>
              <StatusBadge status={c.status} />
            </TableCell>
            <TableCell>
              <div className="flex items-center justify-end gap-1">
                <button
                  onClick={() => onTogglePaid(c)}
                  className="p-1.5 rounded hover:bg-secondary text-muted-foreground hover:text-metric-green"
                >
                  <CheckCircle2 size={14} />
                </button>
                <button
                  onClick={() => onDelete(c.id)}
                  className="p-1.5 rounded hover:bg-secondary text-muted-foreground hover:text-destructive"
                >
                  <Trash2 size={14} />
                </button>
              </div>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
}

/* ------------------------------ Dialogs ------------------------------ */

function RevenueDialog({
  clients,
  userId,
  onSaved,
}: {
  clients: Client[];
  userId?: string;
  onSaved: () => void;
}) {
  const [form, setForm] = useState({
    description: "",
    client_id: "" as string,
    amount: "",
    due_date: new Date().toISOString().slice(0, 10),
    recurrence: "mensal",
    notes: "",
  });
  const [saving, setSaving] = useState(false);

  const save = async () => {
    if (!userId) return;
    if (!form.description || !form.amount) {
      toast({ title: "Preencha descrição e valor", variant: "destructive" });
      return;
    }
    setSaving(true);
    const { error } = await supabase.from("financial_revenues").insert({
      created_by: userId,
      description: form.description,
      client_id: form.client_id || null,
      amount: Number(form.amount),
      due_date: form.due_date,
      recurrence: form.recurrence,
      notes: form.notes || null,
    });
    setSaving(false);
    if (error) toast({ title: "Erro", description: error.message, variant: "destructive" });
    else {
      toast({ title: "Receita criada" });
      onSaved();
    }
  };

  return (
    <DialogContent>
      <DialogHeader>
        <DialogTitle>Nova receita</DialogTitle>
      </DialogHeader>
      <div className="space-y-3">
        <div>
          <Label>Descrição *</Label>
          <Input
            value={form.description}
            onChange={(e) => setForm({ ...form, description: e.target.value })}
            placeholder="Ex: Mensalidade Outubro"
          />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>Cliente</Label>
            <Select value={form.client_id || "none"} onValueChange={(v) => setForm({ ...form, client_id: v === "none" ? "" : v })}>
              <SelectTrigger><SelectValue placeholder="Selecionar" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="none">— Sem cliente —</SelectItem>
                {clients.map((c) => (
                  <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Valor (R$) *</Label>
            <Input
              type="number"
              step="0.01"
              value={form.amount}
              onChange={(e) => setForm({ ...form, amount: e.target.value })}
            />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>Vencimento</Label>
            <Input
              type="date"
              value={form.due_date}
              onChange={(e) => setForm({ ...form, due_date: e.target.value })}
            />
          </div>
          <div>
            <Label>Recorrência</Label>
            <Select value={form.recurrence} onValueChange={(v) => setForm({ ...form, recurrence: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {RECURRENCE_OPTIONS.map((o) => (
                  <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        <div>
          <Label>Observações</Label>
          <Textarea
            rows={2}
            value={form.notes}
            onChange={(e) => setForm({ ...form, notes: e.target.value })}
          />
        </div>
      </div>
      <DialogFooter>
        <Button onClick={save} disabled={saving}>{saving ? "Salvando..." : "Salvar"}</Button>
      </DialogFooter>
    </DialogContent>
  );
}

function ExpenseDialog({ userId, onSaved }: { userId?: string; onSaved: () => void }) {
  const [form, setForm] = useState({
    description: "",
    category: "outros",
    amount: "",
    due_date: new Date().toISOString().slice(0, 10),
    recurrence: "unico",
    notes: "",
  });
  const [saving, setSaving] = useState(false);

  const save = async () => {
    if (!userId) return;
    if (!form.description || !form.amount) {
      toast({ title: "Preencha descrição e valor", variant: "destructive" });
      return;
    }
    setSaving(true);
    const { error } = await supabase.from("financial_expenses").insert({
      created_by: userId,
      description: form.description,
      category: form.category,
      amount: Number(form.amount),
      due_date: form.due_date,
      recurrence: form.recurrence,
      notes: form.notes || null,
    });
    setSaving(false);
    if (error) toast({ title: "Erro", description: error.message, variant: "destructive" });
    else {
      toast({ title: "Despesa criada" });
      onSaved();
    }
  };

  return (
    <DialogContent>
      <DialogHeader>
        <DialogTitle>Nova despesa</DialogTitle>
      </DialogHeader>
      <div className="space-y-3">
        <div>
          <Label>Descrição *</Label>
          <Input
            value={form.description}
            onChange={(e) => setForm({ ...form, description: e.target.value })}
            placeholder="Ex: Assinatura Meta Business"
          />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>Categoria</Label>
            <Select value={form.category} onValueChange={(v) => setForm({ ...form, category: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {EXPENSE_CATEGORIES.map((c) => (
                  <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Valor (R$) *</Label>
            <Input
              type="number"
              step="0.01"
              value={form.amount}
              onChange={(e) => setForm({ ...form, amount: e.target.value })}
            />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>Vencimento</Label>
            <Input
              type="date"
              value={form.due_date}
              onChange={(e) => setForm({ ...form, due_date: e.target.value })}
            />
          </div>
          <div>
            <Label>Recorrência</Label>
            <Select value={form.recurrence} onValueChange={(v) => setForm({ ...form, recurrence: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {RECURRENCE_OPTIONS.map((o) => (
                  <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        <div>
          <Label>Observações</Label>
          <Textarea
            rows={2}
            value={form.notes}
            onChange={(e) => setForm({ ...form, notes: e.target.value })}
          />
        </div>
      </div>
      <DialogFooter>
        <Button onClick={save} disabled={saving}>{saving ? "Salvando..." : "Salvar"}</Button>
      </DialogFooter>
    </DialogContent>
  );
}

function CommissionDialog({
  profiles,
  clients,
  userId,
  onSaved,
}: {
  profiles: Profile[];
  clients: Client[];
  userId?: string;
  onSaved: () => void;
}) {
  const [form, setForm] = useState({
    user_id: "",
    client_id: "",
    description: "",
    amount: "",
    reference_month: new Date().toISOString().slice(0, 7) + "-01",
    notes: "",
  });
  const [saving, setSaving] = useState(false);

  const save = async () => {
    if (!userId) return;
    if (!form.user_id || !form.amount || !form.description) {
      toast({ title: "Preencha beneficiário, descrição e valor", variant: "destructive" });
      return;
    }
    setSaving(true);
    const { error } = await supabase.from("financial_commissions").insert({
      created_by: userId,
      user_id: form.user_id,
      client_id: form.client_id || null,
      description: form.description,
      amount: Number(form.amount),
      reference_month: form.reference_month,
      notes: form.notes || null,
    });
    setSaving(false);
    if (error) toast({ title: "Erro", description: error.message, variant: "destructive" });
    else {
      toast({ title: "Comissão criada" });
      onSaved();
    }
  };

  return (
    <DialogContent>
      <DialogHeader>
        <DialogTitle>Nova comissão / pagamento</DialogTitle>
      </DialogHeader>
      <div className="space-y-3">
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>Beneficiário *</Label>
            <Select value={form.user_id || undefined} onValueChange={(v) => setForm({ ...form, user_id: v })}>
              <SelectTrigger><SelectValue placeholder="Selecionar" /></SelectTrigger>
              <SelectContent>
                {profiles.map((p) => (
                  <SelectItem key={p.user_id} value={p.user_id}>
                    {p.display_name ?? "Usuário"}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Cliente (opcional)</Label>
            <Select value={form.client_id || "none"} onValueChange={(v) => setForm({ ...form, client_id: v === "none" ? "" : v })}>
              <SelectTrigger><SelectValue placeholder="Selecionar" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="none">— Sem cliente —</SelectItem>
                {clients.map((c) => (
                  <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        <div>
          <Label>Descrição *</Label>
          <Input
            value={form.description}
            onChange={(e) => setForm({ ...form, description: e.target.value })}
            placeholder="Ex: Comissão sobre cliente X"
          />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>Valor (R$) *</Label>
            <Input
              type="number"
              step="0.01"
              value={form.amount}
              onChange={(e) => setForm({ ...form, amount: e.target.value })}
            />
          </div>
          <div>
            <Label>Mês de referência</Label>
            <Input
              type="month"
              value={form.reference_month.slice(0, 7)}
              onChange={(e) => setForm({ ...form, reference_month: e.target.value + "-01" })}
            />
          </div>
        </div>
        <div>
          <Label>Observações</Label>
          <Textarea
            rows={2}
            value={form.notes}
            onChange={(e) => setForm({ ...form, notes: e.target.value })}
          />
        </div>
      </div>
      <DialogFooter>
        <Button onClick={save} disabled={saving}>{saving ? "Salvando..." : "Salvar"}</Button>
      </DialogFooter>
    </DialogContent>
  );
}
