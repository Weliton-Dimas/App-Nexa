import { useEffect, useMemo, useState } from "react";
import { DashboardSidebar } from "@/components/DashboardSidebar";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

type Category = "app_improvement" | "client_strategy";
type Priority = "baixa" | "media" | "alta" | "critica";

interface Idea {
  id: string;
  author_id: string;
  category: Category;
  client_id: string | null;
  priority: Priority;
  title: string;
  description: string;
  created_at: string;
}

const PRIORITY_META: Record<Priority, { label: string; className: string }> = {
  baixa: { label: "Baixa", className: "bg-emerald-500/15 text-emerald-500 border-emerald-500/30 hover:bg-emerald-500/25" },
  media: { label: "Média", className: "bg-amber-400/15 text-amber-400 border-amber-400/30 hover:bg-amber-400/25" },
  alta: { label: "Alta", className: "bg-orange-500/15 text-orange-500 border-orange-500/30 hover:bg-orange-500/25" },
  critica: { label: "Crítica", className: "bg-red-500/15 text-red-500 border-red-500/30 hover:bg-red-500/25" },
};

const CATEGORY_LABEL: Record<Category, string> = {
  app_improvement: "Melhoria no App",
  client_strategy: "Estratégia para Cliente",
};

export default function MeuEspacoPage() {
  const { user } = useAuth();
  const qc = useQueryClient();

  const [category, setCategory] = useState<Category>("app_improvement");
  const [clientId, setClientId] = useState<string>("");
  const [authorId, setAuthorId] = useState<string>("");
  const [priority, setPriority] = useState<Priority>("media");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [saving, setSaving] = useState(false);

  const { data: profiles = [] } = useQuery({
    queryKey: ["team-profiles"],
    queryFn: async () => {
      const { data } = await supabase.from("profiles").select("user_id, display_name, avatar_url").order("display_name");
      return data || [];
    },
  });

  useEffect(() => {
    if (user && !authorId) setAuthorId(user.id);
  }, [user, authorId]);

  const { data: clients = [] } = useQuery({
    queryKey: ["clients-min"],
    queryFn: async () => {
      const { data } = await supabase.from("clients").select("id, name").order("name");
      return data || [];
    },
  });

  const { data: ideas = [], isLoading } = useQuery({
    queryKey: ["ideas"],
    queryFn: async () => {
      const { data, error } = await (supabase as any).from("ideas").select("*").order("created_at", { ascending: false });
      if (error) throw error;
      return data as Idea[];
    },
  });

  const authorIds = useMemo(() => Array.from(new Set(ideas.map((i) => i.author_id))), [ideas]);
  const { data: authors = {} } = useQuery({
    queryKey: ["idea-authors", authorIds.join(",")],
    enabled: authorIds.length > 0,
    queryFn: async () => {
      const { data } = await supabase.from("profiles").select("user_id, display_name, avatar_url").in("user_id", authorIds);
      const map: Record<string, { name: string; avatar: string | null }> = {};
      (data || []).forEach((p) => { map[p.user_id] = { name: p.display_name || "Usuário", avatar: p.avatar_url }; });
      return map;
    },
  });

  const clientNameById = useMemo(() => {
    const m: Record<string, string> = {};
    clients.forEach((c: any) => { m[c.id] = c.name; });
    return m;
  }, [clients]);

  const reset = () => {
    setCategory("app_improvement");
    setClientId("");
    setAuthorId(user?.id || "");
    setPriority("media");
    setTitle("");
    setDescription("");
  };

  const submit = async () => {
    if (!user) return;
    if (!authorId) { toast.error("Selecione um autor"); return; }
    if (!title.trim() || !description.trim()) {
      toast.error("Preencha título e descrição");
      return;
    }
    if (category === "client_strategy" && !clientId) {
      toast.error("Selecione um cliente");
      return;
    }
    setSaving(true);
    const { error } = await (supabase as any).from("ideas").insert({
      author_id: authorId,
      category,
      client_id: category === "client_strategy" ? clientId : null,
      priority,
      title: title.trim(),
      description: description.trim(),
    });
    setSaving(false);
    if (error) { toast.error("Erro ao enviar ideia", { description: error.message }); return; }
    toast.success("Ideia enviada!");
    reset();
    qc.invalidateQueries({ queryKey: ["ideas"] });
  };

  return (
    <div className="flex min-h-screen bg-background">
      <DashboardSidebar />
      <main className="flex-1 overflow-y-auto">
        <div className="max-w-[1600px] mx-auto px-8 py-8 space-y-8">
          {/* Header */}
          <header>
            <h1 className="text-3xl font-bold text-foreground">Banco de Ideias 💡</h1>
            <p className="text-muted-foreground mt-2 max-w-3xl">
              Colabore com sugestões de melhoria para o nosso ecossistema ou novas estratégias de performance para os clientes.
            </p>
          </header>

          {/* Form Card */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Nova Ideia</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <div className="space-y-1.5">
                  <Label>Categoria</Label>
                  <Select value={category} onValueChange={(v) => setCategory(v as Category)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="app_improvement">Melhoria no App</SelectItem>
                      <SelectItem value="client_strategy">Estratégia para Cliente</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-1.5">
                  <Label className={cn(category !== "client_strategy" && "text-muted-foreground/50")}>Cliente</Label>
                  <Select
                    value={clientId}
                    onValueChange={setClientId}
                    disabled={category !== "client_strategy"}
                  >
                    <SelectTrigger><SelectValue placeholder={category === "client_strategy" ? "Selecione..." : "—"} /></SelectTrigger>
                    <SelectContent>
                      {clients.map((c: any) => (
                        <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-1.5">
                  <Label>Autor</Label>
                  <Select value={authorId} onValueChange={setAuthorId}>
                    <SelectTrigger><SelectValue placeholder="Selecione..." /></SelectTrigger>
                    <SelectContent>
                      {profiles.map((p: any) => (
                        <SelectItem key={p.user_id} value={p.user_id}>
                          {p.display_name || "Usuário"}{p.user_id === user?.id ? " (você)" : ""}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-1.5 md:col-span-2 lg:col-span-3">
                  <Label>Nível de Prioridade</Label>
                  <div className="flex flex-wrap gap-2">
                    {(Object.keys(PRIORITY_META) as Priority[]).map((p) => {
                      const meta = PRIORITY_META[p];
                      const active = priority === p;
                      return (
                        <button
                          key={p}
                          type="button"
                          onClick={() => setPriority(p)}
                          className={cn(
                            "px-3 py-1.5 rounded-full text-xs font-semibold border transition-all",
                            meta.className,
                            active ? "ring-2 ring-offset-2 ring-offset-background ring-current scale-105" : "opacity-70"
                          )}
                        >
                          {meta.label}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="space-y-1.5 md:col-span-2 lg:col-span-3">
                  <Label>Título da Ideia</Label>
                  <Input value={title} onChange={(e) => setTitle(e.target.value)} maxLength={140} placeholder="Resuma sua ideia em uma frase" />
                </div>

                <div className="space-y-1.5 md:col-span-2 lg:col-span-3">
                  <Label>Descrição Detalhada</Label>
                  <Textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={5} maxLength={2000} placeholder="Conte mais sobre o problema, a solução proposta e o impacto esperado." />
                </div>
              </div>

              <div className="flex justify-end mt-6">
                <Button onClick={submit} disabled={saving} className="bg-accent text-accent-foreground hover:bg-accent/90">
                  {saving ? "Enviando..." : "Enviar Ideia"}
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Mural */}
          <section className="space-y-4">
            <h2 className="text-xl font-semibold text-foreground">Ideias Recentes</h2>

            {isLoading ? (
              <p className="text-sm text-muted-foreground">Carregando...</p>
            ) : ideas.length === 0 ? (
              <Card><CardContent className="py-12 text-center text-muted-foreground">Nenhuma ideia ainda. Seja o primeiro!</CardContent></Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {ideas.map((idea) => {
                  const meta = PRIORITY_META[idea.priority];
                  const author = authors[idea.author_id];
                  const catLabel = idea.category === "client_strategy" && idea.client_id
                    ? clientNameById[idea.client_id] || "Cliente"
                    : CATEGORY_LABEL[idea.category];
                  return (
                    <Card key={idea.id} className="shadow-sm hover:shadow-md transition-shadow flex flex-col">
                      <CardContent className="p-5 flex flex-col gap-3 flex-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <Badge variant="outline" className={cn("border", meta.className)}>{meta.label}</Badge>
                          <Badge variant="secondary">{catLabel}</Badge>
                        </div>
                        <h3 className="font-semibold text-foreground leading-tight">{idea.title}</h3>
                        <p className="text-sm text-muted-foreground line-clamp-3 flex-1">{idea.description}</p>
                        <div className="flex items-center gap-2 pt-3 border-t border-border">
                          <Avatar className="h-7 w-7">
                            <AvatarImage src={author?.avatar || undefined} />
                            <AvatarFallback className="text-xs">{(author?.name || "?").slice(0, 2).toUpperCase()}</AvatarFallback>
                          </Avatar>
                          <span className="text-xs text-foreground font-medium">{author?.name || "Usuário"}</span>
                          <span className="text-xs text-muted-foreground ml-auto">
                            {new Date(idea.created_at).toLocaleDateString("pt-BR", { day: "2-digit", month: "short", year: "numeric" })}
                          </span>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </section>
        </div>
      </main>
    </div>
  );
}
