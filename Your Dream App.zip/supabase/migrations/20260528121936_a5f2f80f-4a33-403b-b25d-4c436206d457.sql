-- 1. Fix client-contracts storage policies (objects.name, not c.name)
DROP POLICY IF EXISTS "Admin or assigned can read contract files" ON storage.objects;
DROP POLICY IF EXISTS "Admin or assigned can update contract files" ON storage.objects;
DROP POLICY IF EXISTS "Admin or assigned can delete contract files" ON storage.objects;
DROP POLICY IF EXISTS "Admin or assigned can upload contract files" ON storage.objects;

CREATE POLICY "Admin or assigned can read contract files"
ON storage.objects FOR SELECT TO authenticated
USING (
  bucket_id = 'client-contracts'
  AND (
    public.has_role(auth.uid(), 'admin'::app_role)
    OR EXISTS (
      SELECT 1 FROM public.clients c
      WHERE c.id::text = (storage.foldername(name))[1]
        AND auth.uid()::text = ANY (c.assigned_users)
    )
  )
);

CREATE POLICY "Admin or assigned can upload contract files"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (
  bucket_id = 'client-contracts'
  AND (
    public.has_role(auth.uid(), 'admin'::app_role)
    OR EXISTS (
      SELECT 1 FROM public.clients c
      WHERE c.id::text = (storage.foldername(name))[1]
        AND auth.uid()::text = ANY (c.assigned_users)
    )
  )
);

CREATE POLICY "Admin or assigned can update contract files"
ON storage.objects FOR UPDATE TO authenticated
USING (
  bucket_id = 'client-contracts'
  AND (
    public.has_role(auth.uid(), 'admin'::app_role)
    OR EXISTS (
      SELECT 1 FROM public.clients c
      WHERE c.id::text = (storage.foldername(name))[1]
        AND auth.uid()::text = ANY (c.assigned_users)
    )
  )
);

CREATE POLICY "Admin or assigned can delete contract files"
ON storage.objects FOR DELETE TO authenticated
USING (
  bucket_id = 'client-contracts'
  AND (
    public.has_role(auth.uid(), 'admin'::app_role)
    OR EXISTS (
      SELECT 1 FROM public.clients c
      WHERE c.id::text = (storage.foldername(name))[1]
        AND auth.uid()::text = ANY (c.assigned_users)
    )
  )
);

-- 2. Restrict clients INSERT to admins only
DO $$
DECLARE p record;
BEGIN
  FOR p IN SELECT polname FROM pg_policy WHERE polrelid='public.clients'::regclass AND polcmd='a' LOOP
    EXECUTE format('DROP POLICY %I ON public.clients', p.polname);
  END LOOP;
END$$;

CREATE POLICY "Admins can insert clients"
ON public.clients FOR INSERT TO authenticated
WITH CHECK (public.has_role(auth.uid(), 'admin'::app_role));

-- 3. Revoke SELECT on sensitive token/credential columns from authenticated
REVOKE SELECT (meta_access_token, google_access_token) ON public.clients FROM authenticated;
REVOKE SELECT (access_token, refresh_token) ON public.client_integrations FROM authenticated;
REVOKE SELECT (auth, p256dh) ON public.push_subscriptions FROM authenticated;
REVOKE SELECT (access_token, refresh_token, sync_token) ON public.user_google_calendar_tokens FROM authenticated;
REVOKE SELECT (access_token, refresh_token) ON public.workspace_integrations FROM authenticated;
REVOKE SELECT (password_encrypted) ON public.workspace_magazord_stores FROM authenticated;