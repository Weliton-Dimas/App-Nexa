ALTER TABLE public.optimization_sessions
  ADD COLUMN IF NOT EXISTS optimized_meta boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS optimized_google boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS action_budget boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS action_creative boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS action_audience boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS action_monitoring boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS observation text;

ALTER TABLE public.clients
  ADD COLUMN IF NOT EXISTS active_optimization_paused_at timestamp with time zone,
  ADD COLUMN IF NOT EXISTS active_optimization_accumulated_seconds integer NOT NULL DEFAULT 0;