
CREATE TABLE IF NOT EXISTS public.workspace_magazord_stores (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  label text NOT NULL,
  base_url text NOT NULL,
  username text NOT NULL,
  password_encrypted text NOT NULL,
  created_by uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.workspace_magazord_stores ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins manage magazord stores"
ON public.workspace_magazord_stores
FOR ALL
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Authenticated read magazord stores"
ON public.workspace_magazord_stores
FOR SELECT
TO authenticated
USING (true);

CREATE TRIGGER update_workspace_magazord_stores_updated_at
BEFORE UPDATE ON public.workspace_magazord_stores
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
