-- pricing_products: relax INSERT for admins
DROP POLICY IF EXISTS "Admin or assigned can insert pricing products" ON public.pricing_products;
CREATE POLICY "Admin or assigned can insert pricing products"
ON public.pricing_products
FOR INSERT
TO authenticated
WITH CHECK (
  has_role(auth.uid(), 'admin'::app_role)
  OR (
    auth.uid() = user_id
    AND EXISTS (
      SELECT 1 FROM clients c
      WHERE c.id = pricing_products.client_id
        AND (auth.uid())::text = ANY (c.assigned_users)
    )
  )
);

-- pricing_settings
DROP POLICY IF EXISTS "Admin or assigned can insert pricing settings" ON public.pricing_settings;
CREATE POLICY "Admin or assigned can insert pricing settings"
ON public.pricing_settings
FOR INSERT
TO authenticated
WITH CHECK (
  has_role(auth.uid(), 'admin'::app_role)
  OR (
    auth.uid() = user_id
    AND EXISTS (
      SELECT 1 FROM clients c
      WHERE c.id = pricing_settings.client_id
        AND (auth.uid())::text = ANY (c.assigned_users)
    )
  )
);

-- pricing_scenarios
DROP POLICY IF EXISTS "Admin or assigned can insert pricing scenarios" ON public.pricing_scenarios;
CREATE POLICY "Admin or assigned can insert pricing scenarios"
ON public.pricing_scenarios
FOR INSERT
TO authenticated
WITH CHECK (
  has_role(auth.uid(), 'admin'::app_role)
  OR (
    auth.uid() = user_id
    AND EXISTS (
      SELECT 1 FROM clients c
      WHERE c.id = pricing_scenarios.client_id
        AND (auth.uid())::text = ANY (c.assigned_users)
    )
  )
);