
-- 1. client_contracts table
CREATE TABLE public.client_contracts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id uuid NOT NULL,
  name text NOT NULL DEFAULT 'Contrato',
  file_url text,
  file_path text,
  external_url text,
  contract_start date,
  contract_end date,
  notes text,
  uploaded_by uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.client_contracts TO authenticated;
GRANT ALL ON public.client_contracts TO service_role;

ALTER TABLE public.client_contracts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admin or assigned can read client contracts"
ON public.client_contracts FOR SELECT TO authenticated
USING (
  has_role(auth.uid(), 'admin'::app_role)
  OR EXISTS (SELECT 1 FROM public.clients c
    WHERE c.id = client_contracts.client_id
      AND (auth.uid())::text = ANY (c.assigned_users))
);

CREATE POLICY "Admin or assigned can insert client contracts"
ON public.client_contracts FOR INSERT TO authenticated
WITH CHECK (
  auth.uid() = uploaded_by AND (
    has_role(auth.uid(), 'admin'::app_role)
    OR EXISTS (SELECT 1 FROM public.clients c
      WHERE c.id = client_contracts.client_id
        AND (auth.uid())::text = ANY (c.assigned_users))
  )
);

CREATE POLICY "Admin or assigned can update client contracts"
ON public.client_contracts FOR UPDATE TO authenticated
USING (
  has_role(auth.uid(), 'admin'::app_role)
  OR EXISTS (SELECT 1 FROM public.clients c
    WHERE c.id = client_contracts.client_id
      AND (auth.uid())::text = ANY (c.assigned_users))
);

CREATE POLICY "Admin or assigned can delete client contracts"
ON public.client_contracts FOR DELETE TO authenticated
USING (
  has_role(auth.uid(), 'admin'::app_role)
  OR EXISTS (SELECT 1 FROM public.clients c
    WHERE c.id = client_contracts.client_id
      AND (auth.uid())::text = ANY (c.assigned_users))
);

CREATE TRIGGER update_client_contracts_updated_at
BEFORE UPDATE ON public.client_contracts
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE INDEX idx_client_contracts_client ON public.client_contracts(client_id);

-- 2. Private storage bucket
INSERT INTO storage.buckets (id, name, public)
VALUES ('client-contracts', 'client-contracts', false)
ON CONFLICT (id) DO NOTHING;

-- Storage policies — path layout: <client_id>/<filename>
CREATE POLICY "Admin or assigned can read contract files"
ON storage.objects FOR SELECT TO authenticated
USING (
  bucket_id = 'client-contracts' AND (
    has_role(auth.uid(), 'admin'::app_role)
    OR EXISTS (SELECT 1 FROM public.clients c
      WHERE c.id::text = (storage.foldername(name))[1]
        AND (auth.uid())::text = ANY (c.assigned_users))
  )
);

CREATE POLICY "Admin or assigned can upload contract files"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (
  bucket_id = 'client-contracts' AND (
    has_role(auth.uid(), 'admin'::app_role)
    OR EXISTS (SELECT 1 FROM public.clients c
      WHERE c.id::text = (storage.foldername(name))[1]
        AND (auth.uid())::text = ANY (c.assigned_users))
  )
);

CREATE POLICY "Admin or assigned can update contract files"
ON storage.objects FOR UPDATE TO authenticated
USING (
  bucket_id = 'client-contracts' AND (
    has_role(auth.uid(), 'admin'::app_role)
    OR EXISTS (SELECT 1 FROM public.clients c
      WHERE c.id::text = (storage.foldername(name))[1]
        AND (auth.uid())::text = ANY (c.assigned_users))
  )
);

CREATE POLICY "Admin or assigned can delete contract files"
ON storage.objects FOR DELETE TO authenticated
USING (
  bucket_id = 'client-contracts' AND (
    has_role(auth.uid(), 'admin'::app_role)
    OR EXISTS (SELECT 1 FROM public.clients c
      WHERE c.id::text = (storage.foldername(name))[1]
        AND (auth.uid())::text = ANY (c.assigned_users))
  )
);
