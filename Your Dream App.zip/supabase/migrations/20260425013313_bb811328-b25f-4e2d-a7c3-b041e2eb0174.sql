
-- Creative demands table
CREATE TABLE public.creative_demands (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  type TEXT NOT NULL,
  element TEXT NOT NULL,
  client_id UUID REFERENCES public.clients(id) ON DELETE SET NULL,
  assignee_id UUID,
  manager_id UUID,
  priority TEXT NOT NULL DEFAULT 'media',
  deadline DATE,
  status TEXT NOT NULL DEFAULT 'backlog',
  briefing TEXT,
  reference_links TEXT[] DEFAULT '{}'::text[],
  checklist JSONB DEFAULT '[]'::jsonb,
  created_by UUID NOT NULL,
  completed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.creative_demands ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated can read creative demands" ON public.creative_demands FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated can insert creative demands" ON public.creative_demands FOR INSERT TO authenticated WITH CHECK (auth.uid() = created_by);
CREATE POLICY "Authenticated can update creative demands" ON public.creative_demands FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Creator or admin can delete creative demands" ON public.creative_demands FOR DELETE TO authenticated USING (auth.uid() = created_by OR has_role(auth.uid(), 'admin'::app_role));

CREATE TRIGGER update_creative_demands_updated_at BEFORE UPDATE ON public.creative_demands FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Creative library
CREATE TABLE public.creative_library (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  client_id UUID REFERENCES public.clients(id) ON DELETE SET NULL,
  media_type TEXT NOT NULL DEFAULT 'image',
  file_url TEXT NOT NULL,
  thumbnail_url TEXT,
  tags TEXT[] DEFAULT '{}'::text[],
  notes TEXT,
  uploaded_by UUID NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.creative_library ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated can read creative library" ON public.creative_library FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated can insert creative library" ON public.creative_library FOR INSERT TO authenticated WITH CHECK (auth.uid() = uploaded_by);
CREATE POLICY "Authenticated can update creative library" ON public.creative_library FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Uploader or admin can delete creative library" ON public.creative_library FOR DELETE TO authenticated USING (auth.uid() = uploaded_by OR has_role(auth.uid(), 'admin'::app_role));

CREATE TRIGGER update_creative_library_updated_at BEFORE UPDATE ON public.creative_library FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Storage bucket for creative files
INSERT INTO storage.buckets (id, name, public) VALUES ('creatives', 'creatives', true);

CREATE POLICY "Public can view creative files" ON storage.objects FOR SELECT USING (bucket_id = 'creatives');
CREATE POLICY "Authenticated can upload creative files" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'creatives');
CREATE POLICY "Authenticated can update creative files" ON storage.objects FOR UPDATE TO authenticated USING (bucket_id = 'creatives');
CREATE POLICY "Authenticated can delete creative files" ON storage.objects FOR DELETE TO authenticated USING (bucket_id = 'creatives');
