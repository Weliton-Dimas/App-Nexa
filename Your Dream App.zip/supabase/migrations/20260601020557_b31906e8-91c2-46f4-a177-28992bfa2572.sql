ALTER TABLE public.pricing_settings
  ADD COLUMN IF NOT EXISTS pix_discount_pct numeric NOT NULL DEFAULT 5
  CHECK (pix_discount_pct >= 0 AND pix_discount_pct < 100);