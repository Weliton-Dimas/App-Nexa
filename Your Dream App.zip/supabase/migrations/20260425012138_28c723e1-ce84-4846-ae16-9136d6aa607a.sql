CREATE TABLE public.calendar_tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  date date NOT NULL,
  status text NOT NULL DEFAULT 'nova',
  priority text NOT NULL DEFAULT 'media',
  client_id uuid REFERENCES public.clients(id) ON DELETE SET NULL,
  assignee_id uuid,
  created_by uuid NOT NULL,
  color text NOT NULL DEFAULT 'blue',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_calendar_tasks_date ON public.calendar_tasks(date);
CREATE INDEX idx_calendar_tasks_assignee ON public.calendar_tasks(assignee_id);

ALTER TABLE public.calendar_tasks ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated can read tasks"
  ON public.calendar_tasks FOR SELECT
  TO authenticated USING (true);

CREATE POLICY "Authenticated can insert tasks"
  ON public.calendar_tasks FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = created_by);

CREATE POLICY "Authenticated can update tasks"
  ON public.calendar_tasks FOR UPDATE
  TO authenticated USING (true);

CREATE POLICY "Creator or admin can delete tasks"
  ON public.calendar_tasks FOR DELETE
  TO authenticated USING (auth.uid() = created_by OR public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER update_calendar_tasks_updated_at
  BEFORE UPDATE ON public.calendar_tasks
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();