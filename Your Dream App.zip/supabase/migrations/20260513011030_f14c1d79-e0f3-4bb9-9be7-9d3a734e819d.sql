-- 1. Nova tabela
CREATE TABLE IF NOT EXISTS public.client_integrations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id uuid NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  provider text NOT NULL CHECK (provider IN ('meta', 'google', 'magazord')),
  status text NOT NULL DEFAULT 'disconnected' CHECK (status IN ('connected','disconnected','expired','error')),
  account_id text,
  account_name text,
  access_token text,
  refresh_token text,
  expires_at timestamptz,
  scope text,
  extra jsonb NOT NULL DEFAULT '{}'::jsonb,
  last_synced_at timestamptz,
  last_error text,
  connected_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (client_id, provider)
);

CREATE INDEX IF NOT EXISTS idx_client_integrations_client ON public.client_integrations(client_id);
CREATE INDEX IF NOT EXISTS idx_client_integrations_expires ON public.client_integrations(expires_at) WHERE status = 'connected';

-- 2. RLS
ALTER TABLE public.client_integrations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admin or assigned can read client integrations"
ON public.client_integrations FOR SELECT TO authenticated
USING (
  has_role(auth.uid(), 'admin'::app_role)
  OR EXISTS (
    SELECT 1 FROM public.clients c
    WHERE c.id = client_integrations.client_id
      AND (auth.uid())::text = ANY (c.assigned_users)
  )
);

CREATE POLICY "Admin or assigned can insert client integrations"
ON public.client_integrations FOR INSERT TO authenticated
WITH CHECK (
  has_role(auth.uid(), 'admin'::app_role)
  OR EXISTS (
    SELECT 1 FROM public.clients c
    WHERE c.id = client_integrations.client_id
      AND (auth.uid())::text = ANY (c.assigned_users)
  )
);

CREATE POLICY "Admin or assigned can update client integrations"
ON public.client_integrations FOR UPDATE TO authenticated
USING (
  has_role(auth.uid(), 'admin'::app_role)
  OR EXISTS (
    SELECT 1 FROM public.clients c
    WHERE c.id = client_integrations.client_id
      AND (auth.uid())::text = ANY (c.assigned_users)
  )
);

CREATE POLICY "Admin or assigned can delete client integrations"
ON public.client_integrations FOR DELETE TO authenticated
USING (
  has_role(auth.uid(), 'admin'::app_role)
  OR EXISTS (
    SELECT 1 FROM public.clients c
    WHERE c.id = client_integrations.client_id
      AND (auth.uid())::text = ANY (c.assigned_users)
  )
);

-- 3. Trigger updated_at
CREATE TRIGGER trg_client_integrations_updated_at
BEFORE UPDATE ON public.client_integrations
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 4. Migrar dados legados (tokens em texto puro — serão re-criptografados na 1ª chamada de refresh)
INSERT INTO public.client_integrations (client_id, provider, status, account_id, access_token, last_synced_at)
SELECT id, 'meta',
       CASE WHEN meta_integration_status = 'ativo' THEN 'connected' ELSE 'disconnected' END,
       meta_account_id, meta_access_token, meta_last_validated_at
FROM public.clients
WHERE meta_access_token IS NOT NULL AND meta_access_token <> ''
ON CONFLICT (client_id, provider) DO NOTHING;

INSERT INTO public.client_integrations (client_id, provider, status, account_id, access_token, last_synced_at)
SELECT id, 'google',
       CASE WHEN google_integration_status = 'ativo' THEN 'connected' ELSE 'disconnected' END,
       google_account_id, google_access_token, google_last_validated_at
FROM public.clients
WHERE google_access_token IS NOT NULL AND google_access_token <> ''
ON CONFLICT (client_id, provider) DO NOTHING;