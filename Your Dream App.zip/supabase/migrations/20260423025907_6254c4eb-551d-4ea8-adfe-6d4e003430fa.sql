ALTER TABLE public.clients
  ADD COLUMN IF NOT EXISTS meta_access_token text,
  ADD COLUMN IF NOT EXISTS meta_account_id text,
  ADD COLUMN IF NOT EXISTS meta_integration_status text NOT NULL DEFAULT 'inativo',
  ADD COLUMN IF NOT EXISTS meta_last_validated_at timestamp with time zone,
  ADD COLUMN IF NOT EXISTS google_access_token text,
  ADD COLUMN IF NOT EXISTS google_account_id text,
  ADD COLUMN IF NOT EXISTS google_integration_status text NOT NULL DEFAULT 'inativo',
  ADD COLUMN IF NOT EXISTS google_last_validated_at timestamp with time zone;