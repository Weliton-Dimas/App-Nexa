ALTER TABLE public.pricing_settings
  ADD COLUMN IF NOT EXISTS column_widths jsonb NOT NULL DEFAULT '{}'::jsonb,
  ADD COLUMN IF NOT EXISTS hidden_columns jsonb NOT NULL DEFAULT '[]'::jsonb;