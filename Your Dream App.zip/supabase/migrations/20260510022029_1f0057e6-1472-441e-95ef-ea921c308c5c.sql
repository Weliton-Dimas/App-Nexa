ALTER TABLE public.creative_demands
  ADD COLUMN IF NOT EXISTS briefing_images text[] NOT NULL DEFAULT '{}'::text[],
  ADD COLUMN IF NOT EXISTS final_assets jsonb NOT NULL DEFAULT '[]'::jsonb,
  ADD COLUMN IF NOT EXISTS final_notes text;