REVOKE SELECT (access_token, refresh_token) ON public.client_integrations FROM authenticated, anon;
REVOKE SELECT (meta_access_token, google_access_token) ON public.clients FROM authenticated, anon;
REVOKE SELECT (p256dh, auth) ON public.push_subscriptions FROM authenticated, anon;
REVOKE SELECT (access_token, refresh_token, sync_token) ON public.user_google_calendar_tokens FROM authenticated, anon;
REVOKE SELECT (access_token, refresh_token) ON public.workspace_integrations FROM authenticated, anon;
REVOKE SELECT (password_encrypted) ON public.workspace_magazord_stores FROM authenticated, anon;