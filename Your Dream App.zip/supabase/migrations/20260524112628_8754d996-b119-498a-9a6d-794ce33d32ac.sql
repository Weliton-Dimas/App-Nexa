
-- Tokens table
CREATE TABLE public.user_google_calendar_tokens (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL UNIQUE,
  google_email TEXT,
  access_token TEXT NOT NULL,
  refresh_token TEXT NOT NULL,
  expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
  scope TEXT,
  calendar_id TEXT NOT NULL DEFAULT 'primary',
  last_synced_at TIMESTAMP WITH TIME ZONE,
  sync_token TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.user_google_calendar_tokens ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users read own google calendar tokens"
ON public.user_google_calendar_tokens FOR SELECT TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "Users insert own google calendar tokens"
ON public.user_google_calendar_tokens FOR INSERT TO authenticated
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users update own google calendar tokens"
ON public.user_google_calendar_tokens FOR UPDATE TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "Users delete own google calendar tokens"
ON public.user_google_calendar_tokens FOR DELETE TO authenticated
USING (auth.uid() = user_id);

CREATE TRIGGER update_user_google_calendar_tokens_updated_at
BEFORE UPDATE ON public.user_google_calendar_tokens
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Map app task <-> google event
ALTER TABLE public.calendar_tasks
ADD COLUMN IF NOT EXISTS google_event_id TEXT,
ADD COLUMN IF NOT EXISTS google_synced_at TIMESTAMP WITH TIME ZONE;

CREATE INDEX IF NOT EXISTS idx_calendar_tasks_google_event_id
ON public.calendar_tasks(google_event_id) WHERE google_event_id IS NOT NULL;
