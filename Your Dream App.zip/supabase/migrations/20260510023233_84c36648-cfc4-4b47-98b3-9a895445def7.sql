CREATE TABLE public.prospects (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  company_name TEXT NOT NULL,
  contact_name TEXT,
  contact_role TEXT,
  email TEXT,
  phone TEXT,
  website_url TEXT,
  instagram_url TEXT,
  linkedin_url TEXT,
  status TEXT NOT NULL DEFAULT 'novo',
  temperature TEXT,
  source TEXT,
  bant_budget BOOLEAN NOT NULL DEFAULT false,
  bant_authority BOOLEAN NOT NULL DEFAULT false,
  bant_need BOOLEAN NOT NULL DEFAULT false,
  bant_timeline BOOLEAN NOT NULL DEFAULT false,
  next_action TEXT,
  next_action_at TIMESTAMP WITH TIME ZONE,
  estimated_value NUMERIC(12,2),
  notes TEXT,
  position INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.prospects ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own prospects or admin"
ON public.prospects FOR SELECT TO authenticated
USING (auth.uid() = user_id OR has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Users can insert own prospects"
ON public.prospects FOR INSERT TO authenticated
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own prospects or admin"
ON public.prospects FOR UPDATE TO authenticated
USING (auth.uid() = user_id OR has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Users can delete own prospects or admin"
ON public.prospects FOR DELETE TO authenticated
USING (auth.uid() = user_id OR has_role(auth.uid(), 'admin'::app_role));

CREATE TRIGGER update_prospects_updated_at
BEFORE UPDATE ON public.prospects
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE INDEX idx_prospects_user_status ON public.prospects(user_id, status);