-- Add new columns to clients table
ALTER TABLE public.clients
  ADD COLUMN IF NOT EXISTS has_meta boolean NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS has_google boolean NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS last_optimized_at timestamp with time zone,
  ADD COLUMN IF NOT EXISTS total_optimization_seconds integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS active_optimization_started_at timestamp with time zone,
  ADD COLUMN IF NOT EXISTS active_optimization_user_id uuid;

-- Create optimization_sessions table
CREATE TABLE IF NOT EXISTS public.optimization_sessions (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  client_id uuid NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  started_at timestamp with time zone NOT NULL DEFAULT now(),
  ended_at timestamp with time zone,
  duration_seconds integer NOT NULL DEFAULT 0,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.optimization_sessions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can read optimization sessions"
  ON public.optimization_sessions FOR SELECT TO authenticated USING (true);

CREATE POLICY "Authenticated users can insert optimization sessions"
  ON public.optimization_sessions FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Authenticated users can update optimization sessions"
  ON public.optimization_sessions FOR UPDATE TO authenticated USING (true);

CREATE POLICY "Authenticated users can delete optimization sessions"
  ON public.optimization_sessions FOR DELETE TO authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_optimization_sessions_client_id ON public.optimization_sessions(client_id);
CREATE INDEX IF NOT EXISTS idx_optimization_sessions_user_id ON public.optimization_sessions(user_id);