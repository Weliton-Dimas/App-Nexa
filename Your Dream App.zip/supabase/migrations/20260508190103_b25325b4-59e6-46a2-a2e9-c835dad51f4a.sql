
-- 1. Restrict SELECT of OAuth token columns on clients (column-level)
REVOKE SELECT (meta_access_token, google_access_token) ON public.clients FROM anon, authenticated;

-- 2. Tighten clients UPDATE/DELETE
DROP POLICY IF EXISTS "Authenticated users can update clients" ON public.clients;
DROP POLICY IF EXISTS "Authenticated users can delete clients" ON public.clients;

CREATE POLICY "Admin or assigned can update clients"
ON public.clients FOR UPDATE TO authenticated
USING (public.has_role(auth.uid(), 'admin') OR auth.uid()::text = ANY(assigned_users))
WITH CHECK (public.has_role(auth.uid(), 'admin') OR auth.uid()::text = ANY(assigned_users));

CREATE POLICY "Admin can delete clients"
ON public.clients FOR DELETE TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- 3. optimization_sessions
DROP POLICY IF EXISTS "Authenticated users can insert optimization sessions" ON public.optimization_sessions;
DROP POLICY IF EXISTS "Authenticated users can update optimization sessions" ON public.optimization_sessions;
DROP POLICY IF EXISTS "Authenticated users can delete optimization sessions" ON public.optimization_sessions;

CREATE POLICY "Owner can insert optimization sessions"
ON public.optimization_sessions FOR INSERT TO authenticated
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Owner or admin can update optimization sessions"
ON public.optimization_sessions FOR UPDATE TO authenticated
USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Owner or admin can delete optimization sessions"
ON public.optimization_sessions FOR DELETE TO authenticated
USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'));

-- 4. creative_library UPDATE
DROP POLICY IF EXISTS "Authenticated can update creative library" ON public.creative_library;
CREATE POLICY "Uploader or admin can update creative library"
ON public.creative_library FOR UPDATE TO authenticated
USING (auth.uid() = uploaded_by OR public.has_role(auth.uid(), 'admin'));

-- 5. creative_demands UPDATE
DROP POLICY IF EXISTS "Authenticated can update creative demands" ON public.creative_demands;
CREATE POLICY "Creator assignee or admin can update creative demands"
ON public.creative_demands FOR UPDATE TO authenticated
USING (
  auth.uid() = created_by
  OR auth.uid() = assignee_id
  OR auth.uid() = manager_id
  OR public.has_role(auth.uid(), 'admin')
);

-- 6. Storage: creatives bucket - require ownership for delete/update via folder prefix
DROP POLICY IF EXISTS "Authenticated can delete creative files" ON storage.objects;
DROP POLICY IF EXISTS "Authenticated can update creative files" ON storage.objects;

CREATE POLICY "Owner or admin can delete creative files"
ON storage.objects FOR DELETE TO authenticated
USING (
  bucket_id = 'creatives'
  AND (owner = auth.uid() OR public.has_role(auth.uid(), 'admin'))
);

CREATE POLICY "Owner or admin can update creative files"
ON storage.objects FOR UPDATE TO authenticated
USING (
  bucket_id = 'creatives'
  AND (owner = auth.uid() OR public.has_role(auth.uid(), 'admin'))
);

-- 7. Restrict listing of public buckets to authenticated users
DROP POLICY IF EXISTS "Public can view creative files" ON storage.objects;
DROP POLICY IF EXISTS "Avatars are publicly readable" ON storage.objects;
DROP POLICY IF EXISTS "Branding is publicly readable" ON storage.objects;

CREATE POLICY "Authenticated can list creative files"
ON storage.objects FOR SELECT TO authenticated
USING (bucket_id = 'creatives');

CREATE POLICY "Authenticated can list avatars"
ON storage.objects FOR SELECT TO authenticated
USING (bucket_id = 'avatars');

CREATE POLICY "Authenticated can list branding"
ON storage.objects FOR SELECT TO authenticated
USING (bucket_id = 'branding');

-- 8. Restrict EXECUTE of trigger-only SECURITY DEFINER functions
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM anon, authenticated, public;
REVOKE EXECUTE ON FUNCTION public.update_updated_at_column() FROM anon, authenticated, public;
REVOKE EXECUTE ON FUNCTION public.has_role(uuid, app_role) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.can_access_financial(uuid) FROM anon, public;
