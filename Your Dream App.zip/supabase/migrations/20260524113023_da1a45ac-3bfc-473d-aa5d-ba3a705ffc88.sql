
-- 1) Magazord stores: remove broad read
DROP POLICY IF EXISTS "Authenticated read magazord stores" ON public.workspace_magazord_stores;

-- 2) Revoke token columns from authenticated/anon on workspace_integrations
REVOKE SELECT (access_token, refresh_token) ON public.workspace_integrations FROM authenticated, anon;

-- 3) Revoke token columns from authenticated/anon on client_integrations
REVOKE SELECT (access_token, refresh_token) ON public.client_integrations FROM authenticated, anon;
