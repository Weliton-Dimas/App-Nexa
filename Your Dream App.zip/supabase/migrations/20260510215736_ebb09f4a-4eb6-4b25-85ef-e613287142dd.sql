
-- Enable required extensions
create extension if not exists pg_cron;
create extension if not exists pg_net;

-- Push subscriptions: one per browser/device per user
create table public.push_subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  endpoint text not null unique,
  p256dh text not null,
  auth text not null,
  user_agent text,
  created_at timestamptz not null default now(),
  last_used_at timestamptz
);
alter table public.push_subscriptions enable row level security;
create policy "Users manage own push subscriptions"
  on public.push_subscriptions for all
  using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- Notification preferences (one row per user)
create table public.notification_preferences (
  user_id uuid primary key,
  kanban_enabled boolean not null default true,
  kanban_minutes_before integer not null default 60,
  calendar_enabled boolean not null default true,
  calendar_hour integer not null default 8,  -- broadcast hour for daily events
  prospects_enabled boolean not null default true,
  prospects_minutes_before integer not null default 15,
  updated_at timestamptz not null default now()
);
alter table public.notification_preferences enable row level security;
create policy "Users manage own notification prefs"
  on public.notification_preferences for all
  using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- Log to avoid sending duplicate notifications
create table public.notification_log (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  source text not null,        -- 'kanban' | 'calendar' | 'prospect'
  source_id uuid not null,
  sent_at timestamptz not null default now(),
  unique(user_id, source, source_id)
);
alter table public.notification_log enable row level security;
create policy "Users read own notification log"
  on public.notification_log for select using (auth.uid() = user_id);

create index idx_push_subs_user on public.push_subscriptions(user_id);
create index idx_notif_log_user on public.notification_log(user_id, source, source_id);

-- Schedule cron job to invoke send-due-notifications every minute
select cron.schedule(
  'send-due-notifications',
  '* * * * *',
  $$
  select net.http_post(
    url:='https://xfmudoopaspsbdrceqdl.supabase.co/functions/v1/send-due-notifications',
    headers:='{"Content-Type":"application/json","apikey":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhmbXVkb29wYXNwc2JkcmNlcWRsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzE1MjAyNzgsImV4cCI6MjA4NzA5NjI3OH0.VcBSNsQWC-OBeN6xrnXymIEXBuwDpGwV-7Ku3F-8Gbg"}'::jsonb,
    body:='{}'::jsonb
  ) as request_id;
  $$
);
