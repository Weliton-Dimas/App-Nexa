
CREATE TABLE public.pricing_products (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  client_id UUID NOT NULL,
  user_id UUID NOT NULL,
  position INTEGER NOT NULL DEFAULT 0,
  name TEXT NOT NULL DEFAULT 'Produto',
  sku TEXT,
  product_cost NUMERIC NOT NULL DEFAULT 0,
  taxes_pct NUMERIC NOT NULL DEFAULT 0,
  card_pct NUMERIC NOT NULL DEFAULT 0,
  platform_pct NUMERIC NOT NULL DEFAULT 0,
  marketing_pct NUMERIC NOT NULL DEFAULT 0,
  commission_pct NUMERIC NOT NULL DEFAULT 0,
  other_deductions_pct NUMERIC NOT NULL DEFAULT 0,
  selling_cost NUMERIC NOT NULL DEFAULT 0,
  shipping_cost NUMERIC NOT NULL DEFAULT 0,
  packaging_cost NUMERIC NOT NULL DEFAULT 0,
  other_inputs_cost NUMERIC NOT NULL DEFAULT 0,
  desired_margin_pct NUMERIC NOT NULL DEFAULT 20,
  extra_costs JSONB NOT NULL DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.pricing_products ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admin or assigned can read pricing products"
ON public.pricing_products FOR SELECT TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role) OR EXISTS (
  SELECT 1 FROM clients c WHERE c.id = pricing_products.client_id AND (auth.uid())::text = ANY (c.assigned_users)
));

CREATE POLICY "Admin or assigned can insert pricing products"
ON public.pricing_products FOR INSERT TO authenticated
WITH CHECK (auth.uid() = user_id AND (has_role(auth.uid(), 'admin'::app_role) OR EXISTS (
  SELECT 1 FROM clients c WHERE c.id = pricing_products.client_id AND (auth.uid())::text = ANY (c.assigned_users)
)));

CREATE POLICY "Admin or assigned can update pricing products"
ON public.pricing_products FOR UPDATE TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role) OR EXISTS (
  SELECT 1 FROM clients c WHERE c.id = pricing_products.client_id AND (auth.uid())::text = ANY (c.assigned_users)
));

CREATE POLICY "Admin or assigned can delete pricing products"
ON public.pricing_products FOR DELETE TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role) OR EXISTS (
  SELECT 1 FROM clients c WHERE c.id = pricing_products.client_id AND (auth.uid())::text = ANY (c.assigned_users)
));

CREATE TRIGGER update_pricing_products_updated_at
BEFORE UPDATE ON public.pricing_products
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE INDEX idx_pricing_products_client ON public.pricing_products(client_id, position);
