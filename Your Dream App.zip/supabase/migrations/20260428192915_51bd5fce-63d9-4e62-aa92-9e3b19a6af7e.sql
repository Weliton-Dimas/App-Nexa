CREATE TABLE public.daily_devotionals (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  date DATE NOT NULL UNIQUE,
  verse TEXT NOT NULL,
  reference TEXT NOT NULL,
  reflection TEXT NOT NULL,
  prayer TEXT NOT NULL,
  application TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.daily_devotionals ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated can read devotionals"
ON public.daily_devotionals FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Authenticated can insert devotionals"
ON public.daily_devotionals FOR INSERT
TO authenticated
WITH CHECK (true);

CREATE INDEX idx_daily_devotionals_date ON public.daily_devotionals(date);