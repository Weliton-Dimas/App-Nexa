
CREATE TABLE public.ideas (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  author_id UUID NOT NULL,
  category TEXT NOT NULL CHECK (category IN ('app_improvement','client_strategy')),
  client_id UUID NULL,
  priority TEXT NOT NULL DEFAULT 'media' CHECK (priority IN ('baixa','media','alta','critica')),
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.ideas ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated can read ideas" ON public.ideas
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Authenticated can insert own ideas" ON public.ideas
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = author_id);

CREATE POLICY "Author or admin can update ideas" ON public.ideas
  FOR UPDATE TO authenticated
  USING (auth.uid() = author_id OR has_role(auth.uid(),'admin'::app_role));

CREATE POLICY "Author or admin can delete ideas" ON public.ideas
  FOR DELETE TO authenticated
  USING (auth.uid() = author_id OR has_role(auth.uid(),'admin'::app_role));

CREATE TRIGGER update_ideas_updated_at
  BEFORE UPDATE ON public.ideas
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE INDEX idx_ideas_created_at ON public.ideas (created_at DESC);
