
-- ============ Tables ============
CREATE TABLE public.kanban_boards (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  created_by uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.kanban_columns (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  board_id uuid NOT NULL REFERENCES public.kanban_boards(id) ON DELETE CASCADE,
  title text NOT NULL,
  position double precision NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_kanban_columns_board ON public.kanban_columns(board_id, position);

CREATE TABLE public.kanban_cards (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  column_id uuid NOT NULL REFERENCES public.kanban_columns(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text,
  position double precision NOT NULL DEFAULT 0,
  due_date timestamptz,
  start_date date,
  reminder text,
  cover_color text,
  created_by uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_kanban_cards_column ON public.kanban_cards(column_id, position);

CREATE TABLE public.kanban_labels (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  board_id uuid NOT NULL REFERENCES public.kanban_boards(id) ON DELETE CASCADE,
  name text NOT NULL DEFAULT '',
  color text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.kanban_card_labels (
  card_id uuid NOT NULL REFERENCES public.kanban_cards(id) ON DELETE CASCADE,
  label_id uuid NOT NULL REFERENCES public.kanban_labels(id) ON DELETE CASCADE,
  PRIMARY KEY (card_id, label_id)
);

CREATE TABLE public.kanban_checklist_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  card_id uuid NOT NULL REFERENCES public.kanban_cards(id) ON DELETE CASCADE,
  text text NOT NULL,
  done boolean NOT NULL DEFAULT false,
  position double precision NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_kanban_checklist_card ON public.kanban_checklist_items(card_id, position);

CREATE TABLE public.kanban_attachments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  card_id uuid NOT NULL REFERENCES public.kanban_cards(id) ON DELETE CASCADE,
  kind text NOT NULL CHECK (kind IN ('link','file')),
  url text NOT NULL,
  display_text text,
  file_path text,
  uploaded_by uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_kanban_attachments_card ON public.kanban_attachments(card_id);

CREATE TABLE public.kanban_members (
  card_id uuid NOT NULL REFERENCES public.kanban_cards(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (card_id, user_id)
);

CREATE TABLE public.kanban_comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  card_id uuid NOT NULL REFERENCES public.kanban_cards(id) ON DELETE CASCADE,
  body text NOT NULL,
  author_id uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_kanban_comments_card ON public.kanban_comments(card_id, created_at);

-- ============ Triggers updated_at ============
CREATE TRIGGER trg_kanban_boards_upd BEFORE UPDATE ON public.kanban_boards
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER trg_kanban_columns_upd BEFORE UPDATE ON public.kanban_columns
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER trg_kanban_cards_upd BEFORE UPDATE ON public.kanban_cards
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER trg_kanban_comments_upd BEFORE UPDATE ON public.kanban_comments
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- ============ RLS ============
ALTER TABLE public.kanban_boards ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.kanban_columns ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.kanban_cards ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.kanban_labels ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.kanban_card_labels ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.kanban_checklist_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.kanban_attachments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.kanban_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.kanban_comments ENABLE ROW LEVEL SECURITY;

-- boards
CREATE POLICY "auth read boards" ON public.kanban_boards FOR SELECT TO authenticated USING (true);
CREATE POLICY "auth insert boards" ON public.kanban_boards FOR INSERT TO authenticated WITH CHECK (auth.uid() = created_by);
CREATE POLICY "auth update boards" ON public.kanban_boards FOR UPDATE TO authenticated USING (true);
CREATE POLICY "owner admin delete boards" ON public.kanban_boards FOR DELETE TO authenticated
  USING (auth.uid() = created_by OR has_role(auth.uid(),'admin'::app_role));

-- columns
CREATE POLICY "auth read columns" ON public.kanban_columns FOR SELECT TO authenticated USING (true);
CREATE POLICY "auth insert columns" ON public.kanban_columns FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "auth update columns" ON public.kanban_columns FOR UPDATE TO authenticated USING (true);
CREATE POLICY "auth delete columns" ON public.kanban_columns FOR DELETE TO authenticated USING (true);

-- cards
CREATE POLICY "auth read cards" ON public.kanban_cards FOR SELECT TO authenticated USING (true);
CREATE POLICY "auth insert cards" ON public.kanban_cards FOR INSERT TO authenticated WITH CHECK (auth.uid() = created_by);
CREATE POLICY "auth update cards" ON public.kanban_cards FOR UPDATE TO authenticated USING (true);
CREATE POLICY "owner admin delete cards" ON public.kanban_cards FOR DELETE TO authenticated
  USING (auth.uid() = created_by OR has_role(auth.uid(),'admin'::app_role));

-- labels
CREATE POLICY "auth read labels" ON public.kanban_labels FOR SELECT TO authenticated USING (true);
CREATE POLICY "auth manage labels insert" ON public.kanban_labels FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "auth manage labels update" ON public.kanban_labels FOR UPDATE TO authenticated USING (true);
CREATE POLICY "auth manage labels delete" ON public.kanban_labels FOR DELETE TO authenticated USING (true);

-- card_labels
CREATE POLICY "auth read card labels" ON public.kanban_card_labels FOR SELECT TO authenticated USING (true);
CREATE POLICY "auth insert card labels" ON public.kanban_card_labels FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "auth delete card labels" ON public.kanban_card_labels FOR DELETE TO authenticated USING (true);

-- checklist
CREATE POLICY "auth read checklist" ON public.kanban_checklist_items FOR SELECT TO authenticated USING (true);
CREATE POLICY "auth insert checklist" ON public.kanban_checklist_items FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "auth update checklist" ON public.kanban_checklist_items FOR UPDATE TO authenticated USING (true);
CREATE POLICY "auth delete checklist" ON public.kanban_checklist_items FOR DELETE TO authenticated USING (true);

-- attachments
CREATE POLICY "auth read attachments" ON public.kanban_attachments FOR SELECT TO authenticated USING (true);
CREATE POLICY "auth insert attachments" ON public.kanban_attachments FOR INSERT TO authenticated WITH CHECK (auth.uid() = uploaded_by);
CREATE POLICY "owner admin delete attachments" ON public.kanban_attachments FOR DELETE TO authenticated
  USING (auth.uid() = uploaded_by OR has_role(auth.uid(),'admin'::app_role));

-- members
CREATE POLICY "auth read members" ON public.kanban_members FOR SELECT TO authenticated USING (true);
CREATE POLICY "auth insert members" ON public.kanban_members FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "auth delete members" ON public.kanban_members FOR DELETE TO authenticated USING (true);

-- comments
CREATE POLICY "auth read comments" ON public.kanban_comments FOR SELECT TO authenticated USING (true);
CREATE POLICY "auth insert comments" ON public.kanban_comments FOR INSERT TO authenticated WITH CHECK (auth.uid() = author_id);
CREATE POLICY "owner admin update comments" ON public.kanban_comments FOR UPDATE TO authenticated
  USING (auth.uid() = author_id OR has_role(auth.uid(),'admin'::app_role));
CREATE POLICY "owner admin delete comments" ON public.kanban_comments FOR DELETE TO authenticated
  USING (auth.uid() = author_id OR has_role(auth.uid(),'admin'::app_role));

-- ============ Storage bucket ============
INSERT INTO storage.buckets (id, name, public) VALUES ('kanban-attachments','kanban-attachments', false)
ON CONFLICT (id) DO NOTHING;

CREATE POLICY "auth read kanban attachments" ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'kanban-attachments');
CREATE POLICY "auth upload kanban attachments" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'kanban-attachments');
CREATE POLICY "owner admin delete kanban attachments" ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'kanban-attachments' AND (auth.uid() = owner OR has_role(auth.uid(),'admin'::app_role)));
