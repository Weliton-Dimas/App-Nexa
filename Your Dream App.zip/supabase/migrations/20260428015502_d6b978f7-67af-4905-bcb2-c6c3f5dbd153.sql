-- Receitas (mensalidades de clientes)
CREATE TABLE public.financial_revenues (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  client_id UUID REFERENCES public.clients(id) ON DELETE SET NULL,
  description TEXT NOT NULL,
  amount NUMERIC(12,2) NOT NULL DEFAULT 0,
  due_date DATE NOT NULL,
  paid_date DATE,
  status TEXT NOT NULL DEFAULT 'pendente', -- pendente | pago | atrasado
  recurrence TEXT NOT NULL DEFAULT 'mensal', -- mensal | unico
  notes TEXT,
  created_by UUID NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Despesas
CREATE TABLE public.financial_expenses (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  description TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT 'outros', -- ferramentas | equipe | marketing | impostos | outros
  amount NUMERIC(12,2) NOT NULL DEFAULT 0,
  due_date DATE NOT NULL,
  paid_date DATE,
  status TEXT NOT NULL DEFAULT 'pendente', -- pendente | pago | atrasado
  recurrence TEXT NOT NULL DEFAULT 'unico', -- mensal | unico
  notes TEXT,
  created_by UUID NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Comissões / pagamentos a equipe
CREATE TABLE public.financial_commissions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  client_id UUID REFERENCES public.clients(id) ON DELETE SET NULL,
  description TEXT NOT NULL,
  amount NUMERIC(12,2) NOT NULL DEFAULT 0,
  reference_month DATE NOT NULL, -- primeiro dia do mês de referência
  paid_date DATE,
  status TEXT NOT NULL DEFAULT 'pendente', -- pendente | pago
  notes TEXT,
  created_by UUID NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.financial_revenues ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.financial_expenses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.financial_commissions ENABLE ROW LEVEL SECURITY;

-- Helper function: pode acessar o financeiro?
CREATE OR REPLACE FUNCTION public.can_access_financial(_user_id UUID)
RETURNS BOOLEAN
LANGUAGE SQL
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT public.has_role(_user_id, 'admin'::app_role)
    OR EXISTS (
      SELECT 1 FROM public.user_page_permissions
      WHERE user_id = _user_id AND page_slug = 'financial'
    );
$$;

-- RLS policies
CREATE POLICY "Financial access can read revenues" ON public.financial_revenues
  FOR SELECT TO authenticated USING (public.can_access_financial(auth.uid()));
CREATE POLICY "Financial access can insert revenues" ON public.financial_revenues
  FOR INSERT TO authenticated WITH CHECK (public.can_access_financial(auth.uid()) AND auth.uid() = created_by);
CREATE POLICY "Financial access can update revenues" ON public.financial_revenues
  FOR UPDATE TO authenticated USING (public.can_access_financial(auth.uid()));
CREATE POLICY "Financial access can delete revenues" ON public.financial_revenues
  FOR DELETE TO authenticated USING (public.can_access_financial(auth.uid()));

CREATE POLICY "Financial access can read expenses" ON public.financial_expenses
  FOR SELECT TO authenticated USING (public.can_access_financial(auth.uid()));
CREATE POLICY "Financial access can insert expenses" ON public.financial_expenses
  FOR INSERT TO authenticated WITH CHECK (public.can_access_financial(auth.uid()) AND auth.uid() = created_by);
CREATE POLICY "Financial access can update expenses" ON public.financial_expenses
  FOR UPDATE TO authenticated USING (public.can_access_financial(auth.uid()));
CREATE POLICY "Financial access can delete expenses" ON public.financial_expenses
  FOR DELETE TO authenticated USING (public.can_access_financial(auth.uid()));

CREATE POLICY "Financial access can read commissions" ON public.financial_commissions
  FOR SELECT TO authenticated USING (public.can_access_financial(auth.uid()));
CREATE POLICY "Financial access can insert commissions" ON public.financial_commissions
  FOR INSERT TO authenticated WITH CHECK (public.can_access_financial(auth.uid()) AND auth.uid() = created_by);
CREATE POLICY "Financial access can update commissions" ON public.financial_commissions
  FOR UPDATE TO authenticated USING (public.can_access_financial(auth.uid()));
CREATE POLICY "Financial access can delete commissions" ON public.financial_commissions
  FOR DELETE TO authenticated USING (public.can_access_financial(auth.uid()));

-- Triggers updated_at
CREATE TRIGGER trg_financial_revenues_updated BEFORE UPDATE ON public.financial_revenues
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER trg_financial_expenses_updated BEFORE UPDATE ON public.financial_expenses
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER trg_financial_commissions_updated BEFORE UPDATE ON public.financial_commissions
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE INDEX idx_financial_revenues_due ON public.financial_revenues(due_date);
CREATE INDEX idx_financial_expenses_due ON public.financial_expenses(due_date);
CREATE INDEX idx_financial_commissions_ref ON public.financial_commissions(reference_month);