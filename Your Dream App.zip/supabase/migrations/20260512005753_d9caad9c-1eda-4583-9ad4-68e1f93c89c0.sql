-- New columns on pricing_products
ALTER TABLE public.pricing_products
  ADD COLUMN IF NOT EXISTS gateway_pct numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS pix_pct numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS boleto_value numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS mix_card_pct numeric NOT NULL DEFAULT 100,
  ADD COLUMN IF NOT EXISTS mix_pix_pct numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS mix_boleto_pct numeric NOT NULL DEFAULT 0;

-- New table: pricing_settings (per client)
CREATE TABLE IF NOT EXISTS public.pricing_settings (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  client_id uuid NOT NULL UNIQUE,
  user_id uuid NOT NULL,
  installment_rates jsonb NOT NULL DEFAULT '[]'::jsonb,
  mix_card_pct numeric NOT NULL DEFAULT 70,
  mix_pix_pct numeric NOT NULL DEFAULT 25,
  mix_boleto_pct numeric NOT NULL DEFAULT 5,
  pix_fee_pct numeric NOT NULL DEFAULT 0,
  boleto_fee_value numeric NOT NULL DEFAULT 0,
  gateway_pct numeric NOT NULL DEFAULT 0,
  max_installments integer NOT NULL DEFAULT 12,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.pricing_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admin or assigned can read pricing settings"
  ON public.pricing_settings FOR SELECT TO authenticated
  USING (has_role(auth.uid(), 'admin'::app_role) OR (EXISTS (
    SELECT 1 FROM clients c WHERE c.id = pricing_settings.client_id AND (auth.uid())::text = ANY (c.assigned_users)
  )));

CREATE POLICY "Admin or assigned can insert pricing settings"
  ON public.pricing_settings FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id AND (has_role(auth.uid(), 'admin'::app_role) OR (EXISTS (
    SELECT 1 FROM clients c WHERE c.id = pricing_settings.client_id AND (auth.uid())::text = ANY (c.assigned_users)
  ))));

CREATE POLICY "Admin or assigned can update pricing settings"
  ON public.pricing_settings FOR UPDATE TO authenticated
  USING (has_role(auth.uid(), 'admin'::app_role) OR (EXISTS (
    SELECT 1 FROM clients c WHERE c.id = pricing_settings.client_id AND (auth.uid())::text = ANY (c.assigned_users)
  )));

CREATE POLICY "Admin or assigned can delete pricing settings"
  ON public.pricing_settings FOR DELETE TO authenticated
  USING (has_role(auth.uid(), 'admin'::app_role) OR (EXISTS (
    SELECT 1 FROM clients c WHERE c.id = pricing_settings.client_id AND (auth.uid())::text = ANY (c.assigned_users)
  )));

CREATE TRIGGER update_pricing_settings_updated_at
  BEFORE UPDATE ON public.pricing_settings
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();