ALTER TABLE public.clients
  ADD COLUMN IF NOT EXISTS visible_pages text[] NOT NULL DEFAULT ARRAY['dashboard','optimization']::text[];