ALTER TABLE public.pricing_products
ADD COLUMN IF NOT EXISTS margin_mode text NOT NULL DEFAULT 'margin'
CHECK (margin_mode IN ('margin', 'markup'));