
DROP POLICY IF EXISTS "Admin or assigned can read contract files" ON storage.objects;
DROP POLICY IF EXISTS "Admin or assigned can upload contract files" ON storage.objects;
DROP POLICY IF EXISTS "Admin or assigned can update contract files" ON storage.objects;
DROP POLICY IF EXISTS "Admin or assigned can delete contract files" ON storage.objects;

CREATE POLICY "Admin or assigned can read contract files"
ON storage.objects FOR SELECT TO authenticated
USING (
  bucket_id = 'client-contracts'
  AND (
    has_role(auth.uid(), 'admin'::app_role)
    OR EXISTS (
      SELECT 1 FROM public.clients c
      WHERE (c.id)::text = (storage.foldername(objects.name))[1]
        AND (auth.uid())::text = ANY (c.assigned_users)
    )
  )
);

CREATE POLICY "Admin or assigned can upload contract files"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (
  bucket_id = 'client-contracts'
  AND (
    has_role(auth.uid(), 'admin'::app_role)
    OR EXISTS (
      SELECT 1 FROM public.clients c
      WHERE (c.id)::text = (storage.foldername(objects.name))[1]
        AND (auth.uid())::text = ANY (c.assigned_users)
    )
  )
);

CREATE POLICY "Admin or assigned can update contract files"
ON storage.objects FOR UPDATE TO authenticated
USING (
  bucket_id = 'client-contracts'
  AND (
    has_role(auth.uid(), 'admin'::app_role)
    OR EXISTS (
      SELECT 1 FROM public.clients c
      WHERE (c.id)::text = (storage.foldername(objects.name))[1]
        AND (auth.uid())::text = ANY (c.assigned_users)
    )
  )
);

CREATE POLICY "Admin or assigned can delete contract files"
ON storage.objects FOR DELETE TO authenticated
USING (
  bucket_id = 'client-contracts'
  AND (
    has_role(auth.uid(), 'admin'::app_role)
    OR EXISTS (
      SELECT 1 FROM public.clients c
      WHERE (c.id)::text = (storage.foldername(objects.name))[1]
        AND (auth.uid())::text = ANY (c.assigned_users)
    )
  )
);
