-- Allow any authenticated user to insert ideas with any author
DROP POLICY IF EXISTS "Authenticated can insert own ideas" ON public.ideas;
CREATE POLICY "Authenticated can insert ideas"
ON public.ideas FOR INSERT TO authenticated
WITH CHECK (true);

-- Allow authenticated team members to read all profiles (basic info)
CREATE POLICY "Authenticated can read profiles"
ON public.profiles FOR SELECT TO authenticated
USING (true);