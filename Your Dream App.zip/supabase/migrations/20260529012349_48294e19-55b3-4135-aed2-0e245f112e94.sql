CREATE SCHEMA IF NOT EXISTS app_private;
REVOKE ALL ON SCHEMA app_private FROM PUBLIC;
GRANT USAGE ON SCHEMA app_private TO authenticated, service_role;

CREATE OR REPLACE FUNCTION app_private.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id
      AND role = _role
  )
$$;

CREATE OR REPLACE FUNCTION app_private.can_access_financial(_user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, app_private
AS $$
  SELECT app_private.has_role(_user_id, 'admin'::public.app_role)
    OR EXISTS (
      SELECT 1
      FROM public.user_page_permissions
      WHERE user_id = _user_id AND page_slug = 'financial'
    )
$$;

REVOKE ALL ON FUNCTION app_private.has_role(uuid, public.app_role) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION app_private.can_access_financial(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION app_private.has_role(uuid, public.app_role) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION app_private.can_access_financial(uuid) TO authenticated, service_role;

DO $$
DECLARE
  p record;
  new_qual text;
  new_check text;
  create_sql text;
BEGIN
  FOR p IN
    SELECT schemaname, tablename, policyname, permissive, roles, cmd, qual, with_check
    FROM pg_policies
    WHERE (qual ILIKE '%has_role(%' OR with_check ILIKE '%has_role(%'
       OR qual ILIKE '%can_access_financial(%' OR with_check ILIKE '%can_access_financial(%')
  LOOP
    new_qual := p.qual;
    new_check := p.with_check;

    IF new_qual IS NOT NULL THEN
      new_qual := replace(new_qual, 'public.has_role(', 'app_private.has_role(');
      new_qual := regexp_replace(new_qual, '(^|[^.[:alnum:]_])has_role\(', '\1app_private.has_role(', 'g');
      new_qual := replace(new_qual, 'public.can_access_financial(', 'app_private.can_access_financial(');
      new_qual := regexp_replace(new_qual, '(^|[^.[:alnum:]_])can_access_financial\(', '\1app_private.can_access_financial(', 'g');
    END IF;

    IF new_check IS NOT NULL THEN
      new_check := replace(new_check, 'public.has_role(', 'app_private.has_role(');
      new_check := regexp_replace(new_check, '(^|[^.[:alnum:]_])has_role\(', '\1app_private.has_role(', 'g');
      new_check := replace(new_check, 'public.can_access_financial(', 'app_private.can_access_financial(');
      new_check := regexp_replace(new_check, '(^|[^.[:alnum:]_])can_access_financial\(', '\1app_private.can_access_financial(', 'g');
    END IF;

    EXECUTE format('DROP POLICY IF EXISTS %I ON %I.%I', p.policyname, p.schemaname, p.tablename);

    create_sql := format(
      'CREATE POLICY %I ON %I.%I AS %s FOR %s TO %s',
      p.policyname,
      p.schemaname,
      p.tablename,
      p.permissive,
      p.cmd,
      (SELECT string_agg(quote_ident(role_name), ', ') FROM unnest(p.roles) AS role_name)
    );

    IF new_qual IS NOT NULL THEN
      create_sql := create_sql || ' USING (' || new_qual || ')';
    END IF;

    IF new_check IS NOT NULL THEN
      create_sql := create_sql || ' WITH CHECK (' || new_check || ')';
    END IF;

    EXECUTE create_sql;
  END LOOP;
END $$;

REVOKE EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) FROM anon, authenticated, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.can_access_financial(uuid) FROM anon, authenticated, PUBLIC;