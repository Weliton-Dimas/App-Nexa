
-- Workspace-level integrations table.
-- One row per provider for the whole workspace (managed by admins only).
-- Tokens are encrypted at rest the same way as client_integrations.
CREATE TABLE public.workspace_integrations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  provider TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'disconnected',
  business_id TEXT,
  business_name TEXT,
  access_token TEXT,
  refresh_token TEXT,
  expires_at TIMESTAMPTZ,
  scope TEXT,
  available_accounts JSONB NOT NULL DEFAULT '[]'::jsonb,
  available_businesses JSONB NOT NULL DEFAULT '[]'::jsonb,
  last_synced_at TIMESTAMPTZ,
  last_error TEXT,
  connected_by UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT workspace_integrations_provider_unique UNIQUE (provider)
);

ALTER TABLE public.workspace_integrations ENABLE ROW LEVEL SECURITY;

-- Only admins can read/write the connection itself (it holds tokens).
CREATE POLICY "Admins manage workspace integrations"
ON public.workspace_integrations
FOR ALL
TO authenticated
USING (public.has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (public.has_role(auth.uid(), 'admin'::app_role));

CREATE TRIGGER update_workspace_integrations_updated_at
BEFORE UPDATE ON public.workspace_integrations
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Public-ish view that exposes ONLY the safe fields (no tokens) so any
-- authenticated user can list available ad accounts to pick from.
CREATE OR REPLACE VIEW public.workspace_integrations_public
WITH (security_invoker = false) AS
SELECT
  id,
  provider,
  status,
  business_id,
  business_name,
  available_accounts,
  last_synced_at
FROM public.workspace_integrations;

GRANT SELECT ON public.workspace_integrations_public TO authenticated;
