
create table public.pricing_scenarios (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  client_id uuid not null,
  name text not null default 'Cenário',
  product_cost numeric not null default 0,
  taxes_pct numeric not null default 0,
  fixed_costs_pct numeric not null default 0,
  profit_margin_pct numeric not null default 30,
  avg_ticket numeric,
  conversion_rate numeric not null default 2,
  estimated_cpa numeric not null default 50,
  monthly_profit_goal numeric not null default 10000,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.pricing_scenarios enable row level security;

create policy "Admin or assigned can read pricing scenarios"
  on public.pricing_scenarios for select to authenticated
  using (
    has_role(auth.uid(), 'admin'::app_role)
    or exists (
      select 1 from public.clients c
      where c.id = pricing_scenarios.client_id
        and ((auth.uid())::text = any(c.assigned_users))
    )
  );

create policy "Admin or assigned can insert pricing scenarios"
  on public.pricing_scenarios for insert to authenticated
  with check (
    auth.uid() = user_id and (
      has_role(auth.uid(), 'admin'::app_role)
      or exists (
        select 1 from public.clients c
        where c.id = client_id
          and ((auth.uid())::text = any(c.assigned_users))
      )
    )
  );

create policy "Admin or assigned can update pricing scenarios"
  on public.pricing_scenarios for update to authenticated
  using (
    has_role(auth.uid(), 'admin'::app_role)
    or exists (
      select 1 from public.clients c
      where c.id = pricing_scenarios.client_id
        and ((auth.uid())::text = any(c.assigned_users))
    )
  );

create policy "Admin or assigned can delete pricing scenarios"
  on public.pricing_scenarios for delete to authenticated
  using (
    has_role(auth.uid(), 'admin'::app_role)
    or exists (
      select 1 from public.clients c
      where c.id = pricing_scenarios.client_id
        and ((auth.uid())::text = any(c.assigned_users))
    )
  );

create trigger trg_pricing_scenarios_updated
  before update on public.pricing_scenarios
  for each row execute function public.update_updated_at_column();

create index idx_pricing_scenarios_client on public.pricing_scenarios(client_id);
