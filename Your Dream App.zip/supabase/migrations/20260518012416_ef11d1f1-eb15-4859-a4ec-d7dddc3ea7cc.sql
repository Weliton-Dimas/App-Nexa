
-- 1. Move pg_net out of public (it doesn't support SET SCHEMA — must drop/recreate)
DROP EXTENSION IF EXISTS pg_net;
CREATE EXTENSION IF NOT EXISTS pg_net WITH SCHEMA extensions;

-- 2. Tighten RLS always-true policies
DROP POLICY IF EXISTS "Authenticated can update tasks" ON public.calendar_tasks;
CREATE POLICY "Authenticated can update tasks" ON public.calendar_tasks
  FOR UPDATE TO authenticated USING (auth.uid() IS NOT NULL);

DROP POLICY IF EXISTS "Authenticated users can insert clients" ON public.clients;
CREATE POLICY "Authenticated users can insert clients" ON public.clients
  FOR INSERT TO authenticated WITH CHECK (auth.uid() IS NOT NULL);

DROP POLICY IF EXISTS "Authenticated can insert devotionals" ON public.daily_devotionals;
CREATE POLICY "Authenticated can insert devotionals" ON public.daily_devotionals
  FOR INSERT TO authenticated WITH CHECK (auth.uid() IS NOT NULL);

DROP POLICY IF EXISTS "Authenticated can insert ideas" ON public.ideas;
CREATE POLICY "Authenticated can insert ideas" ON public.ideas
  FOR INSERT TO authenticated WITH CHECK (auth.uid() IS NOT NULL);

DROP POLICY IF EXISTS "auth update boards" ON public.kanban_boards;
CREATE POLICY "auth update boards" ON public.kanban_boards
  FOR UPDATE TO authenticated USING (auth.uid() IS NOT NULL);

DROP POLICY IF EXISTS "auth delete card labels" ON public.kanban_card_labels;
CREATE POLICY "auth delete card labels" ON public.kanban_card_labels
  FOR DELETE TO authenticated USING (auth.uid() IS NOT NULL);
DROP POLICY IF EXISTS "auth insert card labels" ON public.kanban_card_labels;
CREATE POLICY "auth insert card labels" ON public.kanban_card_labels
  FOR INSERT TO authenticated WITH CHECK (auth.uid() IS NOT NULL);

DROP POLICY IF EXISTS "auth update cards" ON public.kanban_cards;
CREATE POLICY "auth update cards" ON public.kanban_cards
  FOR UPDATE TO authenticated USING (auth.uid() IS NOT NULL);

DROP POLICY IF EXISTS "auth delete checklist" ON public.kanban_checklist_items;
CREATE POLICY "auth delete checklist" ON public.kanban_checklist_items
  FOR DELETE TO authenticated USING (auth.uid() IS NOT NULL);
DROP POLICY IF EXISTS "auth insert checklist" ON public.kanban_checklist_items;
CREATE POLICY "auth insert checklist" ON public.kanban_checklist_items
  FOR INSERT TO authenticated WITH CHECK (auth.uid() IS NOT NULL);
DROP POLICY IF EXISTS "auth update checklist" ON public.kanban_checklist_items;
CREATE POLICY "auth update checklist" ON public.kanban_checklist_items
  FOR UPDATE TO authenticated USING (auth.uid() IS NOT NULL);

DROP POLICY IF EXISTS "auth delete columns" ON public.kanban_columns;
CREATE POLICY "auth delete columns" ON public.kanban_columns
  FOR DELETE TO authenticated USING (auth.uid() IS NOT NULL);
DROP POLICY IF EXISTS "auth insert columns" ON public.kanban_columns;
CREATE POLICY "auth insert columns" ON public.kanban_columns
  FOR INSERT TO authenticated WITH CHECK (auth.uid() IS NOT NULL);
DROP POLICY IF EXISTS "auth update columns" ON public.kanban_columns;
CREATE POLICY "auth update columns" ON public.kanban_columns
  FOR UPDATE TO authenticated USING (auth.uid() IS NOT NULL);

DROP POLICY IF EXISTS "auth manage labels delete" ON public.kanban_labels;
CREATE POLICY "auth manage labels delete" ON public.kanban_labels
  FOR DELETE TO authenticated USING (auth.uid() IS NOT NULL);
DROP POLICY IF EXISTS "auth manage labels insert" ON public.kanban_labels;
CREATE POLICY "auth manage labels insert" ON public.kanban_labels
  FOR INSERT TO authenticated WITH CHECK (auth.uid() IS NOT NULL);
DROP POLICY IF EXISTS "auth manage labels update" ON public.kanban_labels;
CREATE POLICY "auth manage labels update" ON public.kanban_labels
  FOR UPDATE TO authenticated USING (auth.uid() IS NOT NULL);

DROP POLICY IF EXISTS "auth delete members" ON public.kanban_members;
CREATE POLICY "auth delete members" ON public.kanban_members
  FOR DELETE TO authenticated USING (auth.uid() IS NOT NULL);
DROP POLICY IF EXISTS "auth insert members" ON public.kanban_members;
CREATE POLICY "auth insert members" ON public.kanban_members
  FOR INSERT TO authenticated WITH CHECK (auth.uid() IS NOT NULL);

-- 3. Drop broad list policies on public buckets (public URLs still work)
DROP POLICY IF EXISTS "Authenticated can list avatars" ON storage.objects;
DROP POLICY IF EXISTS "Authenticated can list branding" ON storage.objects;
DROP POLICY IF EXISTS "Authenticated can list creative files" ON storage.objects;

-- 4. Revoke EXECUTE on SECURITY DEFINER helpers (still usable inside RLS)
REVOKE EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) FROM anon, authenticated, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.can_access_financial(uuid) FROM anon, authenticated, PUBLIC;
