ALTER TABLE public.pricing_settings
ADD COLUMN IF NOT EXISTS old_price_discount_pct numeric NOT NULL DEFAULT 15
CHECK (old_price_discount_pct >= 0 AND old_price_discount_pct < 100);