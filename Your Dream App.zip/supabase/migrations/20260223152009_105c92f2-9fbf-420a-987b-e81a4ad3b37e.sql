
-- Fix overly permissive RLS policies on clients table
DROP POLICY "Allow public delete" ON public.clients;
DROP POLICY "Allow public insert" ON public.clients;
DROP POLICY "Allow public read" ON public.clients;
DROP POLICY "Allow public update" ON public.clients;

CREATE POLICY "Authenticated users can read clients"
ON public.clients FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Authenticated users can insert clients"
ON public.clients FOR INSERT
TO authenticated
WITH CHECK (true);

CREATE POLICY "Authenticated users can update clients"
ON public.clients FOR UPDATE
TO authenticated
USING (true);

CREATE POLICY "Authenticated users can delete clients"
ON public.clients FOR DELETE
TO authenticated
USING (true);
