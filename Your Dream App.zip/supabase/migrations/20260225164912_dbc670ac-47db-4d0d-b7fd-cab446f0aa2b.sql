
ALTER TABLE public.clients
  ADD COLUMN IF NOT EXISTS website_url text,
  ADD COLUMN IF NOT EXISTS faturamento numeric DEFAULT 0,
  ADD COLUMN IF NOT EXISTS investido numeric DEFAULT 0,
  ADD COLUMN IF NOT EXISTS roi numeric DEFAULT 0,
  ADD COLUMN IF NOT EXISTS percentual_midia numeric DEFAULT 0,
  ADD COLUMN IF NOT EXISTS roas numeric DEFAULT 0,
  ADD COLUMN IF NOT EXISTS conversao_custo numeric DEFAULT 0,
  ADD COLUMN IF NOT EXISTS conversas integer DEFAULT 0,
  ADD COLUMN IF NOT EXISTS assigned_users text[] DEFAULT '{}';
