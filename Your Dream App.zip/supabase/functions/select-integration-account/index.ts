// Sets the chosen ad account on a pending client_integrations row.
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface Body {
  client_id: string;
  provider: "meta" | "google";
  account_id: string;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Missing authorization" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    const userClient = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: userData, error: userErr } = await userClient.auth.getUser();
    if (userErr || !userData.user) {
      return new Response(JSON.stringify({ error: "Invalid session" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body = (await req.json()) as Body;
    if (!body?.client_id || !body?.provider || !body?.account_id) {
      return new Response(JSON.stringify({ error: "client_id, provider, account_id required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const admin = createClient(supabaseUrl, serviceKey);

    // Permission: admin OR assigned to client
    const { data: roleRow } = await admin
      .from("user_roles")
      .select("role")
      .eq("user_id", userData.user.id)
      .eq("role", "admin")
      .maybeSingle();
    const isAdmin = !!roleRow;

    const { data: client } = await admin
      .from("clients")
      .select("assigned_users")
      .eq("id", body.client_id)
      .maybeSingle();
    const assigned = (client?.assigned_users ?? []) as string[];
    if (!isAdmin && !assigned.includes(userData.user.id)) {
      return new Response(JSON.stringify({ error: "Forbidden" }), {
        status: 403,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { data: row, error: rowErr } = await admin
      .from("client_integrations")
      .select("id, extra")
      .eq("client_id", body.client_id)
      .eq("provider", body.provider)
      .maybeSingle();
    if (rowErr || !row) {
      return new Response(JSON.stringify({ error: "Integration not found" }), {
        status: 404,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const available = ((row.extra as { availableAccounts?: Array<{ account_id: string; name: string }> })?.availableAccounts) ?? [];
    const match = available.find((a) => String(a.account_id) === String(body.account_id));
    if (!match) {
      return new Response(JSON.stringify({ error: "Account not in available list" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { error: updErr } = await admin
      .from("client_integrations")
      .update({
        account_id: match.account_id,
        account_name: match.name,
        status: "connected",
        last_error: null,
      })
      .eq("id", row.id);

    if (updErr) throw updErr;

    return new Response(JSON.stringify({ ok: true, account: match }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
