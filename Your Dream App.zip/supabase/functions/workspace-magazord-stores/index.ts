// CRUD de lojas Magazord do workspace.
// GET  -> lista (qualquer autenticado)
// POST -> cria (admin); body { label, base_url, username, password, validate? }
// DELETE ?id=  -> remove (admin)
import { createClient } from "npm:@supabase/supabase-js@2";
import { encryptToken } from "../_shared/integrationCrypto.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "GET, POST, DELETE, OPTIONS",
};

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

function normalizeBaseUrl(input: string): string {
  let u = input.trim();
  if (!/^https?:\/\//i.test(u)) u = `https://${u}`;
  u = u.replace(/\/+$/, "").replace(/\/api$/i, "");
  return u;
}

async function validateMagazord(baseUrl: string, user: string, pass: string) {
  const auth = "Basic " + btoa(`${user}:${pass}`);
  const endpoints = ["/api/v1/listEstoque?limit=1", "/api/v2/site/menu"];
  for (const ep of endpoints) {
    const r = await fetch(`${baseUrl}${ep}`, { headers: { Authorization: auth, Accept: "application/json" } });
    await r.text().catch(() => "");
    if (r.status === 401) throw new Error("Credenciais inválidas — verifique usuário e senha de API.");
    return true;
  }
  return true;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
    const auth = req.headers.get("Authorization");
    if (!auth?.startsWith("Bearer ")) return json({ error: "Unauthorized" }, 401);

    const sb = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!);
    const { data: claims, error: cErr } = await sb.auth.getClaims(auth.slice(7));
    if (cErr || !claims?.claims?.sub) return json({ error: "Unauthorized" }, 401);
    const userId = claims.claims.sub as string;

    const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    const { data: roleRow } = await admin.from("user_roles").select("role").eq("user_id", userId).eq("role", "admin").maybeSingle();
    const isAdmin = !!roleRow;

    if (req.method === "GET") {
      const { data, error } = await admin
        .from("workspace_magazord_stores")
        .select("id, label, base_url, username, created_at")
        .order("label", { ascending: true });
      if (error) throw error;
      return json({ stores: data ?? [] });
    }

    if (req.method === "POST") {
      if (!isAdmin) return json({ error: "Apenas admins" }, 403);
      const body = await req.json().catch(() => null) as null | {
        label?: string; base_url?: string; username?: string; password?: string; validate?: boolean;
      };
      if (!body?.label || !body?.base_url || !body?.username || !body?.password) {
        return json({ error: "label, base_url, username e password são obrigatórios" }, 400);
      }
      const baseUrl = normalizeBaseUrl(body.base_url);
      if (body.validate !== false) {
        try { await validateMagazord(baseUrl, body.username, body.password); }
        catch (e) { return json({ error: e instanceof Error ? e.message : "Falha na validação" }, 400); }
      }
      const { data, error } = await admin
        .from("workspace_magazord_stores")
        .insert({
          label: body.label,
          base_url: baseUrl,
          username: body.username,
          password_encrypted: await encryptToken(body.password) as string,
          created_by: userId,
        })
        .select("id, label, base_url, username, created_at")
        .single();
      if (error) throw error;
      return json({ store: data });
    }

    if (req.method === "DELETE") {
      if (!isAdmin) return json({ error: "Apenas admins" }, 403);
      const url = new URL(req.url);
      const id = url.searchParams.get("id");
      if (!id) return json({ error: "id obrigatório" }, 400);
      const { error } = await admin.from("workspace_magazord_stores").delete().eq("id", id);
      if (error) throw error;
      return json({ ok: true });
    }

    return json({ error: "Method not allowed" }, 405);
  } catch (e) {
    return json({ error: e instanceof Error ? e.message : "Erro" }, 500);
  }
});
