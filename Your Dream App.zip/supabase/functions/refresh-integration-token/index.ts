// Refreshes a client_integrations access_token using its stored refresh_token.
// Internal use: called from other edge functions (meta-ads-metrics) AND from the
// scheduled cron job that warms up tokens before they expire.
//
// Body: { client_id: string, provider: "google"|"meta"|"magazord" }
// Returns: { ok: true, access_token } on success (only when called by service role)
// Otherwise just returns { ok: true, refreshed: boolean }.

import { createClient } from "npm:@supabase/supabase-js@2";
import { decryptToken, encryptToken } from "../_shared/integrationCrypto.ts";
import { getProviderConfig, type Provider } from "../_shared/integrationProviders.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

async function callRefresh(provider: Provider, refreshToken: string) {
  const cfg = getProviderConfig(provider);
  const params = new URLSearchParams({
    client_id: cfg.clientId,
    client_secret: cfg.clientSecret,
    grant_type: "refresh_token",
    refresh_token: refreshToken,
  });
  // Meta uses the long-lived-token exchange endpoint (no refresh_token concept).
  if (provider === "meta") {
    const r = await fetch(
      `${cfg.tokenUrl}?grant_type=fb_exchange_token&client_id=${cfg.clientId}&client_secret=${cfg.clientSecret}&fb_exchange_token=${encodeURIComponent(refreshToken)}`,
    );
    const data = await r.json();
    if (!r.ok) throw new Error(data?.error?.message || "Falha ao renovar token Meta");
    return {
      access_token: data.access_token as string,
      expires_in: data.expires_in as number | undefined,
      refresh_token: refreshToken,
    };
  }
  const r = await fetch(cfg.tokenUrl, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: params.toString(),
  });
  const data = await r.json();
  if (!r.ok) throw new Error(data?.error_description || data?.error || "Falha ao renovar token");
  return {
    access_token: data.access_token as string,
    expires_in: data.expires_in as number | undefined,
    refresh_token: (data.refresh_token as string | undefined) ?? refreshToken,
  };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
    const { client_id, provider, force } = await req.json();
    if (!client_id || !provider) {
      return new Response(JSON.stringify({ error: "client_id e provider obrigatórios" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const admin = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    const { data: row, error } = await admin
      .from("client_integrations")
      .select("*")
      .eq("client_id", client_id)
      .eq("provider", provider)
      .maybeSingle();
    if (error) throw error;
    if (!row) return new Response(JSON.stringify({ error: "Integração não encontrada" }), { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } });

    const expiresAtMs = row.expires_at ? new Date(row.expires_at).getTime() : 0;
    const needsRefresh = force || !row.expires_at || expiresAtMs - Date.now() < 5 * 60 * 1000;

    if (!needsRefresh) {
      const access = await decryptToken(row.access_token);
      return new Response(JSON.stringify({ ok: true, refreshed: false, access_token: access }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const refreshPlain = await decryptToken(row.refresh_token);
    if (!refreshPlain) {
      await admin.from("client_integrations").update({ status: "expired", last_error: "Sem refresh_token disponível — reconecte." }).eq("id", row.id);
      return new Response(JSON.stringify({ error: "Reconexão necessária" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    try {
      const fresh = await callRefresh(provider as Provider, refreshPlain);
      const expiresAt = fresh.expires_in
        ? new Date(Date.now() + fresh.expires_in * 1000).toISOString()
        : null;
      await admin
        .from("client_integrations")
        .update({
          access_token: await encryptToken(fresh.access_token),
          refresh_token: await encryptToken(fresh.refresh_token),
          expires_at: expiresAt,
          status: "connected",
          last_error: null,
        })
        .eq("id", row.id);
      return new Response(JSON.stringify({ ok: true, refreshed: true, access_token: fresh.access_token }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Erro desconhecido";
      await admin
        .from("client_integrations")
        .update({ status: "expired", last_error: msg })
        .eq("id", row.id);
      return new Response(JSON.stringify({ error: msg }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
  } catch (e) {
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Erro" }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
