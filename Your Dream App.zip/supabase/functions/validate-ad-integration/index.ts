// Validates Meta Ads or Google Ads tokens for a given client.
// Public endpoint — no JWT needed (config.toml verify_jwt = false).
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

interface Payload {
  provider: "meta" | "google";
  access_token: string;
  account_id?: string;
}

async function validateMeta(token: string, accountId?: string) {
  // Try the account endpoint first when accountId is supplied, else /me
  const url = accountId
    ? `https://graph.facebook.com/v19.0/act_${accountId.replace(/^act_/, "")}?fields=id,name&access_token=${encodeURIComponent(token)}`
    : `https://graph.facebook.com/v19.0/me?access_token=${encodeURIComponent(token)}`;
  const r = await fetch(url);
  const data = await r.json();
  if (!r.ok) {
    return { ok: false, message: data?.error?.message ?? "Token Meta inválido" };
  }
  return { ok: true, message: "Conexão validada", data };
}

async function validateGoogle(token: string, accountId?: string) {
  // Lightweight check: call Google Ads tokeninfo to ensure the OAuth token is alive.
  const r = await fetch(
    `https://oauth2.googleapis.com/tokeninfo?access_token=${encodeURIComponent(token)}`,
  );
  const data = await r.json();
  if (!r.ok || data.error) {
    return {
      ok: false,
      message: data?.error_description ?? data?.error ?? "Token Google inválido",
    };
  }
  return { ok: true, message: "Conexão validada", data: { ...data, account_id: accountId } };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
    const body = (await req.json()) as Payload;
    if (!body?.provider || !body?.access_token) {
      return new Response(
        JSON.stringify({ ok: false, message: "provider e access_token são obrigatórios" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }
    const result =
      body.provider === "meta"
        ? await validateMeta(body.access_token, body.account_id)
        : await validateGoogle(body.access_token, body.account_id);
    return new Response(JSON.stringify(result), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    return new Response(
      JSON.stringify({ ok: false, message: e instanceof Error ? e.message : "Erro desconhecido" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});
