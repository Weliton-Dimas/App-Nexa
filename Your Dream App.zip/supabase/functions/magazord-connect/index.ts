// Connects a Magazord store using HTTP Basic Auth (URL + user + password).
// Validates against the Magazord API, then upserts an encrypted record into
// client_integrations with provider='magazord'.

import { createClient } from "npm:@supabase/supabase-js@2";
import { encryptToken } from "../_shared/integrationCrypto.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

function normalizeBaseUrl(input: string): string {
  let u = input.trim();
  if (!/^https?:\/\//i.test(u)) u = `https://${u}`;
  // remove trailing slash
  u = u.replace(/\/+$/, "");
  // remove trailing /api if user pasted that — we always add it ourselves
  u = u.replace(/\/api$/i, "");
  return u;
}

async function validateCredentials(baseUrl: string, user: string, pass: string) {
  const auth = "Basic " + btoa(`${user}:${pass}`);
  // Try a couple of well-known endpoints. 401 = bad credentials.
  // Any other status (200/403/404/405) means auth was accepted by the server.
  const endpoints = ["/api/v1/listEstoque?limit=1", "/api/v2/site/menu"];
  for (const ep of endpoints) {
    const r = await fetch(`${baseUrl}${ep}`, {
      headers: { Authorization: auth, Accept: "application/json" },
    });
    await r.text().catch(() => "");
    if (r.status === 401) {
      throw new Error("Credenciais inválidas — verifique usuário e senha de API.");
    }
    // Anything else: server accepted authentication
    return true;
  }
  return true;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
    const authHeader = req.headers.get("Authorization") ?? "";
    const jwt = authHeader.replace(/^Bearer\s+/i, "");
    if (!jwt) {
      return new Response(JSON.stringify({ error: "Não autenticado" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!);
    const { data: claims, error: claimsErr } = await supabase.auth.getClaims(jwt);
    if (claimsErr || !claims?.claims?.sub) {
      return new Response(JSON.stringify({ error: "Sessão inválida" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const userId = claims.claims.sub as string;

    const body = await req.json().catch(() => null) as null | {
      client_id?: string;
      base_url?: string;
      username?: string;
      password?: string;
      validate?: boolean;
    };
    if (!body?.client_id || !body?.base_url || !body?.username || !body?.password) {
      return new Response(JSON.stringify({ error: "Campos obrigatórios: client_id, base_url, username, password" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);

    // Permission check: admin OR assigned to client
    const { data: client, error: cErr } = await admin
      .from("clients")
      .select("id, assigned_users")
      .eq("id", body.client_id)
      .maybeSingle();
    if (cErr || !client) {
      return new Response(JSON.stringify({ error: "Cliente não encontrado" }), { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const { data: roleRow } = await admin.from("user_roles").select("role").eq("user_id", userId).eq("role", "admin").maybeSingle();
    const isAdmin = !!roleRow;
    const assigned = (client.assigned_users ?? []).includes(userId);
    if (!isAdmin && !assigned) {
      return new Response(JSON.stringify({ error: "Sem permissão para este cliente" }), { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const baseUrl = normalizeBaseUrl(body.base_url);

    if (body.validate !== false) {
      try {
        await validateCredentials(baseUrl, body.username, body.password);
      } catch (e) {
        return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Falha na validação" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
    }

    const accountName = new URL(baseUrl).hostname;
    const { error: upErr } = await admin
      .from("client_integrations")
      .upsert(
        {
          client_id: body.client_id,
          provider: "magazord",
          status: "connected",
          account_id: accountName,
          account_name: accountName,
          access_token: await encryptToken(body.password),
          refresh_token: await encryptToken(body.username), // stash username as "refresh"
          expires_at: null,
          scope: null,
          extra: { base_url: baseUrl, auth_type: "basic", username: body.username },
          last_synced_at: new Date().toISOString(),
          last_error: null,
          connected_by: userId,
        },
        { onConflict: "client_id,provider" },
      );
    if (upErr) throw upErr;

    return new Response(JSON.stringify({ ok: true, account: { id: accountName, name: accountName } }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (e) {
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Erro desconhecido" }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
