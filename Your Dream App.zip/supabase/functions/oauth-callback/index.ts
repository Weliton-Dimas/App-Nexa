// Provider redirects here with ?code=...&state=...
// State pode ser kind="client" (vincula a um cliente) ou "workspace" (conecta a BM toda).
import { createClient } from "npm:@supabase/supabase-js@2";
import { encryptToken, verifyState } from "../_shared/integrationCrypto.ts";
import { getProviderConfig, type Provider } from "../_shared/integrationProviders.ts";

interface AccountInfo {
  account_id: string | null;
  account_name: string | null;
  extra: Record<string, unknown>;
}

async function exchangeCode(provider: Provider, code: string) {
  const cfg = getProviderConfig(provider);
  const params = new URLSearchParams({
    code,
    client_id: cfg.clientId,
    client_secret: cfg.clientSecret,
    redirect_uri: cfg.redirectUri,
    grant_type: "authorization_code",
  });
  const r = await fetch(cfg.tokenUrl, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: params.toString(),
  });
  const data = await r.json();
  if (!r.ok) {
    console.error("[oauth-callback] token exchange failed", { provider, status: r.status, body: data });
    throw new Error(data?.error_description || data?.error?.message || `Falha ao trocar code (HTTP ${r.status})`);
  }
  return {
    access_token: data.access_token as string,
    refresh_token: (data.refresh_token as string | undefined) ?? null,
    expires_in: (data.expires_in as number | undefined) ?? null,
    scope: (data.scope as string | undefined) ?? null,
  };
}

// Legacy flow (per-client): mantém compatibilidade para Google.
async function discoverAccount(provider: Provider, accessToken: string): Promise<AccountInfo> {
  if (provider === "google") {
    const r = await fetch(
      "https://googleads.googleapis.com/v17/customers:listAccessibleCustomers",
      { headers: { Authorization: `Bearer ${accessToken}`, "developer-token": Deno.env.get("GOOGLE_DEVELOPER_TOKEN") ?? "" } },
    );
    const data = await r.json();
    if (!r.ok) return { account_id: null, account_name: null, extra: { listError: data } };
    const ids = ((data.resourceNames ?? []) as string[]).map((s) => s.replace("customers/", ""));
    return { account_id: ids[0] ?? null, account_name: ids[0] ? `Customer ${ids[0]}` : null, extra: { availableAccounts: ids } };
  }
  if (provider === "meta") {
    const r = await fetch(
      `https://graph.facebook.com/v19.0/me/adaccounts?fields=id,account_id,name&access_token=${encodeURIComponent(accessToken)}`,
    );
    const data = await r.json();
    if (!r.ok) return { account_id: null, account_name: null, extra: { listError: data } };
    const first = data?.data?.[0];
    const all = (data?.data ?? []).map((a: { account_id: string; name: string }) => ({ account_id: a.account_id, name: a.name }));
    return { account_id: first?.account_id ?? null, account_name: first?.name ?? null, extra: { availableAccounts: all } };
  }
  return { account_id: null, account_name: null, extra: {} };
}

// Workspace flow: descobre BMs e contas dentro da BM.
async function discoverBusinessAccounts(accessToken: string) {
  const bRes = await fetch(
    `https://graph.facebook.com/v19.0/me/businesses?fields=id,name&access_token=${encodeURIComponent(accessToken)}`,
  );
  const bData = await bRes.json();
  if (!bRes.ok) {
    console.error("[oauth-callback] me/businesses failed", bData);
    throw new Error(bData?.error?.message || "Falha ao listar Business Managers");
  }
  const businesses = (bData?.data ?? []) as Array<{ id: string; name: string }>;
  if (businesses.length === 0) {
    throw new Error("Nenhuma Business Manager encontrada nesta conta. Adicione-se como admin de uma BM no Meta Business.");
  }

  // Se mais de uma BM, retorna sem escolher (usuário escolhe na UI).
  if (businesses.length > 1) {
    return { businesses, business: null, accounts: [] };
  }

  const biz = businesses[0];
  const accounts = await fetchAccountsForBusiness(accessToken, biz.id);
  return { businesses, business: biz, accounts };
}

async function fetchAccountsForBusiness(accessToken: string, businessId: string) {
  const fields = "account_id,name";
  const [ownedRes, clientRes] = await Promise.all([
    fetch(`https://graph.facebook.com/v19.0/${businessId}/owned_ad_accounts?fields=${fields}&limit=200&access_token=${encodeURIComponent(accessToken)}`),
    fetch(`https://graph.facebook.com/v19.0/${businessId}/client_ad_accounts?fields=${fields}&limit=200&access_token=${encodeURIComponent(accessToken)}`),
  ]);
  const [ownedData, clientData] = await Promise.all([ownedRes.json(), clientRes.json()]);
  const merged: Array<{ account_id: string; name: string }> = [];
  const seen = new Set<string>();
  for (const a of [...(ownedData?.data ?? []), ...(clientData?.data ?? [])]) {
    const id = a.account_id;
    if (!id || seen.has(id)) continue;
    seen.add(id);
    merged.push({ account_id: id, name: a.name });
  }
  return merged;
}

async function listGoogleAdsAccounts(accessToken: string): Promise<Array<{ account_id: string; name: string }>> {
  const devToken = Deno.env.get("GOOGLE_DEVELOPER_TOKEN") ?? "";
  const r = await fetch("https://googleads.googleapis.com/v17/customers:listAccessibleCustomers", {
    headers: { Authorization: `Bearer ${accessToken}`, "developer-token": devToken },
  });
  const data = await r.json();
  if (!r.ok) {
    console.error("[oauth-callback] google ads list failed", data);
    return [];
  }
  const ids = ((data.resourceNames ?? []) as string[]).map((s) => s.replace("customers/", ""));
  return ids.map((id) => ({ account_id: id, name: `Customer ${id}` }));
}

async function listGAProperties(accessToken: string): Promise<Array<{ account_id: string; name: string }>> {
  // Admin API: accountSummaries returns accounts with their propertySummaries
  const r = await fetch("https://analyticsadmin.googleapis.com/v1beta/accountSummaries?pageSize=200", {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  const data = await r.json();
  if (!r.ok) {
    console.error("[oauth-callback] GA accountSummaries failed", data);
    return [];
  }
  const out: Array<{ account_id: string; name: string }> = [];
  for (const acc of (data.accountSummaries ?? [])) {
    const accountName = acc.displayName ?? acc.account ?? "Conta";
    for (const p of (acc.propertySummaries ?? [])) {
      // p.property = "properties/123456789"
      const propId = (p.property as string ?? "").replace("properties/", "");
      if (!propId) continue;
      out.push({ account_id: propId, name: `${accountName} — ${p.displayName ?? propId}` });
    }
  }
  return out;
}

function popupResponse(payload: Record<string, unknown>) {
  const json = JSON.stringify(payload);
  const heading = payload.ok
    ? (payload.needsAccountSelection || payload.needsBusinessSelection ? "Selecione" : "✅ Conectado")
    : "⚠ Erro na conexão";
  const sub = payload.ok ? "Volte para a aba do app." : (payload.message ?? "");
  const body = `<!doctype html><meta charset="utf-8"><body style="font-family:system-ui;background:#0f172a;color:#e2e8f0;padding:32px;text-align:center">
<h2>${heading}</h2><p style="opacity:.7">${sub}</p>
<script>
try { if (window.opener) window.opener.postMessage({ source: "lovable-oauth", ...${json} }, "*"); } catch(e){}
setTimeout(() => window.close(), 800);
</script></body>`;
  return new Response(body, { status: 200, headers: { "Content-Type": "text/html; charset=utf-8" } });
}

Deno.serve(async (req) => {
  const url = new URL(req.url);
  const code = url.searchParams.get("code");
  const stateRaw = url.searchParams.get("state");
  const errorParam = url.searchParams.get("error_description") || url.searchParams.get("error");

  if (errorParam) return popupResponse({ ok: false, message: errorParam });
  if (!code || !stateRaw) return popupResponse({ ok: false, message: "Resposta inválida do provedor" });

  try {
    const state = await verifyState(stateRaw);
    const provider = state.provider as Provider;
    const tokens = await exchangeCode(provider, code);

    const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    const expiresAt = tokens.expires_in ? new Date(Date.now() + tokens.expires_in * 1000).toISOString() : null;

    // ===== WORKSPACE FLOW =====
    if (state.kind === "workspace") {
      if (provider === "google") {
        const accounts = await listGoogleAdsAccounts(tokens.access_token);
        const { error } = await admin.from("workspace_integrations").upsert({
          provider,
          status: "connected",
          access_token: await encryptToken(tokens.access_token),
          refresh_token: await encryptToken(tokens.refresh_token),
          expires_at: expiresAt,
          scope: tokens.scope,
          available_accounts: accounts,
          last_synced_at: new Date().toISOString(),
          last_error: null,
          connected_by: state.user_id,
        }, { onConflict: "provider" });
        if (error) throw error;
        return popupResponse({ ok: true, scope: "workspace", provider, accountsCount: accounts.length });
      }
      if (provider === "google_analytics") {
        const accounts = await listGAProperties(tokens.access_token);
        const { error } = await admin.from("workspace_integrations").upsert({
          provider,
          status: "connected",
          access_token: await encryptToken(tokens.access_token),
          refresh_token: await encryptToken(tokens.refresh_token),
          expires_at: expiresAt,
          scope: tokens.scope,
          available_accounts: accounts,
          last_synced_at: new Date().toISOString(),
          last_error: null,
          connected_by: state.user_id,
        }, { onConflict: "provider" });
        if (error) throw error;
        return popupResponse({ ok: true, scope: "workspace", provider, accountsCount: accounts.length });
      }

      const discovery = await discoverBusinessAccounts(tokens.access_token);
      const needsBusinessSelection = discovery.businesses.length > 1;

      const { error } = await admin.from("workspace_integrations").upsert({
        provider,
        status: needsBusinessSelection ? "pending_business_selection" : "connected",
        business_id: discovery.business?.id ?? null,
        business_name: discovery.business?.name ?? null,
        access_token: await encryptToken(tokens.access_token),
        refresh_token: await encryptToken(tokens.access_token), // Meta usa o próprio token p/ exchange
        expires_at: expiresAt,
        scope: tokens.scope,
        available_accounts: discovery.accounts,
        available_businesses: discovery.businesses,
        last_synced_at: new Date().toISOString(),
        last_error: null,
        connected_by: state.user_id,
      }, { onConflict: "provider" });
      if (error) throw error;

      return popupResponse({
        ok: true,
        scope: "workspace",
        provider,
        needsBusinessSelection,
        businesses: discovery.businesses,
        business: discovery.business,
        accountsCount: discovery.accounts.length,
      });
    }

    // ===== CLIENT FLOW (legacy) =====
    if (!state.client_id) throw new Error("client_id ausente no state");
    const account = await discoverAccount(provider, tokens.access_token);
    const availableAccounts = Array.isArray((account.extra as { availableAccounts?: unknown })?.availableAccounts)
      ? ((account.extra as { availableAccounts: unknown[] }).availableAccounts) : [];
    const needsSelection = provider === "meta" && availableAccounts.length > 1;

    const { error } = await admin.from("client_integrations").upsert({
      client_id: state.client_id,
      provider,
      status: needsSelection ? "pending_account_selection" : "connected",
      account_id: needsSelection ? null : account.account_id,
      account_name: needsSelection ? null : account.account_name,
      access_token: await encryptToken(tokens.access_token),
      refresh_token: await encryptToken(tokens.refresh_token),
      expires_at: expiresAt,
      scope: tokens.scope,
      extra: account.extra,
      last_synced_at: new Date().toISOString(),
      last_error: null,
      connected_by: state.user_id,
    }, { onConflict: "client_id,provider" });
    if (error) throw error;

    return popupResponse({
      ok: true,
      scope: "client",
      provider,
      client_id: state.client_id,
      needsAccountSelection: needsSelection,
      accounts: availableAccounts,
      account: { id: account.account_id, name: account.account_name },
    });
  } catch (e) {
    console.error("[oauth-callback] error", e);
    return popupResponse({ ok: false, message: e instanceof Error ? e.message : "Erro desconhecido" });
  }
});
