import { createClient } from "https://esm.sh/@supabase/supabase-js@2.97.0";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version',
};

function b64decode(s: string): Uint8Array {
  const pad = s.length % 4 === 0 ? "" : "=".repeat(4 - (s.length % 4));
  const norm = s.replace(/-/g, "+").replace(/_/g, "/") + pad;
  const bin = atob(norm);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
async function decryptToken(stored: string | null | undefined): Promise<string | null> {
  if (!stored) return null;
  if (!stored.startsWith("v1:")) return stored;
  const raw = Deno.env.get("INTEGRATION_TOKEN_KEY");
  if (!raw) throw new Error("INTEGRATION_TOKEN_KEY not configured");
  const keyBytes = b64decode(raw);
  const key = await crypto.subtle.importKey("raw", keyBytes, { name: "AES-GCM" }, false, ["decrypt"]);
  const bytes = b64decode(stored.slice(3));
  const iv = bytes.slice(0, 12);
  const cipher = bytes.slice(12);
  const plain = await crypto.subtle.decrypt({ name: "AES-GCM", iv }, key, cipher);
  return new TextDecoder().decode(plain);
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const anonKey = Deno.env.get('SUPABASE_ANON_KEY')!;
    const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(JSON.stringify({ error: 'Não autorizado' }), { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }
    const callerClient = createClient(supabaseUrl, anonKey, { global: { headers: { Authorization: authHeader } } });
    const { data: userData, error: claimsError } = await callerClient.auth.getUser();
    if (claimsError || !userData?.user) {
      return new Response(JSON.stringify({ error: 'Token inválido' }), { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }
    const userId = userData.user.id;

    const url = new URL(req.url);
    const datePreset = url.searchParams.get('date_preset') || 'last_7d';
    const since = url.searchParams.get('since');
    const until = url.searchParams.get('until');
    const useCustomRange = !!(since && until);
    const dateParam = useCustomRange
      ? `time_range=${encodeURIComponent(JSON.stringify({ since, until }))}`
      : `date_preset=${datePreset}`;
    const clientId = url.searchParams.get('client_id');
    if (!clientId) {
      return new Response(JSON.stringify({ error: 'client_id é obrigatório' }), { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }

    const adminClient = createClient(supabaseUrl, serviceKey);
    const { data: client, error: clientError } = await adminClient
      .from('clients')
      .select('id, name, meta_access_token, meta_account_id, assigned_users')
      .eq('id', clientId)
      .single();

    if (client) {
      const { data: isAdminData } = await adminClient.rpc('has_role', { _user_id: userId, _role: 'admin' });
      const isAdmin = isAdminData === true;
      const assigned = (client.assigned_users || []) as string[];
      if (!isAdmin && !assigned.includes(userId)) {
        return new Response(JSON.stringify({ error: 'Acesso negado a este cliente' }), { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
      }
    }

    if (clientError || !client) {
      return new Response(JSON.stringify({ error: 'Cliente não encontrado' }), { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }

    const { data: ci } = await adminClient
      .from('client_integrations')
      .select('account_id')
      .eq('client_id', clientId)
      .eq('provider', 'meta')
      .maybeSingle();
    const accountId = ci?.account_id ?? client.meta_account_id;

    const { data: ws } = await adminClient
      .from('workspace_integrations')
      .select('access_token, status')
      .eq('provider', 'meta')
      .maybeSingle();
    let accessToken: string | null = null;
    if (ws?.access_token && ws.status === 'connected') {
      accessToken = await decryptToken(ws.access_token);
    }
    if (!accessToken) accessToken = client.meta_access_token ?? null;

    if (!accessToken || !accountId) {
      return new Response(JSON.stringify({
        error: !accessToken
          ? 'Conta Meta do workspace não está conectada. Conecte em Integrações.'
          : `Cliente "${client.name}" não tem ad account vinculada. Selecione na aba Integração.`,
      }), { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }

    const cleanAccountId = accountId.replace(/^act_/, '');
    const baseUrl = `https://graph.facebook.com/v21.0/act_${cleanAccountId}/insights`;
    const baseFields = 'reach,frequency,impressions,spend,cpm,actions,action_values,cost_per_action_type,clicks,ctr,cpc';
    const adFields = 'ad_name,campaign_name,reach,frequency,impressions,spend,cpm,actions,action_values,cost_per_action_type,clicks,ctr,cpc';

    const [insightsRes, platformRes, regionRes, cityRes, adRes] = await Promise.all([
      fetch(`${baseUrl}?fields=${baseFields}&${dateParam}&access_token=${accessToken}`),
      fetch(`${baseUrl}?fields=${baseFields}&breakdowns=publisher_platform&${dateParam}&access_token=${accessToken}`),
      fetch(`${baseUrl}?fields=reach,impressions,spend,actions,clicks&breakdowns=region&${dateParam}&limit=20&access_token=${accessToken}`),
      fetch(`${baseUrl}?fields=reach,impressions,spend,actions,clicks&breakdowns=dma&${dateParam}&limit=20&access_token=${accessToken}`),
      fetch(`${baseUrl}?level=ad&fields=${adFields}&${dateParam}&limit=30&access_token=${accessToken}`),
    ]);

    const [insightsData, platformData, regionData, cityData, adData] = await Promise.all([
      insightsRes.json(),
      platformRes.json(),
      regionRes.json(),
      cityRes.json(),
      adRes.json(),
    ]);

    if (insightsData.error) {
      const isTokenError = insightsData.error.code === 190 ||
        /access token/i.test(insightsData.error.message || '');
      if (isTokenError) {
        // mark integration as inactive so user knows to re-validate
        await adminClient
          .from('clients')
          .update({ meta_integration_status: 'inativo' })
          .eq('id', clientId);
        return new Response(JSON.stringify({
          error: `Token Meta do cliente "${client.name}" expirou. Atualize na aba Integração.`,
        }), {
          status: 401,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
      throw new Error(insightsData.error.message || 'Meta API error');
    }

    const data = insightsData.data?.[0] || {};
    const actions = data.actions || [];
    const actionValues = data.action_values || [];
    const costPerAction = data.cost_per_action_type || [];

    const sumActions = (types: string[], arr: any[] = actions) =>
      arr
        .filter((a: any) => types.includes(a.action_type))
        .reduce((s: number, a: any) => s + (parseFloat(a.value) || 0), 0);

    const getActionValue = (actionType: string, actionsArr: any[] = actions) => {
      const action = actionsArr.find((a: any) => a.action_type === actionType);
      return action ? parseInt(action.value, 10) : 0;
    };

    const getCostPerAction = (actionType: string) => {
      const cost = costPerAction.find((a: any) => a.action_type === actionType);
      return cost ? parseFloat(cost.value) : 0;
    };

    // Aggregate "results" — purchases first, otherwise leads, otherwise conversations
    const PURCHASE_TYPES = ['purchase', 'offsite_conversion.fb_pixel_purchase', 'omni_purchase'];
    const LEAD_TYPES = ['lead', 'onsite_conversion.lead_grouped', 'offsite_conversion.fb_pixel_lead'];
    const MESSAGE_TYPES = ['onsite_conversion.messaging_conversation_started_7d'];

    const purchases = sumActions(PURCHASE_TYPES);
    const purchaseValue = sumActions(PURCHASE_TYPES, actionValues);
    const leads = sumActions(LEAD_TYPES);
    const conversations = getActionValue('onsite_conversion.messaging_conversation_started_7d');
    const messages = getActionValue('onsite_conversion.messaging_first_reply');
    const linkClicks = getActionValue('link_click');
    const pageEngagement = getActionValue('page_engagement');
    const postEngagement = getActionValue('post_engagement');
    const addToCart = sumActions(['add_to_cart', 'offsite_conversion.fb_pixel_add_to_cart']);
    const initiateCheckout = sumActions(['initiate_checkout', 'offsite_conversion.fb_pixel_initiate_checkout']);
    const videoViews = sumActions(['video_view']);
    const profileVisits = sumActions(['onsite_conversion.view_content', 'page_engagement']);

    // Choose best "result" metric automatically
    const results = purchases > 0 ? purchases : leads > 0 ? leads : conversations;
    const resultType = purchases > 0 ? 'purchase' : leads > 0 ? 'lead' : conversations > 0 ? 'conversation' : 'none';

    const spendNum = parseFloat(data.spend || '0');
    const reachNum = parseInt(data.reach || '0', 10);
    const impressionsNum = parseInt(data.impressions || '0', 10);
    const frequency = data.frequency ? parseFloat(data.frequency) : (reachNum > 0 ? impressionsNum / reachNum : 0);
    const cpm = data.cpm ? parseFloat(data.cpm) : (impressionsNum > 0 ? (spendNum / impressionsNum) * 1000 : 0);
    const costPerResult = results > 0 ? spendNum / results : 0;
    const roas = spendNum > 0 ? purchaseValue / spendNum : 0;

    const mapBreakdownRow = (row: any, key: string, fallback: string) => {
      const rActions = row.actions || [];
      return {
        [key]: row[key] || fallback,
        reach: parseInt(row.reach || '0', 10),
        impressions: parseInt(row.impressions || '0', 10),
        spend: parseFloat(row.spend || '0'),
        clicks: parseInt(row.clicks || '0', 10),
        conversations: getActionValue('onsite_conversion.messaging_conversation_started_7d', rActions),
        messages: getActionValue('onsite_conversion.messaging_first_reply', rActions),
        purchases: sumActions(PURCHASE_TYPES, rActions),
        leads: sumActions(LEAD_TYPES, rActions),
      };
    };

    const platformBreakdown: any[] = [];
    if (platformData.data && Array.isArray(platformData.data)) {
      for (const row of platformData.data) {
        platformBreakdown.push(mapBreakdownRow(row, 'publisher_platform', 'unknown'));
      }
    }
    // Normalize key name to "platform"
    for (const r of platformBreakdown) {
      r.platform = r.publisher_platform;
      delete r.publisher_platform;
    }

    const regionBreakdown: any[] = [];
    if (regionData.data && Array.isArray(regionData.data)) {
      for (const row of regionData.data) {
        regionBreakdown.push(mapBreakdownRow(row, 'region', 'Desconhecido'));
      }
    }
    regionBreakdown.sort((a, b) => b.spend - a.spend);

    const cityBreakdown: any[] = [];
    if (cityData.data && Array.isArray(cityData.data)) {
      for (const row of cityData.data) {
        const c = mapBreakdownRow(row, 'dma', 'Desconhecido');
        cityBreakdown.push({ ...c, city: (c as any).dma });
      }
    }
    cityBreakdown.sort((a, b) => b.spend - a.spend);

    const adBreakdown: any[] = [];
    if (adData.data && Array.isArray(adData.data)) {
      for (const row of adData.data) {
        const aActions = row.actions || [];
        const aValues = row.action_values || [];
        const aCostPerAction = row.cost_per_action_type || [];
        const costConv = aCostPerAction.find((a: any) => a.action_type === 'onsite_conversion.messaging_conversation_started_7d');
        const adPurchases = sumActions(PURCHASE_TYPES, aActions);
        const adPurchaseValue = sumActions(PURCHASE_TYPES, aValues);
        const adSpend = parseFloat(row.spend || '0');
        adBreakdown.push({
          adName: row.ad_name || 'Sem nome',
          campaignName: row.campaign_name || 'Sem campanha',
          reach: parseInt(row.reach || '0', 10),
          frequency: row.frequency ? parseFloat(row.frequency) : 0,
          impressions: parseInt(row.impressions || '0', 10),
          spend: adSpend,
          clicks: parseInt(row.clicks || '0', 10),
          ctr: parseFloat(row.ctr || '0'),
          cpc: parseFloat(row.cpc || '0'),
          cpm: row.cpm ? parseFloat(row.cpm) : 0,
          conversations: getActionValue('onsite_conversion.messaging_conversation_started_7d', aActions),
          messages: getActionValue('onsite_conversion.messaging_first_reply', aActions),
          purchases: adPurchases,
          leads: sumActions(LEAD_TYPES, aActions),
          purchaseValue: adPurchaseValue,
          roas: adSpend > 0 ? adPurchaseValue / adSpend : 0,
          costPerConversation: costConv ? parseFloat(costConv.value) : 0,
        });
      }
    }
    adBreakdown.sort((a, b) => b.purchases - a.purchases || b.conversations - a.conversations || b.spend - a.spend);

    const metrics = {
      reach: reachNum,
      frequency,
      impressions: impressionsNum,
      spend: spendNum,
      cpm,
      clicks: parseInt(data.clicks || '0', 10),
      ctr: parseFloat(data.ctr || '0'),
      cpc: parseFloat(data.cpc || '0'),
      conversations,
      messages,
      linkClicks,
      pageEngagement,
      postEngagement,
      purchases,
      purchaseValue,
      roas,
      leads,
      addToCart,
      initiateCheckout,
      videoViews,
      profileVisits,
      results,
      resultType,
      costPerResult,
      costPerConversation: getCostPerAction('onsite_conversion.messaging_conversation_started_7d'),
      costPerMessage: getCostPerAction('onsite_conversion.messaging_first_reply'),
      datePreset: useCustomRange ? 'custom' : datePreset,
      since: since || null,
      until: until || null,
      platformBreakdown,
      regionBreakdown,
      cityBreakdown,
      adBreakdown,
    };

    return new Response(JSON.stringify(metrics), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    return new Response(JSON.stringify({ error: message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
