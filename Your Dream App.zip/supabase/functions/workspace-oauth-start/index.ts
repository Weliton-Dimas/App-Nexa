// Inicia OAuth do nível workspace (admin only). Conecta a Business Manager
// inteira; depois cada cliente escolhe uma das contas da BM.
import { createClient } from "npm:@supabase/supabase-js@2";
import { signState } from "../_shared/integrationCrypto.ts";
import { getProviderConfig, isValidProvider } from "../_shared/integrationProviders.ts";

const html = (msg: string, status = 400) =>
  new Response(
    `<!doctype html><meta charset="utf-8"><body style="font-family:system-ui;background:#0f172a;color:#e2e8f0;padding:32px"><h2>Falha ao iniciar conexão</h2><p>${msg}</p></body>`,
    { status, headers: { "Content-Type": "text/html; charset=utf-8" } },
  );

Deno.serve(async (req) => {
  try {
    const url = new URL(req.url);
    const provider = url.searchParams.get("provider") ?? "";
    const token = url.searchParams.get("token") ?? "";
    if (!isValidProvider(provider)) return html("Provider inválido");
    if (!token) return html("Token de sessão ausente");

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
    );
    const { data: claims, error } = await supabase.auth.getClaims(token);
    if (error || !claims?.claims?.sub) return html("Sessão inválida", 401);
    const userId = claims.claims.sub as string;

    const admin = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );
    const { data: roleRow } = await admin
      .from("user_roles")
      .select("role")
      .eq("user_id", userId)
      .eq("role", "admin")
      .maybeSingle();
    if (!roleRow) return html("Apenas administradores podem conectar integrações do workspace", 403);

    const cfg = getProviderConfig(provider);
    const state = await signState({ kind: "workspace", provider, user_id: userId });

    const params = new URLSearchParams({
      client_id: cfg.clientId,
      redirect_uri: cfg.redirectUri,
      response_type: "code",
      scope: cfg.scopes,
      state,
      ...(cfg.extraAuthParams ?? {}),
    });

    return Response.redirect(`${cfg.authorizeUrl}?${params.toString()}`, 302);
  } catch (e) {
    return html(e instanceof Error ? e.message : "Erro desconhecido", 500);
  }
});
