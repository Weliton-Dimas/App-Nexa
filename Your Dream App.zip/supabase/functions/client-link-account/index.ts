// Vincula uma ad account ao cliente (escolhida da lista da BM do workspace).
// Permissão: admin OU usuário atribuído ao cliente.
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
    const auth = req.headers.get("Authorization");
    if (!auth?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!);
    const { data: claims, error: cErr } = await supabase.auth.getClaims(auth.slice(7));
    if (cErr || !claims?.claims?.sub) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const userId = claims.claims.sub as string;

    const { client_id, provider, account_id } = await req.json();
    if (!client_id || !provider || !account_id) {
      return new Response(JSON.stringify({ error: "client_id, provider e account_id obrigatórios" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);

    // Permissão
    const { data: client } = await admin.from("clients").select("assigned_users").eq("id", client_id).maybeSingle();
    const { data: roleRow } = await admin.from("user_roles").select("role").eq("user_id", userId).eq("role", "admin").maybeSingle();
    const isAdmin = !!roleRow;
    const assigned = (client?.assigned_users ?? []).includes(userId);
    if (!isAdmin && !assigned) {
      return new Response(JSON.stringify({ error: "Sem permissão" }), { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    let resolvedAccountId = account_id;
    let resolvedAccountName: string | null = null;

    if (provider === "magazord") {
      const { data: store } = await admin
        .from("workspace_magazord_stores")
        .select("id, label, base_url")
        .eq("id", account_id)
        .maybeSingle();
      if (!store) {
        return new Response(JSON.stringify({ error: "Loja Magazord não encontrada" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      resolvedAccountName = store.label;
    } else {
      const { data: ws } = await admin
        .from("workspace_integrations")
        .select("status, available_accounts")
        .eq("provider", provider)
        .maybeSingle();
      if (!ws || ws.status !== "connected") {
        return new Response(JSON.stringify({ error: "Workspace não está conectado a este provedor" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      const accounts = (ws.available_accounts ?? []) as Array<{ account_id: string; name: string }>;
      const acc = accounts.find((a) => a.account_id === account_id);
      if (!acc) {
        return new Response(JSON.stringify({ error: "Conta não encontrada nas integrações do workspace" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      resolvedAccountId = acc.account_id;
      resolvedAccountName = acc.name;
    }

    const { error } = await admin.from("client_integrations").upsert({
      client_id,
      provider,
      status: "connected",
      account_id: resolvedAccountId,
      account_name: resolvedAccountName,
      last_synced_at: new Date().toISOString(),
      last_error: null,
      connected_by: userId,
    }, { onConflict: "client_id,provider" });
    if (error) throw error;

    return new Response(JSON.stringify({ ok: true, account: { account_id: resolvedAccountId, name: resolvedAccountName } }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (e) {
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Erro" }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
