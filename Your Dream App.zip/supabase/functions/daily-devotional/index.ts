import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY")!;
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");

    // Auth guard
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Não autorizado" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const callerSb = createClient(SUPABASE_URL, ANON_KEY, { global: { headers: { Authorization: authHeader } } });
    const { data: userData, error: authErr } = await callerSb.auth.getUser();
    if (authErr || !userData?.user) {
      return new Response(JSON.stringify({ error: "Token inválido" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY não configurada");
    }

    const supabase = createClient(SUPABASE_URL, SERVICE_ROLE);

    // Date in São Paulo timezone (YYYY-MM-DD)
    const now = new Date();
    const sp = new Date(now.getTime() - 3 * 60 * 60 * 1000);
    const today = sp.toISOString().slice(0, 10);

    // 1. Try cache
    const { data: cached } = await supabase
      .from("daily_devotionals")
      .select("*")
      .eq("date", today)
      .maybeSingle();

    if (cached) {
      return new Response(JSON.stringify(cached), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // 1b. Recent references to avoid repetition
    const { data: recent } = await supabase
      .from("daily_devotionals")
      .select("reference")
      .order("date", { ascending: false })
      .limit(60);
    const avoidList = Array.from(
      new Set((recent ?? []).map((r: { reference: string }) => r.reference.replace(/\s*\(.*\)\s*$/, "").trim())),
    );
    const avoidText = avoidList.length
      ? `\n\nNÃO use nenhum destes versículos (já foram usados recentemente): ${avoidList.join("; ")}.`
      : "";

    // Random seed to encourage variety
    const seed = Math.random().toString(36).slice(2, 10);
    const themes = [
      "fé", "perseverança", "sabedoria", "gratidão", "humildade", "coragem",
      "paciência", "amor ao próximo", "trabalho com excelência", "descanso em Deus",
      "integridade", "generosidade", "esperança", "perdão", "propósito",
      "confiança", "alegria", "paz interior", "disciplina", "serviço",
    ];
    const theme = themes[Math.floor(Math.random() * themes.length)];

    // 2. Generate via Lovable AI with structured output
    const aiResponse = await fetch(
      "https://ai.gateway.lovable.dev/v1/chat/completions",
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${LOVABLE_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "google/gemini-2.5-flash",
          temperature: 1.1,
          messages: [
            {
              role: "system",
              content:
                "Você é um pastor evangélico brasileiro experiente. Crie devocionais cristãos curtos, profundos e encorajadores em português do Brasil. Use linguagem acessível, calorosa e prática para empreendedores e profissionais. Cite versículos da Bíblia em versão Almeida Revista e Atualizada (ARA) ou Nova Versão Internacional (NVI). IMPORTANTE: varie bastante os livros e versículos — explore Antigo e Novo Testamento (Salmos, Provérbios, Isaías, Eclesiastes, Mateus, Romanos, Tiago, 1 Pedro, etc.). Evite repetir versículos clássicos como Filipenses 4:13 ou Jeremias 29:11.",
            },
            {
              role: "user",
              content: `Gere o devocional de hoje (${today}). Tema sugerido: ${theme}. Semente de variação: ${seed}. Escolha um versículo bíblico DIFERENTE e significativo e crie reflexão, oração e aplicação prática para o dia.${avoidText}`,
            },
          ],
          tools: [
            {
              type: "function",
              function: {
                name: "create_devotional",
                description: "Cria o devocional do dia.",
                parameters: {
                  type: "object",
                  properties: {
                    verse: {
                      type: "string",
                      description: "Texto completo do versículo bíblico.",
                    },
                    reference: {
                      type: "string",
                      description: "Referência (ex: 'Filipenses 4:13').",
                    },
                    reflection: {
                      type: "string",
                      description:
                        "Reflexão de 2-3 frases ligando o versículo ao dia a dia.",
                    },
                    prayer: {
                      type: "string",
                      description:
                        "Oração curta (2-3 frases) na primeira pessoa.",
                    },
                    application: {
                      type: "string",
                      description:
                        "Uma ação prática e concreta para colocar o versículo em prática hoje (1 frase).",
                    },
                  },
                  required: [
                    "verse",
                    "reference",
                    "reflection",
                    "prayer",
                    "application",
                  ],
                  additionalProperties: false,
                },
              },
            },
          ],
          tool_choice: {
            type: "function",
            function: { name: "create_devotional" },
          },
        }),
      },
    );

    if (!aiResponse.ok) {
      const text = await aiResponse.text();
      console.error("AI gateway error:", aiResponse.status, text);
      if (aiResponse.status === 429) {
        return new Response(
          JSON.stringify({ error: "Limite de requisições atingido." }),
          {
            status: 429,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          },
        );
      }
      if (aiResponse.status === 402) {
        return new Response(
          JSON.stringify({
            error: "Créditos esgotados. Adicione créditos no workspace.",
          }),
          {
            status: 402,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          },
        );
      }
      throw new Error(`AI gateway error: ${aiResponse.status}`);
    }

    const aiData = await aiResponse.json();
    const toolCall = aiData.choices?.[0]?.message?.tool_calls?.[0];
    if (!toolCall) throw new Error("Resposta da IA sem tool call");

    const args = JSON.parse(toolCall.function.arguments);

    // 3. Persist
    const { data: inserted, error: insertError } = await supabase
      .from("daily_devotionals")
      .insert({
        date: today,
        verse: args.verse,
        reference: args.reference,
        reflection: args.reflection,
        prayer: args.prayer,
        application: args.application,
      })
      .select()
      .single();

    if (insertError) {
      // Race condition: another request might've inserted; refetch
      const { data: again } = await supabase
        .from("daily_devotionals")
        .select("*")
        .eq("date", today)
        .maybeSingle();
      if (again) {
        return new Response(JSON.stringify(again), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      throw insertError;
    }

    return new Response(JSON.stringify(inserted), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("daily-devotional error:", e);
    return new Response(
      JSON.stringify({
        error: e instanceof Error ? e.message : "Erro desconhecido",
      }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }
});
