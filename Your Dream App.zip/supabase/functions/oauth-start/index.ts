// Initiates an OAuth 2.0 authorization flow for a given provider/client_id.
// The user is redirected to the provider's consent screen.
// On success, the provider redirects back to /functions/v1/oauth-callback.
//
// Auth: requires the user's Supabase JWT (passed as ?token=<jwt> because the
// browser opens this URL directly in a popup, no fetch). We validate the JWT
// here and embed the user_id inside the signed `state`.

import { createClient } from "npm:@supabase/supabase-js@2";
import { signState } from "../_shared/integrationCrypto.ts";
import {
  getProviderConfig,
  isValidProvider,
} from "../_shared/integrationProviders.ts";

const html = (msg: string, status = 400) =>
  new Response(
    `<!doctype html><meta charset="utf-8"><title>Erro</title><body style="font-family:system-ui;background:#0f172a;color:#e2e8f0;padding:32px"><h2>Falha ao iniciar conexão</h2><p>${msg}</p><p style="opacity:.6;font-size:12px">Você pode fechar esta janela.</p></body>`,
    { status, headers: { "Content-Type": "text/html; charset=utf-8" } },
  );

Deno.serve(async (req) => {
  try {
    const url = new URL(req.url);
    const provider = url.searchParams.get("provider") ?? "";
    const clientId = url.searchParams.get("client_id") ?? "";
    const token = url.searchParams.get("token") ?? "";
    if (!isValidProvider(provider)) return html("Provider inválido");
    if (!clientId) return html("client_id ausente");
    if (!token) return html("token de sessão ausente");

    // Validate the user's JWT
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
    );
    const { data: claims, error } = await supabase.auth.getClaims(token);
    if (error || !claims?.claims?.sub) return html("Sessão inválida ou expirada", 401);
    const userId = claims.claims.sub as string;

    // Confirm the user can manage this client (admin or assigned)
    const admin = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );
    const { data: client, error: cErr } = await admin
      .from("clients")
      .select("id, assigned_users")
      .eq("id", clientId)
      .maybeSingle();
    if (cErr || !client) return html("Cliente não encontrado", 404);

    const { data: roleRow } = await admin
      .from("user_roles")
      .select("role")
      .eq("user_id", userId)
      .eq("role", "admin")
      .maybeSingle();
    const isAdmin = !!roleRow;
    const assigned = (client.assigned_users ?? []).includes(userId);
    if (!isAdmin && !assigned) return html("Sem permissão para este cliente", 403);

    // Build authorize URL
    const cfg = getProviderConfig(provider);
    const state = await signState({ client_id: clientId, provider, user_id: userId });

    const params = new URLSearchParams({
      client_id: cfg.clientId,
      redirect_uri: cfg.redirectUri,
      response_type: "code",
      scope: cfg.scopes,
      state,
      ...(cfg.extraAuthParams ?? {}),
    });

    return Response.redirect(`${cfg.authorizeUrl}?${params.toString()}`, 302);
  } catch (e) {
    return html(e instanceof Error ? e.message : "Erro desconhecido", 500);
  }
});
