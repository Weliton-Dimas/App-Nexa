import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors';
import { createClient } from 'npm:@supabase/supabase-js@2';

const CLIENT_ID = Deno.env.get('GOOGLE_CALENDAR_CLIENT_ID')!;
const CLIENT_SECRET = Deno.env.get('GOOGLE_CALENDAR_CLIENT_SECRET')!;
const REDIRECT_URI = `${Deno.env.get('SUPABASE_URL')}/functions/v1/google-calendar-callback`;

function html(body: string, origin: string, payload: object) {
  return `<!doctype html><html><body style="font-family:system-ui;background:#0a0a0a;color:#fff;display:flex;align-items:center;justify-content:center;height:100vh;margin:0">
<div style="text-align:center"><h2>${body}</h2><p>Você pode fechar esta janela.</p></div>
<script>
try { window.opener && window.opener.postMessage(${JSON.stringify({ source: 'lovable-oauth', scope: 'google-calendar', ...payload })}, ${JSON.stringify(origin || '*')}); } catch(e){}
setTimeout(()=>window.close(), 1500);
</script></body></html>`;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });

  const url = new URL(req.url);
  const code = url.searchParams.get('code');
  const stateRaw = url.searchParams.get('state');
  const errorParam = url.searchParams.get('error');

  let origin = '';
  let userId = '';
  try {
    if (stateRaw) {
      const s = JSON.parse(atob(stateRaw));
      origin = s.origin || '';
      userId = s.user_id || '';
    }
  } catch { /* ignore */ }

  if (errorParam || !code || !userId) {
    return new Response(html(`Erro: ${errorParam || 'parâmetros inválidos'}`, origin, { ok: false, message: errorParam || 'Falha' }), {
      headers: { 'Content-Type': 'text/html; charset=utf-8' },
    });
  }

  try {
    // Exchange code -> tokens
    const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        code,
        client_id: CLIENT_ID,
        client_secret: CLIENT_SECRET,
        redirect_uri: REDIRECT_URI,
        grant_type: 'authorization_code',
      }),
    });
    const tokens = await tokenRes.json();
    if (!tokenRes.ok) throw new Error(tokens.error_description || tokens.error || 'token exchange failed');

    // Get user email
    const profileRes = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
      headers: { Authorization: `Bearer ${tokens.access_token}` },
    });
    const profile = await profileRes.json();

    const expiresAt = new Date(Date.now() + (tokens.expires_in ?? 3600) * 1000).toISOString();

    const admin = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
    );

    const { error: upErr } = await admin.from('user_google_calendar_tokens').upsert({
      user_id: userId,
      google_email: profile.email ?? null,
      access_token: tokens.access_token,
      refresh_token: tokens.refresh_token,
      expires_at: expiresAt,
      scope: tokens.scope ?? null,
      calendar_id: 'primary',
    }, { onConflict: 'user_id' });

    if (upErr) throw upErr;

    return new Response(html('Conectado com sucesso!', origin, { ok: true, email: profile.email }), {
      headers: { 'Content-Type': 'text/html; charset=utf-8' },
    });
  } catch (e) {
    const msg = e instanceof Error ? e.message : 'unknown';
    return new Response(html(`Falha: ${msg}`, origin, { ok: false, message: msg }), {
      headers: { 'Content-Type': 'text/html; charset=utf-8' },
    });
  }
});
