const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

function extractNameFromHtml(html: string): string | null {
  const og = html.match(/<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']+)["'][^>]*>/i);
  if (og?.[1]) return og[1].trim();
  const h1 = html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i);
  if (h1?.[1]) return h1[1].replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
  return null;
}

function extractDeepInternalId(html: string): string | null {
  const dataId = html.match(/data-produto-id=["']?(\d+)["']?/i);
  if (dataId?.[1]) return dataId[1];
  const productId = html.match(/['"]product_id['"]\s*:\s*['"]?(\d+)['"]?/i);
  if (productId?.[1]) return productId[1];
  const itemId = html.match(/['"]item_id['"]\s*:\s*['"]?(\d+)['"]?/i);
  if (itemId?.[1]) return itemId[1];
  return null;
}

function extractExactVisibleSku(html: string): string | null {
  const dataRef = html.match(/data-(?:produto-)?referencia=["']([A-Za-z0-9_-]+)["']/i);
  if (dataRef?.[1]) return dataRef[1].trim();
  const ecomm = html.match(/['"]?ecomm_prodid['"]?\s*:\s*['"]?([A-Za-z0-9_-]+)['"]?/i);
  if (ecomm?.[1] && ecomm[1].includes("-")) return ecomm[1].trim();
  const visualSku = html.match(/>\s*SKU\s*:\s*([A-Za-z0-9_-]+)\s*</i);
  if (visualSku?.[1]) return visualSku[1].trim();
  return null;
}

function extractSkuFromJsonLd(html: string): string | null {
  const regex = /<script[^>]*type="application\/ld\+json"[^>]*>([\s\S]*?)<\/script>/gi;
  const matches = Array.from(html.matchAll(regex));
  let fallbackSku: string | null = null;
  for (const m of matches) {
    const raw = (m?.[1] || "").trim();
    if (!raw) continue;
    try {
      const parsed = JSON.parse(raw);
      const stack: any[] = Array.isArray(parsed) ? parsed : [parsed];
      while (stack.length) {
        const node = stack.shift();
        if (!node) continue;
        if (typeof node?.sku === "string" && node.sku.trim()) {
          if (node.sku.includes("-")) return node.sku.trim();
          if (!fallbackSku) fallbackSku = node.sku.trim();
        }
        if (node?.offers && Array.isArray(node.offers)) stack.push(...node.offers);
        if (node?.offers && typeof node.offers === "object") stack.push(node.offers);
        if (Array.isArray(node?.["@graph"])) stack.push(...node["@graph"]);
      }
    } catch {}
  }
  return fallbackSku;
}

function extractSkuFallback(html: string): string | null {
  const m = html.match(/SKU[-\s]*([A-Za-z0-9_-]+)/i);
  return m?.[1]?.trim() || null;
}

import { createClient } from "https://esm.sh/@supabase/supabase-js@2.97.0";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    // Auth guard
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Não autorizado" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const sb = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!, { global: { headers: { Authorization: authHeader } } });
    const { data: userData, error: authErr } = await sb.auth.getUser();
    if (authErr || !userData?.user) {
      return new Response(JSON.stringify({ error: "Token inválido" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const body = await req.json();
    const productUrl = String(body?.productUrl || "").trim();
    if (!productUrl) {
      return new Response(JSON.stringify({ error: "URL inválida." }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // SSRF guard: only public http(s) URLs, block internal/loopback/metadata hosts
    let parsedUrl: URL;
    try { parsedUrl = new URL(productUrl); } catch {
      return new Response(JSON.stringify({ error: "URL inválida." }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    if (!["http:", "https:"].includes(parsedUrl.protocol)) {
      return new Response(JSON.stringify({ error: "Protocolo não permitido." }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const host = parsedUrl.hostname.toLowerCase();
    const blocked = ["localhost", "127.0.0.1", "0.0.0.0", "169.254.169.254", "::1", "metadata.google.internal"];
    const isPrivate = blocked.includes(host)
      || /^10\./.test(host)
      || /^192\.168\./.test(host)
      || /^172\.(1[6-9]|2[0-9]|3[0-1])\./.test(host)
      || host.endsWith(".internal")
      || host.endsWith(".local");
    if (isPrivate) {
      return new Response(JSON.stringify({ error: "URL não permitida." }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 8000);

    try {
      const res = await fetch(productUrl, {
        signal: controller.signal,
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
          "Accept-Language": "pt-BR,pt;q=0.9",
        },
      });
      clearTimeout(timeoutId);
      if (!res.ok) {
        return new Response(JSON.stringify({ error: `Falha ao buscar página (${res.status}).` }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      const html = await res.text();
      const name = extractNameFromHtml(html) || "Produto sem nome";
      const deepId = extractDeepInternalId(html);
      const visibleSku = extractExactVisibleSku(html) || extractSkuFromJsonLd(html) || extractSkuFallback(html);

      if (!visibleSku && !deepId) {
        return new Response(JSON.stringify({ error: "SKU/ID não encontrado." }), { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }

      return new Response(
        JSON.stringify({ sku: visibleSku || deepId, deepId: deepId || visibleSku, name }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    } catch (fetchError: any) {
      clearTimeout(timeoutId);
      if (fetchError.name === "AbortError") {
        return new Response(JSON.stringify({ error: "O site demorou muito a responder." }), { status: 504, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      throw fetchError;
    }
  } catch (e) {
    return new Response(JSON.stringify({ error: "Erro interno do servidor." }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
