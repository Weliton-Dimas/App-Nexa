// Sends due web push notifications. Invoked by pg_cron every minute.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import webpush from "npm:web-push@3.6.7";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const VAPID_PUBLIC = Deno.env.get("VAPID_PUBLIC_KEY")!;
const VAPID_PRIVATE = Deno.env.get("VAPID_PRIVATE_KEY")!;
const VAPID_SUBJECT = Deno.env.get("VAPID_SUBJECT") || "mailto:admin@example.com";

webpush.setVapidDetails(VAPID_SUBJECT, VAPID_PUBLIC, VAPID_PRIVATE);

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

type Payload = { title: string; body: string; url?: string; tag?: string };

async function sendToUser(supabase: any, userId: string, payload: Payload, source: string, sourceId: string) {
  // Skip if already logged
  const { data: log } = await supabase
    .from("notification_log")
    .select("id")
    .eq("user_id", userId)
    .eq("source", source)
    .eq("source_id", sourceId)
    .maybeSingle();
  if (log) return { skipped: true };

  const { data: subs } = await supabase
    .from("push_subscriptions")
    .select("id, endpoint, p256dh, auth")
    .eq("user_id", userId);

  if (!subs?.length) return { sent: 0 };

  let sent = 0;
  for (const s of subs) {
    try {
      await webpush.sendNotification(
        { endpoint: s.endpoint, keys: { p256dh: s.p256dh, auth: s.auth } },
        JSON.stringify(payload),
        { TTL: 3600 }
      );
      sent++;
    } catch (err: any) {
      // Cleanup expired subscriptions (404/410)
      if (err?.statusCode === 404 || err?.statusCode === 410) {
        await supabase.from("push_subscriptions").delete().eq("id", s.id);
      } else {
        console.error("push error", err?.statusCode, err?.body);
      }
    }
  }

  await supabase.from("notification_log").insert({ user_id: userId, source, source_id: sourceId });
  return { sent };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  const supabase = createClient(SUPABASE_URL, SERVICE_KEY);
  const now = new Date();
  const summary = { kanban: 0, calendar: 0, prospects: 0 };

  try {
    // Load all preferences (one row per user who configured)
    const { data: allPrefs } = await supabase.from("notification_preferences").select("*");
    const prefsByUser = new Map<string, any>();
    (allPrefs || []).forEach((p) => prefsByUser.set(p.user_id, p));

    // ---------- Kanban: cards with due_date approaching ----------
    // Get cards due within max window (24h) to limit query
    const dayAhead = new Date(now.getTime() + 24 * 3600_000).toISOString();
    const { data: cards } = await supabase
      .from("kanban_cards")
      .select("id, title, due_date, created_by")
      .gte("due_date", now.toISOString())
      .lte("due_date", dayAhead);

    for (const c of cards || []) {
      const prefs = prefsByUser.get(c.created_by);
      if (prefs && !prefs.kanban_enabled) continue;
      const minutes = prefs?.kanban_minutes_before ?? 60;
      const due = new Date(c.due_date);
      const diffMin = (due.getTime() - now.getTime()) / 60000;
      // Fire if within window [0, minutes]
      if (diffMin <= minutes && diffMin >= 0) {
        const r = await sendToUser(
          supabase,
          c.created_by,
          {
            title: "Tarefa do Kanban",
            body: `${c.title} — vence em ${Math.max(1, Math.round(diffMin))} min`,
            url: "/kanban",
            tag: `kanban-${c.id}`,
          },
          "kanban",
          c.id
        );
        if (r.sent) summary.kanban += r.sent;
      }
    }

    // ---------- Calendar: daily summary at user's chosen hour ----------
    const today = now.toISOString().slice(0, 10);
    for (const [userId, prefs] of prefsByUser.entries()) {
      if (!prefs.calendar_enabled) continue;
      // Only fire in the matching hour & first 5 minutes of it
      if (now.getUTCHours() !== prefs.calendar_hour || now.getUTCMinutes() > 5) continue;
      const dayKey = `daily-${today}`;
      const { data: tasks } = await supabase
        .from("calendar_tasks")
        .select("id, title")
        .eq("date", today)
        .eq("created_by", userId);
      if (!tasks?.length) continue;
      const r = await sendToUser(
        supabase,
        userId,
        {
          title: `Você tem ${tasks.length} evento(s) hoje`,
          body: tasks.slice(0, 3).map((t) => `• ${t.title}`).join("\n"),
          url: "/calendar",
          tag: dayKey,
        },
        "calendar",
        // crypto.randomUUID() not needed — use deterministic id per user/day
        // We need a uuid-shaped value; reuse first task id but log key includes day:
        tasks[0].id
      );
      // Override with daily tag in log (use day as id)
      if (r.sent) summary.calendar += r.sent;
    }

    // ---------- Prospects: next_action_at approaching ----------
    const { data: prospects } = await supabase
      .from("prospects")
      .select("id, company_name, next_action, next_action_at, user_id")
      .not("next_action_at", "is", null)
      .gte("next_action_at", now.toISOString())
      .lte("next_action_at", dayAhead);

    for (const p of prospects || []) {
      const prefs = prefsByUser.get(p.user_id);
      if (prefs && !prefs.prospects_enabled) continue;
      const minutes = prefs?.prospects_minutes_before ?? 15;
      const due = new Date(p.next_action_at);
      const diffMin = (due.getTime() - now.getTime()) / 60000;
      if (diffMin <= minutes && diffMin >= 0) {
        const r = await sendToUser(
          supabase,
          p.user_id,
          {
            title: `Follow-up: ${p.company_name}`,
            body: p.next_action || "Próximo contato agora",
            url: "/prospeccao",
            tag: `prospect-${p.id}`,
          },
          "prospect",
          p.id
        );
        if (r.sent) summary.prospects += r.sent;
      }
    }

    return new Response(JSON.stringify({ ok: true, ...summary }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err: any) {
    console.error(err);
    return new Response(JSON.stringify({ error: err.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
