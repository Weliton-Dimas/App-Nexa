// Shared crypto helpers for client_integrations.
// Tokens are encrypted at rest using AES-GCM with INTEGRATION_TOKEN_KEY.
// State for OAuth round-trip is signed with HMAC-SHA256 using OAUTH_STATE_SECRET.

const enc = new TextEncoder();
const dec = new TextDecoder();

function b64encode(bytes: Uint8Array): string {
  let s = "";
  for (const b of bytes) s += String.fromCharCode(b);
  return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function b64decode(s: string): Uint8Array {
  const pad = s.length % 4 === 0 ? "" : "=".repeat(4 - (s.length % 4));
  const norm = s.replace(/-/g, "+").replace(/_/g, "/") + pad;
  const bin = atob(norm);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

async function importAesKey(): Promise<CryptoKey> {
  const raw = Deno.env.get("INTEGRATION_TOKEN_KEY");
  if (!raw) throw new Error("INTEGRATION_TOKEN_KEY not configured");
  const keyBytes = b64decode(raw);
  if (keyBytes.length !== 32) throw new Error("INTEGRATION_TOKEN_KEY must be 32 bytes (base64)");
  return await crypto.subtle.importKey("raw", keyBytes, { name: "AES-GCM" }, false, ["encrypt", "decrypt"]);
}

export async function encryptToken(plain: string | null | undefined): Promise<string | null> {
  if (!plain) return null;
  const key = await importAesKey();
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const cipher = new Uint8Array(
    await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, enc.encode(plain)),
  );
  const out = new Uint8Array(iv.length + cipher.length);
  out.set(iv, 0);
  out.set(cipher, iv.length);
  return "v1:" + b64encode(out);
}

export async function decryptToken(stored: string | null | undefined): Promise<string | null> {
  if (!stored) return null;
  // Legacy plaintext (migrated rows): no "v1:" prefix.
  if (!stored.startsWith("v1:")) return stored;
  const key = await importAesKey();
  const bytes = b64decode(stored.slice(3));
  const iv = bytes.slice(0, 12);
  const cipher = bytes.slice(12);
  const plain = await crypto.subtle.decrypt({ name: "AES-GCM", iv }, key, cipher);
  return dec.decode(plain);
}

async function hmac(secret: string, data: string): Promise<string> {
  const key = await crypto.subtle.importKey(
    "raw",
    enc.encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const sig = new Uint8Array(await crypto.subtle.sign("HMAC", key, enc.encode(data)));
  return b64encode(sig);
}

interface StatePayload {
  client_id?: string;
  provider: string;
  user_id: string;
  return_to?: string;
  kind?: "client" | "workspace";
  exp: number; // epoch ms
}

export async function signState(payload: Omit<StatePayload, "exp">, ttlMs = 10 * 60 * 1000): Promise<string> {
  const secret = Deno.env.get("OAUTH_STATE_SECRET");
  if (!secret) throw new Error("OAUTH_STATE_SECRET not configured");
  const full: StatePayload = { ...payload, exp: Date.now() + ttlMs };
  const body = b64encode(enc.encode(JSON.stringify(full)));
  const sig = await hmac(secret, body);
  return `${body}.${sig}`;
}

export async function verifyState(token: string): Promise<StatePayload> {
  const secret = Deno.env.get("OAUTH_STATE_SECRET");
  if (!secret) throw new Error("OAUTH_STATE_SECRET not configured");
  const [body, sig] = token.split(".");
  if (!body || !sig) throw new Error("Invalid state");
  const expected = await hmac(secret, body);
  if (expected !== sig) throw new Error("State signature mismatch");
  const payload = JSON.parse(dec.decode(b64decode(body))) as StatePayload;
  if (payload.exp < Date.now()) throw new Error("State expired");
  return payload;
}
