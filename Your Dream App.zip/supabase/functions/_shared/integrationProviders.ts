// Provider config + redirect URLs.
// Used by oauth-start, oauth-callback and refresh-integration-token.

export type Provider = "google" | "meta" | "google_analytics";

const EDGE_REDIRECT_URI = `${Deno.env.get("SUPABASE_URL")}/functions/v1/oauth-callback`;
const APP_BASE_URL = (Deno.env.get("APP_BASE_URL") ?? "https://app.agencianexaperformance.com.br")
  .replace(/\/$/, "");

export interface ProviderConfig {
  authorizeUrl: string;
  tokenUrl: string;
  scopes: string;
  clientId: string;
  clientSecret: string;
  redirectUri: string;
  /** Extra query string params for the authorize step. */
  extraAuthParams?: Record<string, string>;
}

export function getProviderConfig(provider: Provider): ProviderConfig {
  if (provider === "google") {
    return {
      authorizeUrl: "https://accounts.google.com/o/oauth2/v2/auth",
      tokenUrl: "https://oauth2.googleapis.com/token",
      scopes: "https://www.googleapis.com/auth/adwords",
      clientId: required("GOOGLE_CLIENT_ID"),
      clientSecret: required("GOOGLE_CLIENT_SECRET"),
      redirectUri: EDGE_REDIRECT_URI,
      extraAuthParams: {
        access_type: "offline",
        prompt: "consent",
        include_granted_scopes: "true",
      },
    };
  }
  if (provider === "google_analytics") {
    return {
      authorizeUrl: "https://accounts.google.com/o/oauth2/v2/auth",
      tokenUrl: "https://oauth2.googleapis.com/token",
      scopes: "https://www.googleapis.com/auth/analytics.readonly",
      clientId: required("GOOGLE_CLIENT_ID"),
      clientSecret: required("GOOGLE_CLIENT_SECRET"),
      redirectUri: EDGE_REDIRECT_URI,
      extraAuthParams: {
        access_type: "offline",
        prompt: "consent",
        include_granted_scopes: "true",
      },
    };
  }
  if (provider === "meta") {
    return {
      authorizeUrl: "https://www.facebook.com/v19.0/dialog/oauth",
      tokenUrl: "https://graph.facebook.com/v19.0/oauth/access_token",
      scopes: "ads_read,ads_management,business_management",
      clientId: required("META_CLIENT_ID"),
      clientSecret: required("META_CLIENT_SECRET"),
      redirectUri: `${APP_BASE_URL}/oauth/meta/callback`,
    };
  }
  throw new Error(`Unknown provider: ${provider}`);
}

function required(name: string): string {
  const v = Deno.env.get(name);
  if (!v) throw new Error(`${name} not configured`);
  return v;
}

export function isValidProvider(p: string): p is Provider {
  return p === "google" || p === "meta" || p === "google_analytics";
}
