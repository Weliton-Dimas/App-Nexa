import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors';
import { createClient } from 'npm:@supabase/supabase-js@2';

const CLIENT_ID = Deno.env.get('GOOGLE_CALENDAR_CLIENT_ID')!;
const CLIENT_SECRET = Deno.env.get('GOOGLE_CALENDAR_CLIENT_SECRET')!;

const COLOR_TO_GOOGLE: Record<string, string> = {
  blue: '9', green: '10', amber: '5', red: '11',
};
const GOOGLE_TO_COLOR: Record<string, string> = {
  '9': 'blue', '1': 'blue', '7': 'blue',
  '10': 'green', '2': 'green',
  '5': 'amber', '6': 'amber',
  '11': 'red', '4': 'red',
};

interface Tokens {
  user_id: string;
  access_token: string;
  refresh_token: string;
  expires_at: string;
  calendar_id: string;
  google_email: string | null;
}

async function refreshIfNeeded(admin: ReturnType<typeof createClient>, tok: Tokens): Promise<string> {
  if (new Date(tok.expires_at).getTime() > Date.now() + 60_000) return tok.access_token;
  const res = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      client_id: CLIENT_ID,
      client_secret: CLIENT_SECRET,
      refresh_token: tok.refresh_token,
      grant_type: 'refresh_token',
    }),
  });
  const j = await res.json();
  if (!res.ok) throw new Error(j.error_description || j.error || 'refresh failed');
  const newExp = new Date(Date.now() + (j.expires_in ?? 3600) * 1000).toISOString();
  await admin.from('user_google_calendar_tokens').update({
    access_token: j.access_token,
    expires_at: newExp,
  }).eq('user_id', tok.user_id);
  return j.access_token;
}

function taskToEvent(t: { title: string; description: string | null; date: string; color: string }) {
  return {
    summary: t.title,
    description: t.description ?? '',
    start: { date: t.date },
    end: { date: t.date },
    colorId: COLOR_TO_GOOGLE[t.color] ?? '9',
  };
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  const headers = { ...corsHeaders, 'Content-Type': 'application/json' };

  try {
    const auth = req.headers.get('Authorization');
    if (!auth?.startsWith('Bearer ')) return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers });
    const userClient = createClient(
      Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_ANON_KEY')!,
      { global: { headers: { Authorization: auth } } },
    );
    const token = auth.replace('Bearer ', '');
    const { data: claims, error: ce } = await userClient.auth.getClaims(token);
    if (ce || !claims?.claims?.sub) return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers });
    const userId = claims.claims.sub as string;

    const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);

    const { data: tokData } = await admin.from('user_google_calendar_tokens').select('*').eq('user_id', userId).maybeSingle();
    if (!tokData) return new Response(JSON.stringify({ error: 'not_connected' }), { status: 400, headers });
    const tok = tokData as unknown as Tokens;
    const accessToken = await refreshIfNeeded(admin, tok);
    const calId = encodeURIComponent(tok.calendar_id || 'primary');
    const ghdr = { Authorization: `Bearer ${accessToken}`, 'Content-Type': 'application/json' };

    const body = req.method === 'POST' ? await req.json().catch(() => ({})) : {};
    const action = body.action || 'sync';

    // === Single-event actions for app->google ===
    if (action === 'push_task') {
      const { task } = body;
      const ev = taskToEvent(task);
      let res, j;
      if (task.google_event_id) {
        res = await fetch(`https://www.googleapis.com/calendar/v3/calendars/${calId}/events/${task.google_event_id}`, {
          method: 'PATCH', headers: ghdr, body: JSON.stringify(ev),
        });
      } else {
        res = await fetch(`https://www.googleapis.com/calendar/v3/calendars/${calId}/events`, {
          method: 'POST', headers: ghdr, body: JSON.stringify(ev),
        });
      }
      j = await res.json();
      if (!res.ok) throw new Error(j.error?.message || 'google api error');
      await admin.from('calendar_tasks').update({
        google_event_id: j.id, google_synced_at: new Date().toISOString(),
      }).eq('id', task.id);
      return new Response(JSON.stringify({ ok: true, google_event_id: j.id }), { headers });
    }

    if (action === 'delete_task') {
      const { google_event_id } = body;
      if (google_event_id) {
        await fetch(`https://www.googleapis.com/calendar/v3/calendars/${calId}/events/${google_event_id}`, {
          method: 'DELETE', headers: ghdr,
        });
      }
      return new Response(JSON.stringify({ ok: true }), { headers });
    }

    // === Full bidirectional sync ===
    // 1. Pull from Google (current month +/- 60 days)
    const now = new Date();
    const timeMin = new Date(now.getFullYear(), now.getMonth() - 1, 1).toISOString();
    const timeMax = new Date(now.getFullYear(), now.getMonth() + 3, 0).toISOString();
    const listRes = await fetch(
      `https://www.googleapis.com/calendar/v3/calendars/${calId}/events?timeMin=${timeMin}&timeMax=${timeMax}&singleEvents=true&maxResults=2500`,
      { headers: ghdr },
    );
    const listJson = await listRes.json();
    if (!listRes.ok) throw new Error(listJson.error?.message || 'list failed');

    let imported = 0, updated = 0;
    for (const ev of (listJson.items || [])) {
      if (ev.status === 'cancelled') continue;
      const dateStr = ev.start?.date || (ev.start?.dateTime ? ev.start.dateTime.slice(0, 10) : null);
      if (!dateStr) continue;
      const color = GOOGLE_TO_COLOR[ev.colorId] ?? 'blue';

      const { data: existing } = await admin.from('calendar_tasks').select('id').eq('google_event_id', ev.id).maybeSingle();
      if (existing) {
        await admin.from('calendar_tasks').update({
          title: ev.summary || '(sem título)',
          description: ev.description || null,
          date: dateStr,
          color,
          google_synced_at: new Date().toISOString(),
        }).eq('id', existing.id);
        updated++;
      } else {
        await admin.from('calendar_tasks').insert({
          title: ev.summary || '(sem título)',
          description: ev.description || null,
          date: dateStr,
          color,
          status: 'nova',
          priority: 'media',
          created_by: userId,
          google_event_id: ev.id,
          google_synced_at: new Date().toISOString(),
        });
        imported++;
      }
    }

    // 2. Push unsynced tasks created by this user to Google
    const { data: unsynced } = await admin.from('calendar_tasks')
      .select('id, title, description, date, color')
      .eq('created_by', userId).is('google_event_id', null);
    let pushed = 0;
    for (const t of (unsynced || [])) {
      const r = await fetch(`https://www.googleapis.com/calendar/v3/calendars/${calId}/events`, {
        method: 'POST', headers: ghdr, body: JSON.stringify(taskToEvent(t as { title: string; description: string | null; date: string; color: string })),
      });
      const j = await r.json();
      if (r.ok) {
        await admin.from('calendar_tasks').update({
          google_event_id: j.id, google_synced_at: new Date().toISOString(),
        }).eq('id', (t as { id: string }).id);
        pushed++;
      }
    }

    await admin.from('user_google_calendar_tokens').update({
      last_synced_at: new Date().toISOString(),
    }).eq('user_id', userId);

    return new Response(JSON.stringify({ ok: true, imported, updated, pushed }), { headers });
  } catch (e) {
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : 'unknown' }), { status: 500, headers });
  }
});
