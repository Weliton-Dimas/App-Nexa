// Returns aggregated GA4 metrics (sessions, conversions, revenue) for a client.
// Uses workspace google_analytics OAuth token + client_integrations property_id.

import { createClient } from "npm:@supabase/supabase-js@2";
import { decryptToken, encryptToken } from "../_shared/integrationCrypto.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

type Preset = "today" | "yesterday" | "last_7d" | "last_14d" | "last_30d" | "last_90d";

function presetToRange(preset: string): { startDate: string; endDate: string } {
  const map: Record<Preset, string> = {
    today: "today",
    yesterday: "yesterday",
    last_7d: "7daysAgo",
    last_14d: "14daysAgo",
    last_30d: "30daysAgo",
    last_90d: "90daysAgo",
  };
  const start = map[(preset as Preset)] ?? "7daysAgo";
  const end = preset === "yesterday" ? "yesterday" : "today";
  return { startDate: start, endDate: end };
}

async function refreshGoogleToken(refreshToken: string): Promise<{ access_token: string; expires_in: number }> {
  const params = new URLSearchParams({
    client_id: Deno.env.get("GOOGLE_CLIENT_ID")!,
    client_secret: Deno.env.get("GOOGLE_CLIENT_SECRET")!,
    grant_type: "refresh_token",
    refresh_token: refreshToken,
  });
  const r = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: params.toString(),
  });
  const data = await r.json();
  if (!r.ok) throw new Error(data?.error_description || data?.error || "Falha ao renovar token GA");
  return { access_token: data.access_token, expires_in: data.expires_in ?? 3600 };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Não autorizado" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const caller = createClient(supabaseUrl, anonKey, { global: { headers: { Authorization: authHeader } } });
    const { data: userData } = await caller.auth.getUser();
    if (!userData?.user) {
      return new Response(JSON.stringify({ error: "Token inválido" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const userId = userData.user.id;

    const url = new URL(req.url);
    const clientId = url.searchParams.get("client_id");
    const datePreset = url.searchParams.get("date_preset") || "last_7d";
    if (!clientId) {
      return new Response(JSON.stringify({ error: "client_id é obrigatório" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const admin = createClient(supabaseUrl, serviceKey);

    const { data: client } = await admin.from("clients").select("id, assigned_users").eq("id", clientId).single();
    if (!client) {
      return new Response(JSON.stringify({ error: "Cliente não encontrado" }), { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const { data: isAdminData } = await admin.rpc("has_role", { _user_id: userId, _role: "admin" });
    const isAdmin = isAdminData === true;
    const assigned = (client.assigned_users || []) as string[];
    if (!isAdmin && !assigned.includes(userId)) {
      return new Response(JSON.stringify({ error: "Acesso negado a este cliente" }), { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const { data: ci } = await admin
      .from("client_integrations")
      .select("account_id")
      .eq("client_id", clientId)
      .eq("provider", "google_analytics")
      .maybeSingle();
    const propertyId = ci?.account_id;
    if (!propertyId) {
      return new Response(JSON.stringify({ error: "Propriedade GA4 não vinculada para este cliente." }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const { data: ws } = await admin
      .from("workspace_integrations")
      .select("access_token, refresh_token, expires_at, status")
      .eq("provider", "google_analytics")
      .maybeSingle();
    if (!ws || ws.status !== "connected") {
      return new Response(JSON.stringify({ error: "Conta Google Analytics do workspace não está conectada." }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    let accessToken = await decryptToken(ws.access_token);
    const expMs = ws.expires_at ? new Date(ws.expires_at).getTime() : 0;
    if (!accessToken || !expMs || expMs - Date.now() < 5 * 60 * 1000) {
      const refresh = await decryptToken(ws.refresh_token);
      if (!refresh) throw new Error("Refresh token GA ausente — reconecte em Integrações.");
      const t = await refreshGoogleToken(refresh);
      accessToken = t.access_token;
      const newExp = new Date(Date.now() + t.expires_in * 1000).toISOString();
      await admin.from("workspace_integrations").update({
        access_token: await encryptToken(accessToken),
        expires_at: newExp,
      }).eq("provider", "google_analytics");
    }

    const { startDate, endDate } = presetToRange(datePreset);

    const reportRes = await fetch(
      `https://analyticsdata.googleapis.com/v1beta/properties/${propertyId}:runReport`,
      {
        method: "POST",
        headers: { Authorization: `Bearer ${accessToken}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          dateRanges: [{ startDate, endDate }],
          metrics: [
            { name: "sessions" },
            { name: "activeUsers" },
            { name: "conversions" },
            { name: "totalRevenue" },
            { name: "engagementRate" },
            { name: "averageSessionDuration" },
          ],
        }),
      },
    );
    const report = await reportRes.json();
    if (!reportRes.ok) {
      console.error("[ga-metrics] runReport error", report);
      return new Response(JSON.stringify({ error: report?.error?.message || "Falha ao consultar GA4" }), { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const row = report.rows?.[0]?.metricValues ?? [];
    const num = (i: number) => Number(row[i]?.value ?? 0);

    // Channel breakdown
    const chanRes = await fetch(
      `https://analyticsdata.googleapis.com/v1beta/properties/${propertyId}:runReport`,
      {
        method: "POST",
        headers: { Authorization: `Bearer ${accessToken}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          dateRanges: [{ startDate, endDate }],
          dimensions: [{ name: "sessionDefaultChannelGroup" }],
          metrics: [{ name: "sessions" }, { name: "conversions" }, { name: "totalRevenue" }],
          orderBys: [{ metric: { metricName: "sessions" }, desc: true }],
          limit: 8,
        }),
      },
    );
    const chan = await chanRes.json();
    const channels = (chan.rows ?? []).map((r: { dimensionValues: { value: string }[]; metricValues: { value: string }[] }) => ({
      channel: r.dimensionValues[0]?.value ?? "(other)",
      sessions: Number(r.metricValues[0]?.value ?? 0),
      conversions: Number(r.metricValues[1]?.value ?? 0),
      revenue: Number(r.metricValues[2]?.value ?? 0),
    }));

    return new Response(JSON.stringify({
      datePreset,
      sessions: num(0),
      activeUsers: num(1),
      conversions: num(2),
      revenue: num(3),
      engagementRate: num(4),
      avgSessionDuration: num(5),
      channels,
    }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (e) {
    console.error("[ga-metrics] error", e);
    return new Response(JSON.stringify({ error: (e as Error).message }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
