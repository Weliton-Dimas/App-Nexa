import { createClient } from "https://esm.sh/@supabase/supabase-js@2.97.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
  "Access-Control-Max-Age": "86400",
};

/**
 * Reconcilia clients.assigned_users para um usuário:
 * - adiciona o uid em todos os clientes em desiredClientIds
 * - remove o uid de qualquer outro cliente onde estiver presente
 */
async function syncClientAssignments(adminClient: any, userId: string, desiredClientIds: string[]) {
  const desired = new Set(desiredClientIds);
  const { data: allClients, error } = await adminClient
    .from("clients")
    .select("id, assigned_users");
  if (error) throw error;
  for (const c of allClients ?? []) {
    const current = new Set<string>((c.assigned_users ?? []) as string[]);
    const shouldHave = desired.has(c.id);
    const has = current.has(userId);
    if (shouldHave && !has) {
      current.add(userId);
      const { error: upErr } = await adminClient
        .from("clients")
        .update({ assigned_users: Array.from(current) })
        .eq("id", c.id);
      if (upErr) throw upErr;
    } else if (!shouldHave && has) {
      current.delete(userId);
      const { error: upErr } = await adminClient
        .from("clients")
        .update({ assigned_users: Array.from(current) })
        .eq("id", c.id);
      if (upErr) throw upErr;
    }
  }
}

Deno.serve(async (req) => {
  // Trata requisições de preflight (CORS)
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Não autorizado. Token ausente." }), {
        status: 401,
        headers: corsHeaders,
      });
    }

    // Cliente com as credenciais do usuário que fez a requisição
    const callerClient = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: authHeader } },
    });

    // Valida o token via getClaims (compatível com signing-keys system)
    const token = authHeader.replace(/^Bearer\s+/i, "");
    const { data: claimsData, error: claimsError } = await callerClient.auth.getClaims(token);
    if (claimsError || !claimsData?.claims?.sub) {
      console.error("Token validation failed:", claimsError);
      return new Response(JSON.stringify({ error: "Token inválido ou expirado." }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const userId = claimsData.claims.sub as string;

    // Cliente Admin para executar ações privilegiadas
    const adminClient = createClient(supabaseUrl, serviceRoleKey);

    // Checa se o usuário fazendo a requisição realmente é um admin
    const { data: roleData } = await adminClient
      .from("user_roles")
      .select("role")
      .eq("user_id", userId)
      .eq("role", "admin")
      .single();

    if (!roleData) {
      return new Response(JSON.stringify({ error: "Acesso negado. Requer privilégios de administrador." }), {
        status: 403,
        headers: corsHeaders,
      });
    }

    const url = new URL(req.url);
    const action = url.searchParams.get("action");

    // Tenta fazer o parse do body com segurança (apenas se não for GET)
    let body: any = {};
    if (req.method !== "GET") {
      try {
        body = await req.json();
      } catch (e) {
        return new Response(JSON.stringify({ error: "Formato de dados inválido (JSON malformado ou ausente)." }), {
          status: 400,
          headers: corsHeaders,
        });
      }
    }

    // ==========================================
    // LISTAR USUÁRIOS (GET)
    // ==========================================
    if (req.method === "GET" && action === "list") {
      const {
        data: { users },
        error,
      } = await adminClient.auth.admin.listUsers();
      if (error) throw error;

      // OTIMIZAÇÃO: Extrai os IDs para buscar APENAS os dados relacionados a estes usuários
      const userIds = users.map((u) => u.id);

      const [profilesRes, rolesRes, permissionsRes] = await Promise.all([
        adminClient.from("profiles").select("*").in("user_id", userIds),
        adminClient.from("user_roles").select("*").in("user_id", userIds),
        adminClient.from("user_page_permissions").select("*").in("user_id", userIds),
      ]);

      if (profilesRes.error) throw profilesRes.error;
      if (rolesRes.error) throw rolesRes.error;
      if (permissionsRes.error) throw permissionsRes.error;

      const enrichedUsers = users.map((u: any) => {
        const profile = profilesRes.data?.find((p: any) => p.user_id === u.id);
        const userRoles = rolesRes.data?.filter((r: any) => r.user_id === u.id).map((r: any) => r.role) || [];
        const userPages =
          permissionsRes.data?.filter((p: any) => p.user_id === u.id).map((p: any) => p.page_slug) || [];

        return {
          id: u.id,
          email: u.email,
          displayName: profile?.display_name || u.email,
          avatarUrl: profile?.avatar_url || null,
          roles: userRoles,
          pages: userPages,
          createdAt: u.created_at,
        };
      });

      return new Response(JSON.stringify(enrichedUsers), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // ==========================================
    // CRIAR USUÁRIO (POST)
    // ==========================================
    if (req.method === "POST" && action === "create") {
      const { email, password, displayName, role, pages, clientIds } = body;

      if (!email || !password) {
        return new Response(JSON.stringify({ error: "Email e senha são obrigatórios." }), {
          status: 400,
          headers: corsHeaders,
        });
      }

      const { data: newUser, error } = await adminClient.auth.admin.createUser({
        email,
        password,
        email_confirm: true,
        user_metadata: { display_name: displayName || email },
      });

      if (error) throw error;

      const insertPromises = [];

      if (role) {
        insertPromises.push(adminClient.from("user_roles").insert({ user_id: newUser.user.id, role }));
      }

      if (pages && Array.isArray(pages) && pages.length > 0) {
        const rows = pages.map((slug: string) => ({ user_id: newUser.user.id, page_slug: slug }));
        insertPromises.push(adminClient.from("user_page_permissions").insert(rows));
      }

      const insertResults = await Promise.all(insertPromises);
      const insertError = insertResults.find((result) => result.error)?.error;
      if (insertError) throw insertError;

      if (Array.isArray(clientIds)) {
        await syncClientAssignments(adminClient, newUser.user.id, clientIds);
      }

      return new Response(JSON.stringify({ id: newUser.user.id, success: true }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // ==========================================
    // ATUALIZAR USUÁRIO (PUT)
    // ==========================================
    if (req.method === "PUT" && action === "update") {
      const { targetUserId, email, password, displayName, avatarUrl, pages, role, clientIds } = body;

      if (!targetUserId) {
        return new Response(JSON.stringify({ error: "O ID do usuário alvo (targetUserId) é obrigatório." }), {
          status: 400,
          headers: corsHeaders,
        });
      }

      const updateData: any = {};
      if (email) updateData.email = email;
      if (password) updateData.password = password;

      if (Object.keys(updateData).length > 0) {
        const { error } = await adminClient.auth.admin.updateUserById(targetUserId, updateData);
        if (error) throw error;
      }

      const profileUpdate: any = {};
      if (displayName !== undefined) profileUpdate.display_name = displayName;
      if (avatarUrl !== undefined) profileUpdate.avatar_url = avatarUrl;

      if (Object.keys(profileUpdate).length > 0) {
        const { error } = await adminClient.from("profiles").update(profileUpdate).eq("user_id", targetUserId);
        if (error) throw error;
      }

      if (pages !== undefined && Array.isArray(pages)) {
        const { error: deletePermissionsError } = await adminClient
          .from("user_page_permissions")
          .delete()
          .eq("user_id", targetUserId);
        if (deletePermissionsError) throw deletePermissionsError;

        if (pages.length > 0) {
          const rows = pages.map((slug: string) => ({ user_id: targetUserId, page_slug: slug }));
          const { error: insertPermissionsError } = await adminClient.from("user_page_permissions").insert(rows);
          if (insertPermissionsError) throw insertPermissionsError;
        }
      }

      // Atualizar role (admin/user)
      if (role === "admin" || role === "user") {
        if (role === "user" && targetUserId === userId) {
          return new Response(
            JSON.stringify({ error: "Você não pode remover sua própria permissão de admin." }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
          );
        }
        if (role === "admin") {
          const { error: roleErr } = await adminClient
            .from("user_roles")
            .upsert({ user_id: targetUserId, role: "admin" }, { onConflict: "user_id,role" });
          if (roleErr) throw roleErr;
        } else {
          const { error: roleErr } = await adminClient
            .from("user_roles")
            .delete()
            .eq("user_id", targetUserId)
            .eq("role", "admin");
          if (roleErr) throw roleErr;
        }
      }

      if (Array.isArray(clientIds)) {
        await syncClientAssignments(adminClient, targetUserId, clientIds);
      }

      return new Response(JSON.stringify({ success: true }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // ==========================================
    // DELETAR USUÁRIO (DELETE)
    // ==========================================
    if (req.method === "DELETE" && action === "delete") {
      const { targetUserId } = body;

      if (!targetUserId) {
        return new Response(JSON.stringify({ error: "O ID do usuário alvo (targetUserId) é obrigatório." }), {
          status: 400,
          headers: corsHeaders,
        });
      }

      // Opcional: Se as suas tabelas no banco não tiverem "ON DELETE CASCADE",
      // é bom apagar regras e perfis antes de deletar a auth.
      await adminClient.from("user_page_permissions").delete().eq("user_id", targetUserId);
      await adminClient.from("user_roles").delete().eq("user_id", targetUserId);
      await syncClientAssignments(adminClient, targetUserId, []);

      const { error } = await adminClient.auth.admin.deleteUser(targetUserId);
      if (error) throw error;

      return new Response(JSON.stringify({ success: true }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ error: "Ação inválida ou método não suportado." }), {
      status: 400,
      headers: corsHeaders,
    });
  } catch (error: any) {
    console.error("Erro na Edge Function:", error);
    return new Response(JSON.stringify({ error: error.message || "Erro interno do servidor." }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
