// Admin only. Após escolher a BM (quando há mais de uma) ou para refrescar a lista
// de contas, refaz a chamada Graph e atualiza available_accounts.
import { createClient } from "npm:@supabase/supabase-js@2";
import { decryptToken } from "../_shared/integrationCrypto.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

async function fetchAccountsForBusiness(token: string, businessId: string) {
  const fields = "account_id,name";
  const [ownedRes, clientRes] = await Promise.all([
    fetch(`https://graph.facebook.com/v19.0/${businessId}/owned_ad_accounts?fields=${fields}&limit=200&access_token=${encodeURIComponent(token)}`),
    fetch(`https://graph.facebook.com/v19.0/${businessId}/client_ad_accounts?fields=${fields}&limit=200&access_token=${encodeURIComponent(token)}`),
  ]);
  const [ownedData, clientData] = await Promise.all([ownedRes.json(), clientRes.json()]);
  const merged: Array<{ account_id: string; name: string }> = [];
  const seen = new Set<string>();
  for (const a of [...(ownedData?.data ?? []), ...(clientData?.data ?? [])]) {
    if (!a.account_id || seen.has(a.account_id)) continue;
    seen.add(a.account_id);
    merged.push({ account_id: a.account_id, name: a.name });
  }
  return merged;
}

async function listGoogleAds(accessToken: string): Promise<Array<{ account_id: string; name: string }>> {
  const devToken = Deno.env.get("GOOGLE_DEVELOPER_TOKEN") ?? "";
  const r = await fetch("https://googleads.googleapis.com/v17/customers:listAccessibleCustomers", {
    headers: { Authorization: `Bearer ${accessToken}`, "developer-token": devToken },
  });
  const data = await r.json();
  if (!r.ok) { console.error("[set-business] google ads failed", data); return []; }
  const ids = ((data.resourceNames ?? []) as string[]).map((s) => s.replace("customers/", ""));
  return ids.map((id) => ({ account_id: id, name: `Customer ${id}` }));
}

async function listGAProperties(accessToken: string): Promise<Array<{ account_id: string; name: string }>> {
  const r = await fetch("https://analyticsadmin.googleapis.com/v1beta/accountSummaries?pageSize=200", {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  const data = await r.json();
  if (!r.ok) { console.error("[set-business] GA failed", data); return []; }
  const out: Array<{ account_id: string; name: string }> = [];
  for (const acc of (data.accountSummaries ?? [])) {
    const accountName = acc.displayName ?? "Conta";
    for (const p of (acc.propertySummaries ?? [])) {
      const propId = (p.property as string ?? "").replace("properties/", "");
      if (!propId) continue;
      out.push({ account_id: propId, name: `${accountName} — ${p.displayName ?? propId}` });
    }
  }
  return out;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
    const auth = req.headers.get("Authorization");
    if (!auth?.startsWith("Bearer ")) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });

    const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!);
    const { data: claims, error } = await supabase.auth.getClaims(auth.slice(7));
    if (error || !claims?.claims?.sub) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    const userId = claims.claims.sub as string;

    const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    const { data: roleRow } = await admin.from("user_roles").select("role").eq("user_id", userId).eq("role", "admin").maybeSingle();
    if (!roleRow) return new Response(JSON.stringify({ error: "Apenas admins" }), { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });

    const body = await req.json().catch(() => ({}));
    const provider = body.provider ?? "meta";
    const businessId = body.business_id as string | undefined;

    const { data: ws } = await admin.from("workspace_integrations").select("*").eq("provider", provider).maybeSingle();
    if (!ws) return new Response(JSON.stringify({ error: "Integração não encontrada" }), { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } });

    const token = await decryptToken(ws.access_token);
    if (!token) return new Response(JSON.stringify({ error: "Token ausente — reconecte" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });

    // ===== GOOGLE ADS / GA4 — apenas refresca a lista de contas =====
    if (provider === "google" || provider === "google_analytics") {
      const accounts = provider === "google"
        ? await listGoogleAds(token)
        : await listGAProperties(token);
      const { error: upErr } = await admin.from("workspace_integrations").update({
        available_accounts: accounts,
        status: "connected",
        last_synced_at: new Date().toISOString(),
        last_error: null,
      }).eq("id", ws.id);
      if (upErr) throw upErr;
      return new Response(JSON.stringify({ ok: true, accounts }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // ===== META =====
    const targetBizId = businessId ?? ws.business_id;
    if (!targetBizId) return new Response(JSON.stringify({ error: "business_id é obrigatório" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });

    let bizName = ws.business_name;
    if (businessId) {
      const found = ((ws.available_businesses ?? []) as Array<{ id: string; name: string }>).find((b) => b.id === businessId);
      bizName = found?.name ?? bizName;
    }

    const accounts = await fetchAccountsForBusiness(token, targetBizId);

    const { error: upErr } = await admin.from("workspace_integrations").update({
      business_id: targetBizId,
      business_name: bizName,
      available_accounts: accounts,
      status: "connected",
      last_synced_at: new Date().toISOString(),
      last_error: null,
    }).eq("id", ws.id);
    if (upErr) throw upErr;

    return new Response(JSON.stringify({ ok: true, accounts }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (e) {
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Erro" }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
