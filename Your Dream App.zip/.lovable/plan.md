## Objetivo

Permitir que o usuário escolha independentemente se quer fixar o **cabeçalho** (linhas superiores ao rolar verticalmente) e/ou as **colunas de identificação** (#, Produto, SKU ao rolar horizontalmente).

## Comportamento

Substituir o botão único "Fixar" por um controle com 2 opções independentes (estilo toggle/checkbox dentro de um popover do ícone `Pin`):

- **Fixar cabeçalho** (vertical) — mantém `<thead>` sticky no topo.
- **Fixar colunas** (horizontal) — mantém ações, #, Produto e SKU sticky à esquerda.

Cada uma pode ser ligada/desligada de forma independente (ambas, só uma, ou nenhuma). Estado persistido no `localStorage` por cliente, como já é feito hoje.

## Implementação

Em `src/pages/PricingPage.tsx`:

1. Trocar o estado booleano `freeze` por dois estados: `freezeRows` (vertical/header) e `freezeCols` (horizontal/colunas).
2. Migrar a chave atual de localStorage para duas chaves: `pricing.freezeRows.${clientId}` e `pricing.freezeCols.${clientId}` (com fallback lendo o valor antigo `pricing.freeze.${clientId}` para aplicar a ambos na primeira vez).
3. Substituir o botão único por um `Popover` acionado pelo ícone `Pin`/`PinOff` (ativo quando qualquer um dos dois está ligado), contendo dois `Checkbox` rotulados "Fixar cabeçalho" e "Fixar colunas".
4. Ajustar os helpers existentes:
   - `<thead>` recebe `sticky top-0` somente quando `freezeRows` está ligado.
   - `stickyCol(id, kind)` / `frozenLeft(id)` aplicam `left` e `position: sticky` somente quando `freezeCols` está ligado (para `th`, `td` e `tfoot`).
   - Células de interseção (cabeçalho das colunas fixas) só ganham z-index mais alto quando ambos estão ativos.
5. Manter as cores de fundo (`bg-card`/`bg-secondary`) nas células fixas para evitar transparência.

## Fora do escopo

- Persistência no banco (`pricing_settings`) — continua só em `localStorage`.
- Escolher quais colunas específicas ficam fixas.
